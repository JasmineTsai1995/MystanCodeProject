"""
真實使用場景測試

基於用戶提供的三個範例進行實際測試
"""

import pytest
import os
import logging
from unittest.mock import AsyncMock, patch

# 配置 logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 設定測試環境變數
os.environ["DB_HOST"] = os.getenv("DB_HOST", "localhost")
os.environ["DB_PORT"] = os.getenv("DB_PORT", "5432")
os.environ["DB_USER"] = os.getenv("DB_USER", "postgres")
os.environ["DB_PASSWORD"] = os.getenv("DB_PASSWORD", "postgres")
os.environ["DB_NAME"] = os.getenv("DB_NAME", "fastapi_db")

from database import (
    DatabaseConfig,
    init_async_engine,
    init_async_pool,
    get_async_engine,
    get_async_pool,
    get_pool_connection,
    close_db_connections,
    close_pool_connections,
)


# ============================================================================
# 場景 1：複製用戶的 SQLAlchemy 範例配置
# ============================================================================

@pytest.mark.asyncio
class TestUserScenario1_SQLAlchemy:
    """測試用戶的 SQLAlchemy AsyncEngine 範例配置"""
    
    async def test_init_engine_with_user_config(self):
        """使用用戶範例的配置初始化 Engine"""
        
        # 用戶範例的配置
        config = DatabaseConfig(
            host=os.getenv("DAT_POSTGRE_IP", "localhost"),
            port=5432,
            user=os.getenv("POSTGRE_USER", "postgres"),
            password=os.getenv("POSTGRE_PWD", "postgres"),
            database="midaipcm",  # 用戶的資料庫名稱
            pool_size=2,          # 用戶範例的配置
            max_overflow=10,
            pool_pre_ping=True,
            pool_recycle=3600,
        )
        
        try:
            engine = await init_async_engine(config)
            
            # 驗證 Engine 配置
            assert engine is not None
            assert engine.pool.size() == 2
            assert not engine.pool._disposed
            
            # 測試連線
            async with engine.connect() as conn:
                result = await conn.execute("SELECT 1")
                assert result.fetchone()[0] == 1
            
            logger.info("✅ SQLAlchemy Engine 配置成功（與用戶範例一致）")
        
        finally:
            await close_db_connections()
    
    async def test_engine_singleton_pattern(self):
        """測試 Engine 的單例模式（與用戶範例一致）"""
        
        config = DatabaseConfig(
            pool_size=2,
            max_overflow=10,
            pool_pre_ping=True,
            pool_recycle=3600,
        )
        
        try:
            # 第一次初始化
            engine1 = await init_async_engine(config)
            
            # 第二次呼叫應該返回同一個實例
            engine2 = await init_async_engine(config)
            
            assert engine1 is engine2
            logger.info("✅ Engine 單例模式正常運作")
        
        finally:
            await close_db_connections()
    
    async def test_engine_url_format(self):
        """測試 URL 格式與用戶範例一致"""
        
        config = DatabaseConfig(
            host="192.168.1.100",
            port=5432,
            user="myuser",
            password="mypassword",
            database="midaipcm",
        )
        
        # 檢查 URL 格式
        url = config.get_sqlalchemy_url(async_driver=True)
        
        # 應該是：postgresql+asyncpg://myuser:mypassword@192.168.1.100:5432/midaipcm
        assert "postgresql+asyncpg://" in url
        assert "myuser:mypassword@192.168.1.100:5432/midaipcm" in url
        
        logger.info(f"✅ URL 格式正確: {url}")


# ============================================================================
# 場景 2：複製用戶的 psycopg 範例配置
# ============================================================================

@pytest.mark.asyncio
class TestUserScenario2_Psycopg:
    """測試用戶的 psycopg AsyncConnectionPool 範例配置"""
    
    async def test_init_pool_with_user_config(self):
        """使用用戶範例的配置初始化連線池"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            
            # 用戶範例的配置
            config = DatabaseConfig(
                host=os.getenv("DAT_POSTGRE_IP", "localhost"),
                port=5432,
                user=os.getenv("POSTGRE_USER", "postgres"),
                password=os.getenv("POSTGRE_PWD", "postgres"),
                database="midaipcm",
                min_size=2,          # 用戶範例的配置
                max_size=5,
                max_idle=30,
                max_lifetime=600,
                ssl_mode="disable",  # 用戶範例的配置
            )
            
            try:
                pool = await init_async_pool(config)
                
                # 驗證連線池配置
                assert pool is not None
                
                # 測試連線
                async with pool.connection() as conn:
                    cursor = await conn.execute("SELECT 1")
                    result = await cursor.fetchone()
                    assert result[0] == 1
                
                logger.info("✅ psycopg 連線池配置成功（與用戶範例一致）")
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed")
    
    async def test_pool_with_schema_configuration(self):
        """測試帶 schema 配置的連線池（用戶範例中的 configure=set_schema）"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            
            # 模擬用戶的 set_schema 函數
            async def set_schema(conn):
                """設定資料庫 schema"""
                await conn.execute("SET search_path TO public")
                logger.info("✅ Schema 設定完成")
            
            config = DatabaseConfig(
                min_size=2,
                max_size=5,
                max_idle=30,
                max_lifetime=600,
            )
            
            try:
                # 使用 configure callback
                pool = await init_async_pool(
                    config,
                    configure_callback=set_schema
                )
                
                # 測試 schema 是否生效
                async with pool.connection() as conn:
                    cursor = await conn.execute("SHOW search_path")
                    result = await cursor.fetchone()
                    assert "public" in result[0]
                
                logger.info("✅ configure callback 正常運作")
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed")
    
    async def test_pool_url_format(self):
        """測試 URL 格式與用戶範例一致"""
        
        config = DatabaseConfig(
            host="192.168.1.100",
            port=5432,
            user="myuser",
            password="mypassword",
            database="midaipcm",
            ssl_mode="disable",
        )
        
        # 檢查 URL 格式
        url = config.get_psycopg_url()
        
        # 應該是：postgresql://myuser:mypassword@192.168.1.100:5432/midaipcm?sslmode=disable
        assert "postgresql://" in url
        assert "myuser:mypassword@192.168.1.100:5432/midaipcm" in url
        assert "sslmode=disable" in url
        
        logger.info(f"✅ URL 格式正確: {url}")


# ============================================================================
# 場景 3：LangGraph Checkpointer
# ============================================================================

@pytest.mark.asyncio
class TestUserScenario3_LangGraph:
    """測試 LangGraph AsyncPostgresSaver 範例"""
    
    async def test_langgraph_checkpointer_initialization(self):
        """測試 LangGraph Checkpointer 初始化（用戶範例）"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
            
            config = DatabaseConfig(
                min_size=2,
                max_size=5,
                max_idle=30,
                max_lifetime=600,
            )
            
            try:
                # 初始化連線池
                pool = await init_async_pool(config)
                
                # 建立 checkpointer（與用戶範例一致）
                checkpointer = AsyncPostgresSaver(pool)
                
                assert checkpointer is not None
                logger.info("✅ LangGraph Checkpointer 建立成功")
            
            finally:
                await close_pool_connections()
        
        except ImportError as e:
            if "psycopg" in str(e):
                pytest.skip("psycopg not installed")
            elif "langgraph" in str(e):
                pytest.skip("langgraph not installed")
            else:
                raise
    
    async def test_checkpointer_with_schema_callback(self):
        """測試帶 schema 配置的 Checkpointer"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
            
            # 用戶可能需要的 schema 配置
            async def set_langgraph_schema(conn):
                """設定 LangGraph 專用 schema"""
                await conn.execute("SET search_path TO langgraph, public")
            
            config = DatabaseConfig(
                min_size=2,
                max_size=5,
                max_idle=30,
                max_lifetime=600,
            )
            
            try:
                # 初始化帶 configure 的連線池
                pool = await init_async_pool(
                    config,
                    configure_callback=set_langgraph_schema
                )
                
                # 建立 checkpointer
                checkpointer = AsyncPostgresSaver(pool)
                
                # 測試連線是否正常
                async with pool.connection() as conn:
                    cursor = await conn.execute("SHOW search_path")
                    result = await cursor.fetchone()
                    assert "langgraph" in result[0]
                
                logger.info("✅ LangGraph Checkpointer with schema 配置成功")
            
            finally:
                await close_pool_connections()
        
        except ImportError as e:
            if "psycopg" in str(e):
                pytest.skip("psycopg not installed")
            elif "langgraph" in str(e):
                pytest.skip("langgraph not installed")
            else:
                raise


# ============================================================================
# 場景 4：混合使用兩種連線方式
# ============================================================================

@pytest.mark.asyncio
class TestUserScenario4_Mixed:
    """測試同時使用 SQLAlchemy 和 psycopg"""
    
    async def test_use_both_connections_simultaneously(self):
        """測試同時使用兩種連線方式"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            
            # 用戶範例的配置
            config = DatabaseConfig(
                # SQLAlchemy 配置
                pool_size=2,
                max_overflow=10,
                pool_pre_ping=True,
                pool_recycle=3600,
                
                # psycopg 配置
                min_size=2,
                max_size=5,
                max_idle=30,
                max_lifetime=600,
            )
            
            try:
                # 初始化兩種連線
                engine = await init_async_engine(config)
                pool = await init_async_pool(config)
                
                # 同時測試兩種連線
                # SQLAlchemy 查詢
                async with engine.connect() as conn:
                    result1 = await conn.execute("SELECT 1 as sqlalchemy_test")
                    assert result1.fetchone()[0] == 1
                
                # psycopg 查詢
                async with pool.connection() as conn:
                    cursor = await conn.execute("SELECT 2 as psycopg_test")
                    result2 = await cursor.fetchone()
                    assert result2[0] == 2
                
                logger.info("✅ 兩種連線方式可以同時使用")
            
            finally:
                await close_db_connections()
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed")
    
    async def test_real_world_scenario(self):
        """模擬真實世界場景：ORM + LangGraph"""
        
        try:
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig(
                pool_size=2,
                max_overflow=10,
                min_size=2,
                max_size=5,
            )
            
            try:
                # 初始化
                engine = await init_async_engine(config)
                pool = await init_async_pool(config)
                
                # 場景 1: 使用 SQLAlchemy 進行業務邏輯查詢
                async with engine.connect() as conn:
                    # 假設查詢用戶資料
                    result = await conn.execute("SELECT 'user_data' as data")
                    user_data = result.fetchone()[0]
                    assert user_data == "user_data"
                    logger.info("✅ SQLAlchemy 用於業務邏輯查詢")
                
                # 場景 2: 使用 psycopg 進行 LangGraph 狀態管理
                async with pool.connection() as conn:
                    # 假設儲存 LangGraph 狀態
                    await conn.execute(
                        "SELECT 'langgraph_checkpoint' as checkpoint"
                    )
                    logger.info("✅ psycopg 用於 LangGraph checkpointer")
                
                logger.info("✅ 真實世界混合使用場景測試成功")
            
            finally:
                await close_db_connections()
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed")


# ============================================================================
# 執行測試
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
