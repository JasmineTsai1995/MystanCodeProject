"""
資料庫連線測試

測試不同的連線方式：
1. SQLAlchemy AsyncEngine
2. psycopg AsyncConnectionPool
"""

import pytest
import os
from unittest.mock import patch

# 設定測試環境變數
os.environ["DB_HOST"] = os.getenv("DB_HOST", "localhost")
os.environ["DB_PORT"] = os.getenv("DB_PORT", "5432")
os.environ["DB_USER"] = os.getenv("DB_USER", "postgres")
os.environ["DB_PASSWORD"] = os.getenv("DB_PASSWORD", "postgres")
os.environ["DB_NAME"] = os.getenv("DB_NAME", "fastapi_db")

from database import (
    # SQLAlchemy
    init_async_engine,
    get_async_engine,
    get_async_session,
    close_db_connections,
    
    # psycopg
    init_async_pool,
    get_async_pool,
    get_pool_connection,
    close_pool_connections,
    
    # 健康檢查
    check_db_health,
    
    # 配置
    DatabaseConfig,
)


# ============================================================================
# 測試配置
# ============================================================================

class TestDatabaseConfig:
    """測試資料庫配置"""
    
    def test_config_from_env(self):
        """測試從環境變數讀取配置"""
        config = DatabaseConfig()
        
        assert config.host == os.getenv("DB_HOST", "localhost")
        assert config.port == int(os.getenv("DB_PORT", "5432"))
        assert config.user == os.getenv("DB_USER", "postgres")
        assert config.database == os.getenv("DB_NAME", "fastapi_db")
    
    def test_sqlalchemy_url(self):
        """測試 SQLAlchemy URL 生成"""
        config = DatabaseConfig(
            host="localhost",
            port=5432,
            user="testuser",
            password="testpass",
            database="testdb",
        )
        
        # 測試異步 URL
        async_url = config.get_sqlalchemy_url(async_driver=True)
        assert async_url.startswith("postgresql+asyncpg://")
        assert "testuser:testpass@localhost:5432/testdb" in async_url
        
        # 測試同步 URL
        sync_url = config.get_sqlalchemy_url(async_driver=False)
        assert sync_url.startswith("postgresql+psycopg2://")
    
    def test_psycopg_url(self):
        """測試 psycopg URL 生成"""
        config = DatabaseConfig(
            host="localhost",
            port=5432,
            user="testuser",
            password="testpass",
            database="testdb",
            ssl_mode="require",
        )
        
        url = config.get_psycopg_url()
        assert url.startswith("postgresql://")
        assert "testuser:testpass@localhost:5432/testdb" in url
        assert "sslmode=require" in url


# ============================================================================
# 測試 SQLAlchemy 連線
# ============================================================================

@pytest.mark.asyncio
class TestSQLAlchemyConnection:
    """測試 SQLAlchemy 連線方式"""
    
    async def test_init_engine(self):
        """測試初始化 AsyncEngine"""
        config = DatabaseConfig()
        
        try:
            engine = await init_async_engine(config)
            
            assert engine is not None
            assert not engine.pool._disposed
            
            # 測試獲取已初始化的 engine
            engine2 = get_async_engine()
            assert engine is engine2
            
        finally:
            await close_db_connections()
    
    async def test_engine_connection(self):
        """測試 Engine 連線"""
        config = DatabaseConfig()
        
        try:
            await init_async_engine(config)
            engine = get_async_engine()
            
            # 測試簡單查詢
            async with engine.connect() as conn:
                result = await conn.execute("SELECT 1 as test_value")
                row = result.fetchone()
                assert row[0] == 1
        
        finally:
            await close_db_connections()
    
    async def test_session_factory(self):
        """測試 Session 工廠"""
        config = DatabaseConfig()
        
        try:
            await init_async_engine(config)
            
            # 測試獲取 session
            session = await get_async_session()
            assert session is not None
            
            # 測試執行查詢
            result = await session.execute("SELECT 1 as test_value")
            row = result.fetchone()
            assert row[0] == 1
            
            await session.close()
        
        finally:
            await close_db_connections()
    
    async def test_get_db_dependency(self):
        """測試 get_db 依賴注入"""
        config = DatabaseConfig()
        
        try:
            await init_async_engine(config)
            
            # 模擬 FastAPI 依賴注入
            async for session in get_db():
                result = await session.execute("SELECT 1 as test_value")
                row = result.fetchone()
                assert row[0] == 1
                
                # 只測試第一次迭代
                break
        
        finally:
            await close_db_connections()
    
    async def test_multiple_sessions(self):
        """測試多個 Session 同時使用"""
        config = DatabaseConfig()
        
        try:
            await init_async_engine(config)
            
            session1 = await get_async_session()
            session2 = await get_async_session()
            
            # 兩個 session 應該是不同的實例
            assert session1 is not session2
            
            # 兩個 session 都可以執行查詢
            result1 = await session1.execute("SELECT 1")
            result2 = await session2.execute("SELECT 2")
            
            assert result1.fetchone()[0] == 1
            assert result2.fetchone()[0] == 2
            
            await session1.close()
            await session2.close()
        
        finally:
            await close_db_connections()


# ============================================================================
# 測試 psycopg 連線
# ============================================================================

@pytest.mark.asyncio
class TestPsycopgConnection:
    """測試 psycopg AsyncConnectionPool 連線方式"""
    
    async def test_init_pool(self):
        """測試初始化 AsyncConnectionPool"""
        try:
            # 嘗試導入 psycopg
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig()
            
            try:
                pool = await init_async_pool(config)
                
                assert pool is not None
                
                # 測試獲取已初始化的 pool
                pool2 = get_async_pool()
                assert pool is pool2
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed, skipping test")
    
    async def test_pool_connection(self):
        """測試連線池連線"""
        try:
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig()
            
            try:
                await init_async_pool(config)
                
                # 測試簡單查詢
                async with get_pool_connection() as conn:
                    cursor = await conn.execute("SELECT 1 as test_value")
                    row = await cursor.fetchone()
                    assert row[0] == 1
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed, skipping test")
    
    async def test_pool_with_configure_callback(self):
        """測試帶配置回調的連線池"""
        try:
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig()
            
            # 定義配置回調
            async def set_statement_timeout(conn):
                await conn.execute("SET statement_timeout = '30s'")
            
            try:
                await init_async_pool(config, configure_callback=set_statement_timeout)
                
                # 測試配置是否生效
                async with get_pool_connection() as conn:
                    cursor = await conn.execute("SHOW statement_timeout")
                    result = await cursor.fetchone()
                    assert result[0] == "30s"
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed, skipping test")
    
    async def test_multiple_connections(self):
        """測試多個連線同時使用"""
        try:
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig(min_size=2, max_size=5)
            
            try:
                await init_async_pool(config)
                
                # 同時使用多個連線
                async with get_pool_connection() as conn1:
                    async with get_pool_connection() as conn2:
                        cursor1 = await conn1.execute("SELECT 1")
                        cursor2 = await conn2.execute("SELECT 2")
                        
                        row1 = await cursor1.fetchone()
                        row2 = await cursor2.fetchone()
                        
                        assert row1[0] == 1
                        assert row2[0] == 2
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            pytest.skip("psycopg not installed, skipping test")


# ============================================================================
# 測試健康檢查
# ============================================================================

@pytest.mark.asyncio
class TestHealthCheck:
    """測試資料庫健康檢查"""
    
    async def test_sqlalchemy_health(self):
        """測試 SQLAlchemy 健康檢查"""
        config = DatabaseConfig()
        
        try:
            await init_async_engine(config)
            
            health = await check_db_health("sqlalchemy")
            
            assert health["status"] == "healthy"
            assert health["connection_type"] == "sqlalchemy"
            assert health["database"] == config.database
            assert health["host"] == config.host
        
        finally:
            await close_db_connections()
    
    async def test_psycopg_health(self):
        """測試 psycopg 健康檢查"""
        try:
            from psycopg_pool import AsyncConnectionPool
            
            config = DatabaseConfig()
            
            try:
                await init_async_pool(config)
                
                health = await check_db_health("psycopg")
                
                assert health["status"] == "healthy"
                assert health["connection_type"] == "psycopg"
                assert health["database"] == config.database
                assert health["host"] == config.host
                assert "pool_size" in health
            
            finally:
                await close_pool_connections()
        
        except ImportError:
            health = await check_db_health("psycopg")
            assert health["status"] == "unavailable"
            assert "psycopg not installed" in health["error"]
    
    async def test_health_check_without_init(self):
        """測試未初始化時的健康檢查"""
        # 確保未初始化
        await close_db_connections()
        await close_pool_connections()
        
        health = await check_db_health("sqlalchemy")
        
        assert health["status"] == "unhealthy"
        assert "error" in health


# ============================================================================
# 效能測試
# ============================================================================

@pytest.mark.asyncio
class TestPerformance:
    """測試連線效能"""
    
    async def test_connection_pool_reuse(self):
        """測試連線池重複使用"""
        config = DatabaseConfig(pool_size=2)
        
        try:
            await init_async_engine(config)
            
            # 執行多次查詢，測試連線重複使用
            for i in range(10):
                async for session in get_db():
                    result = await session.execute(f"SELECT {i}")
                    row = result.fetchone()
                    assert row[0] == i
                    break
        
        finally:
            await close_db_connections()
    
    async def test_concurrent_queries(self):
        """測試並發查詢"""
        import asyncio
        
        config = DatabaseConfig(pool_size=5, max_overflow=10)
        
        try:
            await init_async_engine(config)
            
            async def query_task(value: int):
                async for session in get_db():
                    result = await session.execute(f"SELECT {value}")
                    row = result.fetchone()
                    return row[0]
            
            # 並發執行 20 個查詢
            tasks = [query_task(i) for i in range(20)]
            results = await asyncio.gather(*tasks)
            
            # 驗證結果
            assert results == list(range(20))
        
        finally:
            await close_db_connections()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
