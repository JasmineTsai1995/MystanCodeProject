"""
OCP Tool API 客戶端單元測試

使用 Mock 測試 OCP 客戶端的各種功能。
"""

import pytest
from unittest.mock import patch, MagicMock
from database import (
    OCPClient,
    OCPConfig,
    OCPError,
    OCPSelectResult,
    OCPDMLResult,
    execute_ocp_query,
    execute_ocp_select,
    execute_ocp_dml,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def mock_ocp_config():
    """建立測試用的 OCP 配置"""
    return OCPConfig(
        env="sit",
        api_url="http://test-ocp-api.example.com/execute_query_postgresql",
        default_database="test_db",
        timeout=30,
        verify_ssl=False,
        max_retries=2,
        retry_delay=0.1
    )


@pytest.fixture
def ocp_client(mock_ocp_config):
    """建立測試用的 OCP 客戶端"""
    return OCPClient(config=mock_ocp_config)


@pytest.fixture
def mock_select_response():
    """Mock SELECT 查詢回應"""
    return {
        "MWHEADER": {
            "RETURNCODE": "0000",
            "RETURNDESC": "交易成功"
        },
        "TRANRS": {
            "status": "Success",
            "session_type": None,
            "query_time": 0.035,
            "result": [
                # data
                [
                    ["TYDV,106,訴,1712,20190625,1", "左脛腓骨骨折之傷害"],
                    ["TYDV,106,重訴,57,20190628,1", "左側股骨開放性骨折合併骨骼缺損12公分、右側脛骨平台骨折、第二頸椎骨折、右前臂撕裂傷、右肩大結節骨折及右側恥骨骨折等傷害"]
                ],
                # columns
                ["jid", "harm"]
            ]
        }
    }


@pytest.fixture
def mock_dml_response():
    """Mock DML 操作回應"""
    return {
        "MWHEADER": {
            "RETURNCODE": "0000",
            "RETURNDESC": "交易成功"
        },
        "TRANRS": {
            "status": "Success",
            "session_type": None,
            "query_time": 0.127,
            "result": [1]  # affected_rows
        }
    }


@pytest.fixture
def mock_error_response():
    """Mock 錯誤回應"""
    return {
        "MWHEADER": {
            "RETURNCODE": "9999",
            "RETURNDESC": "查詢失敗"
        },
        "TRANRS": {
            "status": "Failed",
            "session_type": None,
            "query_time": 0.001,
            "result": []
        }
    }


# ============================================================================
# OCPConfig 測試
# ============================================================================

def test_ocp_config_defaults():
    """測試 OCPConfig 預設值"""
    config = OCPConfig()
    
    assert config.env == "sit"
    assert config.api_url is not None
    assert "ocpsit" in config.api_url  # 預設應該是 sit 環境
    assert config.default_database == "datdatcm"
    assert config.timeout == 30
    assert config.verify_ssl == True
    assert config.max_retries == 3
    assert config.retry_delay == 1.0


def test_ocp_config_dynamic_url_sit():
    """測試動態組合 SIT 環境 URL"""
    config = OCPConfig(env="sit")
    
    assert "ocpsit" in config.api_url
    assert config.api_url == "http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpsit.intranet.tw/execute_query_postgresql"


def test_ocp_config_dynamic_url_uat():
    """測試動態組合 UAT 環境 URL"""
    config = OCPConfig(env="uat")
    
    assert "ocpuat" in config.api_url
    assert config.api_url == "http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpuat.intranet.tw/execute_query_postgresql"


def test_ocp_config_dynamic_url_prod():
    """測試動態組合 PROD 環境 URL"""
    config = OCPConfig(env="prod")
    
    assert "ocpprod" in config.api_url
    assert config.api_url == "http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpprod.intranet.tw/execute_query_postgresql"


def test_ocp_config_custom_url_override():
    """測試自訂 URL 會覆蓋動態組合"""
    custom_url = "http://custom-ocp-api.example.com/execute_query_postgresql"
    config = OCPConfig(env="uat", api_url=custom_url)
    
    # 應該使用自訂 URL，而不是根據 env 組合
    assert config.api_url == custom_url
    assert "ocpuat" not in config.api_url


def test_ocp_config_custom_values(mock_ocp_config):
    """測試 OCPConfig 自訂值"""
    assert mock_ocp_config.api_url == "http://test-ocp-api.example.com/execute_query_postgresql"
    assert mock_ocp_config.default_database == "test_db"
    assert mock_ocp_config.timeout == 30
    assert mock_ocp_config.verify_ssl == False


def test_ocp_config_get_request_payload(mock_ocp_config):
    """測試構建請求 payload"""
    sql = "SELECT * FROM users"
    
    # 使用預設資料庫
    payload1 = mock_ocp_config.get_request_payload(sql)
    assert payload1["database"] == "test_db"
    assert payload1["sql"] == sql
    
    # 指定資料庫
    payload2 = mock_ocp_config.get_request_payload(sql, database="custom_db")
    assert payload2["database"] == "custom_db"
    assert payload2["sql"] == sql


# ============================================================================
# OCPClient 基本測試
# ============================================================================

def test_ocp_client_initialization(ocp_client, mock_ocp_config):
    """測試 OCPClient 初始化"""
    assert ocp_client.config == mock_ocp_config
    assert ocp_client.config.default_database == "test_db"


def test_ocp_client_with_default_config():
    """測試使用預設配置建立客戶端"""
    client = OCPClient()
    assert client.config is not None
    assert isinstance(client.config, OCPConfig)


# ============================================================================
# SELECT 查詢測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_execute_select_success(mock_make_request, ocp_client, mock_select_response):
    """測試 SELECT 查詢成功"""
    # 設定 Mock 回應
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    # 執行查詢
    sql = "SELECT * FROM datbatch.judgement_body_embedding LIMIT 2"
    result = ocp_client.execute_select(sql)
    
    # 驗證結果
    assert isinstance(result, OCPSelectResult)
    assert result.success == True
    assert result.query_time == 0.035
    assert result.row_count == 2
    assert result.columns == ["jid", "harm"]
    assert len(result.data) == 2
    
    # 驗證第一筆資料
    assert result.data[0][0] == "TYDV,106,訴,1712,20190625,1"
    assert result.data[0][1] == "左脛腓骨骨折之傷害"


@patch('database.ocp_client.make_request')
def test_execute_select_to_dict_list(mock_make_request, ocp_client, mock_select_response):
    """測試 SELECT 查詢轉換為字典列表"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    sql = "SELECT * FROM users"
    result = ocp_client.execute_select(sql)
    dict_list = result.to_dict_list()
    
    # 驗證字典列表
    assert isinstance(dict_list, list)
    assert len(dict_list) == 2
    assert isinstance(dict_list[0], dict)
    
    # 驗證第一筆資料
    assert dict_list[0]["jid"] == "TYDV,106,訴,1712,20190625,1"
    assert dict_list[0]["harm"] == "左脛腓骨骨折之傷害"


@patch('database.ocp_client.make_request')
def test_execute_select_with_database(mock_make_request, ocp_client, mock_select_response):
    """測試指定資料庫的 SELECT 查詢"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    sql = "SELECT 1"
    result = ocp_client.execute_select(sql, database="custom_db")
    
    # 驗證 make_request 被正確調用
    assert mock_make_request.called
    call_kwargs = mock_make_request.call_args[1]
    assert call_kwargs["json_data"]["database"] == "custom_db"


# ============================================================================
# DML 操作測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_execute_dml_insert(mock_make_request, ocp_client, mock_dml_response):
    """測試 INSERT 操作"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_dml_response)
    
    sql = "INSERT INTO public.test2(test1) VALUES ('TEST')"
    result = ocp_client.execute_dml(sql)
    
    # 驗證結果
    assert isinstance(result, OCPDMLResult)
    assert result.success == True
    assert result.query_time == 0.127
    assert result.affected_rows == 1


@patch('database.ocp_client.make_request')
def test_execute_dml_update(mock_make_request, ocp_client, mock_dml_response):
    """測試 UPDATE 操作"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_dml_response)
    
    sql = "UPDATE users SET status='active' WHERE id=1"
    result = ocp_client.execute_dml(sql)
    
    assert result.success == True
    assert result.affected_rows == 1


@patch('database.ocp_client.make_request')
def test_execute_dml_delete(mock_make_request, ocp_client, mock_dml_response):
    """測試 DELETE 操作"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_dml_response)
    
    sql = "DELETE FROM logs WHERE id=1"
    result = ocp_client.execute_dml(sql)
    
    assert result.success == True
    assert result.affected_rows == 1


# ============================================================================
# 自動判斷查詢類型測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_execute_query_auto_detect_select(mock_make_request, ocp_client, mock_select_response):
    """測試自動判斷 SELECT 查詢"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    sql = "SELECT * FROM users"
    result = ocp_client.execute_query(sql)
    
    assert isinstance(result, OCPSelectResult)
    assert result.row_count == 2


@patch('database.ocp_client.make_request')
def test_execute_query_auto_detect_dml(mock_make_request, ocp_client, mock_dml_response):
    """測試自動判斷 DML 操作"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_dml_response)
    
    sql = "INSERT INTO users(name) VALUES ('test')"
    result = ocp_client.execute_query(sql)
    
    assert isinstance(result, OCPDMLResult)
    assert result.affected_rows == 1


# ============================================================================
# 錯誤處理測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_execute_select_api_error(mock_make_request, ocp_client, mock_error_response):
    """測試 API 返回錯誤"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_error_response)
    
    sql = "SELECT * FROM non_existent_table"
    
    with pytest.raises(OCPError) as exc_info:
        ocp_client.execute_select(sql)
    
    assert "OCP API 返回錯誤" in str(exc_info.value)
    assert exc_info.value.return_code == "9999"


@patch('database.ocp_client.make_request')
def test_execute_select_http_error(mock_make_request, ocp_client):
    """測試 HTTP 錯誤"""
    from utils.request import HTTPError
    mock_make_request.side_effect = HTTPError("HTTP 500 Error")
    
    sql = "SELECT 1"
    
    with pytest.raises(OCPError) as exc_info:
        ocp_client.execute_select(sql)
    
    assert "HTTP 錯誤" in str(exc_info.value)


@patch('database.ocp_client.make_request')
def test_execute_select_invalid_result_format(mock_make_request, ocp_client):
    """測試無效的結果格式"""
    from database.ocp_client import OCPQueryResponse
    
    # 構造一個格式錯誤的回應
    invalid_response = {
        "MWHEADER": {
            "RETURNCODE": "0000",
            "RETURNDESC": "交易成功"
        },
        "TRANRS": {
            "status": "Success",
            "session_type": None,
            "query_time": 0.01,
            "result": [[1, 2, 3]]  # 缺少 columns
        }
    }
    
    mock_make_request.return_value = OCPQueryResponse(**invalid_response)
    
    sql = "SELECT 1"
    
    with pytest.raises(OCPError) as exc_info:
        ocp_client.execute_select(sql)
    
    assert "格式異常" in str(exc_info.value)


# ============================================================================
# 連線測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_connection_success(mock_make_request, ocp_client):
    """測試連線成功"""
    from database.ocp_client import OCPQueryResponse
    
    mock_response = {
        "MWHEADER": {"RETURNCODE": "0000", "RETURNDESC": "交易成功"},
        "TRANRS": {
            "status": "Success",
            "session_type": None,
            "query_time": 0.01,
            "result": [[[1]], ["test"]]
        }
    }
    
    mock_make_request.return_value = OCPQueryResponse(**mock_response)
    
    success = ocp_client.test_connection()
    assert success == True


@patch('database.ocp_client.make_request')
def test_connection_failure(mock_make_request, ocp_client):
    """測試連線失敗"""
    from utils.request import HTTPError
    mock_make_request.side_effect = HTTPError("Connection failed")
    
    success = ocp_client.test_connection()
    assert success == False


# ============================================================================
# 便捷函數測試
# ============================================================================

@patch('database.ocp_client.make_request')
def test_execute_ocp_query_function(mock_make_request, mock_select_response):
    """測試 execute_ocp_query 便捷函數"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    sql = "SELECT * FROM users"
    result = execute_ocp_query(sql)
    
    assert isinstance(result, OCPSelectResult)
    assert result.row_count == 2


@patch('database.ocp_client.make_request')
def test_execute_ocp_select_function(mock_make_request, mock_select_response):
    """測試 execute_ocp_select 便捷函數"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_select_response)
    
    sql = "SELECT * FROM users"
    result = execute_ocp_select(sql)
    
    assert isinstance(result, OCPSelectResult)
    assert result.columns == ["jid", "harm"]


@patch('database.ocp_client.make_request')
def test_execute_ocp_dml_function(mock_make_request, mock_dml_response):
    """測試 execute_ocp_dml 便捷函數"""
    from database.ocp_client import OCPQueryResponse
    mock_make_request.return_value = OCPQueryResponse(**mock_dml_response)
    
    sql = "INSERT INTO users(name) VALUES ('test')"
    result = execute_ocp_dml(sql)
    
    assert isinstance(result, OCPDMLResult)
    assert result.affected_rows == 1


# ============================================================================
# 重試機制測試
# ============================================================================

@patch('database.ocp_client.make_request')
@patch('database.ocp_client.time.sleep')
def test_retry_mechanism(mock_sleep, mock_make_request, ocp_client, mock_select_response):
    """測試重試機制"""
    from utils.request import HTTPError
    from database.ocp_client import OCPQueryResponse
    
    # 前兩次失敗，第三次成功
    mock_make_request.side_effect = [
        HTTPError("Timeout"),
        HTTPError("Timeout"),
        OCPQueryResponse(**mock_select_response)
    ]
    
    sql = "SELECT 1"
    result = ocp_client.execute_select(sql)
    
    # 驗證重試了兩次
    assert mock_make_request.call_count == 3
    assert mock_sleep.call_count == 2
    assert result.success == True


@patch('database.ocp_client.make_request')
@patch('database.ocp_client.time.sleep')
def test_retry_exhausted(mock_sleep, mock_make_request, ocp_client):
    """測試重試次數用盡"""
    from utils.request import HTTPError
    
    # 所有嘗試都失敗
    mock_make_request.side_effect = HTTPError("Timeout")
    
    sql = "SELECT 1"
    
    with pytest.raises(OCPError):
        ocp_client.execute_select(sql)
    
    # 驗證重試了最大次數（initial + retries）
    assert mock_make_request.call_count == ocp_client.config.max_retries + 1
