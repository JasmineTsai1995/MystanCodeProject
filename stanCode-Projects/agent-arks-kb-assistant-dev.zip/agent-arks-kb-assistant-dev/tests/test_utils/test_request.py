"""
HTTP 請求工具測試

測試 utils/request.py 的功能
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from pydantic import BaseModel, EmailStr, Field
import requests

from utils import request


# 測試用的 Pydantic Schema
class UserInput(BaseModel):
    """使用者輸入 Schema"""
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(..., ge=0, le=150)


class UserOutput(BaseModel):
    """使用者輸出 Schema"""
    id: int
    name: str
    email: str
    age: int
    created_at: str


class TestMakeRequest:
    """測試 request.make_request 函數"""
    
    @patch('utils.request.requests.request')
    def test_simple_get_request(self, mock_request):
        """測試簡單的 GET 請求"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "success"}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request("https://api.example.com/users")
        
        # 驗證
        assert result == {"message": "success"}
        mock_request.assert_called_once()
    
    @patch('utils.request.requests.request')
    def test_post_request_with_json(self, mock_request):
        """測試 POST 請求帶 JSON 數據"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": 1, "name": "John"}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users",
            method="POST",
            json_data={"name": "John", "email": "john@example.com"}
        )
        
        # 驗證
        assert result["id"] == 1
        assert result["name"] == "John"
    
    @patch('utils.request.requests.request')
    def test_request_with_params(self, mock_request):
        """測試帶查詢參數的請求"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = []
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users",
            params={"page": 1, "limit": 10}
        )
        
        # 驗證
        call_args = mock_request.call_args
        assert call_args[1]["params"] == {"page": 1, "limit": 10}
    
    @patch('utils.request.requests.request')
    def test_request_with_headers(self, mock_request):
        """測試帶自訂標頭的請求"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users",
            headers={"Authorization": "Bearer token123"}
        )
        
        # 驗證
        call_args = mock_request.call_args
        assert call_args[1]["headers"]["Authorization"] == "Bearer token123"
    
    @patch('utils.request.requests.request')
    def test_request_with_timeout(self, mock_request):
        """測試超時設定"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users",
            timeout=60
        )
        
        # 驗證
        call_args = mock_request.call_args
        assert call_args[1]["timeout"] == 60
    
    @patch('utils.request.requests.request')
    def test_request_with_auth(self, mock_request):
        """測試認證"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/protected",
            auth=("username", "password")
        )
        
        # 驗證
        call_args = mock_request.call_args
        assert call_args[1]["auth"] == ("username", "password")
    
    @patch('utils.request.requests.request')
    def test_input_schema_validation_success(self, mock_request):
        """測試輸入 Schema 驗證成功"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "id": 1,
            "name": "John",
            "email": "john@example.com",
            "age": 30,
            "created_at": "2025-11-10T12:00:00Z"
        }
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users",
            method="POST",
            json_data={"name": "John", "email": "john@example.com", "age": 30},
            input_schema=UserInput
        )
        
        # 驗證
        assert result["name"] == "John"
    
    @patch('utils.request.requests.request')
    def test_input_schema_validation_failure(self, mock_request):
        """測試輸入 Schema 驗證失敗"""
        # 發送請求（無效的 email）
        with pytest.raises(request.ValidationError) as exc_info:
            request.make_request(
                url="https://api.example.com/users",
                method="POST",
                json_data={"name": "John", "email": "invalid_email", "age": 30},
                input_schema=UserInput
            )
        
        # 驗證錯誤訊息
        assert "輸入數據驗證失敗" in str(exc_info.value)
    
    @patch('utils.request.requests.request')
    def test_output_schema_validation_success(self, mock_request):
        """測試輸出 Schema 驗證成功"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": 1,
            "name": "John",
            "email": "john@example.com",
            "age": 30,
            "created_at": "2025-11-10T12:00:00Z"
        }
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request(
            url="https://api.example.com/users/1",
            output_schema=UserOutput
        )
        
        # 驗證
        assert isinstance(result, UserOutput)
        assert result.id == 1
        assert result.name == "John"
    
    @patch('utils.request.requests.request')
    def test_output_schema_validation_failure(self, mock_request):
        """測試輸出 Schema 驗證失敗"""
        # 模擬響應（缺少必要欄位）
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": 1, "name": "John"}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        with pytest.raises(request.ValidationError) as exc_info:
            request.make_request(
                url="https://api.example.com/users/1",
                output_schema=UserOutput
            )
        
        # 驗證錯誤訊息
        assert "輸出數據驗證失敗" in str(exc_info.value)
    
    @patch('utils.request.requests.request')
    def test_http_error_handling(self, mock_request):
        """測試 HTTP 錯誤處理"""
        # 模擬 404 錯誤
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.raise_for_status.side_effect = requests.HTTPError("404 Not Found")
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        with pytest.raises(request.HTTPError) as exc_info:
            request.make_request("https://api.example.com/users/999")
        
        # 驗證
        assert exc_info.value.status_code == 404
    
    @patch('utils.request.requests.request')
    def test_timeout_error_handling(self, mock_request):
        """測試超時錯誤處理"""
        # 模擬超時
        mock_request.side_effect = requests.Timeout("Request timeout")
        
        # 發送請求
        with pytest.raises(request.HTTPError) as exc_info:
            request.make_request("https://api.example.com/slow-endpoint", timeout=1)
        
        # 驗證
        assert "超時" in str(exc_info.value)
    
    @patch('utils.request.requests.request')
    def test_connection_error_handling(self, mock_request):
        """測試連線錯誤處理"""
        # 模擬連線錯誤
        mock_request.side_effect = requests.ConnectionError("Connection failed")
        
        # 發送請求
        with pytest.raises(request.HTTPError) as exc_info:
            request.make_request("https://api.example.com/users")
        
        # 驗證
        assert "連線錯誤" in str(exc_info.value)
    
    @patch('utils.request.requests.request')
    def test_text_response(self, mock_request):
        """測試文字響應"""
        # 模擬文字響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.side_effect = ValueError("Not JSON")
        mock_response.text = "Plain text response"
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 發送請求
        result = request.make_request("https://api.example.com/text")
        
        # 驗證
        assert result == "Plain text response"


class TestRequestClient:
    """測試 RequestClient 類別"""
    
    @patch('utils.request.requests.request')
    def test_client_initialization(self, mock_request):
        """測試客戶端初始化"""
        client = request.RequestClient(
            base_url="https://api.example.com",
            default_headers={"Authorization": "Bearer token"},
            default_timeout=60
        )
        
        assert client.base_url == "https://api.example.com"
        assert client.default_headers["Authorization"] == "Bearer token"
        assert client.default_timeout == 60
    
    @patch('utils.request.requests.request')
    def test_client_get_request(self, mock_request):
        """測試客戶端 GET 請求"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"users": []}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 建立客戶端
        client = request.RequestClient(base_url="https://api.example.com")
        
        # 發送請求
        result = client.get("/users")
        
        # 驗證
        assert "users" in result
    
    @patch('utils.request.requests.request')
    def test_client_post_request(self, mock_request):
        """測試客戶端 POST 請求"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": 1}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 建立客戶端
        client = request.RequestClient(base_url="https://api.example.com")
        
        # 發送請求
        result = client.post("/users", json_data={"name": "John"})
        
        # 驗證
        assert result["id"] == 1
    
    @patch('utils.request.requests.request')
    def test_client_url_building(self, mock_request):
        """測試 URL 建構"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 建立客戶端
        client = request.RequestClient(base_url="https://api.example.com")
        
        # 發送請求
        client.get("/users")
        
        # 驗證 URL
        call_args = mock_request.call_args
        assert call_args[0][1] == "https://api.example.com/users"
    
    @patch('utils.request.requests.request')
    def test_client_header_merging(self, mock_request):
        """測試標頭合併"""
        # 模擬響應
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_request.return_value = mock_response
        
        # 建立客戶端
        client = request.RequestClient(
            base_url="https://api.example.com",
            default_headers={"Authorization": "Bearer token"}
        )
        
        # 發送請求帶額外標頭
        client.get("/users", headers={"X-Custom": "value"})
        
        # 驗證標頭
        call_args = mock_request.call_args
        headers = call_args[1]["headers"]
        assert headers["Authorization"] == "Bearer token"
        assert headers["X-Custom"] == "value"
    
    def test_client_context_manager(self):
        """測試 context manager"""
        with request.RequestClient(base_url="https://api.example.com") as client:
            assert client.base_url == "https://api.example.com"
        
        # Session 應該已關閉
        # 這裡只是確保沒有異常


class TestConvenienceFunctions:
    """測試便捷函數"""
    
    @patch('utils.request.make_request')
    def test_get_function(self, mock_make_request):
        """測試 get 函數"""
        request.get("https://api.example.com/users")
        mock_make_request.assert_called_once_with(
            "https://api.example.com/users",
            method="GET"
        )
    
    @patch('utils.request.make_request')
    def test_post_function(self, mock_make_request):
        """測試 post 函數"""
        request.post("https://api.example.com/users", json_data={"name": "John"})
        mock_make_request.assert_called_once_with(
            "https://api.example.com/users",
            method="POST",
            json_data={"name": "John"}
        )
    
    @patch('utils.request.make_request')
    def test_put_function(self, mock_make_request):
        """測試 put 函數"""
        request.put("https://api.example.com/users/1", json_data={"name": "Jane"})
        mock_make_request.assert_called_once_with(
            "https://api.example.com/users/1",
            method="PUT",
            json_data={"name": "Jane"}
        )
    
    @patch('utils.request.make_request')
    def test_patch_function(self, mock_make_request):
        """測試 patch 函數"""
        request.patch("https://api.example.com/users/1", json_data={"age": 31})
        mock_make_request.assert_called_once_with(
            "https://api.example.com/users/1",
            method="PATCH",
            json_data={"age": 31}
        )
    
    @patch('utils.request.make_request')
    def test_delete_function(self, mock_make_request):
        """測試 delete 函數"""
        request.delete("https://api.example.com/users/1")
        mock_make_request.assert_called_once_with(
            "https://api.example.com/users/1",
            method="DELETE"
        )


class TestErrorTypes:
    """測試錯誤類型"""
    
    def test_request_error(self):
        """測試 RequestError"""
        error = request.RequestError("Test error")
        assert str(error) == "Test error"
    
    def test_validation_error(self):
        """測試 ValidationError"""
        error = request.ValidationError("Validation failed")
        assert str(error) == "Validation failed"
        assert isinstance(error, request.RequestError)
    
    def test_http_error(self):
        """測試 HTTPError"""
        error = request.HTTPError("HTTP error", status_code=404)
        assert str(error) == "HTTP error"
        assert error.status_code == 404
        assert isinstance(error, request.RequestError)
