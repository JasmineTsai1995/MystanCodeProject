"""
測試 Prompt 模板
"""

import pytest
from config.prompts import (
    ANALYSIS_PROMPT,
    GENERATION_PROMPT,
    SUMMARIZATION_PROMPT,
    TRANSLATION_PROMPT,
    USER_GREETING_PROMPT,
    USER_HELP_PROMPT,
    USER_ERROR_PROMPT,
)
from config.prompts.loader import (
    PromptLoader,
    load_prompt,
    format_prompt,
)


class TestSystemPrompts:
    """測試系統級 Prompt"""
    
    def test_analysis_prompt_exists(self):
        """測試分析 Prompt 存在且有內容"""
        assert ANALYSIS_PROMPT
        assert len(ANALYSIS_PROMPT) > 50
        assert "分析" in ANALYSIS_PROMPT
    
    def test_generation_prompt_exists(self):
        """測試生成 Prompt 存在且有內容"""
        assert GENERATION_PROMPT
        assert len(GENERATION_PROMPT) > 50
        assert "生成" in GENERATION_PROMPT or "創作" in GENERATION_PROMPT
    
    def test_summarization_prompt_exists(self):
        """測試摘要 Prompt 存在且有內容"""
        assert SUMMARIZATION_PROMPT
        assert len(SUMMARIZATION_PROMPT) > 50
        assert "摘要" in SUMMARIZATION_PROMPT
    
    def test_translation_prompt_exists(self):
        """測試翻譯 Prompt 存在且有內容"""
        assert TRANSLATION_PROMPT
        assert len(TRANSLATION_PROMPT) > 50
        assert "翻譯" in TRANSLATION_PROMPT
    
    def test_generation_prompt_formatting(self):
        """測試生成 Prompt 的格式化功能"""
        formatted = GENERATION_PROMPT.format(
            topic="測試主題",
            audience="開發者",
            tone="專業",
            length="1000字"
        )
        assert "測試主題" in formatted
        assert "開發者" in formatted


class TestUserPrompts:
    """測試使用者互動 Prompt"""
    
    def test_greeting_prompt_exists(self):
        """測試歡迎 Prompt 存在"""
        assert USER_GREETING_PROMPT
        assert "歡迎" in USER_GREETING_PROMPT
    
    def test_help_prompt_exists(self):
        """測試幫助 Prompt 存在"""
        assert USER_HELP_PROMPT
        assert len(USER_HELP_PROMPT) > 50
    
    def test_error_prompt_exists(self):
        """測試錯誤 Prompt 存在"""
        assert USER_ERROR_PROMPT
        assert "錯誤" in USER_ERROR_PROMPT or "抱歉" in USER_ERROR_PROMPT
    
    def test_greeting_prompt_formatting(self):
        """測試歡迎 Prompt 的格式化"""
        formatted = USER_GREETING_PROMPT.format(app_name="測試應用")
        assert "測試應用" in formatted
    
    def test_error_prompt_formatting(self):
        """測試錯誤 Prompt 的格式化"""
        formatted = USER_ERROR_PROMPT.format(
            error_type="驗證錯誤",
            error_message="格式不正確",
            support_email="test@example.com"
        )
        assert "驗證錯誤" in formatted
        assert "格式不正確" in formatted
        assert "test@example.com" in formatted


class TestPromptLoader:
    """測試 Prompt 載入器"""
    
    def test_loader_initialization(self):
        """測試載入器初始化"""
        loader = PromptLoader()
        assert loader is not None
        assert loader.templates_dir.exists()
    
    def test_list_templates(self):
        """測試列出所有模板"""
        loader = PromptLoader()
        templates = loader.list_templates()
        assert isinstance(templates, list)
        # 應該至少有 default, analysis, generation 三個模板
        assert "default" in templates
        assert "analysis" in templates
        assert "generation" in templates
    
    def test_load_default_template(self):
        """測試載入預設模板"""
        loader = PromptLoader()
        content = loader.load_template("default")
        assert content
        assert len(content) > 50
    
    def test_load_analysis_template(self):
        """測試載入分析模板"""
        loader = PromptLoader()
        content = loader.load_template("analysis")
        assert content
        assert "分析" in content
    
    def test_load_generation_template(self):
        """測試載入生成模板"""
        loader = PromptLoader()
        content = loader.load_template("generation")
        assert content
        assert "生成" in content or "創作" in content
    
    def test_load_nonexistent_template(self):
        """測試載入不存在的模板"""
        loader = PromptLoader()
        with pytest.raises(FileNotFoundError):
            loader.load_template("nonexistent_template")
    
    def test_cache_functionality(self):
        """測試快取功能"""
        loader = PromptLoader()
        
        # 第一次載入
        content1 = loader.load_template("default")
        
        # 第二次載入（應該從快取）
        content2 = loader.load_template("default")
        
        assert content1 == content2
        assert "default" in loader._cache
    
    def test_reload_template(self):
        """測試重新載入模板"""
        loader = PromptLoader()
        
        # 載入並快取
        content1 = loader.load_template("default")
        
        # 重新載入（忽略快取）
        content2 = loader.reload_template("default")
        
        assert content1 == content2
    
    def test_clear_cache(self):
        """測試清除快取"""
        loader = PromptLoader()
        
        # 載入模板
        loader.load_template("default")
        assert len(loader._cache) > 0
        
        # 清除快取
        loader.clear_cache()
        assert len(loader._cache) == 0


class TestPromptHelperFunctions:
    """測試 Prompt 輔助函數"""
    
    def test_load_prompt_function(self):
        """測試 load_prompt 便捷函數"""
        content = load_prompt("default")
        assert content
        assert len(content) > 50
    
    def test_format_prompt_function(self):
        """測試 format_prompt 便捷函數"""
        # 注意：這需要模板中有對應的變數
        # 如果 default.txt 沒有變數，這個測試會失敗
        # 可以使用其他有變數的模板進行測試
        try:
            content = format_prompt("default", test_var="測試值")
            assert content
        except KeyError:
            # 如果模板沒有變數，會拋出 KeyError
            # 這是預期的行為
            pass


class TestPromptContent:
    """測試 Prompt 內容品質"""
    
    def test_prompts_are_in_traditional_chinese(self):
        """測試 Prompt 使用繁體中文"""
        # 檢查系統 Prompt
        prompts = [
            ANALYSIS_PROMPT,
            GENERATION_PROMPT,
            SUMMARIZATION_PROMPT,
            TRANSLATION_PROMPT,
        ]
        
        for prompt in prompts:
            # 簡單檢查是否包含中文字元
            assert any('\u4e00' <= char <= '\u9fff' for char in prompt)
    
    def test_prompts_have_minimum_length(self):
        """測試 Prompt 有最小長度"""
        prompts = [
            ANALYSIS_PROMPT,
            GENERATION_PROMPT,
            SUMMARIZATION_PROMPT,
            TRANSLATION_PROMPT,
            USER_GREETING_PROMPT,
            USER_HELP_PROMPT,
            USER_ERROR_PROMPT,
        ]
        
        for prompt in prompts:
            assert len(prompt) > 30, f"Prompt 太短: {prompt[:50]}..."
    
    def test_template_files_exist(self):
        """測試模板檔案存在"""
        loader = PromptLoader()
        templates = ["default", "analysis", "generation"]
        
        for template in templates:
            content = loader.load_template(template)
            assert content, f"模板 {template} 是空的"
            assert len(content) > 50, f"模板 {template} 太短"
