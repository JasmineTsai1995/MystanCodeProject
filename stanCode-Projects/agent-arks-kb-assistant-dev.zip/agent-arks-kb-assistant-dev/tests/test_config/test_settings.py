"""
測試應用程式設定
"""

import pytest
from config import settings


class TestSettings:
    """測試 Settings 類別"""
    
    def test_settings_instance(self):
        """測試 settings 實例存在"""
        assert settings is not None
    
    def test_app_basic_settings(self):
        """測試應用程式基本設定"""
        assert settings.app_name
        assert settings.app_version
        assert settings.app_env in ["development", "staging", "production", "testing"]
    
    def test_server_settings(self):
        """測試伺服器設定"""
        assert settings.host
        assert isinstance(settings.port, int)
        assert 1 <= settings.port <= 65535
    
    def test_database_settings(self):
        """測試資料庫設定"""
        assert settings.database_url
        assert settings.database_sync_url
        assert isinstance(settings.db_pool_size, int)
        assert settings.db_pool_size > 0
    
    def test_redis_settings(self):
        """測試 Redis 設定"""
        assert settings.redis_host
        assert isinstance(settings.redis_port, int)
        assert settings.redis_url
    
    def test_security_settings(self):
        """測試安全性設定"""
        assert settings.secret_key
        assert len(settings.secret_key) >= 32
        assert settings.algorithm
        assert settings.access_token_expire_minutes > 0
    
    def test_cors_settings(self):
        """測試 CORS 設定"""
        assert isinstance(settings.cors_origins, list)
        assert isinstance(settings.cors_allow_credentials, bool)
    
    def test_environment_properties(self):
        """測試環境判斷屬性"""
        # 至少有一個環境為 True
        environments = [
            settings.is_production,
            settings.is_development,
            settings.is_testing
        ]
        # 注意：可能不只一個為 True，取決於 app_env 的值
        assert any(environments) or settings.app_env not in ["production", "development", "testing"]
    
    def test_log_settings(self):
        """測試日誌設定"""
        assert settings.log_level in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        assert settings.log_file
    
    def test_upload_settings(self):
        """測試檔案上傳設定"""
        assert settings.max_upload_size > 0
        assert settings.upload_dir
