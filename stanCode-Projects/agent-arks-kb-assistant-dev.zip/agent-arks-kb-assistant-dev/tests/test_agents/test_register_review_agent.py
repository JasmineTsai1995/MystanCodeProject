"""Tests for deployment-time prompt capture during review model registration."""

from __future__ import annotations

import hashlib
import importlib.util
import sys
import types
from pathlib import Path


_SCRIPT_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "services"
    / "scripts"
    / "register_review_agent.py"
)


def _load_script(monkeypatch):
    mlflow = types.ModuleType("mlflow")
    resources = types.ModuleType("mlflow.models.resources")
    resources.DatabricksApp = object
    resources.DatabricksLakebase = object
    resources.DatabricksServingEndpoint = object
    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "mlflow.models", types.ModuleType("mlflow.models"))
    monkeypatch.setitem(sys.modules, "mlflow.models.resources", resources)

    spec = importlib.util.spec_from_file_location("_register_review_agent_test", _SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module, mlflow


def test_capture_prompt_snapshot_and_generated_module(monkeypatch, tmp_path):
    module, mlflow = _load_script(monkeypatch)
    loaded_uris = []

    def load_prompt(uri, cache_ttl_seconds):
        loaded_uris.append(uri)
        return types.SimpleNamespace(template=f"template:{uri}", version="42")

    mlflow.genai = types.SimpleNamespace(load_prompt=load_prompt)

    snapshots, snapshot_digest = module._capture_prompt_snapshot()
    prompt_name = "dev_gaia_experiments.arks.arks_agent"
    expected_digest = hashlib.sha256(
        f"template:prompts:/{prompt_name}@production".encode("utf-8")
    ).hexdigest()
    assert len(snapshots) == 6
    assert snapshots[prompt_name]["version"] == "42"
    assert snapshots[prompt_name]["digest"] == expected_digest
    assert len(snapshot_digest) == 64
    assert len(loaded_uris) == 6

    snapshot_file = module._write_snapshot_module(tmp_path, snapshots)
    generated_spec = importlib.util.spec_from_file_location("_generated_review_snapshot", snapshot_file)
    generated = importlib.util.module_from_spec(generated_spec)
    assert generated_spec.loader is not None
    generated_spec.loader.exec_module(generated)
    assert generated.SNAPSHOTS[prompt_name]["digest"] == expected_digest
