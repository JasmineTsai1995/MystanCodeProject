"""Tests for the ResponsesAgent endpoint smoke verifier."""

from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path


_SCRIPT_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "services"
    / "scripts"
    / "verify_review_endpoint.py"
)


def test_verify_uses_responses_api_request_shape(monkeypatch):
    captured = {}

    calls = []
    mlflow = types.ModuleType("mlflow")
    mlflow.set_tracking_uri = lambda uri: None
    mlflow.get_experiment_by_name = lambda name: types.SimpleNamespace(experiment_id="exp-1")

    def search_traces(**kwargs):
        captured.setdefault("search_locations", []).append(kwargs["locations"])
        if not calls:
            calls.append("initial")
            return []
        return [
            types.SimpleNamespace(
                info=types.SimpleNamespace(
                    trace_id="trace-1",
                    tags={
                        "client_request_id": captured["extra_body"]["custom_inputs"][
                            "client_request_id"
                        ],
                        "arks.prompt.source": "mlflow_snapshot",
                        "arks.prompt.version": "42",
                        "arks.prompt.digest": "digest-42",
                    },
                )
            )
        ]

    mlflow.search_traces = search_traces

    class Responses:
        def create(self, **kwargs):
            captured.update(kwargs)
            return {"ok": True}

    client_module = types.ModuleType("databricks_openai")
    client_module.DatabricksOpenAI = lambda: types.SimpleNamespace(responses=Responses())

    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "databricks_openai", client_module)
    monkeypatch.setattr("time.sleep", lambda _: None)

    spec = importlib.util.spec_from_file_location("_verify_review_endpoint_test", _SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    def configure_trace_location(**kwargs):
        captured["trace_location"] = kwargs
        return types.SimpleNamespace(
            search_location=(
                f"{kwargs['catalog']}.{kwargs['schema']}.{kwargs['table_prefix']}"
            )
        )

    module.configure_experiment_trace_location = configure_trace_location
    module.main(
        [
            "--endpoint-name",
            "arks-agent-review",
            "--experiment-name",
            "/Shared/review",
            "--review-deployment-id",
            "release-1",
            "--wait-seconds",
            "0",
            "--expected-prompt-version",
            "42",
            "--expected-prompt-digest",
            "digest-42",
        ]
    )

    assert captured["model"] == "arks-agent-review"
    assert captured["trace_location"]["catalog"] == "dev_gaia_experiments"
    assert captured["trace_location"]["schema"] == "arks"
    assert captured["trace_location"]["table_prefix"] == "arks_review"
    assert captured["search_locations"] == [
        ["dev_gaia_experiments.arks.arks_review"],
        ["dev_gaia_experiments.arks.arks_review"],
    ]
    assert captured["input"][0]["role"] == "user"
    assert captured["extra_body"]["custom_inputs"]["session_id"] == "review-smoke-release-1"
    assert "inputs" not in captured


def test_verify_rejects_yaml_fallback_trace(monkeypatch):
    captured = {}
    calls = []
    mlflow = types.ModuleType("mlflow")
    mlflow.set_tracking_uri = lambda uri: None
    mlflow.get_experiment_by_name = lambda name: types.SimpleNamespace(experiment_id="exp-1")
    def search_traces(**kwargs):
        if not calls:
            calls.append("initial")
            return []
        return [
            types.SimpleNamespace(
                info=types.SimpleNamespace(
                    trace_id="trace-1",
                    tags={
                        "client_request_id": captured["client_request_id"],
                        "arks.prompt.source": "yaml",
                        "arks.prompt.version": "unknown",
                    },
                )
            )
        ]

    mlflow.search_traces = search_traces
    client_module = types.ModuleType("databricks_openai")

    def create(**kwargs):
        captured["client_request_id"] = kwargs["extra_body"]["custom_inputs"]["client_request_id"]
        return {"ok": True}

    client_module.DatabricksOpenAI = lambda: types.SimpleNamespace(
        responses=types.SimpleNamespace(create=create)
    )
    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "databricks_openai", client_module)
    monkeypatch.setattr("time.sleep", lambda _: None)

    spec = importlib.util.spec_from_file_location("_verify_review_endpoint_yaml_test", _SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    def configure_trace_location(**kwargs):
        captured["trace_location"] = kwargs
        return types.SimpleNamespace(
            search_location=(
                f"{kwargs['catalog']}.{kwargs['schema']}.{kwargs['table_prefix']}"
            )
        )

    module.configure_experiment_trace_location = configure_trace_location

    import pytest

    with pytest.raises(RuntimeError, match="immutable MLflow prompt snapshot"):
        module.main(
            [
                "--endpoint-name",
                "arks-agent-review",
                "--experiment-name",
                "/Shared/review",
                "--review-deployment-id",
                "release-1",
                "--wait-seconds",
                "0",
            ]
        )
