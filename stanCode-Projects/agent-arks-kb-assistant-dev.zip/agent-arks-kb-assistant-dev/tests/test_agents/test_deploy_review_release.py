"""Tests for executing the review deployment task in Databricks job style."""

from __future__ import annotations

import sys
import types
from pathlib import Path


_SCRIPT_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "services"
    / "scripts"
    / "deploy_review_release.py"
)


def test_deploy_script_does_not_require_dunder_file(monkeypatch):
    captured = {}

    mlflow = types.ModuleType("mlflow")
    mlflow.set_experiment = lambda experiment: captured.setdefault("experiment", experiment)

    def deploy(*args, **kwargs):
        captured["deploy_kwargs"] = kwargs
        return types.SimpleNamespace(query_endpoint="endpoint-url")

    agents = types.SimpleNamespace(deploy=deploy)
    databricks = types.ModuleType("databricks")
    databricks.agents = agents

    register = types.ModuleType("register_review_agent")

    def register_review_model(args):
        captured["register_args"] = args
        return types.SimpleNamespace(
            model_name="catalog.schema.review_agent",
            model_version="1",
            git_commit="sha",
            agent_prompt_version="42",
            agent_prompt_digest="digest-42",
            prompt_snapshot_digest="snapshot-digest",
        )

    register.register_review_model = register_review_model
    finalize = types.ModuleType("finalize_review_endpoint")
    finalize.finalize_review_endpoint = lambda args: captured.setdefault("finalize_args", args)

    class ResourceDoesNotExist(Exception):
        pass

    class ServingEndpoints:
        get_calls = 0

        def get(self, *, name):
            self.get_calls += 1
            if self.get_calls == 1:
                raise ResourceDoesNotExist(name)
            return types.SimpleNamespace(
                tags=[
                    types.SimpleNamespace(key="arks_review_deployment_id", value="old-release"),
                    types.SimpleNamespace(key="MONITOR_EXPERIMENT_ID", value="experiment-id"),
                ]
            )

        def patch(self, **kwargs):
            captured.setdefault("tag_patches", []).append(kwargs)

    serving_endpoints = ServingEndpoints()
    sdk = types.ModuleType("databricks.sdk")
    sdk.WorkspaceClient = lambda: types.SimpleNamespace(serving_endpoints=serving_endpoints)
    sdk_errors = types.ModuleType("databricks.sdk.errors")
    sdk_errors.ResourceDoesNotExist = ResourceDoesNotExist
    sdk_serving = types.ModuleType("databricks.sdk.service.serving")
    sdk_serving.EndpointTag = lambda key, value: types.SimpleNamespace(key=key, value=value)

    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "databricks", databricks)
    monkeypatch.setitem(sys.modules, "databricks.sdk", sdk)
    monkeypatch.setitem(sys.modules, "databricks.sdk.errors", sdk_errors)
    monkeypatch.setitem(sys.modules, "databricks.sdk.service.serving", sdk_serving)
    monkeypatch.setitem(sys.modules, "finalize_review_endpoint", finalize)
    monkeypatch.setitem(sys.modules, "register_review_agent", register)

    namespace = {"__name__": "job_task"}
    exec(compile(_SCRIPT_PATH.read_bytes(), str(_SCRIPT_PATH), "exec"), namespace)
    namespace["configure_experiment_trace_location"] = (
        lambda **kwargs: captured.setdefault("trace_location", kwargs)
    )
    namespace["main"](
        [
            "--review-deployment-id",
            "release-1",
            "--experiment-name",
            "/Shared/review",
            "--registered-model-name",
            "catalog.schema.review_agent",
            "--mcp-app-url",
            "https://mcp.example",
            "--git-commit",
            "sha",
            "--skip-smoke-test",
        ]
    )

    assert captured["register_args"].requirements_file is None
    assert captured["register_args"].uc_catalog == "dev_gaia_experiments"
    assert captured["register_args"].uc_schema == "arks"
    assert captured["register_args"].trace_table_prefix == "arks_review"
    assert captured["register_args"].llm_provider == "litellm"
    assert captured["register_args"].litellm_model == "gpt-5.5"
    assert captured["experiment"] == "/Shared/review"
    assert captured["trace_location"]["catalog"] == "dev_gaia_experiments"
    assert captured["trace_location"]["schema"] == "arks"
    assert captured["trace_location"]["table_prefix"] == "arks_review"
    assert "tags" not in captured["deploy_kwargs"]
    environment_vars = captured["deploy_kwargs"]["environment_vars"]
    assert environment_vars["ARKS_TRACE_TABLE_PREFIX"] == "arks_review"
    assert environment_vars["LLM_PROVIDER"] == "litellm"
    assert environment_vars["LITELLM_MODEL"] == "gpt-5.5"
    assert environment_vars["LITELLM_API_KEY"] == "{{secrets/arks/litellm-api-key}}"
    assert captured["finalize_args"].endpoint_name == "arks-agent-review"
    assert captured["finalize_args"].uc_catalog == "dev_gaia_experiments"
    assert captured["finalize_args"].uc_schema == "arks"
    assert captured["finalize_args"].trace_table_prefix == "arks_review"
    assert captured["finalize_args"].expected_prompt_version == "42"
    assert captured["tag_patches"][0] == {
        "name": "arks-agent-review",
        "delete_tags": ["arks_review_deployment_id"],
    }
    added_tags = {tag.key: tag.value for tag in captured["tag_patches"][1]["add_tags"]}
    assert added_tags == {
        "arks_review_deployment_id": "release-1",
        "arks_git_commit": "sha",
        "arks_prompt_source": "mlflow_snapshot",
        "arks_prompt_agent_version": "42",
        "arks_prompt_agent_digest": "digest-42",
        "arks_prompt_snapshot_digest": "snapshot-digest",
        "arks_uc_catalog": "dev_gaia_experiments",
        "arks_uc_schema": "arks",
        "arks_trace_table_prefix": "arks_review",
        "arks_llm_provider": "litellm",
    }
