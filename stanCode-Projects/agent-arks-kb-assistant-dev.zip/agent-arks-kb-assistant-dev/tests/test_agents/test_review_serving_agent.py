"""Tests for the thin Model Serving adapter without importing live MLflow clients."""

from __future__ import annotations

import asyncio
import importlib.util
import sys
import types
from pathlib import Path


_ADAPTER_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "services"
    / "entrypoints"
    / "review_serving_agent.py"
)


class _Response:
    def __init__(self, output):
        self.output = output


class _StreamEvent:
    def __init__(self, type, item):
        self.type = type
        self.item = item


class _ResponsesAgent:
    @staticmethod
    def create_text_output_item(text, id):
        return {"text": text, "id": id}


class _Request:
    def __init__(self, *, custom_inputs=None, conversation_id=None):
        self.custom_inputs = custom_inputs or {}
        self.context = types.SimpleNamespace(conversation_id=conversation_id)

    def model_copy(self, *, update):
        return _Request(
            custom_inputs=update.get("custom_inputs", self.custom_inputs),
            conversation_id=self.context.conversation_id,
        )


def _load_adapter(monkeypatch, *, logging_mode: bool, app_module=None):
    captured = {"trace_updates": []}
    mlflow = types.ModuleType("mlflow")
    mlflow.models = types.SimpleNamespace(set_model=lambda model: captured.setdefault("model", model))
    mlflow.update_current_trace = lambda **kwargs: captured["trace_updates"].append(kwargs)

    pyfunc = types.ModuleType("mlflow.pyfunc")
    pyfunc.ResponsesAgent = _ResponsesAgent

    responses = types.ModuleType("mlflow.types.responses")
    responses.ResponsesAgentRequest = object
    responses.ResponsesAgentResponse = _Response
    responses.ResponsesAgentStreamEvent = _StreamEvent

    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "mlflow.pyfunc", pyfunc)
    monkeypatch.setitem(sys.modules, "mlflow.types", types.ModuleType("mlflow.types"))
    monkeypatch.setitem(sys.modules, "mlflow.types.responses", responses)
    if logging_mode:
        monkeypatch.setenv("SKIP_MCP_TOOL_INIT", "true")
    else:
        monkeypatch.delenv("SKIP_MCP_TOOL_INIT", raising=False)
        services = types.ModuleType("services")
        services.__path__ = []
        core = types.ModuleType("services.core")
        core.__path__ = []
        services.core = core
        core.databricks_agent = app_module
        monkeypatch.setitem(sys.modules, "services", services)
        monkeypatch.setitem(sys.modules, "services.core", core)
        monkeypatch.setitem(sys.modules, "services.core.databricks_agent", app_module)

    name = f"_review_serving_agent_test_{int(logging_mode)}"
    spec = importlib.util.spec_from_file_location(name, _ADAPTER_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module, captured["model"], captured


def test_packaging_mode_does_not_import_active_app(monkeypatch):
    _, model, captured = _load_adapter(monkeypatch, logging_mode=True)

    response = model.predict(object())
    events = list(model.predict_stream(object()))

    assert response.output[0]["text"] == "Review endpoint model packaging validation succeeded."
    assert events[0].item["text"] == "Review endpoint model packaging validation succeeded."
    assert captured["trace_updates"] == []


def test_adapter_delegates_invoke_and_stream_on_one_async_loop(monkeypatch):
    observed_loops = []
    observed_requests = []
    fake_app = types.ModuleType("services.core.databricks_agent")
    fake_app._agent_prompt_identity = ("mlflow", "42", "dev_gaia_experiments.arks.arks_agent")
    fake_app._agent_prompt_snapshot = types.SimpleNamespace(
        source="mlflow_snapshot",
        registry_name="dev_gaia_experiments.arks.arks_agent",
        alias="production",
        version="42",
        digest="digest-42",
    )

    async def invoke_handler(request):
        observed_loops.append(asyncio.get_running_loop())
        observed_requests.append(request)
        return _Response([{"request": request}])

    async def stream_handler(request):
        observed_loops.append(asyncio.get_running_loop())
        observed_requests.append(request)
        yield _StreamEvent("response.output_item.done", {"request": request})

    fake_app.invoke_handler = invoke_handler
    fake_app.stream_handler = stream_handler
    _, model, captured = _load_adapter(monkeypatch, logging_mode=False, app_module=fake_app)

    request = _Request(conversation_id="conversation-1")
    assert model.predict(request).output == [{"request": observed_requests[0]}]
    assert list(model.predict_stream(request))[0].item == {"request": observed_requests[1]}
    assert observed_loops[0] is observed_loops[1]
    assert all(r.custom_inputs["session_id"] == "review-conversation-1" for r in observed_requests)
    assert len(captured["trace_updates"]) == 2
    assert captured["trace_updates"][0]["tags"]["arks.prompt.version"] == "42"
    assert captured["trace_updates"][0]["tags"]["arks.prompt.source"] == "mlflow_snapshot"
    assert captured["trace_updates"][0]["tags"]["arks.prompt.digest"] == "digest-42"
    assert captured["trace_updates"][0]["tags"]["arks.runtime.adapter"] == "review_serving_agent"

    model._runner._loop.call_soon_threadsafe(model._runner._loop.stop)
