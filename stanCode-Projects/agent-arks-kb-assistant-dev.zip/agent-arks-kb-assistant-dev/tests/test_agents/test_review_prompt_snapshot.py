"""Tests for the opt-in immutable review prompt snapshot loader."""

from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

import pytest


_LOADER_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "config"
    / "prompts"
    / "loader.py"
)


def _load_loader():
    spec = importlib.util.spec_from_file_location("_review_prompt_loader_test", _LOADER_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_deployment_snapshot_reads_bundled_prompt_and_metadata(monkeypatch):
    template = "captured production prompt"
    import hashlib

    snapshot_module = types.ModuleType("review_prompt_snapshot")
    snapshot_module.SNAPSHOTS = {
        "dev_gaia_experiments.arks.arks_agent": {
            "template": template,
            "version": "42",
            "alias": "production",
            "digest": hashlib.sha256(template.encode("utf-8")).hexdigest(),
        }
    }
    monkeypatch.setitem(sys.modules, "review_prompt_snapshot", snapshot_module)
    monkeypatch.setenv("ARKS_PROMPT_MODE", "deployment_snapshot")

    snapshot = _load_loader().load_snapshot("dev_gaia_experiments.arks.arks_agent", "agent")

    assert snapshot.template == template
    assert snapshot.source == "mlflow_snapshot"
    assert snapshot.version == "42"
    assert snapshot.digest == snapshot_module.SNAPSHOTS[
        "dev_gaia_experiments.arks.arks_agent"
    ]["digest"]


def test_deployment_snapshot_never_falls_back_to_yaml(monkeypatch):
    snapshot_module = types.ModuleType("review_prompt_snapshot")
    snapshot_module.SNAPSHOTS = {}
    monkeypatch.setitem(sys.modules, "review_prompt_snapshot", snapshot_module)
    monkeypatch.setenv("ARKS_PROMPT_MODE", "deployment_snapshot")

    with pytest.raises(RuntimeError, match="missing from deployment snapshot"):
        _load_loader().load_snapshot("dev_gaia_experiments.arks.arks_agent", "agent")
