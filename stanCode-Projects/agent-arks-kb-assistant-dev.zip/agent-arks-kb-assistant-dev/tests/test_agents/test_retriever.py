"""
Integration tests for MongoDB retriever tools.

Requires real credentials — skipped automatically if env vars are missing.

Setup:
    cp .env.example .env   # fill in MONGODB_URI, OPENROUTER_API_KEY
    cd dev
    python -m pytest tests/test_agents/test_retriever.py -v -s
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from dotenv import load_dotenv

# Ensure app/ is on sys.path
_APP_DIR = Path(__file__).resolve().parents[2] / "app"
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

# Load .env from project root before checking env vars
load_dotenv(Path(__file__).resolve().parents[2] / ".env")

# ---------------------------------------------------------------------------
# Skip entire module if required env vars are absent
# ---------------------------------------------------------------------------
_MISSING = [v for v in ("MONGODB_URI", "OPENROUTER_API_KEY") if not os.getenv(v)]
if _MISSING:
    pytest.skip(
        f"Skipping retriever tests — missing env vars: {', '.join(_MISSING)}",
        allow_module_level=True,
    )

QUERY = "申請理賠需要哪些文件？"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def vector_tool():
    from services.tools.retrievers.vector_search_tool import MongoVectorSearchTool
    return MongoVectorSearchTool.build()


@pytest.fixture(scope="module")
def hybrid_tool():
    from services.tools.retrievers.hybrid_search_tool import MongoHybridSearchTool
    return MongoHybridSearchTool.build()


# ---------------------------------------------------------------------------
# Tests — MongoVectorSearchTool
# ---------------------------------------------------------------------------

def test_vector_tool_build(vector_tool):
    """Tool should build without errors."""
    assert vector_tool is not None
    assert vector_tool.name == "mongo_vector_search"


def test_vector_tool_returns_string(vector_tool):
    """Tool should return a non-empty string for a valid query."""
    result = vector_tool._run(QUERY)
    assert isinstance(result, str)
    assert len(result) > 0
    print(f"\n[vector] result preview:\n{result[:300]}")


def test_vector_tool_no_result_query(vector_tool):
    """Tool should return fallback message for irrelevant query."""
    result = vector_tool._run("banana smoothie recipe xyzzy")
    assert isinstance(result, str)
    # Either returns fallback or actual docs — both are valid
    print(f"\n[vector] no-result query response: {result[:200]}")


# ---------------------------------------------------------------------------
# Tests — MongoHybridSearchTool
# ---------------------------------------------------------------------------

def test_hybrid_tool_build(hybrid_tool):
    """Tool should build without errors."""
    assert hybrid_tool is not None
    assert hybrid_tool.name == "mongo_hybrid_search"


def test_hybrid_tool_returns_string(hybrid_tool):
    """Tool should return a non-empty string for a valid query."""
    result = hybrid_tool._run(QUERY)
    assert isinstance(result, str)
    assert len(result) > 0
    print(f"\n[hybrid] result preview:\n{result[:300]}")


# ---------------------------------------------------------------------------
# Tests — RetrieverModel predict logic (without MLflow dependency)
# ---------------------------------------------------------------------------

class _FakeRetrieverModel:
    """Minimal re-implementation of RetrieverModel.predict() for local testing."""

    def __init__(self, vector_tool, hybrid_tool):
        self._vector = vector_tool
        self._hybrid = hybrid_tool

    def predict(self, model_input):
        import pandas as pd
        results = []
        for _, row in model_input.iterrows():
            query = str(row.get("query", ""))
            tool  = str(row.get("tool", "vector")).lower()
            result = self._hybrid._run(query) if tool == "hybrid" else self._vector._run(query)
            results.append(result)
        return results


def test_retriever_model_vector(vector_tool, hybrid_tool):
    """predict() should return results for tool=vector."""
    import pandas as pd
    model = _FakeRetrieverModel(vector_tool, hybrid_tool)
    results = model.predict(pd.DataFrame([{"query": QUERY, "tool": "vector"}]))
    assert isinstance(results[0], str) and len(results[0]) > 0
    print(f"\n[RetrieverModel/vector] preview:\n{results[0][:300]}")


def test_retriever_model_hybrid(vector_tool, hybrid_tool):
    """predict() should return results for tool=hybrid."""
    import pandas as pd
    model = _FakeRetrieverModel(vector_tool, hybrid_tool)
    results = model.predict(pd.DataFrame([{"query": QUERY, "tool": "hybrid"}]))
    assert isinstance(results[0], str) and len(results[0]) > 0
    print(f"\n[RetrieverModel/hybrid] preview:\n{results[0][:300]}")


def test_retriever_model_default_tool(vector_tool, hybrid_tool):
    """predict() should default to vector when tool column absent."""
    import pandas as pd
    model = _FakeRetrieverModel(vector_tool, hybrid_tool)
    results = model.predict(pd.DataFrame([{"query": QUERY}]))
    assert isinstance(results[0], str) and len(results[0]) > 0
