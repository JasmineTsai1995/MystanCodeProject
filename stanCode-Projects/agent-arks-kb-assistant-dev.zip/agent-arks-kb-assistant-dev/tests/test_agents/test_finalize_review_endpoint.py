"""Tests for the idempotent Review App endpoint finalization task."""

from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path


_SCRIPT_PATH = (
    Path(__file__).resolve().parents[2]
    / "app"
    / "services"
    / "scripts"
    / "finalize_review_endpoint.py"
)


def test_finalize_waits_for_ready_endpoint_before_smoke_query(monkeypatch):
    captured = {"verification": []}

    mlflow = types.ModuleType("mlflow")
    mlflow.set_tracking_uri = lambda uri: captured.setdefault("tracking_uri", uri)
    mlflow.set_experiment = lambda experiment: captured.setdefault("experiment", experiment)

    agents = types.SimpleNamespace(
        PermissionLevel=types.SimpleNamespace(CAN_QUERY="CAN_QUERY"),
        set_permissions=lambda **kwargs: captured.setdefault("permissions", kwargs),
    )
    databricks = types.ModuleType("databricks")
    databricks.agents = agents

    class EndpointStateReady:
        READY = "READY"

    class ServingEndpoints:
        def wait_get_serving_endpoint_not_updating(self, **kwargs):
            captured["wait"] = kwargs
            return types.SimpleNamespace(state=types.SimpleNamespace(ready="READY"))

    sdk = types.ModuleType("databricks.sdk")
    sdk.WorkspaceClient = lambda: types.SimpleNamespace(serving_endpoints=ServingEndpoints())
    serving = types.ModuleType("databricks.sdk.service.serving")
    serving.EndpointStateReady = EndpointStateReady

    review_app = types.SimpleNamespace(
        url="review-url",
        add_agent=lambda **kwargs: captured.setdefault("review_agent", kwargs),
    )
    labeling = types.ModuleType("mlflow.genai.labeling")
    labeling.get_review_app = lambda: review_app
    verify = types.ModuleType("verify_review_endpoint")
    verify.main = lambda args: captured["verification"].append(args)

    monkeypatch.setitem(sys.modules, "mlflow", mlflow)
    monkeypatch.setitem(sys.modules, "databricks", databricks)
    monkeypatch.setitem(sys.modules, "databricks.sdk", sdk)
    monkeypatch.setitem(sys.modules, "databricks.sdk.service", types.ModuleType("databricks.sdk.service"))
    monkeypatch.setitem(sys.modules, "databricks.sdk.service.serving", serving)
    monkeypatch.setitem(sys.modules, "mlflow.genai", types.ModuleType("mlflow.genai"))
    monkeypatch.setitem(sys.modules, "mlflow.genai.labeling", labeling)
    monkeypatch.setitem(sys.modules, "verify_review_endpoint", verify)

    spec = importlib.util.spec_from_file_location("_finalize_review_endpoint_test", _SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    module.configure_experiment_trace_location = (
        lambda **kwargs: captured.setdefault("trace_location", kwargs)
    )
    module.main(
        [
            "--review-deployment-id",
            "release-1",
            "--experiment-name",
            "/Shared/review",
            "--registered-model-name",
            "catalog.schema.review_agent",
            "--reviewers",
            "bu-reviewers",
            "--expected-prompt-version",
            "42",
            "--expected-prompt-digest",
            "digest-42",
        ]
    )

    assert captured["wait"]["name"] == "arks-agent-review"
    assert captured["review_agent"]["model_serving_endpoint"] == "arks-agent-review"
    assert captured["permissions"]["users"] == ["bu-reviewers"]
    assert captured["trace_location"]["catalog"] == "dev_gaia_experiments"
    assert captured["trace_location"]["schema"] == "arks"
    assert captured["trace_location"]["table_prefix"] == "arks_review"
    assert captured["verification"]
    assert "--uc-catalog" in captured["verification"][0]
    assert "--uc-schema" in captured["verification"][0]
    assert "--trace-table-prefix" in captured["verification"][0]
    assert "--expected-prompt-version" in captured["verification"][0]
