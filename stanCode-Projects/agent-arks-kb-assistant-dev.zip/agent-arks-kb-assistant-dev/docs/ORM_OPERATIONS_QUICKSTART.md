# 通用 ORM 操作 - 快速開始

> **🚀 5 分鐘快速上手**  
> 學會使用通用 ORM 函數，不再需要撰寫 SQL

---

## 📦 新增的檔案

```
app/database/
└── orm_operations.py          # 🆕 通用 ORM 操作核心模組

app/routes/
└── user_crud.py               # 🆕 使用範例：用戶管理 API

examples/
└── orm_operations_examples.py # 🆕 完整功能範例

docs/
├── ORM_OPERATIONS_GUIDE.md    # 🆕 詳細使用指南
└── ORM_OPERATIONS_QUICKSTART.md # 🆕 本檔案
```

---

## ⚡ 快速開始

### 步驟 1：匯入函數

```python
from database import get_db
from database import orm_operations as orm  # 使用命名空間避免命名衝突
from models.user import User
```

### 步驟 2：在 API 中使用

```python
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_db
from database import orm_operations as orm

router = APIRouter()

@router.post("/users")
async def create_user(
    username: str,
    email: str,
    db: AsyncSession = Depends(get_db)
):
    """新增用戶 - 零 SQL！"""
    user = await orm.create(
        db, User,
        username=username,
        email=email,
        is_active=True
    )
    return user.to_dict()

@router.get("/users")
async def list_users(
    skip: int = 0,
    limit: int = 10,
    db: AsyncSession = Depends(get_db)
):
    """查詢用戶 - 零 SQL！"""
    users = await orm.get_multi(
        db, User,
        filters={"is_active": True},
        order_by=["-created_at"],
        skip=skip,
        limit=limit
    )
    return [u.to_dict() for u in users]
```

---

## 🎯 核心函數一覽

| 操作 | 函數 | 範例 |
|------|------|------|
| 新增 | `create()` | `await orm.create(db, User, username="john")` |
| 查詢單筆 | `get()` | `await orm.get(db, User, id=1)` |
| 查詢多筆 | `get_multi()` | `await orm.get_multi(db, User, filters={...})` |
| 更新 | `update()` | `await orm.update(db, User, id=1, username="new")` |
| 刪除 | `delete()` | `await orm.delete(db, User, id=1)` |
| 檢查存在 | `exists()` | `await orm.exists(db, User, username="john")` |
| 計數 | `count()` | `await orm.count(db, User, filters={...})` |

---

## 💡 常用範例

### 1. 新增資料

```python
# 新增單筆
user = await orm.create(db, User, username="john", email="john@example.com")

# 批次新增
users = await orm.create_many(db, User, [
    {"username": "alice", "email": "alice@example.com"},
    {"username": "bob", "email": "bob@example.com"},
])
```

### 2. 查詢資料

```python
# 依 ID 查詢
user = await orm.get(db, User, id=1)

# 依條件查詢
user = await orm.get_by(db, User, username="john")

# 查詢多筆（過濾 + 排序 + 分頁）
users = await orm.get_multi(
    db, User,
    filters={"is_active": True},
    order_by=["-created_at"],
    skip=0,
    limit=10
)
```

### 3. 更新資料

```python
# 更新單筆
user = await orm.update(db, User, id=1, email="new@example.com")

# 批次更新
count = await orm.update_many(
    db, User,
    filters={"is_active": False},
    is_active=True
)
```

### 4. 刪除資料

```python
# 刪除單筆
success = await orm.delete(db, User, id=1)

# 批次刪除
count = await orm.delete_many(db, User, filters={"is_active": False})
```

### 5. 檢查和計數

```python
# 檢查資料是否存在
if await orm.exists(db, User, username="john"):
    raise HTTPException(status_code=400, detail="Username exists")

# 計算資料數量
total = await orm.count(db, User)
active_count = await orm.count(db, User, filters={"is_active": True})
```

---

## 📚 完整範例

### 執行範例程式

```bash
# 執行功能範例（展示所有函數）
cd app
python ../examples/orm_operations_examples.py
```

### 查看範例 API

完整的 CRUD API 範例：**`app/routes/user_crud.py`**

包含：
- ✅ 新增用戶
- ✅ 查詢用戶（單筆/多筆）
- ✅ 更新用戶
- ✅ 刪除用戶
- ✅ 用戶統計
- ✅ 檢查 username 可用性

### 註冊路由到主程式

在 `app/main.py` 中註冊路由：

```python
from routes.user_crud import router as user_crud_router

# 註冊路由
app.include_router(user_crud_router)
```

---

## ✨ 主要優勢

### 之前（需要寫 SQL）

```python
@router.get("/users")
async def list_users(db: AsyncSession = Depends(get_db)):
    # ❌ 需要寫 SQL
    stmt = select(User).where(User.is_active == True).order_by(desc(User.created_at)).offset(0).limit(10)
    result = await db.execute(stmt)
    users = result.scalars().all()
    return users
```

### 現在（零 SQL）

```python
@router.get("/users")
async def list_users(db: AsyncSession = Depends(get_db)):
    # ✅ 零 SQL，簡單明瞭
    users = await get_multi(
        db, User,
        filters={"is_active": True},
        order_by=["-created_at"],
        skip=0, limit=10
    )
    return users
```

---

## 🎓 進階學習

- **詳細指南**：[ORM_OPERATIONS_GUIDE.md](./ORM_OPERATIONS_GUIDE.md)
- **完整範例**：`examples/orm_operations_examples.py`
- **API 範例**：`app/routes/user_crud.py`

---

## ❓ 常見問題

**Q: 支援哪些 Model？**  
A: 任何 SQLAlchemy ORM Model 都可以使用。

**Q: 效能如何？**  
A: 經過優化，效能接近手寫 SQL。

**Q: 可以處理複雜查詢嗎？**  
A: `get_multi()` 支援基本過濾、排序、分頁。超複雜查詢仍可使用原生 SQL。

**Q: 支援關聯查詢嗎？**  
A: 支援！使用 `load_relationships` 參數避免 N+1 問題。

```python
users = await orm.get_multi(
    db, User,
    load_relationships=["posts", "comments"]
)
```

---

## 🎉 開始使用

1. ✅ 匯入函數
2. ✅ 在 API 中呼叫
3. ✅ 不需要寫 SQL
4. ✅ 完成功能

**就是這麼簡單！** 🚀

---

**版本**：v1.0  
**最後更新**：2025-01-24
