# Arks Agent Existing App 與 Review Endpoint 部署規格

## 1. 文件目的

目前 `arks-agent` 已經由 DAB 部署為 Databricks App。本規格不要求重新建立、
替換或重新設計該 App，而是定義如何以目前 App 所使用的同一份 Arks Agent
source code，額外新增：

1. 可被 MLflow Review App Chat UI 使用的 Model Serving endpoint。
2. 獨立的 review MLflow experiment 與 Review App 設定。
3. 最低限度的 deployment automation 與行為一致性驗證。

Production App 維持現狀；新增的 endpoint 只作為 BU review surface：

```text
Existing deployment, unchanged              New review deployment

arks-agent Databricks App                    MLflow Review App Chat UI
@invoke() / @stream()                                  |
        |                                      arks-agent-review endpoint
        |                                      ResponsesAgent adapter
        +--------------- same source / prompt / tools / Lakebase --------+
```

## 2. 官方支援結論

### 2.1 支援的流程

Databricks 官方支援以下兩條分開的發佈路徑：

| 需求 | 官方部署介面 | 本專案用途 |
| --- | --- | --- |
| 部署 agent 到 Databricks Apps | `AgentServer`、`@invoke()` / `@stream()`、DAB App resource | 正式 App |
| 部署 agent 到 Model Serving | `ResponsesAgent`、Models from Code、UC registered model、`agents.deploy()` | Review endpoint |
| Review App 即時聊天測試 | 已部署的 Model Serving endpoint | BU review |
| 對既有 App traces 進行標註 | MLflow labeling session | 正式 trace review |

### 2.2 不支援的流程

目前沒有官方機制可將一個已部署的 Databricks App resource 直接「註冊」
或「轉接」成 Model Serving endpoint。Review App Chat UI 也不接受
Databricks App URL 作為 chat agent。

因此，本規格採用以下原則：

```text
不是 App -> endpoint 轉換
也不重新部署既有 App
而是 current App source -> additional review model endpoint -> Review App
```

### 2.3 官方文件依據

| 主題 | 文件 |
| --- | --- |
| Review App Chat UI 只能連 Model Serving endpoint；不支援 Apps | [Test an app version with the Review App's Chat UI](https://docs.databricks.com/aws/en/mlflow3/genai/human-feedback/expert-feedback/live-app-testing) |
| 新式 agent 在 Apps 的 authoring/deployment 方式 | [Author an AI agent and deploy it on Databricks Apps](https://docs.databricks.com/aws/en/generative-ai/agent-framework/author-agent) |
| Model Serving agent 的 logging/register 流程 | [Log and register AI agents (Model Serving)](https://docs.databricks.com/aws/en/generative-ai/agent-framework/log-agent) |
| UC model 到 serving endpoint 的部署流程 | [Deploy an agent for generative AI applications (Model Serving)](https://docs.databricks.com/aws/en/generative-ai/agent-framework/deploy-agent) |
| `ResponsesAgent` 與 `@invoke`/`@stream` runtime 契約差異 | [Migrate an agent from Model Serving to Databricks Apps](https://docs.databricks.com/aws/en/generative-ai/agent-framework/migrate-agent-to-apps) |
| Serving agent 依賴資源與 on-behalf-of / automatic authentication | [Authentication for AI agents (Model Serving)](https://docs.databricks.com/aws/en/generative-ai/agent-framework/agent-authentication-model-serving) |
| Apps resource 與 authentication | [Authorize access to Databricks resources from a Databricks app](https://docs.databricks.com/aws/en/dev-tools/databricks-apps/resources) |
| DAB 管理 Apps | [Databricks Apps bundle resource](https://docs.databricks.com/aws/en/dev-tools/bundles/resources#app) |
| 多個 DAB bundles 共用 source files (`sync.paths`) | [Sharing bundles and bundle files](https://docs.databricks.com/aws/en/dev-tools/bundles/sharing) |
| MLflow application version 與 prompt/traces 關聯 | [Track application versions with MLflow](https://docs.databricks.com/aws/en/mlflow3/genai/prompt-version-mgmt/version-tracking/track-application-versions-with-mlflow) |

## 3. 一致性的定義與邊界

「App 與 Serving endpoint 完全一致」應定義為行為與 release provenance
一致，而不是宣稱兩個平台 runtime 完全相同。

### 3.1 必須一致

Review endpoint 必須對齊目前 App 的下列 runtime contract：

| 項目 | 要求 |
| --- | --- |
| Source code | endpoint 必須從目前 App 對應的 repository source 建置，並記錄 git SHA |
| Agent graph | 都使用 `services.core.agent.create_core_agent()` |
| Tool registry | 都使用 `services.tools.registry.get_tools()` |
| MCP server | 相同 MCP App 名稱與 URL，或由 environment policy 明確分流 |
| LLM endpoint | 相同 endpoint 名稱、temperature 及相關 generation config |
| Retrieval config | 相同 provider、index/function/MCP tool 設定、`top_k` |
| Prompt content | deployment job resolve 目前 `@production` 並將 immutable snapshot 封裝至 review model artifact |
| Python dependencies | 由單一 dependency source 產生 App 與 model dependencies |
| Request/response contract | `ResponsesAgentRequest` / response items / custom inputs 一致 |
| Trace metadata | endpoint trace 至少記錄 git SHA、resolved prompt version、surface 與 review experiment |

### 3.2 不可能物理一致的項目

| 項目 | 原因 | 規格要求 |
| --- | --- | --- |
| Runtime server | App 使用 AgentServer；Serving 使用 MLflow model runtime | 僅 adapter 不同，execution core 共用 |
| Service principal | App 與 serving endpoint 各有自己的執行 identity | 分別授予相同所需權限並納入驗證 |
| Endpoint URL / request auth | Apps API 與 Serving API 是不同服務 | 測試相同 response contract，不假設 URL 相同 |
| Trace / feedback dataset | Review App 產生的是測試與人工回饋資料 | 使用獨立 review experiment，不與 App production traces 混放 |

### 3.3 State 資源的建議政策

LLM endpoint、MCP retriever、knowledge source、prompt loader 與 Lakebase
memory 均使用既有 App 的相同設定，讓 BU 在 review UI 中驗證的對話行為
儘量貼近目前 App。

本專案接受 review endpoint 與 App 共用 `arks-lakebase`。這代表 BU
conversation 會落在同一個 memory store；為避免 conversation collision，
Review UI 或 Serving adapter 必須讓 review 對話使用可識別的 session ID
namespace，例如 `review-<reviewer>-<conversation-id>`。

需要隔離的是 MLflow experiment：

| Surface | Experiment |
| --- | --- |
| Existing Databricks App | `arks-agent-experiment` |
| New review endpoint / Review App | `arks-agent-review-experiment` |

如此可將 BU feedback、labeling 權限及 review traces 與正式流量分離，同時
保留相同 conversation memory backend 的行為。

因為 Model Serving 必須多一個 `ResponsesAgent` entrypoint，Review model
artifact 不可能和已部署 App artifact 位元組完全相同。本規格所稱的同一份
source code，是指 endpoint 直接包入並執行 App 現有的 agent graph、tools、
prompt loader、memory 與 runtime settings；新增 adapter 只處理 Serving
contract。

## 4. 現況盤點與差距

### 4.1 目前可重用的程式

| 現有檔案 | 現況 | 目標用途 |
| --- | --- | --- |
| `app/services/core/agent.py` | 提供 `create_core_agent()` | 保持為唯一 agent graph factory |
| `app/services/core/databricks_agent.py` | Active App handlers；底部保留已註解 legacy `ResponsesAgent` | App 不改動；review adapter 應重用其 execution 行為 |
| `app/services/start_server.py` | App `AgentServer` 入口 | Existing App entrypoint，不在新增 review 流程中重建 |
| `app/services/tools/registry.py` | 統一選擇 MCP / Databricks / Mongo tools | App 與 Review 共用 |
| `app/config/prompts/loader.py` | 目前固定讀取 `@production` alias | Phase 1 沿用；candidate prompt review 時再擴充 |
| `databricks.yml` | DAB 管理既有 App、experiment、resource jobs | 只增加 review deployment job 與 review experiment |
| `app/services/scripts/log_to_databricks.py` | 舊 model logging 流程已註解 | 取代為可執行的 review model registration script |
| `app/services/scripts/deploy_to_databricks.py` | 舊 serving deploy 流程已註解 | 取代為 review endpoint deployment script |

### 4.2 必須先修正的差距

| 差距 | 影響 | 需求 |
| --- | --- | --- |
| App-only `@invoke`/`@stream` handler 無法直接作為 logged model | 不能直接部署 Serving | 新增薄的 `ResponsesAgent` adapter |
| Prompt loader 寫死 `@production` alias | 若只測目前 production prompt 不構成 blocker；若 review candidate prompt，會無法隔離候選版本 | Phase 1 不改；進入 candidate promotion 流程時支援 alias/version override |
| App resources 與 logged-model resources 分開宣告 | endpoint 可能遺漏目前 App 已可用的 MCP/Lakebase 權限 | review deployment script 顯式宣告相同 resources，並 smoke test |
| App requirements 與 model `pip_requirements` 可獨立漂移 | 同 commit 仍可能執行行為不同 | 單一 lock / export 機制 |
| Legacy serving implementation 與 active App logic 已分叉 | Review 可能不是在測目前 App agent | 新 adapter 應委派給 active handler/helper，不復活複製的 legacy graph |

## 5. Target Architecture

### 5.1 程式結構

最小實作不應重構或重新部署 App。新增一個 Model Serving entrypoint，重用
現有 graph、tools、prompt loader 與 memory，並將它隨 source code 一起
打包為 logged model：

```text
app/
  services/
    core/
      agent.py                       # existing: graph factory only
      databricks_agent.py            # existing App handlers / 可重用 execution helpers
      memory/store.py                # existing: shared checkpointer policy
    entrypoints/
      review_serving_agent.py        # new: ResponsesAgent adapter for Model Serving only
    scripts/
      register_review_agent.py       # new: Models from Code + UC register
      deploy_review_endpoint.py      # new: agents.deploy + Review App setup
      verify_review_endpoint.py      # optional: resource/smoke comparison
  config/prompts/loader.py           # existing @production loader in Phase 1
databricks.yml                       # existing App bundle, unchanged
review_bundle/
  databricks.yml                     # new review-only bundle; syncs ../app source
```

Review adapter 需要直接重用目前 App 中已有的行為，而不是先改寫它們：

- session ID resolution；adapter 僅在進入共用 memory 前加上 `review-`
  namespace，以區分測試資料。
- `custom_inputs` normalize / prefilter mapping。
- prompt snapshot resolve 與 identity logging。
- `_get_agent()` lazy cache / prompt refresh。
- graph execution 與 stream item mapping。
- MLflow trace tags/metadata 更新。

### 5.2 Serving adapter 為何需要，以及如何運作

Model Serving 不會啟動 App 的 FastAPI `AgentServer`，而是載入一個
registered MLflow model，再透過其 `predict()` / `predict_stream()` 方法處理
invocation。現有 App 則是以 module-level `@invoke()` / `@stream()` handler
註冊給 `AgentServer`。因此：

- 不需要新增另一套 agent graph。
- 但需要一個可被 Model Serving 載入的 `ResponsesAgent` model entrypoint。
- 這個 entrypoint 即為 Serving adapter；它的功能是轉接 runtime contract，
  而不是實作新的 agent。

最小 adapter 的資料流如下：

```text
Review App request
  -> Model Serving invokes ArksReviewAgent.predict() / predict_stream()
  -> adapter 補上 review session namespace 後交給現有 async execution path
  -> create_core_agent() + get_tools() + prompt loader + Lakebase
  -> adapter 將 execution 結果回傳為 ResponsesAgentResponse / stream events
```

由於目前 App execution path 是 async，而 `ResponsesAgent` serving method
通常是 sync method，adapter 需要很薄的 sync-to-async bridge。Adapter 內
除 review-only session namespace 與 trace release tags 外，不可重新寫
prompt、retrieval、business session resolution 或 graph decision logic。

是否一定要 adapter：

| 選項 | 可行性 | 建議 |
| --- | --- | --- |
| 將目前 App URL 直接註冊給 Model Serving | 不支援；App URL 不是 MLflow model | 不可行 |
| 以現有 App source 新增一個薄 `ResponsesAgent` entrypoint，直接呼叫現有 handler/helper | 可行；符合官方 Model Serving contract | Phase 1 建議 |
| 先全面抽出 `agent_runtime.py` 再讓兩端改用它 | 可行，但會修改現存 App | 僅在需要長期維護或 App 本來就要更新時進行 |

Phase 1 adapter 概念範例：

```python
# review_serving_agent.py
class ArksReviewAgent(ResponsesAgent):
    def predict(self, request):
        return run_async(existing_agent_execution.invoke(request))

    def predict_stream(self, request):
        yield from bridge_async_stream(
            existing_agent_execution.stream(request)
        )

mlflow.models.set_model(ArksReviewAgent())
```

Serving adapter 的 sync-to-async bridge 是 runtime 限制造成的唯一必要差異；
agent graph、prompt、tools 與輸出 mapping 不得在 adapter 中重寫。

### 5.3 部署架構

```text
Existing arks-agent App (no deployment change)

Current repository source
        |
DAB job: register_review_agent
        |
UC model version
        |
DAB job: deploy_review_endpoint
        |
arks-agent-review Model Serving endpoint
        |
wait until endpoint READY
        |
finalize_review_endpoint (bind Review App + smoke test)
        |
MLflow Review App Chat UI
```

## 6. Deployment Configuration 與 Optional Single Release Manifest

### 6.1 是否需要 Single Release Manifest

DAB App resource 與 MLflow logged model 的 `resources=` 是不同平台設定面。
官方沒有提供一個宣告可自動同時生成兩者。但因為既有 App 在本方案中不會
重建，Phase 1 **不需要**為了建立 review endpoint 先導入 Single Release
Manifest。

Phase 1 的必要條件只有：

1. Review logging/deploy script 以目前 App 的設定宣告 LLM endpoint、
   MCP App/URL、Lakebase 與 prompt loader 行為。
2. Review endpoint 使用獨立 experiment。
3. Deployment 後跑 smoke test，確認 tool、prompt 與 memory 可用。

Single Release Manifest 的作用不是讓 endpoint 能執行，而是當以下情境發生
時，避免人工同步設定造成漂移：

| 情境 | Manifest 帶來的價值 |
| --- | --- |
| review endpoint 會反覆部署不同 candidate | 記錄每次測到的是哪些 config |
| App 之後也會更新或 promotion | 可以比較 reviewed endpoint 與後續 App deployment |
| LLM / MCP / prompt / Lakebase 設定增加 | 提供唯一 config inventory |
| 需要 audit、rollback、automated parity check | 提供 machine-readable source of truth |

因此本專案採分階段決策：

| Phase | Manifest 決策 |
| --- | --- |
| Phase 1：只把目前 App 行為提供給 BU review | Optional；可先由一個 deploy script 明確設定 |
| Phase 2：review candidate 後 promotion 到 App | Recommended |
| Phase 3：正式 release governance / audit | Required |

### 6.2 Optional manifest 範例

`deployment/release/agent_resources.yaml`：

```yaml
agent:
  name: arks-agent
  review_endpoint_name: arks-agent-review
  registered_model_name: dev_gaia_experiments.arks.arks_agent_review

runtime:
  llm_provider: databricks
  llm_endpoint: databricks-gpt-5-4
  temperature: 0.0
  retrieval_provider: mcp
  mcp_app_name: mcp-kb-retriever
  mcp_app_url: https://mcp-kb-retriever-2269228939259303.aws.databricksapps.com
  prompt_registry_name: dev_gaia_experiments.arks.arks_agent_system
  prompt_alias: production
  prompt_cache_ttl_seconds: 60

state:
  lakebase: arks-lakebase

tracking:
  app_experiment: /Users/allen.wu@cathay-ins.com.tw/arks-agent-experiment
  review_experiment: /Users/allen.wu@cathay-ins.com.tw/arks-agent-review-experiment
  app_trace_table_prefix: dev_gaia_experiments.arks.arks_agent
  review_trace_table_prefix: dev_gaia_experiments.arks.arks_review
```

### 6.3 最低 deployment record

每次 review deployment 必須生成 release metadata，至少寫入 MLflow
LoggedModel / run tags：

| Tag / Param | 範例 |
| --- | --- |
| `arks.review_deployment_id` | `arks-review-20260525-a1b2c3d` |
| `git.commit` | 完整 commit SHA |
| `arks.surface` | `review_endpoint` |
| `arks.environment` | `review` |
| `arks.prompt.name` | `dev_gaia_experiments.arks.arks_agent_system` |
| `arks.prompt.version` | 不可變 version number |
| `arks.llm_endpoint` | `databricks-gpt-5-4` |
| `arks.retrieval_provider` | `mcp` |
| `arks.mcp_app_name` | `mcp-kb-retriever` |
| `arks.dependency_lock_digest` | lock file hash |

MLflow application version tracking 的官方做法可將 code version、prompt
versions、traces 與 evaluation 關聯在同一 LoggedModel 下。若目前目的僅是
讓 BU 測試 existing App 對應行為，記錄 review endpoint 自身的 model
version 與 resolved prompt version 即已足夠；只有後續要把 review 結果
當作 App promotion gate 時，才需要讓 App deployment 也帶相同 release
identity。

## 7. Prompt 一致性規格

### 7.1 `@production` alias 的使用邊界

Existing App 仍可在 runtime 讀：

```python
prompts:/<registry_name>@production
```

是否有問題取決於 Review App 的用途：

| 使用情境 | `@production` 是否可接受 | 原因 |
| --- | --- | --- |
| BU 要測目前已上線 App 的相同行為 | deployment 時可接受 | review endpoint capture 當下 resolved production version，而非 runtime 跟隨 alias |
| BU 要測尚未上線的新 prompt | 不可接受 | endpoint 若也讀 `@production`，就沒有測到 candidate |
| Review 結果要作 audit / release approval 證據 | 僅讀 alias 不足 | alias 可移動，無法只靠 alias 重現當時內容 |

Review endpoint 不在 runtime 讀 Prompt Registry。原因是 Model Serving
automatic authentication 不涵蓋 Prompt Registry；改為 deployment job
identity 讀取 alias，才可保留 LLM、MCP App 與 Lakebase 的 automatic
authentication，並固定 BU 所評估的 prompt version。

### 7.2 Phase 1 行為

Review endpoint 的 prompt 行為：

```text
Existing App       -> prompts:/<name>@production
Deploy job         -> resolve prompts:/<name>@production
Review endpoint    -> bundled immutable prompt snapshot
Required metadata  -> source=mlflow_snapshot / resolved version / digest
```

Snapshot mode 找不到 artifact、digest 不一致或 trace 顯示 YAML fallback
時，smoke test 必須失敗，該 release 不可提供 BU 驗收。

### 7.3 後續 candidate promotion 才需要的擴充

當目標改為讓 BU 測試尚未正式發布的新 prompt，loader 才需支援：

```text
ARKS_PROMPT_VERSION 已設定 -> prompts:/<name>/<exact-version>
ARKS_PROMPT_ALIAS 已設定   -> prompts:/<name>@<alias>
未設定                       -> @production
```

可能的 promotion 流程：

```text
1. 註冊新的 prompt version V42
2. Review endpoint 指定 ARKS_PROMPT_VERSION=42
3. BU review + automated evaluation
4. 通過後將 production alias 指到 V42，或在下一次 App deployment 固定 V42
```

## 8. Resource 與 Authentication 規格

### 8.1 共用 dependency contract

| Resource | App resource 設定 | Logged model resource 設定 | 一致性要求 |
| --- | --- | --- | --- |
| Foundation Model endpoint | `serving_endpoint: databricks-gpt-5-4` | `DatabricksServingEndpoint(endpoint_name=...)` | 相同 endpoint |
| MCP retriever App | `app: mcp-kb-retriever`, `CAN_USE` | `DatabricksApp(app_name=...)` | 相同 App，且兩個 identity 都有權限 |
| MCP URL | env `MCP_APP_URL` | serving environment variable `MCP_APP_URL` | Phase 1 由 review deployment config 設為同值 |
| Prompt Registry | App runtime identity permissions | deployment job identity permission | Serving runtime 不讀 Registry；model artifact 使用 captured snapshot |
| Lakebase | App resource/manual grant | `DatabricksLakebase(...)` | 共用 `arks-lakebase`；review session ID 可辨識 |
| MLflow experiment | App experiment resource | review experiment configured during logging/deploy | 分開儲存 traces，release metadata 相同 |

### 8.2 Review model logging resources

`register_review_agent.py` 應使用官方 resource declaration 模式：

```python
from mlflow.models.resources import (
    DatabricksApp,
    DatabricksLakebase,
    DatabricksServingEndpoint,
)

resources = [
    DatabricksServingEndpoint(endpoint_name="databricks-gpt-5-4"),
    DatabricksApp(app_name="mcp-kb-retriever"),
    DatabricksLakebase(database_instance_name="arks-lakebase"),
]
```

若 future retrieval 改用 Vector Search 或 UC Function，必須在 review
deployment config（導入 manifest 後則在 manifest）增加設定，且 logging
時相應加入：

```python
DatabricksVectorSearchIndex(index_name=...)
DatabricksFunction(function_name=...)
```

### 8.3 權限驗證

同一 resource declaration 不代表 App SP 與 Serving SP 自動擁有完全相同
database table privilege。Deployment pipeline 必須檢查：

1. App service principal 可 query LLM endpoint、use MCP App、讀 prompt、
   存取 `arks-lakebase`。
2. Review deployment job identity 可讀取 `@production` prompts；Review
   endpoint service principal 可 query LLM endpoint、use MCP App、存取
   相同 `arks-lakebase`，但不需讀 Prompt Registry。
3. BU reviewer 僅需 `CAN_QUERY` review endpoint 與 Review App/session
   所需權限，不直接取得 production experiment 或 Lakebase 權限。

## 9. Dependency 一致性規格

### 9.1 原則

不能維護兩組人工撰寫的 dependencies：

- `app/requirements.txt`
- `mlflow.pyfunc.log_model(..., pip_requirements=[...])`

否則即使 git source 相同，runtime package version 不同也會使 agent 行為漂移。

### 9.2 建議作法

以 `pyproject.toml` 及 committed lock file 作為唯一來源，部署前產生：

```text
app/requirements.txt
deployment/release/review_model_requirements.txt
```

Model logging 時讀取 generated requirements：

```python
pip_requirements = Path(
    "deployment/release/review_model_requirements.txt"
).read_text().splitlines()
```

最低要求：

- App 與 Review model 的 agent dependency 版本完全相同。
- 將 `mlflow[databricks]` 與 `databricks-agents` pin 到經驗證的 exact
  version，不以開放式 `>=` 作 release artifact。
- release tags 記錄 lock digest。
- CI 執行 App adapter 與 Serving adapter 的 contract tests。

## 10. DAB 與部署工作流

### 10.1 官方 best practice 的採用方式

Databricks 官方文件分別建議：

- Apps 使用 DAB 管理 version-controlled deployment 與多環境資源。
- Model Serving agent 使用 Models from Code logging、UC registration 與
  `agents.deploy()`。
- Review App 連到已部署的 Serving endpoint。

官方目前沒有提供一個 DAB 宣告可從既有 App 直接產生 Models from Code
registration 與 Review App wiring。並且，對目前 `databricks.yml` 執行
`bundle deploy` 時，既有 `resources.apps.arks_agent` 仍屬於該 bundle
管理範圍。為嚴格達成「不重建或更新 existing App」，本專案應新增一個
review-only bundle。

Databricks 官方的 sharing bundles 文件支援以多個 bundle 共用 source files，
並用 `sync.paths` sync 位於 bundle root 之外的共用程式碼。因此可採用：

```text
dev/databricks.yml                 # existing App bundle，不修改、不部署
dev/app/                           # existing shared agent source
dev/review_bundle/databricks.yml   # review-only bundle
                                   # - review experiment
                                   # - review endpoint deploy job
                                   # - sync.paths: ../app

review-only DAB job 內執行 MLflow register + agents.deploy + Review App add_agent
```

### 10.2 Bundle targets

既有 App bundle targets 保持不變。新的 `review_bundle` 僅需要 review 使用的
target：

| Target | 目的 | 主要資源 |
| --- | --- | --- |
| `review` | BU review existing behavior 或 future candidate | review experiment、review deploy job、review endpoint |

### 10.3 Bundle jobs

新增 `review_bundle/databricks.yml`；不要在既有 App bundle 中加入 review
resource：

```yaml
bundle:
  name: arks_agent_review

sync:
  paths:
    - ../app

resources:
  experiments:
    arks_review_experiment:
      name: "/Users/allen.wu@cathay-ins.com.tw/arks-agent-review-experiment"

  jobs:
    arks_deploy_review_endpoint:
      name: "Arks Deploy Review Endpoint"
      parameters:
        - name: review_deployment_id
          default: "manual-review"
      tasks:
        - task_key: register_and_deploy
          spark_python_task:
            python_file: ../app/services/scripts/deploy_review_release.py
            parameters:
              - "--review-deployment-id"
              - "{{job.parameters.review_deployment_id}}"

    arks_finalize_review_endpoint:
      name: "Arks Finalize Existing Review Endpoint"
      tasks:
        - task_key: wait_bind_and_verify
          spark_python_task:
            python_file: ../app/services/scripts/finalize_review_endpoint.py

targets:
  review:
    mode: development
```

具體 compute configuration 依 workspace policy 補齊；部署 script 不應包含
hardcoded resource 值散落在多處；Phase 1 可集中於單一 review deployment
config/script，加上 job parameters。Git SHA 應由 `bundle run` caller 明確
傳入，因為 workspace sync artifact 不保證包含 `.git` metadata。導入
manifest 後則由 manifest 讀取。

### 10.4 Review release pipeline

```text
Step 1  取得目前 App 對應 source revision，記錄 git SHA
Step 2  cd review_bundle && databricks bundle deploy -t review
        （review-only bundle，只建立/更新 review experiment 與 job）
Step 3  cd review_bundle && databricks bundle run arks_deploy_review_endpoint -t review
Step 4  Script logging model using review_serving_agent.py
Step 5  Register UC model version with review deployment metadata
Step 6  Validate model input/output contract before endpoint deployment
Step 7  agents.deploy(... endpoint_name="arks-agent-review")
Step 8  Configure endpoint env to match current App (`@production`, MCP, `arks-lakebase`)
Step 9  Wait for endpoint configuration update to complete and endpoint state READY
Step 10 Add/update endpoint in MLflow Review App
Step 11 Run endpoint smoke test through the Responses API; open BU review
```

以上步驟不對 existing App bundle 執行 `bundle deploy` 或
`databricks bundle run arks_agent`，因此不更新 existing App。

若 `agents.deploy()` 已成功送出 endpoint create/update，但 job 在 endpoint
尚未 READY 前中止，不應重新執行 registration + deployment task，否則可能
產生未實際 serving 的額外 UC model version。此情況改執行
`arks_finalize_review_endpoint`，等待既有 endpoint READY 後完成 Review App
binding 與 smoke test。

### 10.5 Optional candidate promotion pipeline

```text
Step 1  Future candidate changes code or prompt, not merely exposes existing App behavior
Step 2  Fix candidate prompt/version and deploy it to the review endpoint
Step 3  Confirm BU feedback / required evaluations
Step 4  Promote reviewed code/prompt through the existing App deployment process
```

這是後續 governance enhancement，不是建立 Review App 的前置條件。

## 11. Model Logging 與 Endpoint Deployment 規格

### 11.1 Registration script responsibilities

`register_review_agent.py` 必須：

1. 讀取 review deployment configuration；Phase 1 可由 script/job parameters
   提供，manifest 非必要。
2. 設定 review MLflow experiment。
3. 以 deployment job identity resolve `@production` prompts，產生內含
   content、version 與 digest 的 immutable snapshot module。
4. 使用 `services/entrypoints/review_serving_agent.py` 執行 Models from
   Code logging，且將 snapshot module 打包至 model artifact。
5. 宣告所有 dependent Databricks resources。
6. 使用與 App 相同 dependency export。
7. 將 logged model 註冊至固定 UC model，例如
   `dev_gaia_experiments.arks.arks_agent_review`。
8. 記錄 model version、run ID、release tags，供 deployment task 使用。

### 11.2 Deployment script responsibilities

`deploy_review_endpoint.py` 必須：

1. 取得 registration step 產生的 UC model version。
2. 使用明確 endpoint name，避免每次產生新的 endpoint：

   ```python
   agents.deploy(
       "dev_gaia_experiments.arks.arks_agent_review",
       version,
       endpoint_name="arks-agent-review",
       scale_to_zero=True,
   )
   ```

3. 設定/驗證 endpoint 所需 environment variables：

   ```text
   LLM_PROVIDER=databricks
   DATABRICKS_LLM_ENDPOINT=databricks-gpt-5-4
   RETRIEVAL_PROVIDER=mcp
   MCP_APP_URL=<same value used by existing App>
   DATABRICKS_LAKEBASE_NAME=arks-lakebase
   ARKS_REVIEW_DEPLOYMENT_ID=<review deployment ID>
   ARKS_GIT_COMMIT=<repository SHA>
   ARKS_REVIEW_SESSION_PREFIX=review
   ARKS_PROMPT_MODE=deployment_snapshot
   ```

4. 等候 endpoint READY 後執行 smoke tests。
5. 以 idempotent 方式將 `arks-agent-review` 加入或更新至 Review App。
6. 驗證 endpoint traces 進入 `arks-agent-review-experiment`，而不是既有
   App experiment。

`ResponsesAgent` endpoint 的 smoke query 必須使用官方 OpenAI-compatible
Responses API，例如 `DatabricksOpenAI().responses.create(input=...,
extra_body={"custom_inputs": ...})`；不可使用 custom pyfunc endpoint 的
`WorkspaceClient.serving_endpoints.query(inputs=...)` envelope。

## 12. Tracing、Feedback 與 Evaluation

### 12.1 Tracing

現有 App 的 tracing 設定保持不變。Review endpoint 必須啟用 MLflow tracing，
並對每次 root trace 至少加入：

```text
arks.review_deployment_id
arks.surface = review_endpoint
arks.prompt.version
arks.git.commit
arks.runtime.adapter
arks.session_source
```

若後續更新 App 以支援正式 promotion tracking，再讓 App traces 加入相同
release identity；這不是 Phase 1 建立 Review App 的 blocker。

### 12.2 Experiment 隔離

| Surface | Experiment | 理由 |
| --- | --- | --- |
| Databricks App production | `arks-agent-experiment` | 真實服務 traces 與 production monitoring |
| Review endpoint | `arks-agent-review-experiment` | BU 測試資料、comments、labeling 權限隔離 |

Reviewer 不應因為參與 review 而讀取 production experiment 的全部 traces。

### 12.3 Optional feedback 回流與 future promotion

Review 流程完成後：

1. 將有價值的 BU conversations 轉為 evaluation dataset records。
2. 將期望回答、approval/rejection 與 comment 保存為 regression assets。
3. 以相同 dataset 對 endpoint candidate 與 promoted App 執行 smoke /
   regression evaluation。
4. 只 promotion 通過 defined threshold 的 release。

## 13. Verification 與 Release Gate

### 13.1 Static parity checks

`verify_review_endpoint.py` 在 deployment 前後檢查：

| Check | Failure condition |
| --- | --- |
| Git identity | registered model 未記錄所使用的 repository SHA |
| Dependency digest | App requirements 與 model requirements agent packages 不同 |
| LLM configuration | endpoint 或 generation config 不同 |
| Tool configuration | retrieval provider / MCP app / URL / top_k 不同 |
| Prompt behavior | Review 未讀到 `@production` resolved version，或 fallback 到 YAML 未被標示 |
| Resource coverage | Review model 遺漏 App 所需 external resource |
| Trace destination | Review trace 未寫入 review experiment |

### 13.2 Runtime contract tests

在相同 release candidate 下，對 App 與 endpoint 提交相同測試資料：

```json
{
  "input": [{"role": "user", "content": "請說明測試保單內容"}],
  "custom_inputs": {
    "system_code": "arks",
    "session_id": "review-contract-<release-id>-001",
    "role": ["0001"],
    "insurance_department": {"car": ["underwriting"]},
    "cathay_no": "REVIEW_TEST_USER"
  }
}
```

驗證項目：

- 兩端接受同一 request schema。
- 兩端回傳合法 `ResponsesAgentResponse` output item。
- streaming event type 與必要 custom outputs 相容。
- endpoint traces 包含 review deployment ID 與 resolved prompt version；必要時人工或測試輸出比對 App 使用的 prompt。
- MCP tool 可成功呼叫且 resource authorization 無誤。
- 共用 `arks-lakebase` 可正常持久化，且測試 session 使用 `review-*` namespace。

LLM response 文字不要求逐字相等；應以 deterministic configuration、
tool invocation 結果、schema、trace metadata 與 evaluation scorers 判定
行為一致性。

### 13.3 Release gates

| Gate | Review deployment | Production promotion |
| --- | --- | --- |
| Model load / signature validation | Required | N/A |
| Endpoint/App smoke test | Endpoint required | Optional future process |
| Resource/auth validation | Required for endpoint | Optional future process |
| Resolved `@production` prompt version/digest recorded and trace verified | Required | Optional future candidate rule |
| BU feedback completed | Review App available | Optional future promotion rule |
| Automated regression eval | Recommended | Optional future promotion rule |

## 14. 運維與成本 Best Practices

| 項目 | 建議 |
| --- | --- |
| Review endpoint 命名 | 固定使用 `arks-agent-review`，以更新 model version 取代累積 endpoint |
| Scale-to-zero | Review endpoint 開啟 `scale_to_zero=True`，接受 cold start |
| Lifecycle | review endpoint 僅供候選測試，不承接 production traffic |
| Stateful data | 共用 `arks-lakebase`；review session ID 使用清楚 namespace |
| Prompt behavior | Deployment 時 capture `@production` immutable snapshot；alias 更新後部署新的 model version |
| Rollback | Review endpoint rollback 以 review deployment ID / UC model version 可追溯 |
| Sensitive feedback | Review experiment 僅授予 BU 必要權限，不分享 production traces |
| Manual operations | 避免 notebook 作部署主流程；以 DAB-managed jobs 或 CI 執行 |

## 15. 實作階段

### Phase 1: Establish review endpoint without changing production

- 新增 `review_serving_agent.py`，以薄 wrapper 委派現有 active
  handler/helper；不復活註解中的複製版 legacy implementation。
- 若實作驗證顯示 decorated handler 不能被 Model Serving wrapper 安全呼叫，
  才評估抽取 common runtime；該變更因觸及 App source，另行安排 App 部署。
- 新增 review model register/deploy scripts。
- 新增 review experiment 與 bundle deployment job。
- 宣告與 App 相同的 LLM、MCP App、`arks-lakebase` resources。
- 將 deployment-time prompt snapshot 封裝入 review model artifact，endpoint
  runtime 不存取 Prompt Registry。
- 將 endpoint 連入 Review App。
- Existing App 保持原部署與 API 不變，不重新建立或啟動。

### Phase 2: Enforce release parity

- 視需要新增 release manifest。
- 視需要讓 deployment job 支援指定 candidate/exact prompt version。
- 統一 dependency export / lock。
- 新增 parity validation 與 smoke tests。
- App 與 endpoint trace 加入 release metadata。

### Phase 3: Release governance

- Review feedback 回流 evaluation dataset。
- 定義 automated evaluation + BU approval gate。
- 建立 candidate-to-production promotion workflow。
- 將 rollback、data retention 與 permissions audit 納入操作手冊。

## 16. 驗收條件

此方案完成的定義如下：

1. 既有 `arks-agent` Databricks App 未因新增 Review App 而重建、替換或
   改變 API。
2. 從目前 App 所使用的 source 可部署出 `arks-agent-review` serving endpoint 並在
   MLflow Review App Chat UI 中互動。
3. App 與 review endpoint 都從同一 core factory、tool registry 及 request
   normalization logic 執行 agent。
4. 每次 review deployment 均記錄 captured `@production` prompt version、
   digest、git SHA、dependencies digest、resources 與 trace metadata，且
   trace 證明 runtime 使用 `mlflow_snapshot`。
5. App 與 Review endpoint 的外部 resource contract 通過 automatic parity
   validation。
6. Review endpoint 與 App 可共用 `arks-lakebase`，且 review sessions 可識別。
7. Review traces 與 feedback 寫入獨立 review experiment。

## 17. 決策摘要

| Decision | 選擇 |
| --- | --- |
| Existing App | 保持既有 DAB 部署，不納入 Phase 1 重建流程 |
| Review UI runtime | 額外部署 Model Serving endpoint |
| Code reuse | 共用 execution runtime；僅保留兩個 platform adapters |
| Endpoint registration | Models from Code -> UC model -> `agents.deploy()` |
| Deployment 操作入口 | DAB 新增 review experiment/job；job 執行 MLflow/Serving 動作 |
| Prompt consistency | Deployment job capture `@production` immutable snapshot；trace 記錄 resolved version/digest |
| Resource consistency | Review endpoint 顯式重用 App 的 LLM、MCP、`arks-lakebase`；manifest 為後續選項 |
| Feedback governance | Review experiment 隔離，核准資料回流 evaluation dataset |
