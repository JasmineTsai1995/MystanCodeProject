# 完整專案結構範例 - 用戶管理模組

**日期**: 2025-11-18  
**類型**: 架構示範  
**狀態**: ✅ 完成並測試通過

---

## 🎯 概述

本文件展示如何使用專案的標準結構建立一個完整的功能模組，並說明每個資料夾的核心價值和協作方式。

### 範例模組：用戶管理 (User Management)

- ✅ 完整的 CRUD 操作
- ✅ 用戶認證（登入）
- ✅ 密碼雜湊和驗證
- ✅ 資料驗證和序列化
- ✅ 業務邏輯封裝
- ✅ 統計和分析功能

---

## 📂 專案結構與核心價值

```
app/
├── models/                    # 🗄️ 資料層 - 資料庫 ORM 模型
│   ├── base.py               # SQLAlchemy Base 類別
│   └── user.py               # User 資料庫模型
│
├── schemas/                   # 📋 驗證層 - API 請求/回應驗證
│   └── user.py               # User Pydantic Schemas
│
├── utils/                     # 🔧 工具層 - 可重用工具函數
│   └── hash.py               # 密碼雜湊工具
│
├── services/                  # 💼 業務層 - 業務邏輯封裝
│   └── user.py               # User 服務類別
│
├── routes/                    # 🌐 API層 - 路由端點定義
│   └── user.py               # User API 路由
│
├── database/                  # 🔌 資料庫管理
│   ├── connection.py         # 連線配置
│   └── session.py            # Session 管理
│
└── main.py                    # 🚀 應用程式入口
```

---

## 📚 各層詳細說明

### 1️⃣ Models 層 (app/models/user.py)

**核心價值**: 定義資料庫表結構和 ORM 對應關係

```python
# 職責
- 資料庫表定義
- ORM 欄位映射
- 約束和索引
- 資料庫層面的驗證

# 特點
- 不包含業務邏輯
- 直接對應資料庫表
- 使用 SQLAlchemy ORM
```

**範例**:
```python
@file:///D:/coding/docker/fastapi_structure_standard/app/models/user.py#20:86
```

**依賴**:
- ✅ `sqlalchemy` - ORM 框架
- ✅ `models.base.Base` - 基礎模型類別

---

### 2️⃣ Schemas 層 (app/schemas/user.py)

**核心價值**: API 請求驗證和回應序列化

```python
# 職責
- 請求資料驗證
- 回應資料序列化
- 資料格式定義
- API 文件生成

# 特點
- 使用 Pydantic 模型
- 自動驗證和轉換
- 與 ORM 模型分離
```

**Schema 類型**:

| Schema | 用途 | 說明 |
|--------|------|------|
| `UserCreate` | 請求 | 建立用戶時的輸入驗證 |
| `UserUpdate` | 請求 | 更新用戶時的輸入驗證 |
| `UserLogin` | 請求 | 登入時的憑證驗證 |
| `UserResponse` | 回應 | 返回用戶資料（不含密碼） |
| `UserListResponse` | 回應 | 用戶列表（含分頁） |

**範例**:
```python
@file:///D:/coding/docker/fastapi_structure_standard/app/schemas/user.py#48:68
```

**依賴**:
- ✅ `pydantic` - 資料驗證
- ❌ 無業務邏輯依賴

---

### 3️⃣ Utils 層 (app/utils/hash.py)

**核心價值**: 可重用的工具函數，無業務邏輯依賴

```python
# 職責
- 通用工具函數
- 獨立功能模組
- 可跨專案重用

# 特點
- 純函數（無狀態）
- 無業務邏輯
- 易於測試
```

**提供的功能**:
- `hash_password(password)` - 密碼雜湊
- `verify_password(plain, hashed)` - 密碼驗證
- `generate_token(length)` - 隨機 token 生成

**範例**:
```python
@file:///D:/coding/docker/fastapi_structure_standard/app/utils/hash.py#16:42
```

**依賴**:
- ✅ `hashlib` (標準庫)
- ✅ `secrets` (標準庫)
- ❌ 無專案內部依賴

---

### 4️⃣ Services 層 (app/services/user.py)

**核心價值**: 業務邏輯封裝和資料操作抽象

```python
# 職責
- 業務邏輯實現
- 資料庫操作封裝
- 錯誤處理統一
- 可重用的業務方法

# 特點
- 與 API 解耦
- 可單獨測試
- 集中管理業務規則
```

**核心方法**:

| 方法 | 功能 | 業務邏輯 |
|------|------|----------|
| `create_user()` | 建立用戶 | 唯一性檢查、密碼雜湊 |
| `authenticate_user()` | 用戶認證 | 多方式登入、密碼驗證、狀態檢查 |
| `update_user()` | 更新用戶 | 部分更新、密碼處理 |
| `get_users()` | 獲取列表 | 分頁、篩選 |

**範例**:
```python
@file:///D:/coding/docker/fastapi_structure_standard/app/services/user.py#141:187
```

**依賴**:
- ✅ `models.user.User` - ORM 模型
- ✅ `schemas.user.*` - 資料驗證
- ✅ `utils.hash.*` - 工具函數
- ✅ `sqlalchemy` - 資料庫操作

---

### 5️⃣ Routes 層 (app/routes/user.py)

**核心價值**: API 端點定義和請求處理

```python
# 職責
- API 端點定義
- 請求/回應處理
- 依賴注入整合
- HTTP 狀態碼管理

# 特點
- 薄控制器（thin controller）
- 業務邏輯委託給 Service
- 自動文件生成
```

**API 端點**:

```
POST   /api/users/init              - 初始化資料庫表
POST   /api/users/                  - 建立新用戶
GET    /api/users/                  - 獲取用戶列表（分頁）
GET    /api/users/{id}              - 獲取單一用戶
PUT    /api/users/{id}              - 更新用戶
DELETE /api/users/{id}              - 刪除用戶
POST   /api/users/login             - 用戶登入
GET    /api/users/stats/summary     - 用戶統計
GET    /api/users/architecture/info - 架構說明
```

**範例**:
```python
@file:///D:/coding/docker/fastapi_structure_standard/app/routes/user.py#108:132
```

**依賴**:
- ✅ `schemas.user.*` - 請求/回應驗證
- ✅ `services.user.UserService` - 業務邏輯
- ✅ `database.get_async_session` - 資料庫 Session
- ✅ `fastapi` - 路由框架

---

## 🔄 資料流程圖

```
Client Request
      ↓
[Routes Layer] - 接收請求
      ↓
  驗證請求
[Schemas Layer] - UserCreate/UserLogin
      ↓
  呼叫服務
[Services Layer] - UserService
      ↓           ↙        ↘
  業務邏輯    [Utils]     [Models]
  密碼處理    hash.py     User ORM
      ↓
  資料庫操作
[Database Layer]
      ↓
  返回資料
[Services Layer]
      ↓
  序列化回應
[Schemas Layer] - UserResponse
      ↓
[Routes Layer] - 返回 JSON
      ↓
Client Response
```

---

## 🧪 完整測試流程

### 1. 初始化資料庫

```bash
curl -X POST http://localhost:8000/api/users/init
```

**回應**:
```json
{
  "status": "success",
  "message": "Database tables created successfully",
  "tables": ["users"]
}
```

### 2. 建立用戶

```bash
curl -X POST http://localhost:8000/api/users/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice",
    "email": "alice@example.com",
    "full_name": "Alice Wang",
    "password": "securePassword123"
  }'
```

**回應**:
```json
{
  "id": 1,
  "username": "alice",
  "email": "alice@example.com",
  "full_name": "Alice Wang",
  "is_active": true,
  "is_superuser": false,
  "created_at": "2025-11-18T12:00:00Z",
  "updated_at": "2025-11-18T12:00:00Z"
}
```

### 3. 用戶登入

```bash
curl -X POST http://localhost:8000/api/users/login \
  -H "Content-Type: application/json" \
  -d '{
    "username_or_email": "alice",
    "password": "securePassword123"
  }'
```

**驗證流程** (Services Layer):
1. ✅ 查找用戶（username 或 email）
2. ✅ 驗證密碼（使用 Utils）
3. ✅ 檢查帳號狀態
4. ✅ 返回用戶資訊

### 4. 獲取用戶列表

```bash
curl "http://localhost:8000/api/users/?skip=0&limit=10"
```

**回應**:
```json
{
  "total": 2,
  "users": [
    {
      "id": 1,
      "username": "alice",
      "email": "alice@example.com",
      "full_name": "Alice Wang",
      ...
    },
    {
      "id": 2,
      "username": "bob",
      "email": "bob@example.com",
      ...
    }
  ]
}
```

### 5. 用戶統計

```bash
curl http://localhost:8000/api/users/stats/summary
```

**回應**:
```json
{
  "total": 2,
  "active": 2,
  "inactive": 0,
  "active_rate": "100.0%"
}
```

---

## 📊 實測結果

| 測試項目 | 狀態 | 說明 |
|---------|------|------|
| 資料庫初始化 | ✅ | 成功建立 users 表 |
| 建立用戶 | ✅ | ID=1, username=alice |
| 用戶登入 | ✅ | 密碼驗證通過 |
| 建立第二個用戶 | ✅ | ID=2, username=bob |
| 獲取用戶列表 | ✅ | 返回 2 筆資料 |
| 用戶統計 | ✅ | total=2, active=2, active_rate=100.0% |
| 架構說明端點 | ✅ | 返回完整架構資訊 |

---

## 🎓 架構優勢總結

### 1. **關注點分離 (Separation of Concerns)**
- 每層負責特定功能
- 易於維護和擴展
- 降低耦合度

### 2. **可測試性 (Testability)**
- 每層可獨立測試
- Services 和 Utils 純業務邏輯
- 易於模擬 (Mock) 依賴

### 3. **可重用性 (Reusability)**
- Utils 函數跨專案重用
- Services 方法可在多個 Routes 使用
- Schemas 可用於不同場景

### 4. **可維護性 (Maintainability)**
- 清晰的資料夾結構
- 統一的命名慣例
- 完整的文件註解

### 5. **可擴展性 (Scalability)**
- 新增功能只需添加對應層
- 不影響現有程式碼
- 支援模組化開發

---

## 🚀 如何使用這個範例

### 開發新功能時的步驟：

1. **定義資料模型** (models/)
   ```python
   # app/models/product.py
   class Product(Base):
       __tablename__ = "products"
       # ... 欄位定義
   ```

2. **建立 Schemas** (schemas/)
   ```python
   # app/schemas/product.py
   class ProductCreate(BaseModel):
       # ... 請求驗證
   ```

3. **實作工具函數** (utils/) - 如需要
   ```python
   # app/utils/price.py
   def calculate_discount(...):
       # ... 工具邏輯
   ```

4. **建立 Service** (services/)
   ```python
   # app/services/product.py
   class ProductService:
       async def create_product(...):
           # ... 業務邏輯
   ```

5. **定義 API 路由** (routes/)
   ```python
   # app/routes/product.py
   @router.post("/")
   async def create_product(...):
       # ... API 端點
   ```

6. **註冊路由** (main.py)
   ```python
   from routes import product
   app.include_router(product.router)
   ```

---

## 📖 相關文件

- [DEVELOPMENT.md](../DEVELOPMENT.md) - 開發指南
- [DB_PATTERNS_GUIDE.md](./DB_PATTERNS_GUIDE.md) - 資料庫操作模式完整指南

---

## ✅ 檢查清單

完成本範例後，您應該了解：

- [x] Models 層的職責和使用方式
- [x] Schemas 層如何驗證和序列化資料
- [x] Utils 層如何提供可重用工具
- [x] Services 層如何封裝業務邏輯
- [x] Routes 層如何定義 API 端點
- [x] 各層之間的資料流程和依賴關係
- [x] 如何使用依賴注入整合各層
- [x] 完整的 CRUD 操作實作
- [x] 認證和授權的基本模式

---

**完成時間**: 2025-11-18 12:40 UTC+8  
**測試狀態**: ✅ 全部通過  
**版本**: 1.0.0
