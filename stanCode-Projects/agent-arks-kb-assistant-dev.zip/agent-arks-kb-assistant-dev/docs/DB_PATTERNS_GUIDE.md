# 資料庫操作模式完整指南

本專案支援 **4 種資料庫操作模式**，各有獨立的 Route + Service 檔案，
遵循 **Route → Schema → Service(Facade) → Database** 分層架構。
所有 DB 參數統一由 `app/config/settings.py` 管理。

---

## 模式總覽

| # | 模式 | 底層技術 | 適用場景 | 端點前綴 | 端點數 |
|---|------|---------|---------|---------|-------|
| 1 | SQLAlchemy AsyncEngine | asyncpg | ORM 操作、原生 SQL、完整 CRUD | `/api/db/sqlalchemy/` | 9 |
| 2 | psycopg AsyncConnectionPool | psycopg | 高效原生 SQL、完整 CRUD | `/api/db/psycopg/` | 8 |
| 3 | OCP Tool API | HTTP requests | 跨網路環境、無需直連 DB、含 CRUD 範例 | `/api/db/ocp/` | 11 |
| 4 | 完整分層架構 | SQLAlchemy ORM + orm_operations | 業務 CRUD（標準開發模式） | `/api/sample/items/` | 5 |

### 架構圖

```
┌───────────────────────────────────────────────────────────────────┐
│  Routes（API 端點 — 薄控制器）                                      │
│  db_sqlalchemy.py │ db_psycopg.py │ db_ocp.py │ sample.py         │
├───────────────────┴───────────────┴───────────┴───────────────────┤
│  Schemas（請求/回應驗證）                                           │
│  db_common.py（通用 CRUD Schema）│ db_ocp.py │ sample_item.py     │
├──────────┬──────────┬──────────┬──────────────────────────────────┤
│  Services（Facade 封裝層）                                         │
│  db_sqlalchemy.py │ db_psycopg.py │ db_ocp.py │ sample_item.py   │
├──────────┴──────────┤             ├──────────────────────────────┤
│  database/session.py │             │ database/ocp_client.py       │
│  (連線池管理)         │             │ database/orm_operations.py   │
├──────────────────────┤             │ (通用 CRUD function)         │
│  database/connection.py            │                              │
│  DatabaseConfig.from_settings()    │ OCPConfig.from_settings()   │
├────────────────────────────────────┴──────────────────────────────┤
│  config/settings.py（統一參數來源）                                  │
└───────────────────────────────────────────────────────────────────┘
```

---

## 模式 1：SQLAlchemy AsyncEngine

**用途**：ORM 操作、原生 SQL 查詢、完整 CRUD、資料表管理

**驅動**：`asyncpg`（非同步 PostgreSQL 驅動）

**連線 URL**：`postgresql+asyncpg://user:pwd@host:5432/db`

**檔案對應**：
| 層級 | 檔案 | 職責 |
|------|------|------|
| Route | `app/routes/db_sqlalchemy.py` | 9 個 API 端點 |
| Schema | `app/schemas/db_common.py` | 通用請求/回應驗證 |
| Service | `app/services/db_sqlalchemy.py` | SQLAlchemy Facade（封裝 session 管理） |
| Database | `app/database/session.py` | 底層連線池管理 |

### Service 方法

| 方法 | 用途 |
|------|------|
| `SQLAlchemyService.init_engine_and_tables()` | 初始化引擎 + 建立 ORM 資料表 |
| `SQLAlchemyService.health_check()` | 健康檢查 |
| `SQLAlchemyService.execute_query(sql, params)` | 執行原生 SQL |
| `SQLAlchemyService.create_table(table_name, ddl_sql)` | 建立資料表 |
| `SQLAlchemyService.insert_data(table_name, data)` | 通用插入 |
| `SQLAlchemyService.query_data(table_name, ...)` | 通用查詢（過濾+排序+分頁） |
| `SQLAlchemyService.update_data(table_name, filters, data)` | 通用更新 |
| `SQLAlchemyService.delete_data(table_name, filters)` | 通用刪除 |
| `SQLAlchemyService.drop_table(table_name)` | 刪除資料表 |

### API 端點（9 個）

```
POST   /api/db/sqlalchemy/init          → 初始化引擎 + 建立 ORM 資料表
GET    /api/db/sqlalchemy/health        → 健康檢查
POST   /api/db/sqlalchemy/query         → 通用原生 SQL 查詢
POST   /api/db/sqlalchemy/table/create  → 建立資料表
POST   /api/db/sqlalchemy/data/insert   → 通用資料插入
POST   /api/db/sqlalchemy/data/query    → 通用資料查詢（過濾+排序+分頁）
PUT    /api/db/sqlalchemy/data/update   → 通用資料更新
DELETE /api/db/sqlalchemy/data/delete   → 通用資料刪除
DELETE /api/db/sqlalchemy/table/drop    → 刪除資料表
```

### 程式碼範例

```python
# 方式 1：透過 Service Facade（推薦）
from services.db_sqlalchemy import SQLAlchemyService

# 初始化
result = await SQLAlchemyService.init_engine_and_tables()

# 通用插入
result = await SQLAlchemyService.insert_data("users", {"name": "Alice", "email": "a@b.com"})

# 通用查詢
result = await SQLAlchemyService.query_data("users", filters={"is_active": True}, limit=10)

# 通用更新
result = await SQLAlchemyService.update_data("users", {"id": 1}, {"name": "Bob"})

# 通用刪除
result = await SQLAlchemyService.delete_data("users", {"id": 1})
```

```python
# 方式 2：直接使用 Database 層
from database import init_async_engine, get_async_session, DatabaseConfig
from sqlalchemy import text

config = DatabaseConfig.from_settings()
await init_async_engine(config)

session = await get_async_session()
result = await session.execute(text("SELECT version()"))
row = result.fetchone()
await session.close()
```

### 連線池參數

| 參數 | settings 欄位 | 說明 | 預設值 |
|------|-------------|------|--------|
| pool_size | `db_pool_min_size` | 連線池大小 | 2 |
| max_overflow | `db_pool_max_size - db_pool_min_size` | 最大溢出連線數 | 8 |
| pool_pre_ping | `db_pool_pre_ping` | 使用前 ping 測試 | True |
| pool_recycle | `db_pool_recycle` | 連線回收時間（秒） | 3600 |
| pool_timeout | `db_pool_timeout` | 取得連線超時（秒） | 30 |

---

## 模式 2：psycopg AsyncConnectionPool

**用途**：高效原生 SQL、完整 CRUD、LangGraph Checkpointer 整合

**驅動**：`psycopg`（PostgreSQL 原生適配器）

**連線 URL**：`postgresql://user:pwd@host:5432/db`

**安裝**：`pip install "psycopg[binary]" psycopg_pool`

**檔案對應**：
| 層級 | 檔案 | 職責 |
|------|------|------|
| Route | `app/routes/db_psycopg.py` | 8 個 API 端點 |
| Schema | `app/schemas/db_common.py` | 通用請求/回應驗證 |
| Service | `app/services/db_psycopg.py` | psycopg Facade（封裝 pool 管理） |
| Database | `app/database/session.py` | 底層連線池管理 |

### Service 方法

| 方法 | 用途 |
|------|------|
| `PsycopgService.init_pool(min_size, max_size)` | 初始化連線池 |
| `PsycopgService.health_check()` | 健康檢查 |
| `PsycopgService.execute_query(sql, params)` | 執行原生 SQL |
| `PsycopgService.insert_data(table_name, data)` | 通用插入 |
| `PsycopgService.query_data(table_name, ...)` | 通用查詢（過濾+排序+分頁） |
| `PsycopgService.update_data(table_name, filters, data)` | 通用更新 |
| `PsycopgService.delete_data(table_name, filters)` | 通用刪除 |
| `PsycopgService.get_pool_stats()` | 連線池統計 |

### API 端點（8 個）

```
POST   /api/db/psycopg/init          → 初始化連線池
GET    /api/db/psycopg/health        → 健康檢查
POST   /api/db/psycopg/query         → 通用原生 SQL 查詢
POST   /api/db/psycopg/data/insert   → 通用資料插入
POST   /api/db/psycopg/data/query    → 通用資料查詢（過濾+排序+分頁）
PUT    /api/db/psycopg/data/update   → 通用資料更新
DELETE /api/db/psycopg/data/delete   → 通用資料刪除
GET    /api/db/psycopg/pool/stats    → 連線池統計資訊
```

### 程式碼範例

```python
# 方式 1：透過 Service Facade（推薦）
from services.db_psycopg import PsycopgService

# 初始化
result = await PsycopgService.init_pool()

# 原生 SQL
result = await PsycopgService.execute_query("SELECT version()")

# 通用插入
result = await PsycopgService.insert_data("users", {"name": "Alice"})

# 通用查詢
result = await PsycopgService.query_data("users", filters={"is_active": True})

# 通用更新
result = await PsycopgService.update_data("users", {"id": 1}, {"name": "Bob"})

# 通用刪除
result = await PsycopgService.delete_data("users", {"id": 1})
```

```python
# 方式 2：直接使用 Database 層
from database import init_async_pool, get_pool_connection, DatabaseConfig

async def set_schema(conn):
    await conn.execute("SET search_path TO my_schema")

config = DatabaseConfig.from_settings()
await init_async_pool(config, configure_callback=set_schema)

async with get_pool_connection() as conn:
    cursor = await conn.execute("SELECT * FROM users WHERE id = %(id)s", {"id": 1})
    rows = await cursor.fetchall()
```

### LangGraph 整合

psycopg 連線池可直接供 LangGraph `AsyncPostgresSaver` 使用（共用同一個 pool）：

```python
from langgraph.checkpoint.postgres import PostgresSaver
from database import get_async_pool

pool = get_async_pool()
checkpointer = PostgresSaver(pool)
```

### 連線池參數

| 參數 | settings 欄位 | 說明 | 預設值 |
|------|-------------|------|--------|
| min_size | `db_pool_min_size` | 最小連線數 | 2 |
| max_size | `db_pool_max_size` | 最大連線數 | 10 |
| max_idle | `db_pool_max_idle` | 最大空閒時間（秒） | 300 |
| max_lifetime | `db_pool_max_lifetime` | 連線最大生命週期（秒） | 3600 |

---

## 模式 3：OCP Tool API

**用途**：跨網路環境的 HTTP-based PostgreSQL 操作，無需直連資料庫

**驅動**：HTTP requests（透過 `utils/request.py`）

**特點**：
- 自動重試機制
- 自動判斷 SELECT / DML
- 支援動態切換資料庫
- 含完整 CRUD 範例端點

**檔案對應**：
| 層級 | 檔案 | 職責 |
|------|------|------|
| Route | `app/routes/db_ocp.py` | 11 個 API 端點（7 基礎 + 4 CRUD 範例） |
| Schema | `app/schemas/db_ocp.py` + `db_common.py` | OCP 專用 + 通用 CRUD Schema |
| Service | `app/services/db_ocp.py` | OCP Facade（封裝 OCPClient） |
| Database | `app/database/ocp_client.py` | 底層 HTTP Client |

### Service 方法

| 方法 | 用途 |
|------|------|
| `OCPService.test_connection(database)` | 測試連線 |
| `OCPService.execute_query(sql, database)` | 自動判斷 SELECT/DML |
| `OCPService.execute_select(sql, database)` | 執行 SELECT |
| `OCPService.execute_dml(sql, database)` | 執行 DML |
| `OCPService.execute_select_as_dict(sql, database)` | SELECT 結果轉字典列表 |
| `OCPService.get_config()` | 獲取 OCP 配置 |
| `OCPService.batch_select(queries)` | 批次 SELECT |

### API 端點（11 個）

```
# 基礎操作（7 個）
GET    /api/db/ocp/test          → 測試 OCP API 連線
POST   /api/db/ocp/query         → 自動判斷 SELECT/DML 並執行
POST   /api/db/ocp/select        → 執行 SELECT 查詢
POST   /api/db/ocp/dml           → 執行 DML 操作
POST   /api/db/ocp/select/dict   → SELECT 結果轉字典列表
GET    /api/db/ocp/config        → 獲取 OCP 配置資訊
POST   /api/db/ocp/batch/select  → 批次 SELECT 查詢

# CRUD 範例端點（4 個，使用通用 Schema，內部組裝 SQL）
POST   /api/db/ocp/data/insert   → 通用資料插入
POST   /api/db/ocp/data/query    → 通用資料查詢（過濾+排序+分頁）
PUT    /api/db/ocp/data/update   → 通用資料更新
DELETE /api/db/ocp/data/delete   → 通用資料刪除
```

### 程式碼範例

```python
# 方式 1：透過 Service Facade（推薦）
from services.db_ocp import OCPService

result = OCPService.test_connection()
result = OCPService.execute_query("SELECT * FROM users LIMIT 10")
result = OCPService.execute_dml("INSERT INTO users(name) VALUES('Alice')")
result = OCPService.execute_select_as_dict("SELECT id, name FROM users")
```

```python
# 方式 2：直接使用 Database 層
from database import OCPClient, execute_ocp_query

client = OCPClient()
result = client.execute_select("SELECT * FROM users LIMIT 10")
print(result.columns)    # ['id', 'name', ...]
print(result.data)       # [[1, 'Alice'], ...]

result = execute_ocp_query("INSERT INTO logs(msg) VALUES ('test')")
print(result.affected_rows)  # 1
```

### 配置參數

| 參數 | settings 欄位 | 說明 | 預設值 |
|------|-------------|------|--------|
| env | `ocp_env` | OCP 環境（sit/uat/prod） | sit |
| api_url | `ocp_api_url` | API URL（空則自動組合） | "" |
| default_database | `ocp_default_database` | 預設資料庫 | datdatcm |
| timeout | `ocp_timeout` | 請求超時（秒） | 30 |
| verify_ssl | `ocp_verify_ssl` | 驗證 SSL | True |
| max_retries | `ocp_max_retries` | 最大重試次數 | 3 |
| retry_delay | `ocp_retry_delay` | 重試延遲（秒） | 1.0 |

---

## 模式 4：完整分層架構（標準開發模式）

**用途**：業務 CRUD 的標準開發模式，展示 Model → Schema → Service → Route 完整串接

**底層**：SQLAlchemy ORM（透過 `database/orm_operations.py` 通用 CRUD function）

### 架構流程

```
Client 請求
  ↓
Route (routes/sample.py)        ← API 端點定義、HTTP 處理
  ↓
Schema (schemas/sample_item.py) ← 請求驗證 (Create/Update)
  ↓
Service (services/sample_item.py) ← 業務邏輯封裝
  ↓
orm_operations (database/)       ← 通用 CRUD function（不寫 SQL）
  ↓
Model (models/sample_item.py)    ← ORM 資料表定義
  ↓
Schema (schemas/sample_item.py) ← 回應序列化 (Response)
  ↓
Client 回應
```

**檔案對應**：

| 層級 | 檔案 | 職責 |
|------|------|------|
| **Route** | `app/routes/sample.py` | API 端點、HTTP 狀態碼、依賴注入 |
| **Schema** | `app/schemas/sample_item.py` | 請求驗證（Create/Update）、回應序列化（Response） |
| **Service** | `app/services/sample_item.py` | 業務邏輯、錯誤處理、呼叫 orm function |
| **ORM** | `app/database/orm_operations.py` | 通用 CRUD（create/get/get_multi/update/delete/exists/count） |
| **Model** | `app/models/sample_item.py` | SQLAlchemy ORM 資料表（SampleItem） |
| **DI** | `app/dependencies.py` | `get_db_session()` 依賴注入 |

### API 端點

```
POST   /api/sample/items           → 建立項目
GET    /api/sample/items           → 查詢列表（分頁 + 過濾）
GET    /api/sample/items/{item_id} → 取得單筆
PUT    /api/sample/items/{item_id} → 更新（部分更新）
DELETE /api/sample/items/{item_id} → 刪除
```

### 程式碼範例

**Route 層**（只做 HTTP 處理，業務邏輯委託 Service）：

```python
@router.post("/items", response_model=SampleItemResponse, status_code=201)
async def create_item(
    data: SampleItemCreate,                    # ← Schema 自動驗證
    db: AsyncSession = Depends(get_db_session), # ← 依賴注入 DB Session
) -> SampleItemResponse:
    service = SampleItemService(db)            # ← 實例化 Service
    item = await service.create_item(data)     # ← 委託業務邏輯
    return item                                # ← 自動序列化為 Response
```

**Service 層**（封裝業務邏輯，呼叫 orm function）：

```python
class SampleItemService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_item(self, data: SampleItemCreate) -> SampleItem:
        return await orm.create(self.db, SampleItem,
            title=data.title, description=data.description, is_done=False)

    async def get_items(self, skip=0, limit=10, is_done=None):
        filters = {"is_done": is_done} if is_done is not None else None
        return await orm.get_multi(self.db, SampleItem,
            filters=filters, order_by=["-created_at"], skip=skip, limit=limit)
```

### orm_operations 可用的通用 function

| function | 用途 | 範例 |
|----------|------|------|
| `create(db, Model, **kwargs)` | 建立 | `orm.create(db, User, name="A")` |
| `get(db, Model, id=1)` | 依主鍵查詢 | `orm.get(db, User, id=1)` |
| `get_by(db, Model, **filters)` | 依條件查詢單筆 | `orm.get_by(db, User, email="a@b.c")` |
| `get_multi(db, Model, ...)` | 查詢多筆（過濾/排序/分頁） | `orm.get_multi(db, User, filters={"is_active": True})` |
| `update(db, Model, id=1, **kwargs)` | 更新 | `orm.update(db, User, id=1, name="B")` |
| `delete(db, Model, id=1)` | 刪除 | `orm.delete(db, User, id=1)` |
| `exists(db, Model, **filters)` | 檢查是否存在 | `orm.exists(db, User, email="a@b.c")` |
| `count(db, Model, filters=...)` | 計數 | `orm.count(db, User)` |
| `create_many(db, Model, items)` | 批次建立 | `orm.create_many(db, User, [{...}, {...}])` |
| `update_many(db, Model, filters, **kwargs)` | 批次更新 | `orm.update_many(db, User, {"active": False}, active=True)` |
| `delete_many(db, Model, filters)` | 批次刪除 | `orm.delete_many(db, User, {"active": False})` |

---

## 統一配置管理

所有 DB 參數集中在 `app/config/settings.py`，不在 `database/` 層直接讀取環境變數。

### 設定值來源

```
.env / 環境變數
    ↓
config/settings.py（Settings 類別）
    ↓
DatabaseConfig.from_settings()  →  session.py（SQLAlchemy / psycopg）
OCPConfig.from_settings()       →  ocp_client.py（OCP）
```

### 環境變數對照

```bash
# === 資料庫連線 ===
DB_HOST=db
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=postgres
DB_NAME=fastapi_db

# === 連線池（SQLAlchemy + psycopg 共用） ===
DB_POOL_MIN_SIZE=2
DB_POOL_MAX_SIZE=10
DB_POOL_PRE_PING=true
DB_POOL_TIMEOUT=30
DB_POOL_RECYCLE=3600
DB_POOL_MAX_IDLE=300
DB_POOL_MAX_LIFETIME=3600

# === OCP Tool API ===
OCP_ENV=sit
OCP_API_URL=              # 空值則根據 OCP_ENV 自動組合
OCP_DEFAULT_DATABASE=datdatcm
OCP_TIMEOUT=30
OCP_VERIFY_SSL=True
OCP_MAX_RETRIES=3
OCP_RETRY_DELAY=1.0
```

---

## 如何選擇模式？

| 需求 | 建議模式 |
|------|---------|
| 業務 CRUD（新功能開發） | **模式 4**：完整分層架構 |
| 需要 ORM、關聯查詢、型別安全 | **模式 1**：SQLAlchemy |
| 高效能原生 SQL、批次操作 | **模式 2**：psycopg |
| LangGraph Agent 狀態持久化 | **模式 2**：psycopg（共用 pool） |
| 跨網路環境、無法直連 DB | **模式 3**：OCP Tool API |
| 簡單查詢、快速原型 | **模式 1** 或 **模式 2** |

---

## 三種 DB 的 CRUD 端點對照表

| CRUD 操作 | SQLAlchemy | psycopg | OCP |
|-----------|-----------|---------|-----|
| 初始化 | `POST /init` | `POST /init` | `GET /test` |
| 健康檢查 | `GET /health` | `GET /health` | — |
| 原生 SQL | `POST /query` | `POST /query` | `POST /query` |
| **插入** | `POST /data/insert` | `POST /data/insert` | `POST /data/insert` |
| **查詢** | `POST /data/query` | `POST /data/query` | `POST /data/query` |
| **更新** | `PUT /data/update` | `PUT /data/update` | `PUT /data/update` |
| **刪除** | `DELETE /data/delete` | `DELETE /data/delete` | `DELETE /data/delete` |
| 建表 | `POST /table/create` | — | — |
| 刪表 | `DELETE /table/drop` | — | — |
| 連線池統計 | — | `GET /pool/stats` | `GET /config` |
| SELECT(dict) | — | — | `POST /select/dict` |
| 批次查詢 | — | — | `POST /batch/select` |

---

## 套件安裝

```bash
# 基礎（SQLAlchemy + asyncpg）- 已包含在 requirements.txt
pip install sqlalchemy asyncpg

# psycopg 支援（模式 2）
pip install "psycopg[binary]" psycopg_pool

# LangGraph 支援（搭配模式 2）
pip install langgraph "psycopg[binary]" psycopg_pool
```
