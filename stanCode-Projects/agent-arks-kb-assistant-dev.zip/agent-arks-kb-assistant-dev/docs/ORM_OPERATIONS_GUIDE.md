# 通用 ORM 操作指南

> **📌 零 SQL 開發指南**  
> 使用通用 ORM 函數進行資料庫操作，無需撰寫任何 SQL 語法

---

## 📋 目錄

- [概述](#概述)
- [核心功能](#核心功能)
- [快速開始](#快速開始)
- [詳細使用說明](#詳細使用說明)
- [最佳實踐](#最佳實踐)
- [常見問題](#常見問題)

---

## 概述

### 什麼是通用 ORM 操作？

通用 ORM 操作模組（`database.orm_operations`）提供一組統一的函數介面，讓開發者可以對任何 SQLAlchemy Model 進行 CRUD 操作，而無需撰寫 SQL 語法。

### 核心優勢

✅ **零 SQL 撰寫**：完全不需要寫 SQL 語句  
✅ **統一介面**：所有 Model 使用相同的操作方式  
✅ **類型安全**：IDE 可以自動完成和類型檢查  
✅ **易於測試**：通用函數更容易進行單元測試  
✅ **符合規範**：遵循專案的分層架構和日誌規範  

---

## 核心功能

### 創建操作（Create）

| 函數 | 說明 | 範例 |
|------|------|------|
| `create()` | 新增單筆資料 | `await orm.create(db, User, username="john")` |
| `create_many()` | 批次新增多筆資料 | `await orm.create_many(db, User, items)` |

### 讀取操作（Read）

| 函數 | 說明 | 範例 |
|------|------|------|
| `get()` | 依主鍵查詢單筆 | `await orm.get(db, User, id=1)` |
| `get_by()` | 依條件查詢單筆 | `await orm.get_by(db, User, username="john")` |
| `get_multi()` | 查詢多筆（支援過濾、排序、分頁） | `await orm.get_multi(db, User, filters={...})` |

### 更新操作（Update）

| 函數 | 說明 | 範例 |
|------|------|------|
| `update()` | 更新單筆資料 | `await orm.update(db, User, id=1, username="new")` |
| `update_many()` | 批次更新多筆資料 | `await orm.update_many(db, User, filters={...}, ...)` |

### 刪除操作（Delete）

| 函數 | 說明 | 範例 |
|------|------|------|
| `delete()` | 刪除單筆資料 | `await orm.delete(db, User, id=1)` |
| `delete_many()` | 批次刪除多筆資料 | `await orm.delete_many(db, User, filters={...})` |

### 工具函數

| 函數 | 說明 | 範例 |
|------|------|------|
| `exists()` | 檢查資料是否存在 | `await orm.exists(db, User, username="john")` |
| `count()` | 計算資料數量 | `await orm.count(db, User, filters={...})` |

---

## 快速開始

### 1. 匯入函數

```python
from database import get_db
from database import orm_operations as orm  # 使用命名空間避免命名衝突
from models.user import User
```

### 2. 基本使用

```python
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

@router.post("/users")
async def create_user(
    username: str,
    email: str,
    db: AsyncSession = Depends(get_db)
):
    """新增用戶 - 無需寫 SQL"""
    user = await orm.create(
        db, User,
        username=username,
        email=email,
        is_active=True
    )
    return user.to_dict()

@router.get("/users")
async def list_users(
    skip: int = 0,
    limit: int = 10,
    db: AsyncSession = Depends(get_db)
):
    """查詢用戶列表 - 無需寫 SQL"""
    users = await orm.get_multi(
        db, User,
        skip=skip,
        limit=limit,
        order_by=["-created_at"]
    )
    return [user.to_dict() for user in users]
```

---

## 詳細使用說明

### 創建操作

#### `create()` - 新增單筆資料

```python
# 基本使用
user = await orm.create(
    db, User,
    username="john",
    email="john@example.com",
    is_active=True
)

# 自動處理時間戳記（如果 Model 有定義）
# created_at 和 updated_at 會自動設定
```

#### `create_many()` - 批次新增

```python
users_data = [
    {"username": "alice", "email": "alice@example.com"},
    {"username": "bob", "email": "bob@example.com"},
]

users = await orm.create_many(db, User, users_data)
# 返回：List[User]
```

---

### 讀取操作

#### `get()` - 依主鍵查詢

```python
# 預設使用 id 欄位
user = await orm.get(db, User, id=1)

# 使用其他欄位作為主鍵
user = await orm.get(db, User, id="uuid-string", id_field="uuid")
```

#### `get_by()` - 依條件查詢

```python
# 單一條件
user = await orm.get_by(db, User, username="john")

# 多個條件（AND）
user = await orm.get_by(
    db, User,
    username="john",
    is_active=True
)
```

#### `get_multi()` - 查詢多筆（最強大）

```python
# 1. 基本查詢
users = await orm.get_multi(db, User)

# 2. 過濾條件
users = await orm.get_multi(
    db, User,
    filters={"is_active": True}
)

# 3. 排序
users = await orm.get_multi(
    db, User,
    order_by=["-created_at", "id"]  # 前綴 "-" 表示降序
)

# 4. 分頁
users = await orm.get_multi(
    db, User,
    skip=0,
    limit=10
)

# 5. 組合查詢
users = await orm.get_multi(
    db, User,
    filters={"is_active": True, "is_superuser": False},
    order_by=["-created_at"],
    skip=0,
    limit=10
)

# 6. 預載關聯（避免 N+1 問題）
users = await orm.get_multi(
    db, User,
    load_relationships=["posts", "comments"]
)
```

---

### 更新操作

#### `update()` - 更新單筆

```python
# 更新用戶資料
user = await orm.update(
    db, User, id=1,
    username="john_updated",
    email="john_new@example.com"
)

# 如果資料不存在，返回 None
if not user:
    raise HTTPException(status_code=404, detail="User not found")
```

#### `update_many()` - 批次更新

```python
# 將所有未啟用的用戶設為啟用
affected = await orm.update_many(
    db, User,
    filters={"is_active": False},
    is_active=True
)

print(f"更新了 {affected} 筆資料")
```

---

### 刪除操作

#### `delete()` - 刪除單筆

```python
success = await orm.delete(db, User, id=1)

if success:
    print("刪除成功")
else:
    print("找不到資料")
```

#### `delete_many()` - 批次刪除

```python
# 刪除所有未啟用的用戶
affected = await orm.delete_many(
    db, User,
    filters={"is_active": False}
)

print(f"刪除了 {affected} 筆資料")
```

---

### 工具函數

#### `exists()` - 檢查存在

```python
# 檢查 username 是否已存在
if await orm.exists(db, User, username="john"):
    raise HTTPException(status_code=400, detail="Username already exists")

# 檢查多個條件
if await orm.exists(db, User, email="john@example.com", is_active=True):
    print("用戶存在且已啟用")
```

#### `count()` - 計算數量

```python
# 計算所有用戶
total = await orm.count(db, User)

# 計算啟用的用戶
active_count = await orm.count(db, User, filters={"is_active": True})

# 用於分頁
total = await orm.count(db, User, filters={...})
users = await orm.get_multi(db, User, filters={...}, skip=0, limit=10)
```

---

## 最佳實踐

### 1. 在 Routes 層使用

```python
# ✅ 推薦：在 routes 層使用
@router.get("/users")
async def list_users(db: AsyncSession = Depends(get_db)):
    users = await orm.get_multi(db, User, filters={"is_active": True})
    return users
```

### 2. 驗證資料存在

```python
# ✅ 推薦：使用 exists() 檢查資料是否已存在
if await orm.exists(db, User, username=username):
    raise HTTPException(status_code=400, detail="Username already exists")

user = await orm.create(db, User, username=username, ...)
```

### 3. 分頁和計數

```python
# ✅ 推薦：同時提供總數和分頁資料
filters = {"is_active": True}
total = await orm.count(db, User, filters=filters)
users = await orm.get_multi(db, User, filters=filters, skip=skip, limit=limit)

return {
    "total": total,
    "items": users
}
```

### 4. 錯誤處理

```python
# ✅ 推薦：處理資料不存在的情況
user = await orm.get(db, User, id=user_id)
if not user:
    raise HTTPException(status_code=404, detail="User not found")

# 或使用 update/delete 的返回值
success = await orm.delete(db, User, id=user_id)
if not success:
    raise HTTPException(status_code=404, detail="User not found")
```

### 5. 批次操作

```python
# ✅ 推薦：批次新增多筆資料
users_data = [{"username": f"user{i}", "email": f"user{i}@example.com"} for i in range(10)]
users = await orm.create_many(db, User, users_data)

# ✅ 推薦：批次更新
affected = await orm.update_many(
    db, User,
    filters={"is_active": False},
    is_active=True
)
```

---

## 常見問題

### Q1: 如何處理複雜查詢？

**A**: `get_multi()` 支援基本過濾、排序、分頁。對於非常複雜的查詢（如多表 JOIN），仍可以使用原生 SQL：

```python
from sqlalchemy import select
from database import get_db

stmt = select(User).join(Post).where(...)
result = await db.execute(stmt)
users = result.scalars().all()
```

### Q2: 如何避免 N+1 查詢問題？

**A**: 使用 `load_relationships` 參數：

```python
users = await orm.get_multi(
    db, User,
    load_relationships=["posts", "comments"]
)
```

### Q3: 支援軟刪除嗎？

**A**: 目前不直接支援。建議在 Model 加入 `deleted_at` 欄位，並使用 `update()` 設定時間：

```python
# 軟刪除
await orm.update(db, User, id=user_id, deleted_at=datetime.now())

# 查詢時過濾
users = await orm.get_multi(
    db, User,
    filters={"deleted_at": None}  # 只查詢未刪除的
)
```

### Q4: 如何處理事務？

**A**: 函數內部自動處理 commit/rollback。如需手動控制：

```python
async with db.begin():
    user = await orm.create(db, User, ...)
    profile = await orm.create(db, Profile, user_id=user.id, ...)
    # 兩個操作在同一個事務中
```

### Q5: 效能如何？

**A**: 通用函數經過優化，效能接近手寫 SQL。建議：
- 使用 `load_relationships` 避免 N+1 問題
- 使用 `skip` 和 `limit` 進行分頁
- 使用 `filters` 限制查詢範圍

---

## 範例檔案

### 完整範例

- **`examples/orm_operations_examples.py`** - 所有功能的完整範例
- **`app/routes/user_crud.py`** - 在 FastAPI 路由中的實際應用

### 執行範例

```bash
# 執行範例（需要資料庫連線）
cd app
python ../examples/orm_operations_examples.py
```

---

## 總結

通用 ORM 操作模組讓開發者可以：

✅ **不寫 SQL**，直接使用 Python 函數  
✅ **統一操作**，所有 Model 使用相同方式  
✅ **類型安全**，IDE 自動完成和檢查  
✅ **易於維護**，減少重複代碼  

**開始使用**：匯入函數 → 呼叫函數 → 完成操作 🚀

---

**版本**：v1.0  
**最後更新**：2025-01-24  
**維護者**：FastAPI 開發團隊
