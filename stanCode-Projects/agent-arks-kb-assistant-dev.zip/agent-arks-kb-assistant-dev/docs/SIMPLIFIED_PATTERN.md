# 簡化設計模式說明

**日期**: 2025-11-18  
**主題**: 簡化的服務層依賴注入模式

---

## 🎯 設計原則

**「只有一個通用 DB，直接在 routes 實例化 Service」**

```
dependencies.py  →  只提供 get_db_session()（通用）
routes/xxx.py    →  直接實例化 UserService(db)
```

---

## ✅ 簡化後的架構

### 📁 檔案結構

```
app/
├── dependencies.py          # 只管理基礎設施
│   └── get_db_session()    # ⭐ 唯一的 DB Session（通用）
│
├── services/               # 業務邏輯
│   ├── user.py            # UserService
│   ├── product.py         # ProductService
│   └── order.py           # OrderService
│
└── routes/                # API 路由
    ├── user.py           # 用戶 API（直接實例化 UserService）
    ├── product.py        # 產品 API（直接實例化 ProductService）
    └── order.py          # 訂單 API（直接實例化 OrderService）
```

---

## 📝 完整實作

### 1. dependencies.py - 只提供 DB Session

```python
# app/dependencies.py

from fastapi import Depends

async def get_db_session():
    """
    獲取資料庫 AsyncSession
    
    ⭐ 這是唯一需要的依賴注入函數
    所有 routes 都使用這個獲取 DB Session
    """
    from database import get_db as database_get_db
    async for session in database_get_db():
        yield session
```

**就這樣！不需要為每個服務建立 `get_xxx_service()` 函數**

---

### 2. services/user.py - 業務邏輯

```python
# app/services/user.py

class UserService:
    """用戶業務邏輯"""
    
    def __init__(self, db):
        self.db = db  # 接收 DB Session
    
    async def create_user(self, user_data):
        # 業務邏輯實作
        ...
    
    async def get_user_by_id(self, user_id):
        # 業務邏輯實作
        ...
```

**注意**: Service 類別不依賴 FastAPI，可在任何環境使用

---

### 3. routes/user.py - API 路由

```python
# app/routes/user.py

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from schemas.user import UserCreate, UserResponse
from services.user import UserService
from dependencies import get_db_session  # 只需要這個

router = APIRouter(prefix="/api/users")

@router.post("/", response_model=UserResponse)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db_session)  # ⭐ 注入 DB
):
    """建立新用戶"""
    # ⭐ 直接在這裡實例化 Service
    service = UserService(db)
    user = await service.create_user(user_data)
    return user


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db_session)  # ⭐ 注入 DB
):
    """獲取用戶"""
    # ⭐ 直接在這裡實例化 Service
    service = UserService(db)
    user = await service.get_user_by_id(user_id)
    return user
```

---

## 🆚 對比：之前 vs 現在

### ❌ 之前的方式（複雜）

```python
# app/dependencies.py
async def get_db_session(): ...
async def get_user_service(db = Depends(get_db_session)): ...      # 要寫這個
async def get_product_service(db = Depends(get_db_session)): ...   # 要寫這個
async def get_order_service(db = Depends(get_db_session)): ...     # 要寫這個
# 每個新 model 都要加一個函數！❌

# app/routes/user.py
@router.post("/")
async def create_user(
    user_data: UserCreate,
    service: UserService = Depends(get_user_service)  # 使用特定的依賴
):
    user = await service.create_user(user_data)
    return user
```

**問題**:
- ❌ 每次新增 model 要改 `dependencies.py`
- ❌ `dependencies.py` 會越來越長
- ❌ 增加維護複雜度

---

### ✅ 現在的方式（簡潔）

```python
# app/dependencies.py
async def get_db_session(): ...  
# ⭐ 就這一個！不需要為每個服務建立函數

# app/routes/user.py
@router.post("/")
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db_session)  # ⭐ 統一注入 DB
):
    service = UserService(db)  # ⭐ 直接實例化
    user = await service.create_user(user_data)
    return user
```

**優點**:
- ✅ `dependencies.py` 保持簡潔
- ✅ 新增 model 不需修改 `dependencies.py`
- ✅ 職責清晰：`dependencies` = 基礎設施，`routes` = API 邏輯

---

## 📊 工作流程

### 新增一個 Product 模組

#### 1️⃣ 建立 Service

```python
# app/services/product.py

class ProductService:
    def __init__(self, db):
        self.db = db
    
    async def create_product(self, product_data):
        # 實作業務邏輯
        ...
```

#### 2️⃣ 建立 Routes（直接使用）

```python
# app/routes/product.py

from dependencies import get_db_session  # 用通用的 DB Session
from services.product import ProductService

@router.post("/")
async def create_product(
    product_data: ProductCreate,
    db: AsyncSession = Depends(get_db_session)  # ⭐ 統一的 DB
):
    service = ProductService(db)  # ⭐ 直接實例化
    product = await service.create_product(product_data)
    return product
```

**完成！不需要修改 `dependencies.py`** ✅

---

## 🔄 跨服務使用場景

### 場景：訂單需要使用用戶和產品服務

```python
# app/routes/order.py

@router.post("/")
async def create_order(
    order_data: OrderCreate,
    db: AsyncSession = Depends(get_db_session)  # ⭐ 同一個 DB Session
):
    # 實例化多個服務（都用同一個 db）
    user_service = UserService(db)
    product_service = ProductService(db)
    order_service = OrderService(db)
    
    # 1. 驗證用戶
    user = await user_service.get_user_by_id(order_data.user_id)
    if not user:
        raise HTTPException(404, "User not found")
    
    # 2. 驗證產品
    product = await product_service.get_product_by_id(order_data.product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    
    # 3. 建立訂單
    order = await order_service.create_order(order_data)
    
    # ⭐ 所有操作在同一個 DB Session，自動支援交易
    return order
```

---

## 💡 為什麼這樣更好？

### 1. **簡單明瞭**
- ✅ 一眼就能看出 `service = XxxService(db)` 在做什麼
- ✅ 不需要記住每個服務的依賴函數名稱

### 2. **易於維護**
- ✅ `dependencies.py` 只管基礎設施（DB、認證等）
- ✅ 新增業務模組不影響 `dependencies.py`

### 3. **靈活性高**
- ✅ 可以輕鬆在一個端點使用多個服務
- ✅ 可以根據需要組合不同服務

### 4. **測試友好**
```python
# 測試非常簡單
async def test_create_user():
    mock_db = MockAsyncSession()
    service = UserService(mock_db)  # ⭐ 直接實例化，不需要依賴注入
    
    user = await service.create_user(user_data)
    assert user.username == "alice"
```

---

## 🎓 何時需要專門的服務依賴函數？

只有在以下情況才考慮建立 `get_xxx_service()`：

### 1. **服務需要複雜初始化**
```python
async def get_email_service(
    db = Depends(get_db_session),
    config = Depends(get_email_config),
    redis = Depends(get_redis)
):
    """Email 服務需要多個依賴"""
    return EmailService(db, config, redis)
```

### 2. **需要單例或快取**
```python
async def get_llm_service():
    """LLM 服務需要單例（避免重複載入模型）"""
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService()
    return _llm_service
```

### 3. **需要依賴鏈**
```python
async def get_advanced_user_service(
    db = Depends(get_db_session),
    cache = Depends(get_cache_service),
    notification = Depends(get_notification_service)
):
    """進階用戶服務依賴多個其他服務"""
    return AdvancedUserService(db, cache, notification)
```

**否則，直接實例化即可！** ✅

---

## 📋 檢查清單

當你需要新增業務模組時：

- [ ] ✅ 建立 `services/xxx.py` - 業務邏輯類別
- [ ] ✅ 建立 `routes/xxx.py` - API 端點
- [ ] ✅ 在 routes 中使用 `Depends(get_db_session)` 注入 DB
- [ ] ✅ 在 routes 中實例化 `service = XxxService(db)`
- [ ] ❌ **不需要** 修改 `dependencies.py`

---

## ✨ 總結

### 簡化前（3 步驟）
1. 建立 `services/user.py`
2. 在 `dependencies.py` 加 `get_user_service()`  ← 多餘
3. 在 `routes/user.py` 使用

### 簡化後（2 步驟）
1. 建立 `services/user.py`
2. 在 `routes/user.py` 直接用 `UserService(db)`  ← 簡潔！

---

**核心思想**:
- `dependencies.py` = 基礎設施層（DB、認證、快取等）
- `routes/` = 業務組裝層（實例化服務、組合邏輯）
- `services/` = 業務邏輯層（純粹的業務代碼）

---

## 🏢 補充：Service Facade 模式（DB 操作封裝）

除了上述 DI 簡化模式外，專案中的 DB 操作路由使用了另一種 Service 模式：**Facade（門面）模式**。

### 適用場景

當 Service **不需要 DB Session 依賴注入**，而是自行管理 session/pool/client 時：

```python
# 這些 DB Service 內部自己管理連線，不需要外部注入
SQLAlchemyService  → 內部使用 get_async_session()
PsycopgService     → 內部使用 get_pool_connection()
OCPService         → 內部使用 OCPClient()
```

### Facade 模式 vs DI 模式

| 特性 | DI 模式（上方介紹） | Facade 模式（DB 操作） |
|------|-------------------|---------------------|
| Session 來源 | `Depends(get_db_session)` 注入 | Service 內部自行取得 |
| Service 實例化 | `service = XxxService(db)` | `XxxService.method()` 靜態方法 |
| 適用場景 | 業務 CRUD、需要事務控制 | DB 連線封裝、隱藏複雜度 |
| 範例 | `services/sample_item.py` | `services/db_sqlalchemy.py` |

### Facade 模式範例

```python
# routes/db_sqlalchemy.py — 薄控制器
from services.db_sqlalchemy import SQLAlchemyService

@router.post("/data/insert", response_model=ExecuteResultResponse)
async def insert_data(request: TableInsertRequest):
    # 直接呼叫靜態方法，不需要注入 DB Session
    return await SQLAlchemyService.insert_data(request.table_name, request.data)
```

```python
# services/db_sqlalchemy.py — Facade Service
class SQLAlchemyService:
    @staticmethod
    async def insert_data(table_name: str, data: dict) -> dict:
        # Service 內部自行管理 session 生命週期
        session = await get_async_session()
        try:
            result = await session.execute(text(sql), data)
            await session.commit()
            return {"status": "success", "affected_rows": 1}
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
```

### 何時使用哪種模式？

- **開發業務功能**（用戶管理、訂單等） → 使用 **DI 模式**（`UserService(db)`）
- **封裝 DB 連線操作**（通用 SQL 查詢工具） → 使用 **Facade 模式**（`SQLAlchemyService.method()`）
