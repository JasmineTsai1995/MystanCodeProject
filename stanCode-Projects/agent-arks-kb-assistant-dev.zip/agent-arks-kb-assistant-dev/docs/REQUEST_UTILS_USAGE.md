# HTTP 請求工具使用指南

## 概述

`utils/request.py` 提供統一的 HTTP 請求封裝，用於調用外部 API 和微服務通訊。

## 核心功能

- **多種 HTTP 方法**: GET, POST, PUT, PATCH, DELETE
- **Pydantic Schema 驗證**: 自動驗證輸入和輸出數據
- **統一錯誤處理**: 自訂錯誤類型，便於捕獲和處理
- **靈活配置**: 支援超時、認證、標頭等多種配置
- **Session 管理**: 使用 RequestClient 保持連線池
- **日誌記錄**: 自動記錄請求和響應資訊

## Import 方式

**推薦使用 `from utils import request` 避免名稱衝突：**

```python
from utils import request

# 使用時
result = request.get("https://api.example.com")
client = request.RequestClient(base_url="...")
```

**為什麼不使用 `from utils.request import get, post`？**
- `get`, `post` 等是極其常見的函數名稱
- 容易與其他 HTTP 客戶端（如 `httpx`, `aiohttp`）混淆
- `request.get()` 更清楚表達來源和意圖

## 快速開始

### 1. 基本使用

#### 方式一：使用 `make_request` 函數

```python
from utils import request

# 簡單的 GET 請求
result = request.make_request("https://api.example.com/users")
logger.info(result)

# POST 請求
result = request.make_request(
    url="https://api.example.com/users",
    method="POST",
    json_data={"name": "John", "email": "john@example.com"}
)
```

#### 方式二：使用便捷函數

```python
from utils import request

# GET 請求
users = request.get("https://api.example.com/users")

# POST 請求
new_user = request.post(
    "https://api.example.com/users",
    json_data={"name": "John", "email": "john@example.com"}
)

# PUT 請求
updated_user = request.put(
    "https://api.example.com/users/1",
    json_data={"name": "Jane"}
)

# DELETE 請求
request.delete("https://api.example.com/users/1")
```

#### 方式三：使用 `RequestClient` 類別

```python
from utils import request

# 建立客戶端
client = request.RequestClient(
    base_url="https://api.example.com",
    default_headers={"Authorization": "Bearer token123"}
)

# 發送請求
users = client.get("/users")
new_user = client.post("/users", json_data={"name": "John"})

# 使用 context manager 自動關閉
with request.RequestClient(base_url="https://api.example.com") as client:
    result = client.get("/users")
```

## 進階使用

### 1. 使用 Pydantic Schema 驗證

#### 定義 Schema

```python
from pydantic import BaseModel, EmailStr, Field

class UserInput(BaseModel):
    """使用者輸入 Schema"""
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(..., ge=0, le=150)

class UserOutput(BaseModel):
    """使用者輸出 Schema"""
    id: int
    name: str
    email: str
    age: int
    created_at: str
```

#### 使用 Schema

```python
from utils.request import make_request

# POST 請求帶 Schema 驗證
result = make_request(
    url="https://api.example.com/users",
    method="POST",
    json_data={
        "name": "John Doe",
        "email": "john@example.com",
        "age": 30
    },
    input_schema=UserInput,   # 驗證輸入
    output_schema=UserOutput  # 驗證輸出
)

# result 是 UserOutput 的實例
logger.info(result.id)          # 1
logger.info(result.name)        # "John Doe"
logger.info(result.created_at)  # "2025-11-10T12:00:00Z"
```

#### Schema 驗證的好處

1. **型別安全**: 確保數據符合預期格式
2. **自動驗證**: 在發送前驗證輸入，接收後驗證輸出
3. **錯誤提示**: 提供清晰的驗證錯誤訊息
4. **IDE 支援**: 獲得更好的自動完成和型別提示

### 2. 帶參數的請求

#### URL 查詢參數

```python
from utils.request import get

# GET 請求帶查詢參數
users = get(
    "https://api.example.com/users",
    params={
        "page": 1,
        "limit": 10,
        "sort": "created_at",
        "order": "desc"
    }
)
# 實際請求: https://api.example.com/users?page=1&limit=10&sort=created_at&order=desc
```

#### 自訂請求標頭

```python
from utils.request import get

# 帶自訂標頭
result = get(
    "https://api.example.com/users",
    headers={
        "Authorization": "Bearer your_token_here",
        "Content-Type": "application/json",
        "X-Custom-Header": "custom_value"
    }
)
```

### 3. 認證方式

#### Basic Auth

```python
from utils import request

# HTTP Basic 認證
result = request.get(
    "https://api.example.com/protected",
    auth=("username", "password")
)
```

#### Bearer Token

```python
from utils import request

# Bearer Token 認證
result = request.get(
    "https://api.example.com/protected",
    headers={"Authorization": "Bearer your_token_here"}
)
```

#### API Key

```python
from utils import request

# API Key 認證（在標頭中）
result = request.get(
    "https://api.example.com/data",
    headers={"X-API-Key": "your_api_key_here"}
)

# API Key 認證（在查詢參數中）
result = request.get(
    "https://api.example.com/data",
    params={"api_key": "your_api_key_here"}
)
```

### 4. 超時控制

```python
from utils import request

# 設定超時時間（秒）
try:
    result = request.get(
        "https://api.example.com/slow-endpoint",
        timeout=60  # 60 秒超時
    )
except request.HTTPError as e:
    if "超時" in str(e):
        logger.info("請求超時")
```

### 5. 錯誤處理

#### 捕捉特定錯誤

```python
from utils import request

try:
    result = request.get("https://api.example.com/users/1")
except request.ValidationError as e:
    logger.info(f"數據驗證失敗: {e}")
except request.HTTPError as e:
    logger.info(f"HTTP 錯誤: {e}")
    if e.status_code == 404:
        logger.info("資源不存在")
    elif e.status_code >= 500:
        logger.info("伺服器錯誤")
except request.RequestError as e:
    logger.info(f"請求錯誤: {e}")
```

#### 不拋出異常

```python
from utils import request

# 不自動拋出 HTTP 錯誤
result = request.get(
    "https://api.example.com/users/999",
    raise_for_status=False  # 不拋出異常
)

# 手動檢查狀態碼
if result.status_code == 404:
    logger.info("使用者不存在")
```

### 6. 使用 RequestClient

#### 基本配置

```python
from utils import request

# 建立客戶端，設定基礎 URL 和預設標頭
client = request.RequestClient(
    base_url="https://api.example.com",
    default_headers={
        "Authorization": "Bearer token123",
        "Content-Type": "application/json"
    },
    default_timeout=30,
    verify=True  # 驗證 SSL 證書
)

# 所有請求都會自動加上 base_url 和預設標頭
users = client.get("/users")  # 實際請求: https://api.example.com/users
user = client.get("/users/1")
```

#### Session 管理

```python
from utils import request

# 使用 Session（保持連線，提升效能）
client = request.RequestClient(
    base_url="https://api.example.com",
    use_session=True  # 預設為 True
)

# 發送多個請求，重用連線
for i in range(10):
    user = client.get(f"/users/{i}")

# 記得關閉
client.close()
```

#### Context Manager

```python
from utils import request

# 使用 context manager 自動管理 Session
with request.RequestClient(base_url="https://api.example.com") as client:
    users = client.get("/users")
    new_user = client.post("/users", json_data={"name": "John"})
    # Session 會自動關閉
```

## 實際應用範例

### 範例 1: 調用第三方支付 API

```python
from utils import request
from config import settings
from pydantic import BaseModel

class PaymentRequest(BaseModel):
    amount: float
    currency: str
    description: str

class PaymentResponse(BaseModel):
    payment_id: str
    status: str
    amount: float
    created_at: str

# 建立支付客戶端
payment_client = request.RequestClient(
    base_url=settings.payment_api_url,
    default_headers={
        "Authorization": f"Bearer {settings.payment_api_key}",
        "Content-Type": "application/json"
    }
)

# 建立支付
def create_payment(amount: float, currency: str, description: str):
    try:
        result = payment_client.post(
            "/payments",
            json_data={
                "amount": amount,
                "currency": currency,
                "description": description
            },
            input_schema=PaymentRequest,
            output_schema=PaymentResponse
        )
        return result
    except request.ValidationError as e:
        logger.info(f"支付數據驗證失敗: {e}")
        raise
    except request.HTTPError as e:
        logger.info(f"支付 API 錯誤: {e}")
        raise

# 使用
payment = create_payment(100.0, "TWD", "購買商品")
logger.info(f"支付 ID: {payment.payment_id}")
```

### 範例 2: 微服務通訊

```python
from utils import request
from typing import Dict, Any

class UserService:
    """使用者服務客戶端"""
    
    def __init__(self):
        self.client = request.RequestClient(
            base_url="http://user-service:8001",
            default_timeout=10
        )
    
    def get_user(self, user_id: int) -> Dict[str, Any]:
        """獲取使用者資訊"""
        return self.client.get(f"/users/{user_id}")
    
    def create_user(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """建立使用者"""
        return self.client.post("/users", json_data=user_data)
    
    def update_user(self, user_id: int, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """更新使用者"""
        return self.client.put(f"/users/{user_id}", json_data=user_data)
    
    def delete_user(self, user_id: int) -> None:
        """刪除使用者"""
        self.client.delete(f"/users/{user_id}")

# 使用
user_service = UserService()
user = user_service.get_user(1)
logger.info(user)
```

### 範例 3: 資料同步服務

```python
from utils import request
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class DataSyncService:
    """資料同步服務"""
    
    def __init__(self, api_url: str, api_key: str):
        self.client = request.RequestClient(
            base_url=api_url,
            default_headers={"X-API-Key": api_key},
            default_timeout=60
        )
    
    def sync_users(self) -> List[Dict[str, Any]]:
        """同步使用者資料"""
        try:
            # 獲取外部資料
            users = self.client.get(
                "/users",
                params={"updated_since": "2025-11-01"}
            )
            
            logger.info(f"成功同步 {len(users)} 個使用者")
            return users
            
        except request.HTTPError as e:
            logger.error(f"同步失敗: {e}")
            raise
    
    def sync_products(self) -> List[Dict[str, Any]]:
        """同步產品資料"""
        try:
            products = self.client.get("/products")
            logger.info(f"成功同步 {len(products)} 個產品")
            return products
        except request.HTTPError as e:
            logger.error(f"同步失敗: {e}")
            raise

# 使用
sync_service = DataSyncService(
    api_url="https://external-api.example.com",
    api_key="your_api_key"
)
users = sync_service.sync_users()
```

### 範例 4: 批次請求

```python
from utils import request
from typing import List
import asyncio

async def fetch_user(client: request.RequestClient, user_id: int):
    """獲取單個使用者"""
    return client.get(f"/users/{user_id}")

async def fetch_users_batch(user_ids: List[int]):
    """批次獲取使用者"""
    client = request.RequestClient(base_url="https://api.example.com")
    
    # 使用 asyncio 並發請求
    tasks = [fetch_user(client, user_id) for user_id in user_ids]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    client.close()
    return results

# 使用
user_ids = [1, 2, 3, 4, 5]
users = asyncio.run(fetch_users_batch(user_ids))
```

## 配置建議

### 1. 使用環境變數

```python
# config/settings.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # 外部 API 配置
    external_api_url: str
    external_api_key: str
    external_api_timeout: int = 30
    
    # 支付 API 配置
    payment_api_url: str
    payment_api_key: str
    
    class Config:
        env_file = ".env"

settings = Settings()
```

```python
# .env
EXTERNAL_API_URL=https://api.example.com
EXTERNAL_API_KEY=your_api_key_here
EXTERNAL_API_TIMEOUT=30

PAYMENT_API_URL=https://payment.example.com
PAYMENT_API_KEY=your_payment_key_here
```

### 2. 建立專用客戶端

```python
# utils/api_clients.py
from utils import request
from config import settings

# 外部 API 客戶端
external_api_client = request.RequestClient(
    base_url=settings.external_api_url,
    default_headers={"X-API-Key": settings.external_api_key},
    default_timeout=settings.external_api_timeout
)

# 支付 API 客戶端
payment_api_client = request.RequestClient(
    base_url=settings.payment_api_url,
    default_headers={"Authorization": f"Bearer {settings.payment_api_key}"}
)
```

## 日誌記錄

### 啟用日誌

```python
import logging

# 設定日誌級別
logging.basicConfig(level=logging.INFO)

# 或針對特定模組
logger = logging.getLogger("app.utils.request")
logger.setLevel(logging.DEBUG)
```

### 日誌輸出範例

```
INFO:app.utils.request:發送 GET 請求到 https://api.example.com/users
DEBUG:app.utils.request:查詢參數: {'page': 1, 'limit': 10}
INFO:app.utils.request:收到響應: 200
DEBUG:app.utils.request:響應數據類型: JSON
```

### 關閉日誌

```python
from utils.request import make_request

# 關閉請求和響應日誌
result = make_request(
    "https://api.example.com/users",
    log_request=False,
    log_response=False
)
```

## 錯誤類型

### RequestError
所有請求錯誤的基類

### ValidationError
Pydantic Schema 驗證失敗

```python
# 輸入驗證失敗
ValidationError: 輸入數據驗證失敗: ...

# 輸出驗證失敗
ValidationError: 輸出數據驗證失敗: ...
```

### HTTPError
HTTP 請求錯誤

```python
# HTTP 狀態碼錯誤
HTTPError: HTTP 錯誤 404: Not Found

# 超時錯誤
HTTPError: 請求超時 (30秒): ...

# 連線錯誤
HTTPError: 連線錯誤: ...
```

## 最佳實踐

### 1. 使用 Schema 驗證

```python
# ✅ 好的做法
result = make_request(
    url="https://api.example.com/users",
    method="POST",
    json_data=user_data,
    input_schema=UserInput,
    output_schema=UserOutput
)

# ❌ 不好的做法（沒有驗證）
result = make_request(
    url="https://api.example.com/users",
    method="POST",
    json_data=user_data
)
```

### 2. 統一錯誤處理

```python
# ✅ 好的做法
try:
    result = make_request(url)
except request.ValidationError as e:
    logger.error(f"驗證失敗: {e}")
    raise
except request.HTTPError as e:
    logger.error(f"請求失敗: {e}")
    raise

# ❌ 不好的做法（捕捉所有異常）
try:
    result = make_request(url)
except Exception as e:
    pass  # 忽略錯誤
```

### 3. 使用 RequestClient

```python
# ✅ 好的做法（重用客戶端）
client = request.RequestClient(base_url="https://api.example.com")
for i in range(100):
    user = client.get(f"/users/{i}")
client.close()

# ❌ 不好的做法（每次建立新客戶端）
for i in range(100):
    client = request.RequestClient(base_url="https://api.example.com")
    user = client.get(f"/users/{i}")
    client.close()
```

### 4. 設定合理的超時

```python
# ✅ 好的做法
result = make_request(url, timeout=30)

# ❌ 不好的做法（沒有超時或超時過長）
result = make_request(url, timeout=None)  # 可能永遠等待
result = make_request(url, timeout=300)   # 5 分鐘太長
```

### 5. 使用環境變數

```python
# ✅ 好的做法
from config import settings
client = request.RequestClient(
    base_url=settings.api_url,
    default_headers={"Authorization": f"Bearer {settings.api_key}"}
)

# ❌ 不好的做法（硬編碼）
client = request.RequestClient(
    base_url="https://api.example.com",
    default_headers={"Authorization": "Bearer hardcoded_token"}
)
```

## 總結

`app/utils/request.py` 提供了強大且靈活的 HTTP 請求工具：

- ✅ 支援多種 HTTP 方法
- ✅ Pydantic Schema 自動驗證
- ✅ 統一的錯誤處理
- ✅ 完整的日誌記錄
- ✅ Session 管理和連線池
- ✅ 靈活的配置選項

使用這個工具可以：
- 簡化外部 API 調用
- 確保數據型別安全
- 統一錯誤處理流程
- 提升程式碼可維護性

---

**文件版本**: 1.0  
**最後更新**: 2025-11-10
