# 重構討論：Routes → Service → Database 分層架構調整

**日期**: 2026-02-11
**狀態**: ✅ 全部完成（實作 + CRUD 補全 + Docker 驗證 + 文檔同步）
**目標**: 將四個 `db_*.py` route 檔案重構為符合 `ARCHITECTURE_EXAMPLE.md` 標準的分層架構

---

## 📌 目錄

1. [現況分析](#1-現況分析)
2. [問題診斷](#2-問題診斷)
3. [目標架構](#3-目標架構)
4. [各檔案重構方案](#4-各檔案重構方案)
5. [新增/修改檔案清單](#5-新增修改檔案清單)
6. [Schema 設計規劃](#6-schema-設計規劃)
7. [Service 設計規劃](#7-service-設計規劃)
8. [Route 重構規劃](#8-route-重構規劃)
9. [範例教學調整建議](#9-範例教學調整建議)
10. [執行順序與追蹤](#10-執行順序與追蹤)

---

## 1. 現況分析

### 1.1 專案已有的標準範例（✅ 正確架構）

`app/routes/sample.py` 已經展示了正確的分層架構：

```
Route (sample.py)
  ↓ 使用 Schema 驗證參數
  ↓ 呼叫 Service 方法
Service (sample_item.py)
  ↓ 封裝業務邏輯
  ↓ 使用 orm_operations
Database (orm_operations.py)
  ↓ 通用 CRUD
Model (sample_item.py ORM)
```

`sample.py` 同時也引用了三個尚未建立的 Service：
- `SQLAlchemyService` (from `services/db_sqlalchemy.py`)
- `PsycopgService` (from `services/db_psycopg.py`)
- `OCPService` (from `services/db_ocp.py`)

### 1.2 四個 db_*.py Route 檔案（❌ 不符合標準架構）

| 檔案 | 連線方式 | 主要問題 |
|------|---------|---------|
| `db_sqlalchemy.py` | SQLAlchemy AsyncEngine | Route 直接操作 Session/SQL |
| `db_psycopg.py` | psycopg AsyncConnectionPool | Route 直接操作連線池/SQL |
| `db_ocp.py` | OCP Tool API (HTTP) | Schema 定義在 route 內、直接建立 OCPClient |
| `db_langgraph.py` | LangGraph PostgresSaver | Route 直接操作連線池/SQL/Checkpointer |

### 1.3 services/__init__.py 現況

目前 `services/__init__.py` 引用了 4 個 Service，但只有 1 個實際存在：

```python
from services.db_sqlalchemy import SQLAlchemyService   # ❌ 檔案不存在
from services.db_psycopg import PsycopgService          # ❌ 檔案不存在
from services.db_ocp import OCPService                   # ❌ 檔案不存在
from services.sample_item import SampleItemService       # ✅ 已建立
```

---

## 2. 問題診斷

### 2.1 架構層面問題

| # | 問題 | 影響 | 嚴重度 |
|---|------|------|--------|
| P1 | Route 直接操作 Database | 違反關注點分離原則，Route 承擔過多職責 | 🔴 高 |
| P2 | 缺少 Service 層 | 業務邏輯無法重用、難以測試 | 🔴 高 |
| P3 | Schema 定義在 Route 內 | `db_ocp.py` 的 `QueryRequest` 等應抽出至 `schemas/` | 🟡 中 |
| P4 | 無 response_model 約束 | 大部分端點回傳 `Dict[str, Any]`，無法自動生成精確 API 文件 | 🟡 中 |
| P5 | Session 生命週期管理在 Route | `db_sqlalchemy.py` 手動 commit/rollback/close | 🟡 中 |
| P6 | 錯誤處理不一致 | 每個檔案各自處理 try/except，風格不統一 | 🟠 中低 |
| P7 | services/__init__.py 引用了不存在的模組 | 應用啟動會報 ImportError | 🔴 高 |

### 2.2 範例教學層面問題

| # | 問題 | 對使用者的影響 |
|---|------|--------------|
| T1 | 四個 db_*.py 各自獨立，與 `sample.py` 風格不一致 | 使用者不知道該參考哪個 |
| T2 | 沒有展示「如何從 Route 呼叫 Service 來操作不同 DB」 | 使用者看不到正確的調用鏈 |
| T3 | `db_ocp.py` 有 Schema 但定義在 route 內 | 使用者可能誤以為 Schema 可以寫在 route |
| T4 | 缺少「同一 Service 被多個 Route 重用」的範例 | 使用者不理解 Service 的重用價值 |
| T5 | 缺少從 Schema → Service → DB 的完整參數傳遞範例 | 使用者不知道參數如何在各層間流動 |

---

## 3. 目標架構

### 3.1 重構後的調用鏈

```
Client Request
      ↓
[Route Layer]  ← 薄控制器：接收請求、驗證參數、回傳結果
      ↓
[Schema Layer] ← 請求驗證：Pydantic BaseModel（Request Schema）
      ↓
[Service Layer] ← 業務邏輯：封裝 DB 操作、錯誤處理、資料轉換
      ↓
[Database Layer] ← DB 操作：
      │  ├── orm_operations (SQLAlchemy ORM)
      │  ├── session.py (SQLAlchemy raw SQL / psycopg raw SQL)
      │  ├── ocp_client.py (OCP HTTP API)
      │  └── LangGraph PostgresSaver (Checkpoint)
      ↓
[Schema Layer] ← 回應序列化：Pydantic BaseModel（Response Schema）
      ↓
[Route Layer]  ← 最終整理並回傳 JSON
      ↓
Client Response
```

### 3.2 各層職責劃分

| 層 | 職責 | 不該做的事 |
|----|------|-----------|
| **Route** | HTTP 端點定義、參數接收（透過 Schema）、呼叫 Service、回傳回應 | ❌ 不直接操作 DB、不含業務邏輯 |
| **Schema** | 請求驗證、回應序列化、API 文件描述 | ❌ 不含業務邏輯、不操作 DB |
| **Service** | 業務邏輯、呼叫 Database 層、錯誤處理、資料轉換 | ❌ 不處理 HTTP 層邏輯（status code 除外） |
| **Database** | 連線管理、SQL 執行、ORM 操作 | ❌ 不含業務邏輯 |

---

## 4. 各檔案重構方案

### 4.1 db_sqlalchemy.py（SQLAlchemy AsyncEngine）

**目前功能端點**：
- `POST /init` — 初始化引擎
- `GET /health` — 健康檢查
- `GET /query` — 查詢 PG 版本
- `POST /table/create` — 建立測試表
- `POST /data/insert` — 插入資料
- `GET /data/list` — 查詢資料
- `DELETE /table/drop` — 刪除測試表

**重構方向**：
```python
# Route (db_sqlalchemy.py) — 只做 HTTP 處理
@router.post("/data/insert", response_model=InsertResultResponse)
async def insert_test_data(
    data: TestUserCreateRequest,           # ← Schema 驗證參數
    db: AsyncSession = Depends(get_db_session),
):
    result = await SQLAlchemyService.insert_data(db, data)  # ← 委託 Service
    return result                                            # ← 回傳結果
```

```python
# Service (db_sqlalchemy.py) — 業務邏輯
class SQLAlchemyService:
    @staticmethod
    async def insert_data(db: AsyncSession, data: TestUserCreateRequest) -> dict:
        result = await db.execute(
            text("INSERT INTO test_users (name, email) VALUES (:name, :email) RETURNING id"),
            {"name": data.name, "email": data.email}
        )
        ...
```

### 4.2 db_psycopg.py（psycopg AsyncConnectionPool）

**目前功能端點**：
- `GET /` — 功能說明
- `POST /init` — 初始化連線池
- `GET /health` — 健康檢查
- `POST /query` — 原生 SQL 查詢
- `GET /pool/stats` — 連線池統計

**重構方向**：
```python
# Route — 只做 HTTP 處理
@router.post("/query", response_model=RawQueryResponse)
async def execute_raw_query(request: RawSQLRequest):     # ← Schema 驗證
    result = await PsycopgService.raw_query(request.sql)  # ← 委託 Service
    return result
```

### 4.3 db_ocp.py（OCP Tool API）

**目前功能端點**：
- `GET /` — 功能說明
- `GET /test` — 連線測試
- `POST /select` — SELECT 查詢
- `POST /dml` — DML 操作
- `POST /query` — 自動判斷查詢
- `POST /select/dict` — SELECT（字典格式）
- `GET /config` — 配置資訊
- `POST /batch/select` — 批次查詢

**重構重點**：
1. 將 `QueryRequest`、`SelectResponse`、`DMLResponse` 移至 `schemas/db_ocp.py`
2. 建立 `OCPService` 封裝所有 OCPClient 操作
3. Route 只負責調用 Service 並回傳

### 4.4 db_langgraph.py（LangGraph PostgresSaver）

**目前功能端點**：
- `GET /` — 說明
- `POST /init` — 初始化 PostgresSaver
- `POST /checkpoint/save` — 儲存 Checkpoint
- `GET /checkpoint/{thread_id}` — 讀取 Checkpoint
- `GET /checkpoints/{thread_id}/history` — Checkpoint 歷史
- `DELETE /checkpoint/{thread_id}` — 刪除 Checkpoint

**重構方向**：
```python
# Schema — 請求驗證
class CheckpointSaveRequest(BaseModel):
    thread_id: str = Field(..., description="對話或工作流程的唯一 ID")
    state: Dict[str, Any] = Field(..., description="要儲存的狀態資料")

# Route — 薄控制器
@router.post("/checkpoint/save", response_model=CheckpointSaveResponse)
async def save_checkpoint(request: CheckpointSaveRequest):
    return await LangGraphService.save_checkpoint(request.thread_id, request.state)

# Service — 業務邏輯
class LangGraphService:
    @staticmethod
    async def save_checkpoint(thread_id: str, state: Dict[str, Any]) -> dict:
        pool = get_async_pool()
        # ... 所有 DB 操作都在 Service 內 ...
```

---

## 5. 新增/修改檔案清單

### 5.1 需要新增的檔案

| 檔案路徑 | 用途 | 說明 |
|---------|------|------|
| `app/schemas/db_common.py` | 通用 Schema | 四種 DB 共用的請求/回應（RawSQLRequest、TableInsertRequest 等） |
| `app/schemas/db_ocp.py` | OCP 專用 Schema | OCP 特殊格式（繼承 db_common + OCP 專有欄位） |
| `app/schemas/db_langgraph.py` | LangGraph 專用 Schema | Checkpoint 相關請求/回應 |
| `app/services/db_sqlalchemy.py` | SQLAlchemy Facade Service | 封裝 session 管理 + SQL 操作 |
| `app/services/db_psycopg.py` | psycopg Facade Service | 封裝 pool 管理 + 原生 SQL |
| `app/services/db_ocp.py` | OCP Facade Service | 封裝 OCPClient + 結果轉換 |
| `app/services/db_langgraph.py` | LangGraph Facade Service | 封裝 Checkpoint 管理 |

> **注意**：SQLAlchemy 和 psycopg 不需要獨立 Schema 檔，共用 `db_common.py` 即可。

### 5.2 需要修改的檔案

| 檔案路徑 | 修改內容 |
|---------|---------|
| `app/routes/db_sqlalchemy.py` | 改為薄控制器，引用 Service + Schema |
| `app/routes/db_psycopg.py` | 改為薄控制器，引用 Service + Schema |
| `app/routes/db_ocp.py` | 移除內嵌 Schema，改為薄控制器 |
| `app/routes/db_langgraph.py` | 改為薄控制器，引用 Service + Schema |
| `app/services/__init__.py` | 補上 LangGraphService 的匯出 |
| `app/schemas/__init__.py` | 新增 db_* schemas 的匯出 |

---

## 6. Schema 設計規劃（通用化設計）

> **設計原則**：Schema 不綁定特定領域（如 User），改為通用的 table + SQL + data 參數設計，
> 讓使用者可以對任何資料表操作。

### 6.1 共用 Schema (`schemas/db_common.py`)

四個 DB 都會用到的通用請求/回應 Schema：

```python
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ============================================================================
# 通用請求 Schema
# ============================================================================

class RawSQLRequest(BaseModel):
    """通用原生 SQL 請求（適用所有 DB 連線方式）"""
    sql: str = Field(..., min_length=1, description="SQL 語句")
    params: Optional[Dict[str, Any]] = Field(None, description="SQL 參數")

class TableInsertRequest(BaseModel):
    """通用資料插入請求"""
    table_name: str = Field(..., description="資料表名稱", example="test_users")
    data: Dict[str, Any] = Field(
        ..., description="欄位與值的對應",
        example={"name": "Alice", "email": "alice@example.com"}
    )

class TableQueryRequest(BaseModel):
    """通用資料查詢請求"""
    table_name: str = Field(..., description="資料表名稱")
    columns: Optional[List[str]] = Field(None, description="查詢欄位（None=全部）")
    filters: Optional[Dict[str, Any]] = Field(None, description="過濾條件", example={"is_active": True})
    order_by: Optional[str] = Field(None, description="排序欄位（前綴 - 為降序）", example="-created_at")
    skip: int = Field(0, ge=0, description="跳過筆數")
    limit: int = Field(10, ge=1, le=100, description="每頁筆數")

class TableUpdateRequest(BaseModel):
    """通用資料更新請求"""
    table_name: str = Field(..., description="資料表名稱")
    filters: Dict[str, Any] = Field(..., description="WHERE 條件", example={"id": 1})
    data: Dict[str, Any] = Field(..., description="要更新的欄位與值", example={"name": "Bob"})

class TableDeleteRequest(BaseModel):
    """通用資料刪除請求"""
    table_name: str = Field(..., description="資料表名稱")
    filters: Dict[str, Any] = Field(..., description="WHERE 條件", example={"id": 1})


# ============================================================================
# 通用回應 Schema
# ============================================================================

class HealthCheckResponse(BaseModel):
    """通用健康檢查回應"""
    status: str
    connection_type: str
    database: Optional[str] = None
    host: Optional[str] = None
    detail: Optional[Dict[str, Any]] = None

class InitResponse(BaseModel):
    """通用初始化回應"""
    status: str
    message: str
    info: Optional[Dict[str, Any]] = None

class QueryResultResponse(BaseModel):
    """通用查詢結果回應"""
    status: str
    row_count: int = 0
    columns: Optional[List[str]] = None
    data: Optional[List[Dict[str, Any]]] = None
    message: Optional[str] = None

class ExecuteResultResponse(BaseModel):
    """通用 DML 執行結果回應（INSERT/UPDATE/DELETE）"""
    status: str
    affected_rows: int = 0
    returning_data: Optional[Dict[str, Any]] = None
    message: Optional[str] = None

class InfoResponse(BaseModel):
    """通用功能說明回應"""
    status: str
    features: List[str]
    examples: List[Dict[str, str]]
    message: Optional[str] = None
```

### 6.2 OCP 專用 Schema (`schemas/db_ocp.py`)

OCP 有一些特殊回應格式，獨立定義（同時重用 `db_common` 的通用 Schema）：

```python
from schemas.db_common import RawSQLRequest

class OCPQueryRequest(RawSQLRequest):
    """OCP 查詢請求（擴展通用 SQL 請求，加上 database 欄位）"""
    database: Optional[str] = Field(None, description="資料庫名稱（預設使用環境變數設定）")

class OCPSelectResponse(BaseModel):
    """OCP SELECT 查詢回應"""
    status: str
    query_time: float
    row_count: int
    columns: List[str]
    data: List[List[Any]]

class OCPDMLResponse(BaseModel):
    """OCP DML 操作回應"""
    status: str
    query_time: float
    affected_rows: int

class OCPBatchResultItem(BaseModel):
    """OCP 批次查詢單筆結果"""
    index: int
    status: str
    query_time: Optional[float] = None
    row_count: Optional[int] = None
    columns: Optional[List[str]] = None
    data: Optional[List[List[Any]]] = None
    error: Optional[str] = None
```

### 6.3 LangGraph 專用 Schema (`schemas/db_langgraph.py`)

```python
class CheckpointSaveRequest(BaseModel):
    """儲存 Checkpoint 請求"""
    thread_id: str = Field(..., description="對話或工作流程的唯一 ID")
    state: Dict[str, Any] = Field(..., description="要儲存的狀態資料")

class CheckpointResponse(BaseModel):
    """Checkpoint 回應"""
    checkpoint_id: str
    state: Any
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None

class CheckpointSaveResponse(BaseModel):
    """儲存 Checkpoint 回應"""
    status: str
    message: str
    thread_id: str
    checkpoint_id: str

class CheckpointHistoryResponse(BaseModel):
    """Checkpoint 歷史回應"""
    status: str
    thread_id: str
    count: int
    history: List[CheckpointResponse]
```

### 6.4 Schema 設計重點

| 設計決策 | 說明 |
|---------|------|
| **通用 vs 特定** | `db_common.py` 放通用 Schema（四種 DB 共用），特殊需求才建專用檔 |
| **不綁定領域** | 用 `table_name` + `data: Dict` 取代 `TestUserCreateRequest` |
| **繼承重用** | `OCPQueryRequest` 繼承 `RawSQLRequest` 加上 `database` 欄位 |
| **response_model** | 每個端點都指定 response_model，自動生成 Swagger 文件 |

---

## 7. Service 設計規劃（Facade 門面模式）

> **設計原則**：Service 作為 Facade（門面），封裝 database 層的複雜度。
> 使用者只需要呼叫 Service 方法，不需要了解 session/pool/client 的管理方式。
>
> **核心價值**：
> - 隱藏 session 生命週期（commit/rollback/close）
> - 隱藏連線池管理（get_pool/connection context manager）
> - 隱藏 SQL 組裝邏輯（text()、參數綁定）
> - 提供統一的錯誤處理和回傳格式
> - 使用者只需要看 Service 的方法簽名就能上手

### 7.1 SQLAlchemyService (`services/db_sqlalchemy.py`)

```python
class SQLAlchemyService:
    """
    SQLAlchemy 資料庫操作服務（Facade）

    封裝所有 SQLAlchemy AsyncEngine 操作，使用者不需要了解：
    - session 如何建立和管理
    - text() 如何使用
    - commit/rollback/close 的時機

    使用範例：
        # 初始化
        result = await SQLAlchemyService.init_engine_and_tables()

        # 查詢
        result = await SQLAlchemyService.execute_query("SELECT * FROM users")

        # 插入（通用：任意 table + data dict）
        result = await SQLAlchemyService.insert_data("users", {"name": "Alice", "email": "a@b.com"})

        # 查詢（通用：任意 table + filters）
        result = await SQLAlchemyService.query_data("users", filters={"is_active": True})
    """

    @staticmethod
    async def init_engine_and_tables(pool_size=5, max_overflow=10) -> dict:
        """初始化引擎（封裝 DatabaseConfig + init_async_engine）"""
        ...

    @staticmethod
    async def health_check() -> dict:
        """健康檢查（封裝 check_db_health）"""
        ...

    @staticmethod
    async def execute_query(sql: str, params: dict = None) -> dict:
        """
        執行原生 SQL 查詢（通用）
        封裝：session 建立 → text(sql) → execute → 結果轉換 → session 關閉
        """
        ...

    @staticmethod
    async def create_table(table_name: str, ddl_sql: str = None) -> dict:
        """建立資料表（封裝 DDL 執行 + commit）"""
        ...

    @staticmethod
    async def insert_data(table_name: str, data: dict) -> dict:
        """
        通用插入：任意 table + data dict
        封裝：SQL 組裝 → execute → commit → 回傳 RETURNING 結果
        """
        ...

    @staticmethod
    async def query_data(table_name: str, columns: list = None,
                         filters: dict = None, order_by: str = None,
                         skip: int = 0, limit: int = 10) -> dict:
        """
        通用查詢：任意 table + 過濾 + 分頁
        封裝：SQL 組裝 → execute → 結果轉 dict list
        """
        ...

    @staticmethod
    async def drop_table(table_name: str) -> dict:
        """刪除資料表（封裝 DDL 執行 + commit）"""
        ...
```

### 7.2 PsycopgService (`services/db_psycopg.py`)

```python
class PsycopgService:
    """
    psycopg 資料庫操作服務（Facade）

    封裝所有 psycopg AsyncConnectionPool 操作，使用者不需要了解：
    - pool 如何初始化和管理
    - connection context manager 如何使用
    - cursor/fetchall/description 的處理方式

    使用範例：
        result = await PsycopgService.init_pool()
        result = await PsycopgService.execute_query("SELECT version()")
        result = await PsycopgService.insert_data("users", {"name": "Alice"})
    """

    @staticmethod
    async def init_pool(min_size=2, max_size=10) -> dict:
        """初始化連線池（封裝 DatabaseConfig + init_async_pool + 配置回調）"""
        ...

    @staticmethod
    async def health_check() -> dict:
        """健康檢查（封裝 check_db_health + pool stats）"""
        ...

    @staticmethod
    async def execute_query(sql: str, params: dict = None) -> dict:
        """
        執行原生 SQL 查詢（通用）
        封裝：pool.connection() → execute → cursor → fetchall → 結果轉換
        """
        ...

    @staticmethod
    async def insert_data(table_name: str, data: dict) -> dict:
        """通用插入：組裝 SQL → pool.connection() → execute → 回傳結果"""
        ...

    @staticmethod
    async def query_data(table_name: str, filters: dict = None,
                         order_by: str = None, skip: int = 0, limit: int = 10) -> dict:
        """通用查詢：組裝 SQL → pool.connection() → execute → 結果轉換"""
        ...

    @staticmethod
    async def get_pool_stats() -> dict:
        """獲取連線池統計（封裝 pool.get_stats()）"""
        ...
```

### 7.3 OCPService (`services/db_ocp.py`)

```python
class OCPService:
    """
    OCP Tool API 操作服務（Facade）

    封裝所有 OCP HTTP API 操作，使用者不需要了解：
    - OCPClient 如何初始化
    - OCPConfig 如何配置
    - HTTP 請求/重試的細節
    - 回應格式的解析方式

    使用範例：
        result = OCPService.test_connection()
        result = OCPService.execute_query("SELECT * FROM users LIMIT 10")
        result = OCPService.execute_query("INSERT INTO users(name) VALUES('Alice')")
    """

    @staticmethod
    def test_connection(database: str = None) -> dict:
        """測試連線（封裝 OCPClient 初始化 + test）"""
        ...

    @staticmethod
    def execute_query(sql: str, database: str = None) -> dict:
        """自動判斷 SELECT/DML 並執行（封裝 OCPClient.execute_query）"""
        ...

    @staticmethod
    def execute_select(sql: str, database: str = None) -> dict:
        """執行 SELECT 查詢（封裝 OCPClient.execute_select + 結果轉換）"""
        ...

    @staticmethod
    def execute_dml(sql: str, database: str = None) -> dict:
        """執行 DML 操作（封裝 OCPClient.execute_dml + 結果轉換）"""
        ...

    @staticmethod
    def execute_select_as_dict(sql: str, database: str = None) -> dict:
        """SELECT 結果轉字典列表（封裝 execute_select + to_dict_list）"""
        ...

    @staticmethod
    def get_config() -> dict:
        """獲取 OCP 配置資訊（封裝 get_ocp_config）"""
        ...

    @staticmethod
    def batch_select(queries: list) -> dict:
        """批次 SELECT 查詢（封裝迴圈 execute_select + 錯誤收集）"""
        ...
```

### 7.4 LangGraphService (`services/db_langgraph.py`)

```python
class LangGraphService:
    """
    LangGraph Checkpoint 操作服務（Facade）

    封裝所有 LangGraph PostgresSaver 操作，使用者不需要了解：
    - psycopg pool 如何初始化
    - PostgresSaver 如何建立
    - checkpoint 表結構和 SQL 語法
    - 連線的 schema 配置

    使用範例：
        await LangGraphService.init_saver()
        await LangGraphService.save_checkpoint("thread-1", {"messages": [...]})
        result = await LangGraphService.get_checkpoint("thread-1")
    """

    @staticmethod
    async def init_saver() -> dict:
        """初始化 PostgresSaver（封裝 pool 初始化 + checkpointer setup）"""
        ...

    @staticmethod
    async def save_checkpoint(thread_id: str, state: dict) -> dict:
        """儲存 Checkpoint（封裝 SQL INSERT/UPSERT）"""
        ...

    @staticmethod
    async def get_checkpoint(thread_id: str) -> dict:
        """讀取最新 Checkpoint（封裝 SQL SELECT + 結果轉換）"""
        ...

    @staticmethod
    async def get_checkpoint_history(thread_id: str, limit: int = 10) -> dict:
        """獲取 Checkpoint 歷史（封裝 SQL SELECT + 列表轉換）"""
        ...

    @staticmethod
    async def delete_checkpoint(thread_id: str) -> dict:
        """刪除 Checkpoint（封裝 SQL DELETE + 結果回傳）"""
        ...
```

### 7.5 Service 設計重點

```
使用者看到的（簡單）          Service 內部封裝的（複雜）
─────────────────────       ──────────────────────────────
SQLAlchemyService            get_async_session()
  .execute_query(sql)    →   session.execute(text(sql), params)
                             result.fetchall() / result.keys()
                             session.commit() / rollback() / close()
                             錯誤處理 + logging

PsycopgService               get_pool_connection()
  .execute_query(sql)    →   conn.execute(sql)
                             cursor.fetchall() / cursor.description
                             dict(zip(colnames, row))
                             錯誤處理 + logging

OCPService                   OCPClient()
  .execute_query(sql)    →   client.execute_query(sql, database)
                             hasattr(result, 'columns') 判斷
                             結果格式轉換
                             OCPError 處理

LangGraphService              get_async_pool()
  .save_checkpoint(...)  →   pool.connection()
                             conn.execute(INSERT SQL...)
                             參數序列化 + 錯誤處理
```

| 設計決策 | 說明 |
|---------|------|
| **Facade 模式** | Service 不是業務邏輯層，是「封裝門面」— 隱藏底層複雜度 |
| **通用方法** | `insert_data(table, data)` / `query_data(table, filters)` 不綁定特定領域 |
| **靜態方法** | 大部分用 `@staticmethod`，無需實例化（基礎設施類操作） |
| **一致命名** | 四個 Service 都有 `execute_query`、`health_check` 等統一方法名 |
| **使用者只看 Service** | docstring 寫清楚使用範例，使用者不需要翻 database/ 目錄 |

---

## 8. Route 重構規劃（通用化範例）

### 8.1 重構後的 Route 範例（以 db_sqlalchemy.py 為例）

```python
"""
資料庫範例 API - SQLAlchemy ORM 方式

【分層架構】Route → Schema(通用) → Service(封裝) → Database
【使用者只需看】本檔案（Route）+ Service 的 docstring

【相關檔案】
  - schemas/db_common.py          → 通用請求/回應 Schema
  - services/db_sqlalchemy.py     → SQLAlchemy 封裝服務
  - database/session.py           → 底層連線管理（使用者不需要看）
"""

from fastapi import APIRouter, HTTPException
from schemas.db_common import (
    RawSQLRequest,
    TableInsertRequest,
    TableQueryRequest,
    HealthCheckResponse,
    InitResponse,
    QueryResultResponse,
    ExecuteResultResponse,
)
from services.db_sqlalchemy import SQLAlchemyService

router = APIRouter(prefix="/api/db/sqlalchemy", tags=["Database - SQLAlchemy"])


@router.post("/init", response_model=InitResponse)
async def initialize_engine(pool_size: int = 5, max_overflow: int = 10):
    """初始化 SQLAlchemy 引擎 → 委託 SQLAlchemyService"""
    return await SQLAlchemyService.init_engine_and_tables(pool_size, max_overflow)


@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """健康檢查 → 委託 SQLAlchemyService"""
    return await SQLAlchemyService.health_check()


@router.post("/query", response_model=QueryResultResponse)
async def execute_query(request: RawSQLRequest):
    """
    通用 SQL 查詢

    【調用鏈】Schema(RawSQLRequest) → Service → session.execute(text(sql))
    【使用者帶入】sql + params → 就能查詢任意資料表
    """
    return await SQLAlchemyService.execute_query(request.sql, request.params)


@router.post("/data/insert", response_model=ExecuteResultResponse)
async def insert_data(request: TableInsertRequest):
    """
    通用資料插入

    【調用鏈】Schema(TableInsertRequest) → Service → 組裝 INSERT SQL → execute
    【使用者帶入】table_name + data dict → 就能插入任意資料表

    範例 body:
    {
        "table_name": "test_users",
        "data": {"name": "Alice", "email": "alice@example.com"}
    }
    """
    return await SQLAlchemyService.insert_data(request.table_name, request.data)


@router.post("/data/query", response_model=QueryResultResponse)
async def query_data(request: TableQueryRequest):
    """
    通用資料查詢（支援過濾、排序、分頁）

    【調用鏈】Schema(TableQueryRequest) → Service → 組裝 SELECT SQL → execute
    【使用者帶入】table_name + filters + 分頁參數 → 就能查詢任意資料表

    範例 body:
    {
        "table_name": "test_users",
        "filters": {"name": "Alice"},
        "order_by": "-created_at",
        "skip": 0,
        "limit": 10
    }
    """
    return await SQLAlchemyService.query_data(
        request.table_name,
        columns=request.columns,
        filters=request.filters,
        order_by=request.order_by,
        skip=request.skip,
        limit=request.limit,
    )
```

### 8.2 重構原則

1. **Route 不直接 import database 模組**
2. **所有 DB 操作都在 Service 內執行**
3. **使用通用 Schema**（`TableInsertRequest` 而非 `TestUserCreateRequest`）
4. **使用 `response_model` 定義回應格式**
5. **Route 只做：接收 Schema → 呼叫 Service → 回傳結果**
6. **每個端點的 docstring 註明調用鏈 + 範例**

### 8.3 四個 Route 的端點對照表

| 端點功能 | SQLAlchemy | psycopg | OCP | LangGraph |
|---------|-----------|---------|-----|-----------|
| 初始化 | `POST /init` | `POST /init` | — | `POST /init` |
| 健康檢查 | `GET /health` | `GET /health` | `GET /test` | — |
| 通用 SQL 查詢 | `POST /query` | `POST /query` | `POST /query` | — |
| 通用插入 | `POST /data/insert` | `POST /data/insert` | `POST /dml` | — |
| 通用查詢 | `POST /data/query` | `POST /data/query` | `POST /select` | — |
| 建表 | `POST /table/create` | — | — | — |
| 刪表 | `DELETE /table/drop` | — | — | — |
| 連線池統計 | — | `GET /pool/stats` | `GET /config` | — |
| Checkpoint CRUD | — | — | — | 完整 CRUD |

---

## 9. 範例教學調整建議

### 9.1 讓使用者更快上手的改進

| 改進項目 | 說明 | 效果 |
|---------|------|------|
| **統一範例風格** | 四個 db_*.py 都遵循相同的 Route → Service → Schema 模式 | 使用者看一個就懂全部 |
| **增加調用鏈註解** | 每個端點 docstring 標明完整調用鏈 | 使用者清楚知道資料流向 |
| **Schema 獨立檔案** | 所有 Schema 放在 `schemas/` 目錄 | 使用者知道去哪裡找/改 |
| **共用 Schema 範例** | `db_common.py` 展示如何重用回應格式 | 教會使用者 DRY 原則 |
| **Service 方法命名一致** | 所有 Service 都用 `init_*`、`health_check`、`raw_query` 等統一命名 | 降低學習成本 |

### 9.2 建議的端點學習路徑

```
新手學習路徑：

Step 1: 看 sample.py 的「完整分層架構範例」
        → 理解 Route → Schema → Service → ORM → DB 的完整流程

Step 2: 看 db_sqlalchemy.py
        → 理解 SQLAlchemy Session 搭配 Service 的操作方式
        → 包含：初始化、建表、CRUD、清理

Step 3: 看 db_psycopg.py
        → 理解 psycopg 原生 SQL 搭配 Service 的操作方式
        → 包含：連線池初始化、健康檢查、原生 SQL

Step 4: 看 db_ocp.py
        → 理解 HTTP-based DB 操作搭配 Service 的方式
        → 包含：SELECT、DML、批次操作

Step 5: 看 db_langgraph.py（進階）
        → 理解 LangGraph Checkpointer 搭配 Service
        → 包含：狀態持久化、歷史追蹤
```

### 9.3 每個 route 檔案頭部建議增加的說明

```python
"""
資料庫範例 API - SQLAlchemy ORM 方式

【分層架構】
  Route (本檔案)
    → Schema (schemas/db_sqlalchemy.py) 驗證請求/回應
    → Service (services/db_sqlalchemy.py) 業務邏輯
    → Database (database/session.py) DB 操作

【使用方式】
  1. POST /init 初始化連線引擎
  2. POST /table/create 建立測試表
  3. POST /data/insert 插入資料（注意：使用 Schema 驗證參數）
  4. GET  /data/list 查詢資料
  5. DELETE /table/drop 清理測試表

【相關檔案】
  - schemas/db_sqlalchemy.py  → 請求/回應 Schema
  - services/db_sqlalchemy.py → 業務邏輯 Service
  - database/session.py       → 連線管理
"""
```

---

## 10. 執行順序與追蹤

### 10.1 建議執行順序

```
Phase 1: Schema 層建立（無依賴，可並行）
  ├── [✅] schemas/db_common.py
  ├── [—] schemas/db_sqlalchemy.py（不需要，共用 db_common.py）
  ├── [—] schemas/db_psycopg.py（不需要，共用 db_common.py）
  ├── [✅] schemas/db_ocp.py
  └── [✅] schemas/db_langgraph.py

Phase 2: Service 層建立（依賴 Schema + Database）
  ├── [✅] services/db_sqlalchemy.py
  ├── [✅] services/db_psycopg.py
  ├── [✅] services/db_ocp.py
  └── [✅] services/db_langgraph.py

Phase 3: Route 層重構（依賴 Schema + Service）
  ├── [✅] routes/db_sqlalchemy.py
  ├── [✅] routes/db_psycopg.py
  ├── [✅] routes/db_ocp.py
  └── [✅] routes/db_langgraph.py

Phase 4: 整合與更新
  ├── [✅] services/__init__.py（加入 LangGraphService）
  ├── [✅] schemas/__init__.py（加入新 Schema 匯出）
  ├── [✅] routes/sample.py（確認 Service 引用正常）
  └── [✅] main.py（確認新 route 的註冊）

Phase 5: 驗證與文件
  ├── [✅] 啟動應用確認無 ImportError（Docker 驗證通過）
  ├── [✅] Swagger UI 確認所有端點正常（42 個端點，7 個 tag）
  ├── [✅] CRUD 完整性補全（SQLAlchemy/psycopg 加入 update_data + delete_data）
  ├── [✅] OCP Route 加入 CRUD 範例端點（data/insert, query, update, delete）
  ├── [✅] Docker 環境 CRUD 全流程驗證（C→R→U→D 全部通過）
  └── [✅] 文檔同步更新（README, DEVELOPMENT, DB_PATTERNS_GUIDE 等 6 個文檔）
```

### 10.2 追蹤清單

| 項目 | 狀態 | 負責 | 備註 |
|------|------|------|------|
| schemas/db_common.py | ✅ 完成 | | 共用請求/回應 Schema（6 Request + 5 Response） |
| schemas/db_sqlalchemy.py | — 不需要 | | 共用 db_common.py |
| schemas/db_psycopg.py | — 不需要 | | 共用 db_common.py |
| schemas/db_ocp.py | ✅ 完成 | | OCP 專用 Schema（繼承 RawSQLRequest） |
| schemas/db_langgraph.py | ✅ 完成 | | Checkpoint 請求/回應 Schema |
| services/db_sqlalchemy.py | ✅ 完成 | | SQLAlchemy Facade Service |
| services/db_psycopg.py | ✅ 完成 | | psycopg Facade Service |
| services/db_ocp.py | ✅ 完成 | | OCP Facade Service |
| services/db_langgraph.py | ✅ 完成 | | LangGraph Facade Service |
| routes/db_sqlalchemy.py 重構 | ✅ 完成 | | 薄控制器（9 端點，含完整 CRUD） |
| routes/db_psycopg.py 重構 | ✅ 完成 | | 薄控制器（8 端點，含完整 CRUD） |
| routes/db_ocp.py 重構 | ✅ 完成 | | 薄控制器（11 端點，含 CRUD 範例） |
| routes/db_langgraph.py 重構 | ✅ 完成 | | 薄控制器（6 端點） |
| services/__init__.py 更新 | ✅ 完成 | | 加入 LangGraphService |
| schemas/__init__.py 更新 | ✅ 完成 | | 加入所有新 Schema |
| CRUD 完整性補全 | ✅ 完成 | | SQLAlchemy/psycopg 加入 update_data + delete_data |
| OCP CRUD 範例端點 | ✅ 完成 | | 4 個 CRUD 端點（insert/query/update/delete） |
| 整合測試 | ✅ 完成 | | Docker 啟動確認 + 42 端點 + 7 tag 正常 |
| CRUD 全流程驗證 | ✅ 完成 | | SQLAlchemy + psycopg C→R→U→D 全部通過 |
| 文檔同步更新 | ✅ 完成 | | README, DEVELOPMENT, DB_PATTERNS_GUIDE 等 6 個文檔 |

---

## 📝 討論記錄

### 第一輪討論（2026-02-11）— 初始分析

- 完成四個 db_*.py 檔案分析
- 識別出 7 個架構問題 + 5 個教學問題
- 建立初版重構方案

### 第二輪討論（2026-02-11）— Service vs Utils + 通用化

**議題 1：功能應該放在 Service 還是 Utils？**

> 結論：✅ **放在 Service（Facade 門面模式）**
>
> 理由：Service 的核心價值不在於業務邏輯複雜度，而在於**封裝底層複雜度**。
> 目標是讓使用者不需要了解 database 層的 session/pool/client 管理方式，
> 只需要呼叫 Service 的方法就能完成操作。
>
> ```
> Service 的定位 = Facade（門面）
> ├── 隱藏 session 生命週期（commit/rollback/close）
> ├── 隱藏連線池管理（pool.connection context manager）
> ├── 隱藏 SQL 組裝邏輯（text()、參數綁定）
> ├── 提供統一的錯誤處理和回傳格式
> └── 使用者只看 Service docstring 就能上手
> ```

**議題 2：Schema 要綁定特定領域（如 User）嗎？**

> 結論：✅ **改為通用設計，不綁定特定領域**
>
> - `TestUserCreateRequest` → `TableInsertRequest(table_name, data)`
> - `TestUserResponse` → `ExecuteResultResponse(status, affected_rows, returning_data)`
> - 通用 Schema 放在 `schemas/db_common.py`，四種 DB 共用
> - OCP / LangGraph 特殊需求才建專用 Schema 檔

**議題 3：四個 DB 範例能更通用化嗎？**

> 結論：✅ **Service 提供通用方法，用 table_name + data dict 取代固定領域**
>
> ```python
> # 使用者只需要這樣呼叫：
> await SQLAlchemyService.insert_data("任意table", {"col1": "val1", "col2": "val2"})
> await SQLAlchemyService.query_data("任意table", filters={"col1": "val1"})
> await PsycopgService.execute_query("任意 SQL", {"param1": "val1"})
> OCPService.execute_query("任意 SQL")
> ```

### 待確認事項（已決議）

| # | 議題 | 決議 |
|---|------|------|
| 1 | db_ocp.py Schema 整合方式 | ✅ 獨立建 `schemas/db_ocp.py`，通用部分放 `db_common.py` |
| 2 | LangGraph 是否加入 `services/__init__.py` | ✅ 加入，保持一致性 |
| 3 | Route 前綴統一 | ✅ 獨立 route 用 `/api/db/*`，`sample.py` 用 `/api/sample/*` |
| 4 | 是否保留四個獨立 route 檔案 | ✅ 保留，每種 DB 有完整獨立範例 |
| 5 | Service vs Utils | ✅ 放 Service（Facade 門面模式） |
| 6 | Schema 通用 vs 特定領域 | ✅ 通用設計（table_name + data dict） |

---

### 第三輪（2026-02-11）— 實作完成 + Docker 驗證

- Phase 1-4 全部完成
- Docker `docker-compose up --build` 啟動成功
- 應用程式 healthy，無 ImportError
- OpenAPI 確認 35 個端點、7 個 Swagger tag 正常註冊

### 第四輪（2026-02-12）— CRUD 補全 + Docker 驗證

- SQLAlchemy Service 補上 `update_data()` + `delete_data()`
- psycopg Service 補上 `update_data()` + `delete_data()`
- OCP Route 新增 4 個 CRUD 範例端點（data/insert, query, update, delete）
- 端點數量：35 → 42（+7 個 CRUD 端點）
- Docker 環境完整 CRUD 流程測試通過（C→R→U→D）
- Git 推送至 `origin/fastapi_structure_standard`

### 第五輪（2026-02-12）— 文檔同步更新

更新以下 6 個文檔以反映所有變更：
- `README.md` — 新增 DB API 特色、文檔導航
- `DEVELOPMENT.md` — 更新目錄結構、分層架構說明
- `docs/DB_PATTERNS_GUIDE.md` — 更新 3 種 DB 端點列表、CRUD 對照表
- `docs/OCP_DATABASE_GUIDE.md` — 新增 CRUD 範例端點文檔
- `docs/SIMPLIFIED_PATTERN.md` — 補充 Service Facade 模式說明
- `docs/REFACTORING_DISCUSSION.md` — 更新追蹤清單和版本

---

**建立時間**: 2026-02-11
**最後更新**: 2026-02-12
**版本**: 3.1.0（CRUD 補全 + Docker 驗證 + 文檔同步完成）
