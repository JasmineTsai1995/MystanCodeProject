# OCP Tool API 資料庫操作指南

> **📌 OCP Tool API 是基於 HTTP 的 PostgreSQL 資料庫操作介面**  
> 適合跨網路環境、無需直連資料庫的場景

---

## 📋 目錄

- [簡介](#簡介)
- [快速開始](#快速開始)
- [配置說明](#配置說明)
- [基本使用](#基本使用)
- [API 規格](#api-規格)
- [進階使用](#進階使用)
- [錯誤處理](#錯誤處理)
- [最佳實踐](#最佳實踐)
- [API 路由](#api-路由)

---

## 🎯 簡介

### 什麼是 OCP Tool API？

OCP Tool API 是一個基於 HTTP 的 PostgreSQL 資料庫操作介面，提供：

- ✅ **SELECT 查詢**：返回資料 + 欄位名稱
- ✅ **DML 操作**：INSERT/UPDATE/DELETE，返回影響筆數
- ✅ **自動重試**：網路失敗時自動重試
- ✅ **HTTP-based**：無需直連資料庫，透過 API 訪問
- ✅ **動態切換**：支援切換不同資料庫

### 適用場景

- 🌐 跨網路環境的資料庫訪問
- 🔒 受限的網路環境（無法直連資料庫）
- 🔄 需要統一 API 介面進行資料庫操作
- 📊 資料查詢和簡單的資料操作

---

## 🚀 快速開始

### 1. 環境配置

在 `.env` 檔案中配置 OCP API：

```bash
# OCP Tool API 配置

# 方式 1: 使用環境參數（推薦，自動組合 URL）
OCP_ENV=sit  # 可選值: sit, uat, prod
OCP_DEFAULT_DATABASE=datdatcm
OCP_TIMEOUT=30
OCP_VERIFY_SSL=True
OCP_MAX_RETRIES=3
OCP_RETRY_DELAY=1.0

# 方式 2: 直接指定完整 URL（可選，會覆蓋自動組合）
# OCP_API_URL=http://custom-ocp-api.example.com/execute_query_postgresql
```

**環境對應的 URL：**
- `sit`: http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpsit.intranet.tw/execute_query_postgresql
- `uat`: http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpuat.intranet.tw/execute_query_postgresql
- `prod`: http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpprod.intranet.tw/execute_query_postgresql

### 2. 基本使用

```python
from database import OCPClient

# 建立客戶端
client = OCPClient()

# SELECT 查詢
result = client.execute_select("SELECT * FROM users LIMIT 10")
logger.info(f"查詢到 {result.row_count} 筆資料")
logger.info(f"欄位: {result.columns}")
logger.info(f"資料: {result.data}")

# INSERT 操作
result = client.execute_dml("INSERT INTO users(name) VALUES ('Alice')")
logger.info(f"插入 {result.affected_rows} 筆")
```

### 3. 使用便捷函數

```python
from database import execute_ocp_select, execute_ocp_dml

# SELECT
result = execute_ocp_select("SELECT * FROM products")

# INSERT
result = execute_ocp_dml("INSERT INTO logs(message) VALUES ('test')")
```

---

## ⚙️ 配置說明

### OCPConfig 配置選項

| 參數 | 類型 | 預設值 | 說明 |
|------|------|--------|------|
| `env` | str | `sit` | OCP 環境 (sit, uat, prod) |
| `api_url` | Optional[str] | None | OCP API 端點 URL（可選，若不設定則根據 env 自動組合） |
| `default_database` | str | `datdatcm` | 預設資料庫名稱 |
| `timeout` | int | `30` | 請求超時時間（秒） |
| `verify_ssl` | bool | `True` | 是否驗證 SSL 證書 |
| `max_retries` | int | `3` | 最大重試次數 |
| `retry_delay` | float | `1.0` | 重試延遲時間（秒） |

### 環境變數

所有配置都可以透過環境變數設定：

```bash
# 推薦方式：使用環境參數
OCP_ENV=sit  # sit, uat, prod
OCP_DEFAULT_DATABASE=datdatcm

# 可選（有預設值）
OCP_TIMEOUT=30
OCP_VERIFY_SSL=True
OCP_MAX_RETRIES=3
OCP_RETRY_DELAY=1.0

# 進階：自訂 API URL（會覆蓋自動組合）
# OCP_API_URL=http://custom-ocp-api.example.com/execute_query_postgresql
```

### 自訂配置

```python
from database import OCPClient, OCPConfig

# 方式 1: 指定環境（推薦）
config = OCPConfig(
    env="uat",  # 會自動組合為 UAT 環境的 URL
    default_database="custom_db",
    timeout=60,
    max_retries=5
)

# 方式 2: 直接指定完整 URL
config = OCPConfig(
    api_url="http://custom-api.example.com/execute_query_postgresql",
    default_database="custom_db",
    timeout=60,
    max_retries=5
)

# 使用自訂配置建立客戶端
client = OCPClient(config=config)

# 檢視使用的 API URL
logger.info(f"API URL: {client.config.api_url}")
# sit: http://...ocpsit.intranet.tw/...
# uat: http://...ocpuat.intranet.tw/...
# prod: http://...ocpprod.intranet.tw/...
```

---

## 📖 基本使用

### SELECT 查詢

#### 基本查詢

```python
from database import OCPClient

client = OCPClient()

# 執行 SELECT
result = client.execute_select(
    "SELECT * FROM datbatch.judgement_body_embedding LIMIT 2"
)

logger.info(f"查詢時間: {result.query_time} 秒")
logger.info(f"資料筆數: {result.row_count}")
logger.info(f"欄位: {result.columns}")
logger.info(f"資料: {result.data}")
```

#### 轉換為字典格式

```python
result = client.execute_select("SELECT id, name FROM users")

# 轉換為字典列表
dict_list = result.to_dict_list()
# [
#   {"id": 1, "name": "Alice"},
#   {"id": 2, "name": "Bob"}
# ]

for user in dict_list:
    logger.info(f"ID: {user['id']}, Name: {user['name']}")
```

#### 指定資料庫

```python
# 使用預設資料庫
result1 = client.execute_select("SELECT * FROM users")

# 指定其他資料庫
result2 = client.execute_select(
    "SELECT * FROM products",
    database="other_database"
)
```

### DML 操作

#### INSERT

```python
# 插入單筆
result = client.execute_dml(
    "INSERT INTO public.test2(test1) VALUES ('TEST')"
)
logger.info(f"插入 {result.affected_rows} 筆")

# 插入多筆
result = client.execute_dml("""
    INSERT INTO users(name, email) VALUES 
    ('Alice', 'alice@example.com'),
    ('Bob', 'bob@example.com')
""")
logger.info(f"插入 {result.affected_rows} 筆")
```

#### UPDATE

```python
result = client.execute_dml(
    "UPDATE users SET status='active' WHERE id=1"
)
logger.info(f"更新 {result.affected_rows} 筆")

# ⚠️ 記得加 WHERE 條件！
result = client.execute_dml(
    "UPDATE users SET last_login=NOW() WHERE id IN (1, 2, 3)"
)
```

#### DELETE

```python
result = client.execute_dml(
    "DELETE FROM logs WHERE created_at < '2024-01-01'"
)
logger.info(f"刪除 {result.affected_rows} 筆")

# ⚠️ 謹慎使用，建議先 SELECT 確認
# DELETE 前先檢查
check = client.execute_select(
    "SELECT COUNT(*) FROM logs WHERE created_at < '2024-01-01'"
)
logger.info(f"即將刪除 {check.data[0][0]} 筆")

# 確認後再刪除
result = client.execute_dml(
    "DELETE FROM logs WHERE created_at < '2024-01-01'"
)
```

### 自動判斷查詢類型

```python
# 自動判斷 SQL 類型
result = client.execute_query("SELECT * FROM users")
if hasattr(result, 'columns'):
    logger.info(f"SELECT 查詢，返回 {result.row_count} 筆")
else:
    logger.info(f"DML 操作，影響 {result.affected_rows} 筆")
```

---

## 📡 API 規格

### OCP API 端點

**URL**: `http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpsit.intranet.tw/execute_query_postgresql`

**Method**: `POST`

**Content-Type**: `application/json`

### 請求格式

```json
{
  "database": "datdatcm",
  "sql": "SELECT * FROM users LIMIT 10"
}
```

### 回應格式

#### SELECT 查詢回應

```json
{
  "MWHEADER": {
    "RETURNCODE": "0000",
    "RETURNDESC": "交易成功"
  },
  "TRANRS": {
    "status": "Success",
    "session_type": null,
    "query_time": 0.035,
    "result": [
      [
        ["value1", "value2"],
        ["value3", "value4"]
      ],
      ["column1", "column2"]
    ]
  }
}
```

**result 結構**：
- `result[0]`：資料陣列（二維陣列）
- `result[1]`：欄位名稱陣列

#### DML 操作回應

```json
{
  "MWHEADER": {
    "RETURNCODE": "0000",
    "RETURNDESC": "交易成功"
  },
  "TRANRS": {
    "status": "Success",
    "session_type": null,
    "query_time": 0.127,
    "result": [1]
  }
}
```

**result 結構**：
- `result[0]`：影響的資料筆數

#### 錯誤回應

```json
{
  "MWHEADER": {
    "RETURNCODE": "9999",
    "RETURNDESC": "查詢失敗"
  },
  "TRANRS": {
    "status": "Failed",
    "session_type": null,
    "query_time": 0.001,
    "result": []
  }
}
```

---

## 🔧 進階使用

### 批次查詢

```python
from database import OCPClient

client = OCPClient()

queries = [
    "SELECT COUNT(*) FROM users",
    "SELECT COUNT(*) FROM products",
    "SELECT COUNT(*) FROM orders"
]

results = []
for sql in queries:
    try:
        result = client.execute_select(sql)
        results.append({
            "sql": sql,
            "count": result.data[0][0],
            "success": True
        })
    except Exception as e:
        results.append({
            "sql": sql,
            "error": str(e),
            "success": False
        })

# 顯示結果
for r in results:
    if r["success"]:
        logger.info(f"✅ {r['sql']}: {r['count']}")
    else:
        logger.info(f"❌ {r['sql']}: {r['error']}")
```

### 事務處理（模擬）

⚠️ **注意**：OCP API 每次請求是獨立的，無法直接支援事務。如需事務，請使用傳統資料庫連線。

```python
# 不推薦：無法保證原子性
try:
    client.execute_dml("INSERT INTO orders(user_id) VALUES (1)")
    client.execute_dml("UPDATE users SET order_count=order_count+1 WHERE id=1")
except Exception as e:
    # 無法回滾第一個 INSERT
    logger.info(f"操作失敗: {e}")
```

### 動態 SQL 構建

```python
def search_users(name_filter: str = None, email_filter: str = None):
    """動態構建查詢條件"""
    conditions = []
    
    if name_filter:
        conditions.append(f"name LIKE '%{name_filter}%'")
    if email_filter:
        conditions.append(f"email LIKE '%{email_filter}%'")
    
    where_clause = " AND ".join(conditions) if conditions else "1=1"
    sql = f"SELECT * FROM users WHERE {where_clause}"
    
    return client.execute_select(sql)

# 使用
result = search_users(name_filter="John", email_filter="example.com")
```

⚠️ **安全提示**：動態構建 SQL 容易受到 SQL 注入攻擊，請謹慎處理用戶輸入。

---

## ❌ 錯誤處理

### OCPError 異常

```python
from database import OCPClient, OCPError

client = OCPClient()

try:
    result = client.execute_select("SELECT * FROM non_existent_table")
except OCPError as e:
    logger.info(f"OCP 錯誤: {e}")
    logger.info(f"錯誤代碼: {e.return_code}")
    logger.info(f"錯誤描述: {e.return_desc}")
    if e.original_error:
        logger.info(f"原始錯誤: {e.original_error}")
```

### 常見錯誤

| 錯誤代碼 | 說明 | 處理方式 |
|---------|------|---------|
| `0000` | 成功 | - |
| `9999` | 查詢失敗 | 檢查 SQL 語法和權限 |
| HTTP 超時 | 請求超時 | 增加 timeout 或檢查網路 |
| HTTP 500 | 伺服器錯誤 | 檢查 API 狀態 |

### 重試機制

```python
from database import OCPConfig, OCPClient

# 配置重試
config = OCPConfig(
    max_retries=5,      # 最多重試 5 次
    retry_delay=2.0     # 每次重試間隔 2 秒
)

client = OCPClient(config=config)

# 網路不穩定時會自動重試
try:
    result = client.execute_select("SELECT * FROM users")
except OCPError as e:
    logger.info(f"重試 {config.max_retries} 次後仍然失敗: {e}")
```

---

## ✅ 最佳實踐

### 1. 使用連線測試

```python
from database import OCPClient

client = OCPClient()

# 在執行查詢前先測試連線
if not client.test_connection():
    logger.info("⚠️ OCP API 連線失敗，請檢查配置")
    exit(1)

# 連線正常，繼續執行
result = client.execute_select("SELECT * FROM users")
```

### 2. 限制查詢結果

```python
# ✅ 好的做法：使用 LIMIT
result = client.execute_select("SELECT * FROM large_table LIMIT 100")

# ❌ 不好的做法：查詢全表
# result = client.execute_select("SELECT * FROM large_table")  # 可能返回數百萬筆
```

### 3. 使用適當的查詢方法

```python
from database import OCPClient

client = OCPClient()

# ✅ SELECT 使用 execute_select
result = client.execute_select("SELECT * FROM users")

# ✅ DML 使用 execute_dml
result = client.execute_dml("INSERT INTO logs(message) VALUES ('test')")

# ✅ 不確定類型時使用 execute_query
result = client.execute_query(dynamic_sql)
```

### 4. 適當的錯誤處理

```python
import logging
from database import OCPClient, OCPError

logger = logging.getLogger(__name__)
client = OCPClient()

def safe_query(sql: str):
    """安全的查詢封裝"""
    try:
        result = client.execute_select(sql)
        logger.info(f"查詢成功，返回 {result.row_count} 筆")
        return result
    except OCPError as e:
        logger.error(f"OCP 查詢失敗: {e}")
        return None
    except Exception as e:
        logger.error(f"未預期的錯誤: {e}")
        return None

# 使用
result = safe_query("SELECT * FROM users")
if result:
    logger.info(result.data)
```

### 5. 環境配置管理

```python
# ✅ 使用環境變數
from database import OCPClient

# 自動從環境變數讀取配置
client = OCPClient()

# ❌ 不要硬編碼配置
# config = OCPConfig(api_url="http://hardcoded-url/...")
```

### 6. SQL 最佳化

```python
# ✅ 使用索引欄位查詢
sql = "SELECT * FROM users WHERE id = 123"  # id 有索引

# ✅ 只查詢需要的欄位
sql = "SELECT id, name, email FROM users"

# ❌ 避免全表掃描
# sql = "SELECT * FROM users WHERE name LIKE '%test%'"  # 開頭的 % 無法使用索引
```

### 7. 日誌記錄

```python
import logging
from database import OCPClient

# 配置日誌
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

client = OCPClient()

# 記錄重要操作
logger.info("開始查詢使用者資料")
result = client.execute_select("SELECT * FROM users LIMIT 10")
logger.info(f"查詢完成，返回 {result.row_count} 筆，耗時 {result.query_time:.3f} 秒")
```

---

## 🌐 API 路由

專案提供了完整的 FastAPI 路由供測試和使用，共 **11 個端點**。

**分層架構**：Route → Schema → Service(Facade) → OCPClient

| 層級 | 檔案 | 職責 |
|------|------|------|
| Route | `app/routes/db_ocp.py` | 11 個 API 端點 |
| Schema | `app/schemas/db_ocp.py` + `db_common.py` | OCP 專用 + 通用 CRUD Schema |
| Service | `app/services/db_ocp.py` | OCP Facade（封裝 OCPClient） |
| Database | `app/database/ocp_client.py` | 底層 HTTP Client |

### 基礎操作端點（7 個）

```bash
# 測試連線
GET /api/db/ocp/test

# 自動判斷查詢類型（SELECT/DML）
POST /api/db/ocp/query
{"sql": "SELECT 1", "database": "datdatcm"}

# 執行 SELECT 查詢
POST /api/db/ocp/select
{"sql": "SELECT * FROM users LIMIT 10", "database": "datdatcm"}

# 執行 DML 操作
POST /api/db/ocp/dml
{"sql": "INSERT INTO logs(message) VALUES ('test')", "database": "datdatcm"}

# 查詢結果轉為字典格式
POST /api/db/ocp/select/dict
{"sql": "SELECT id, name FROM users", "database": "datdatcm"}

# 查看配置
GET /api/db/ocp/config

# 批次查詢
POST /api/db/ocp/batch/select
[{"sql": "SELECT COUNT(*) FROM users"}, {"sql": "SELECT COUNT(*) FROM products"}]
```

### CRUD 範例端點（4 個）

使用通用 Schema（`db_common.py`），Route 內部組裝 SQL 委託 `OCPService` 執行：

```bash
# 通用資料插入
POST /api/db/ocp/data/insert
{"table_name": "test_users", "data": {"name": "Alice", "email": "alice@example.com"}}

# 通用資料查詢（支援過濾、排序、分頁）
POST /api/db/ocp/data/query
{"table_name": "test_users", "filters": {"name": "Alice"}, "order_by": "-created_at", "skip": 0, "limit": 10}

# 通用資料更新
PUT /api/db/ocp/data/update
{"table_name": "test_users", "filters": {"id": 1}, "data": {"name": "Alice Updated"}}

# 通用資料刪除
DELETE /api/db/ocp/data/delete
{"table_name": "test_users", "filters": {"id": 1}}
```

### 使用 curl 測試

```bash
# 測試連線
curl -X GET http://localhost:8000/api/db/ocp/test

# 執行 SELECT
curl -X POST http://localhost:8000/api/db/ocp/select \
  -H "Content-Type: application/json" \
  -d '{"sql": "SELECT * FROM users LIMIT 2"}'

# CRUD 範例 - 插入
curl -X POST http://localhost:8000/api/db/ocp/data/insert \
  -H "Content-Type: application/json" \
  -d '{"table_name": "test_users", "data": {"name": "Alice", "email": "alice@example.com"}}'

# CRUD 範例 - 查詢
curl -X POST http://localhost:8000/api/db/ocp/data/query \
  -H "Content-Type: application/json" \
  -d '{"table_name": "test_users", "filters": {"name": "Alice"}}'
```

### Swagger 文檔

啟動應用後訪問：`http://localhost:8000/docs`

---

## 📚 相關文件

- **[DEVELOPMENT.md](../DEVELOPMENT.md)** - 專案開發指南
- **[examples/ocp_examples.py](../examples/ocp_examples.py)** - 完整使用範例
- **[tests/test_database/test_ocp_client.py](../tests/test_database/test_ocp_client.py)** - 單元測試

---

## 🔍 常見問題

### Q: OCP API 支援事務嗎？

**A**: 不支援。每個請求都是獨立的，無法保證多個操作的原子性。如需事務，請使用 SQLAlchemy 或 psycopg 直連資料庫。

### Q: 如何處理大量資料？

**A**: 
1. 使用 `LIMIT` 和 `OFFSET` 分頁查詢
2. 避免一次性查詢全表
3. 考慮在資料庫端建立視圖或物化視圖

### Q: 可以執行 DDL 語句嗎？

**A**: 技術上可以，但不建議。DDL 操作（CREATE/ALTER/DROP）應該透過資料庫管理工具或 migration 腳本執行。

### Q: 如何提高查詢效能？

**A**:
1. 在資料庫端建立適當的索引
2. 只查詢需要的欄位
3. 使用 WHERE 條件過濾資料
4. 避免複雜的 JOIN 和子查詢

### Q: 重試機制在什麼情況下會觸發？

**A**: 當遇到網路錯誤（如超時、連線失敗）時會自動重試。API 返回的業務錯誤（如 SQL 語法錯誤）不會重試。

---

**版本**: v2.0
**最後更新**: 2026-02-12
**維護者**: FastAPI 開發團隊
