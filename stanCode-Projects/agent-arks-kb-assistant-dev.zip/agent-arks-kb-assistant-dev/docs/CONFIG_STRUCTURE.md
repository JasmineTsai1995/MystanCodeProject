# Config 資料夾結構說明

## 概述

`app/config/` 資料夾用於集中管理應用程式的所有配置和 Prompt 模板，確保配置的一致性和可維護性。

> **注意**: `prompts/` 目錄及其內容為範例實作，展示如何管理 AI/LLM 相關的 Prompt 模板。開發者可根據實際專案需求自行調整、擴展或移除此功能。

## 目錄結構

```
app/config/
├── __init__.py                      # 模組初始化，匯出 settings
├── settings.py                      # 應用程式設定（環境變數、配置）
└── prompts/                         # Prompt 模板存放區（範例）
    ├── __init__.py                  # 匯出常用 Prompt
    ├── system_prompts.py            # 系統級 Prompt（範例）
    ├── user_prompts.py              # 使用者互動 Prompt（範例）
    ├── loader.py                    # Prompt 載入工具（範例）
    └── templates/                   # 純文字 Prompt 模板（範例）
        ├── default.txt              # 預設 AI 助手 Prompt
        ├── analysis.txt             # 資料分析專家 Prompt
        └── generation.txt           # 內容生成專家 Prompt
```

## 檔案說明

### `settings.py` - 應用程式設定

使用 Pydantic Settings 管理所有環境變數和應用程式配置。

**主要功能：**
- 環境變數自動載入（從 `.env` 檔案）
- 型別驗證和轉換
- 預設值設定
- 配置分組（資料庫、Redis、安全性等）

**使用範例：**
```python
from config import settings

# 存取配置
database_url = settings.database_url
is_production = settings.is_production
cors_origins = settings.cors_origins
```

**配置分類：**
- 應用程式基本設定（名稱、版本、環境）
- 伺服器配置（Host、Port）
- 資料庫配置（PostgreSQL）
- Redis 配置
- 安全性與認證（JWT）
- CORS 設定
- Email 配置
- 檔案上傳
- 日誌設定
- Sentry 錯誤追蹤
- 速率限制

### `prompts/` - Prompt 模板管理

集中管理所有 AI/LLM 相關的 Prompt 模板。

#### `system_prompts.py`

定義系統級 Prompt，用於設定 AI 的角色和行為規範。

**包含的 Prompt：**
- `ANALYSIS_PROMPT` - 資料分析專家
- `GENERATION_PROMPT` - 內容生成專家
- `SUMMARIZATION_PROMPT` - 摘要生成專家
- `TRANSLATION_PROMPT` - 翻譯專家
- `CODE_REVIEW_PROMPT` - 程式碼審查專家
- `QA_PROMPT` - 問題解答專家

#### `user_prompts.py`

定義使用者互動相關的 Prompt 模板。

**包含的 Prompt：**
- `USER_GREETING_PROMPT` - 歡迎訊息
- `USER_HELP_PROMPT` - 幫助訊息
- `USER_ERROR_PROMPT` - 錯誤訊息
- `USER_CONFIRMATION_PROMPT` - 確認訊息
- `USER_COMPLETION_PROMPT` - 完成訊息
- `USER_PROGRESS_PROMPT` - 進度訊息
- `USER_FEEDBACK_PROMPT` - 反饋請求
- `USER_LIMIT_PROMPT` - 限制提醒

#### `loader.py`

提供 Prompt 模板的載入和管理功能。

**主要類別：**
- `PromptLoader` - Prompt 載入器類別

**便捷函數：**
- `load_prompt(template_name)` - 載入模板
- `format_prompt(template_name, **kwargs)` - 格式化模板

#### `templates/`

存放純文字格式的 Prompt 模板檔案。

**優點：**
- 非技術人員也能編輯
- 支援版本控制
- 適合長篇 Prompt
- 易於多語言支援

## 使用指南

### 1. 使用應用程式設定

```python
from config import settings

# 在 FastAPI 應用中使用
@app.on_event("startup")
async def startup():
    logger.info(f"Starting {settings.app_name} v{settings.app_version}")
    logger.info(f"Environment: {settings.app_env}")
    
    # 連接資料庫
    await connect_database(settings.database_url)
    
    # 連接 Redis
    await connect_redis(settings.redis_url)
```

### 2. 使用 System Prompt

```python
from config.prompts import ANALYSIS_PROMPT

async def analyze_data(data: dict):
    """使用 AI 分析資料"""
    messages = [
        {"role": "system", "content": ANALYSIS_PROMPT},
        {"role": "user", "content": f"請分析：{data}"}
    ]
    # 調用 AI API...
```

### 3. 使用 User Prompt

```python
from config.prompts import USER_GREETING_PROMPT, USER_ERROR_PROMPT

# 歡迎新使用者
welcome = USER_GREETING_PROMPT.format(app_name="我的應用")

# 顯示錯誤
error = USER_ERROR_PROMPT.format(
    error_type="驗證錯誤",
    error_message="格式不正確",
    support_email="support@example.com"
)
```

### 4. 使用模板檔案

```python
from config.prompts.loader import load_prompt, format_prompt

# 載入模板
analysis_prompt = load_prompt("analysis")

# 載入並格式化
custom_prompt = format_prompt(
    "generation",
    topic="API 設計",
    style="技術文件"
)
```

## 設計原則

### 1. 單一職責

- `settings.py` 只負責配置管理
- `prompts/` 只負責 Prompt 管理
- 每個檔案有明確的用途

### 2. 集中管理

- 所有配置集中在 `config/` 目錄
- 避免配置散落在各處
- 便於維護和更新

### 3. 環境隔離

- 使用 `.env` 檔案管理環境變數
- 不同環境使用不同配置
- 敏感資訊不進入版本控制

### 4. 型別安全

- 使用 Pydantic 進行型別驗證
- 提供型別提示
- 在開發時捕捉錯誤

### 5. 可擴展性

- 易於新增新的配置項目
- 易於新增新的 Prompt
- 支援多版本和多語言

## 最佳實踐

### 配置管理

1. **使用環境變數**
   - 敏感資訊（密碼、API Key）使用環境變數
   - 提供 `.env.example` 作為範本
   - 不要將 `.env` 加入版本控制

2. **提供預設值**
   - 所有配置都應有合理的預設值
   - 開發環境使用寬鬆設定
   - 生產環境使用嚴格設定

3. **驗證配置**
   - 使用 Pydantic validator 驗證配置
   - 啟動時檢查必要配置
   - 提供清晰的錯誤訊息

### Prompt 管理

1. **版本控制**
   - 所有 Prompt 納入 Git
   - 重大變更建立新版本
   - 記錄變更原因

2. **參數化**
   - 使用 `{變數}` 進行參數化
   - 避免硬編碼
   - 提高重用性

3. **測試**
   - 測試 Prompt 格式化
   - 測試必要元素存在
   - 測試輸出品質

4. **文件化**
   - 說明每個 Prompt 的用途
   - 提供使用範例
   - 記錄最佳實踐

## 擴展指南

### 新增配置項目

1. 在 `settings.py` 的 `Settings` 類別中新增欄位
2. 在 `.env.example` 中新增對應的環境變數
3. 更新文件說明

```python
# settings.py
class Settings(BaseSettings):
    # ... 現有配置 ...
    
    # 新增配置
    new_feature_enabled: bool = Field(default=False, description="新功能開關")
    new_api_key: Optional[str] = Field(default=None, description="新 API 金鑰")
```

### 新增 Prompt

#### 方式 1: Python 變數（適合短 Prompt）

```python
# system_prompts.py
NEW_PROMPT = """
你的新 Prompt 內容...
"""

# __init__.py
from .system_prompts import NEW_PROMPT
__all__ = [..., "NEW_PROMPT"]
```

#### 方式 2: 模板檔案（適合長 Prompt）

```bash
# 建立新模板
echo "你的 Prompt 內容" > app/config/prompts/templates/new_prompt.txt

# 使用
from config.prompts.loader import load_prompt
prompt = load_prompt("new_prompt")
```

## 遷移指南

如果你的專案原本使用 `app/config.py`，請按以下步驟遷移：

### 步驟 1: 備份現有配置

```bash
cp app/config.py app/config.py.backup
```

### 步驟 2: 建立新結構

```bash
mkdir -p app/config/prompts/templates
```

### 步驟 3: 移動配置

將 `config.py` 的內容移到 `config/settings.py`

### 步驟 4: 更新引用

```python
# 舊的引用
from config import settings

# 新的引用（相同）
from config import settings
```

### 步驟 5: 測試

```bash
pytest tests/
```

## 常見問題

### Q1: 為什麼要分離 config.py 為 config/ 資料夾？

**答：** 
- 更好的組織結構
- 支援 Prompt 管理
- 便於擴展和維護
- 符合大型專案的最佳實踐

### Q2: Prompt 應該放在 Python 檔案還是文字檔案？

**答：**
- **Python 檔案**：短 Prompt、需要程式碼補全
- **文字檔案**：長 Prompt、需要非技術人員編輯

### Q3: 如何在不同環境使用不同配置？

**答：**
```bash
# 開發環境
cp .env.development .env

# 生產環境
cp .env.production .env
```

### Q4: 如何保護敏感配置？

**答：**
- 使用環境變數
- 不要提交 `.env` 到 Git
- 使用密鑰管理服務（如 AWS Secrets Manager）
- 在 CI/CD 中注入環境變數

## 相關文件

- [Prompt 使用指南](./PROMPT_USAGE.md)
- [專案結構說明](../PROJECT_STRUCTURE.md)
- [開發指南](./DEVELOPMENT.md)

---

**最後更新**: 2025-11-07
