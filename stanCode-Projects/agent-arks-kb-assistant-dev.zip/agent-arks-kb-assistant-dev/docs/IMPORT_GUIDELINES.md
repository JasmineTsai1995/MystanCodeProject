# 專案開發規範

## 概述

本文件說明專案的核心開發規範，包括 Import 路徑和日誌記錄。

---

## 規範 1: Import 路徑

本專案使用 Docker 建置 FastAPI 應用程式，容器內的工作目錄起始於 `app/`，因此所有 import 路徑**不需要**使用 `app.` 前綴。

## 基本原則

### ✅ 正確的 Import 方式

```python
# 從 utils 匯入（推薦使用模組 import 避免名稱衝突）
from utils import request  # ✅ 推薦：避免 get, post 等常見名稱衝突
result = request.get("https://api.example.com")
client = request.RequestClient(base_url="...")

# 從 config 匯入
from config import settings
from config.prompts import ANALYSIS_PROMPT

# 從 models 匯入
from models.user import User

# 從 schemas 匯入
from schemas.user import UserCreate, UserResponse

# 從 services 匯入
from services.user_service import UserService

# 從 routes 匯入
from routes import user, product
```

### ❌ 錯誤的 Import 方式

```python
# 不要使用 app. 前綴
from app.utils.request import make_request  # ❌
from app.config import settings  # ❌
from app.models.user import User  # ❌
```

## 原因說明

### Docker 容器結構

當使用 Docker 建置時，容器內的目錄結構如下：

```
/app/                    # 容器內的工作目錄
├── main.py
├── config/
│   ├── settings.py
│   └── prompts/
├── utils/
│   └── request.py
├── models/
├── schemas/
├── routes/
└── services/
```

Python 的 `sys.path` 包含 `/app/`，因此可以直接從頂層模組匯入。

### Dockerfile 範例

```dockerfile
# base/Dockerfile - 基礎映像
FROM python:3.11-slim-bullseye

WORKDIR /app

# 從 base 目錄複製 requirements.txt
COPY base/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Dockerfile - 應用映像
FROM fastapi-base:latest

WORKDIR /app
COPY ./app /app

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 各模組的 Import 規範

### 1. Utils 工具函數

**特別注意：request 工具推薦使用模組 import**

```python
# ✅ 推薦（避免名稱衝突）
from utils import request

result = request.get("https://api.example.com")
client = request.RequestClient(base_url="...")
data = request.post("/api/users", json_data={...})

# ⚠️ 可用但不推薦（容易與其他套件衝突）
from utils.request import get, post, RequestClient
result = get("https://api.example.com")  # 可能與 httpx.get, aiohttp.get 混淆

# ❌ 錯誤
from app.utils.request import make_request
```

**為什麼 request 工具要特別處理？**
- `get`, `post`, `put`, `delete` 是極其常見的函數名稱
- 容易與 `httpx`, `aiohttp`, `requests` 等套件的同名函數混淆
- 使用 `request.get()` 明確表示來源，提高程式碼可讀性

**其他 utils 工具**

```python
# ✅ 正確
from utils.validators import validate_email
from utils.formatters import format_date
from utils.helpers import some_helper

# ❌ 錯誤
from app.utils.validators import validate_email
```

**注意**: `utils/__init__.py` 保持簡潔，不匯出所有工具，避免名稱衝突。

### 2. Config 配置

```python
# ✅ 正確
from config import settings
from config.prompts import ANALYSIS_PROMPT
from config.prompts.loader import load_prompt

# ❌ 錯誤
from app.config import settings
```

### 3. Models 資料庫模型

```python
# ✅ 正確
from models.user import User
from models.product import Product

# ❌ 錯誤
from app.models.user import User
```

### 4. Schemas 資料驗證

```python
# ✅ 正確
from schemas.user import UserCreate, UserResponse
from schemas.product import ProductCreate

# ❌ 錯誤
from app.schemas.user import UserCreate
```

### 5. Services 業務邏輯

```python
# ✅ 正確
from services.user_service import UserService
from services.payment_service import PaymentService

# ❌ 錯誤
from app.services.user_service import UserService
```

### 6. Routes 路由

```python
# ✅ 正確
from routes import user, product
from routes.user import router as user_router

# ❌ 錯誤
from app.routes import user
```

### 7. Database 資料庫

```python
# ✅ 正確
from database.connection import get_db
from database.session import SessionLocal

# ❌ 錯誤
from app.database.connection import get_db
```

### 8. Middleware 中介軟體

```python
# ✅ 正確
from middleware.auth import AuthMiddleware
from middleware.logging import LoggingMiddleware

# ❌ 錯誤
from app.middleware.auth import AuthMiddleware
```

## 測試檔案的 Import

測試檔案位於 `tests/` 目錄，需要能夠匯入 `app/` 下的模組。

### pytest.ini 配置

```ini
[pytest]
pythonpath = app
testpaths = tests
```

### 測試檔案中的 Import

```python
# tests/test_utils/test_request.py

# ✅ 正確（推薦）
from utils import request

def test_get_request():
    result = request.get("https://api.example.com")
    assert result is not None

# ❌ 錯誤
from app.utils.request import make_request
```

## 範例檔案的 Import

範例檔案位於 `examples/` 目錄，同樣需要能夠匯入 `app/` 下的模組。

### 範例檔案中的 Import

```python
# examples/request_examples.py

# ✅ 正確（推薦）
from utils import request
from config import settings

result = request.get("https://api.example.com")
client = request.RequestClient(base_url="...")

# ❌ 錯誤
from app.utils.request import make_request
```

## 相對 Import vs 絕對 Import

### 絕對 Import（推薦）

```python
# 在 services/user_service.py 中

# ✅ 推薦使用絕對 import
from models.user import User
from schemas.user import UserCreate
from utils import request
```

### 相對 Import（不推薦）

```python
# 在 services/user_service.py 中

# ❌ 不推薦
from ..models.user import User
from ..schemas.user import UserCreate
```

**原因**: 絕對 import 更清晰、更容易理解，且在重構時更安全。

## 常見問題

### Q1: 為什麼不使用 `app.` 前綴？

**A**: 因為 Docker 容器的工作目錄是 `/app/`，Python 的 `sys.path` 已經包含這個路徑，所以可以直接從頂層模組匯入。

### Q2: 本地開發時如何確保 import 正確？

**A**: 在專案根目錄執行 Python 時，需要設定 `PYTHONPATH`：

```bash
# Linux/Mac
export PYTHONPATH="${PYTHONPATH}:${PWD}/app"

# Windows (PowerShell)
$env:PYTHONPATH = "$env:PYTHONPATH;$PWD\app"

# 或使用 pytest（已在 pytest.ini 中配置）
pytest
```

### Q3: IDE 顯示 import 錯誤怎麼辦？

**A**: 配置 IDE 的 Python 路徑：

**VS Code** - `.vscode/settings.json`:
```json
{
    "python.analysis.extraPaths": ["./app"]
}
```

**PyCharm**: 
1. 右鍵點擊 `app` 資料夾
2. 選擇 "Mark Directory as" → "Sources Root"

### Q4: utils/__init__.py 為什麼是空的？

**A**: 為了避免名稱衝突和混淆。當工具函數變多時，在 `__init__.py` 中全部匯出會造成：
- 名稱衝突（不同模組可能有相同名稱的函數）
- 匯入不明確（不知道函數來自哪個模組）
- 維護困難（每次新增工具都要更新 `__init__.py`）

**正確做法**:
```python
# ✅ 明確指定來源（推薦）
from utils import request  # request 工具使用模組 import
from utils.validators import validate_email  # 其他工具直接 import

# ✅ 也可以這樣（但 request 建議用模組 import）
from utils.validators import validate_email
from utils.formatters import format_date

# ❌ 不明確的來源
from utils import make_request, validate_email  # 不知道來自哪個模組
```

---

## 規範 2: 日誌記錄

### 使用 `logger` 而非 `print`

所有日誌輸出都應該使用 Python 的 `logging` 模組，而不是 `print()` 函數。

### ✅ 正確的日誌記錄方式

```python
import logging

# 在模組頂部建立 logger
logger = logging.getLogger(__name__)

# 不同級別的日誌
logger.debug("除錯資訊：變數值為 %s", value)
logger.info("使用者 %s 登入成功", username)
logger.warning("警告：記憶體使用率達到 80%%")
logger.error("錯誤：無法連線到資料庫 - %s", error)
logger.exception("發生異常")  # 自動記錄 traceback

# 在函數中使用
def create_user(user_data: dict):
    logger.info(f"建立使用者: {user_data.get('email')}")
    try:
        # 業務邏輯
        user = User(**user_data)
        logger.debug(f"使用者物件已建立: {user}")
        return user
    except Exception as e:
        logger.error(f"建立使用者失敗: {e}")
        raise

# 在 API 路由中使用
@router.post("/users")
async def create_user_endpoint(user: UserCreate):
    logger.info(f"收到建立使用者請求: {user.email}")
    result = await user_service.create(user)
    logger.info(f"使用者建立成功: ID={result.id}")
    return result
```

### ❌ 錯誤的日誌記錄方式

```python
# 不要使用 print
print("使用者登入成功")
print(f"錯誤: {error}")
print(f"除錯資訊: {data}")

# 不要在生產程式碼中使用 print
def create_user(user_data: dict):
    print(f"建立使用者: {user_data}")  # ❌
    # ...
```

### 日誌級別說明

| 級別 | 使用時機 | 範例 |
|------|---------|------|
| **DEBUG** | 詳細的除錯資訊 | `logger.debug(f"變數值: {value}")` |
| **INFO** | 一般資訊訊息 | `logger.info("使用者登入成功")` |
| **WARNING** | 警告訊息，不影響運行 | `logger.warning("快取未命中")` |
| **ERROR** | 錯誤訊息，影響功能 | `logger.error("資料庫連線失敗")` |
| **CRITICAL** | 嚴重錯誤，系統可能停止 | `logger.critical("磁碟空間不足")` |

### 日誌配置範例

```python
# config/logging_config.py
import logging
import sys

def setup_logging():
    """設定日誌配置"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('logs/app.log')
        ]
    )

# main.py
from config.logging_config import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

logger.info("應用程式啟動")
```

### 使用 logger 的好處

1. **可控制的日誌級別**
   - 開發環境使用 DEBUG 級別
   - 生產環境使用 INFO 或 WARNING 級別
   - 不需要修改程式碼，只需調整配置

2. **結構化的日誌輸出**
   - 包含時間戳記
   - 包含模組名稱
   - 包含日誌級別
   - 便於搜尋和過濾

3. **靈活的輸出目標**
   - 可以輸出到控制台
   - 可以輸出到檔案
   - 可以輸出到外部系統（如 ELK、Sentry）

4. **生產環境友善**
   - 便於日誌收集和分析
   - 支援日誌輪轉（log rotation）
   - 不會被 print 的輸出干擾

### 實際範例

```python
# services/user_service.py
import logging
from typing import Optional
from models.user import User
from schemas.user import UserCreate

logger = logging.getLogger(__name__)

class UserService:
    """使用者服務"""
    
    async def create_user(self, user_data: UserCreate) -> User:
        """建立使用者"""
        logger.info(f"開始建立使用者: {user_data.email}")
        
        try:
            # 檢查使用者是否存在
            existing_user = await self.get_by_email(user_data.email)
            if existing_user:
                logger.warning(f"使用者已存在: {user_data.email}")
                raise ValueError("使用者已存在")
            
            # 建立使用者
            user = User(**user_data.dict())
            await user.save()
            
            logger.info(f"使用者建立成功: ID={user.id}, Email={user.email}")
            return user
            
        except Exception as e:
            logger.error(f"建立使用者失敗: {e}", exc_info=True)
            raise
    
    async def get_by_email(self, email: str) -> Optional[User]:
        """根據 email 獲取使用者"""
        logger.debug(f"查詢使用者: {email}")
        user = await User.find_one({"email": email})
        
        if user:
            logger.debug(f"找到使用者: {email}")
        else:
            logger.debug(f"使用者不存在: {email}")
        
        return user
```

---

## 檢查清單

在編寫程式碼時，請確認：

### Import 規範
- [ ] 所有 import 都不使用 `app.` 前綴
- [ ] 使用絕對 import 而非相對 import
- [ ] 從 `utils` 匯入時明確指定子模組（如 `utils.request`）
- [ ] 測試檔案的 import 路徑正確
- [ ] IDE 已正確配置 Python 路徑

### 日誌規範
- [ ] 使用 `logger` 而非 `print`
- [ ] 在模組頂部使用 `logger = logging.getLogger(__name__)`
- [ ] 根據情況選擇適當的日誌級別
- [ ] 日誌訊息清晰且包含必要資訊
- [ ] 錯誤日誌包含異常資訊（使用 `exc_info=True` 或 `logger.exception()`）

## 總結

### Import 規範核心原則
1. ✅ 不使用 `app.` 前綴
2. ✅ 使用絕對 import
3. ✅ 明確指定來源模組
4. ✅ 保持 `utils/__init__.py` 簡潔

### 日誌規範核心原則
1. ✅ 使用 `logger` 而非 `print`
2. ✅ 選擇適當的日誌級別
3. ✅ 提供清晰的日誌訊息
4. ✅ 在錯誤時記錄完整資訊

遵循這些規範可以確保：
- 程式碼在 Docker 容器中正確執行
- 測試可以正常運行
- IDE 提供正確的自動完成
- 程式碼易於維護和重構
- 日誌管理統一且易於追蹤
- 生產環境問題容易診斷

---

**文件版本**: 2.0  
**最後更新**: 2025-11-10
