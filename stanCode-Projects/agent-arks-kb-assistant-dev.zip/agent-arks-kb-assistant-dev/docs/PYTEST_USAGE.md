# Pytest 配置與使用說明

## ✅ pytest.ini 使用狀態

### 問題：pytest.ini 在 Docker 容器內用得到嗎？

**答案：是的，用得到！**

### 掛載配置

查看 `docker-compose.yml`：

```yaml
services:
  app:
    volumes:
      - ./app:/app                    # ✅ 應用代碼
      - ./tests:/app/tests            # ✅ 測試文件
      - ./pytest.ini:/app/pytest.ini  # ✅ pytest 配置
      - ./logs:/app/logs              # ✅ 日誌目錄
```

**結論**：
- `pytest.ini` 位於專案根目錄
- 透過 volume 掛載到容器的 `/app/pytest.ini`
- 容器內執行 pytest 時會正確讀取配置

---

## 📁 當前測試結構

```
D:\coding\docker\fastapi_structure_standard\
├── pytest.ini                    # ✅ pytest 配置文件
├── tests/                        # ✅ 測試目錄
│   ├── test_config/             # 配置測試
│   │   ├── __init__.py
│   │   ├── test_settings.py
│   │   └── test_prompts.py
│   ├── test_database/           # 資料庫測試
│   │   ├── __init__.py
│   │   ├── test_connections.py
│   │   └── test_real_scenarios.py
│   └── test_utils/              # 工具測試
│       ├── __init__.py
│       └── test_request.py
└── app/                          # 應用代碼
```

---

## 🎯 pytest.ini 配置內容

```ini
[pytest]
# 測試發現規則
python_files = test_*.py
python_classes = Test*
python_functions = test_*

# 測試目錄
testpaths = tests

# 預設選項
addopts =
    -v                              # 詳細輸出
    --tb=short                      # 簡短的錯誤追蹤
    --asyncio-mode=auto             # 自動處理異步測試
    -W ignore::DeprecationWarning   # 忽略棄用警告

# 異步測試支援
asyncio_mode = auto

# 測試標記
markers =
    unit: 單元測試
    integration: 整合測試
    database: 需要資料庫連線的測試
    slow: 執行時間較長的測試
```

---

## 🚀 如何在容器內運行測試

### 方法 1：進入容器執行（推薦）

```bash
# 進入容器
docker-compose exec app bash

# 執行所有測試
pytest

# 執行特定目錄
pytest tests/test_database/

# 執行特定文件
pytest tests/test_database/test_connections.py

# 執行特定測試函數
pytest tests/test_database/test_connections.py::test_sqlalchemy_init

# 使用標記
pytest -m unit          # 只跑單元測試
pytest -m database      # 只跑資料庫測試
pytest -m "not slow"    # 跳過慢速測試
```

### 方法 2：直接執行

```bash
# 不進入容器，直接執行
docker-compose exec app pytest

# 帶參數執行
docker-compose exec app pytest -v tests/test_database/

# 查看覆蓋率
docker-compose exec app pytest --cov=app --cov-report=html
```

### 方法 3：在宿主機執行（需要安裝依賴）

```bash
# 確保本地有 Python 環境和依賴
pip install -r base/requirements.txt

# 執行測試
pytest
```

---

## 📊 測試驗證

### 驗證 pytest.ini 是否生效

```bash
# 進入容器
docker-compose exec app bash

# 查看 pytest 配置
pytest --version
pytest --markers    # 查看自定義標記

# 檢查配置文件是否存在
ls -la /app/pytest.ini

# 查看 pytest 找到的測試
pytest --collect-only
```

**預期輸出**：
```
collected 8 items / 0 deselected / 8 selected

<Module tests/test_config/test_settings.py>
  <Function test_settings_loading>
  ...
<Module tests/test_database/test_connections.py>
  <Function test_sqlalchemy_init>
  <Function test_psycopg_init>
  ...
```

---

## 🔍 常見問題

### Q1: pytest.ini 沒有被讀取？

**檢查步驟**：

1. **確認文件是否掛載**
   ```bash
   docker-compose exec app ls -la /app/pytest.ini
   ```
   應該看到文件存在

2. **檢查工作目錄**
   ```bash
   docker-compose exec app pwd
   ```
   應該顯示 `/app`

3. **查看 pytest 配置**
   ```bash
   docker-compose exec app pytest --version
   docker-compose exec app pytest --markers
   ```
   應該看到自定義的 markers（unit, integration, database, slow）

### Q2: 測試找不到 app 模組？

**原因**：PYTHONPATH 設定問題

**解決方案 1**：檢查 Dockerfile（已設定）
```dockerfile
ENV PYTHONPATH=/app
```

**解決方案 2**：手動設定
```bash
export PYTHONPATH=/app
```

### Q3: 異步測試報錯？

**確認配置**：
```ini
# pytest.ini
asyncio_mode = auto
addopts = --asyncio-mode=auto
```

**確認依賴**：
```bash
# 檢查是否安裝 pytest-asyncio
pip list | grep pytest-asyncio
```

---

## 📝 測試範例

### 基本測試範例

```python
# tests/test_example.py
import pytest

def test_basic():
    """基本測試"""
    assert 1 + 1 == 2

@pytest.mark.unit
def test_with_marker():
    """帶標記的測試"""
    assert True

@pytest.mark.asyncio
async def test_async():
    """異步測試"""
    result = await some_async_function()
    assert result == expected
```

### 資料庫測試範例

```python
# tests/test_database/test_example.py
import pytest
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_db

@pytest.mark.database
@pytest.mark.asyncio
async def test_database_connection():
    """測試資料庫連線"""
    async for session in get_db():
        result = await session.execute("SELECT 1")
        assert result is not None
```

---

## 🎯 建議的測試策略

### 1. 測試分類

使用 markers 區分測試類型：

```bash
# 快速測試（開發時）
pytest -m "unit and not slow"

# 完整測試（CI/CD）
pytest -m "unit or integration"

# 資料庫測試（需要 DB）
pytest -m database
```

### 2. 測試覆蓋率

```bash
# 生成覆蓋率報告
docker-compose exec app pytest --cov=app --cov-report=term-missing

# 生成 HTML 報告
docker-compose exec app pytest --cov=app --cov-report=html

# 查看報告
# 報告會在 htmlcov/index.html
```

### 3. 持續整合

在 CI/CD 中運行測試：

```yaml
# .github/workflows/test.yml
- name: Run tests
  run: |
    docker-compose up -d db
    docker-compose run --rm app pytest -v --cov=app
```

---

## ✅ 驗證清單

- [x] pytest.ini 存在於專案根目錄
- [x] pytest.ini 已掛載到容器（/app/pytest.ini）
- [x] tests 目錄已掛載到容器（/app/tests）
- [x] PYTHONPATH 已設定為 /app
- [x] pytest 和 pytest-asyncio 已安裝
- [x] 測試文件遵循命名規則（test_*.py）

---

## 🚀 快速測試腳本

創建一個測試腳本 `scripts/run-tests.sh`：

```bash
#!/bin/bash
# 運行所有測試

echo "Starting tests..."

# 確保容器運行
docker-compose up -d

# 等待資料庫就緒
sleep 3

# 執行測試
docker-compose exec app pytest -v \
    --tb=short \
    --cov=app \
    --cov-report=term-missing \
    --cov-report=html

echo "Tests completed!"
echo "Coverage report: htmlcov/index.html"
```

Windows 版本 `scripts/run-tests.bat`：

```batch
@echo off
echo Starting tests...

docker-compose up -d
timeout /t 3 /nobreak

docker-compose exec app pytest -v --tb=short --cov=app --cov-report=term-missing --cov-report=html

echo Tests completed!
echo Coverage report: htmlcov/index.html
```

---

## 📚 總結

**pytest.ini 完全可用！**

✅ **已正確配置**：
- pytest.ini 透過 volume 掛載到容器
- 測試目錄結構完整
- 異步測試支援已啟用
- 自定義標記已設定

✅ **可以直接使用**：
```bash
# 在容器內執行測試
docker-compose exec app pytest

# 或進入容器
docker-compose exec app bash
pytest -v
```

✅ **配置生效**：
- 測試發現規則：test_*.py
- 異步模式：自動
- 輸出格式：詳細模式
- 自定義標記：unit, integration, database, slow

**開始測試吧！** 🎉
