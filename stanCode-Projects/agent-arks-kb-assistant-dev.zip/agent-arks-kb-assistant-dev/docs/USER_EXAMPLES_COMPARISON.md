# 用戶範例對比文檔

> **📌 驗證我們的實現完全涵蓋用戶提供的三個範例**

---

## 📋 用戶提供的範例

### 範例 1：SQLAlchemy AsyncEngine

```python
_async_engine = None 

async def init_engine(): 
    global _async_engine 
    if _async_engine is not None: 
        return _async_engine 
    
    db_url = f"{os.getenv('POSTGRE_USER')}:{os.getenv('POSTGRE_PWD')}@{os.getenv('DAT_POSTGRE_IP')}:5432/midaipcm" 
    
    _async_engine = create_async_engine( 
        f"postgresql+asyncpg://{db_url}", 
        pool_size=2, 
        max_overflow=10, 
        pool_pre_ping=True, 
        pool_recycle=3600
    )
    
    return _async_engine
```

### 範例 2：psycopg AsyncConnectionPool

```python
db_url = f"{os.getenv('POSTGRE_USER')}:{os.getenv('POSTGRE_PWD')}@{os.getenv('DAT_POSTGRE_IP')}:5432/midaipcm" 

pool = AsyncConnectionPool( 
    conninfo=f"postgresql://{db_url}?sslmode=disable", 
    configure=set_schema, 
    min_size=2, 
    max_size=5, 
    max_idle=30, 
    max_lifetime=600, 
    kwargs={ 
        "autocommit": True, 
        "prepare_threshold": 0, 
    }, 
)

checkpointer = AsyncPostgresSaver(pool) 
return checkpointer
```

---

## ✅ 我們的實現對比

### 範例 1 對比：SQLAlchemy AsyncEngine

#### 用戶範例的關鍵特性

| 特性 | 用戶範例 | 我們的實現 | 狀態 |
|------|---------|-----------|------|
| **全域變數緩存** | `_async_engine = None` | `_async_engine = None` | ✅ 完全相同 |
| **單例檢查** | `if _async_engine is not None: return` | `if _async_engine is not None: return` | ✅ 完全相同 |
| **URL 格式** | `postgresql+asyncpg://{user}:{pwd}@{host}:5432/{db}` | `config.get_sqlalchemy_url()` | ✅ 完全相同 |
| **pool_size** | `2` | `config.pool_size=2` | ✅ 支援自定義 |
| **max_overflow** | `10` | `config.max_overflow=10` | ✅ 支援自定義 |
| **pool_pre_ping** | `True` | `config.pool_pre_ping=True` | ✅ 支援自定義 |
| **pool_recycle** | `3600` | `config.pool_recycle=3600` | ✅ 支援自定義 |

#### 使用方式對比

**用戶範例**：
```python
engine = await init_engine()
```

**我們的實現**：
```python
from database import DatabaseConfig, init_async_engine

config = DatabaseConfig(
    host=os.getenv("DAT_POSTGRE_IP"),
    user=os.getenv("POSTGRE_USER"),
    password=os.getenv("POSTGRE_PWD"),
    database="midaipcm",
    pool_size=2,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600,
)

engine = await init_async_engine(config)
```

**優勢**：
- ✅ 完全符合用戶範例的行為
- ✅ 更靈活的配置方式
- ✅ 類型安全（使用 Pydantic）
- ✅ 支援從環境變數自動讀取

---

### 範例 2 對比：psycopg AsyncConnectionPool

#### 用戶範例的關鍵特性

| 特性 | 用戶範例 | 我們的實現 | 狀態 |
|------|---------|-----------|------|
| **URL 格式** | `postgresql://{user}:{pwd}@{host}:5432/{db}?sslmode=disable` | `config.get_psycopg_url()` | ✅ 完全相同 |
| **configure 回調** | `configure=set_schema` | `configure_callback=set_schema` | ✅ 支援 |
| **min_size** | `2` | `config.min_size=2` | ✅ 支援自定義 |
| **max_size** | `5` | `config.max_size=5` | ✅ 支援自定義 |
| **max_idle** | `30` | `config.max_idle=30` | ✅ 支援自定義 |
| **max_lifetime** | `600` | `config.max_lifetime=600` | ✅ 支援自定義 |
| **autocommit** | `True` | `kwargs={"autocommit": True}` | ✅ 預設啟用 |
| **prepare_threshold** | `0` | `kwargs={"prepare_threshold": 0}` | ✅ 預設設定 |

#### 使用方式對比

**用戶範例**：
```python
async def set_schema(conn):
    await conn.execute("SET search_path TO my_schema")

pool = AsyncConnectionPool(
    conninfo=f"postgresql://{db_url}?sslmode=disable",
    configure=set_schema,
    min_size=2,
    max_size=5,
    max_idle=30,
    max_lifetime=600,
    kwargs={"autocommit": True, "prepare_threshold": 0},
)
```

**我們的實現**：
```python
from database import DatabaseConfig, init_async_pool

async def set_schema(conn):
    await conn.execute("SET search_path TO my_schema")

config = DatabaseConfig(
    host=os.getenv("DAT_POSTGRE_IP"),
    user=os.getenv("POSTGRE_USER"),
    password=os.getenv("POSTGRE_PWD"),
    database="midaipcm",
    ssl_mode="disable",
    min_size=2,
    max_size=5,
    max_idle=30,
    max_lifetime=600,
)

pool = await init_async_pool(config, configure_callback=set_schema)
```

**優勢**：
- ✅ 完全符合用戶範例的參數
- ✅ `autocommit` 和 `prepare_threshold` 已預設配置
- ✅ 支援 configure callback
- ✅ 自動測試連線

---

### 範例 3 對比：LangGraph Checkpointer

#### 用戶範例

```python
checkpointer = AsyncPostgresSaver(pool)
return checkpointer
```

#### 我們的實現

```python
from database import init_async_pool, get_async_pool
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

# 初始化連線池
await init_async_pool(config)

# 獲取連線池並建立 checkpointer
pool = get_async_pool()
checkpointer = AsyncPostgresSaver(pool)
```

**狀態**：✅ 完全支援，可以直接使用

---

## 🎯 完整使用範例

### 在 FastAPI 中整合用戶的三個範例

```python
from fastapi import FastAPI
from contextlib import asynccontextmanager
from database import (
    DatabaseConfig,
    init_async_engine,
    init_async_pool,
    get_async_pool,
    close_db_connections,
    close_pool_connections,
)

# 配置（與用戶範例相同）
config = DatabaseConfig(
    host=os.getenv("DAT_POSTGRE_IP", "localhost"),
    port=5432,
    user=os.getenv("POSTGRE_USER", "postgres"),
    password=os.getenv("POSTGRE_PWD", "postgres"),
    database="midaipcm",
    
    # SQLAlchemy 配置（範例 1）
    pool_size=2,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600,
    
    # psycopg 配置（範例 2）
    min_size=2,
    max_size=5,
    max_idle=30,
    max_lifetime=600,
    ssl_mode="disable",
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 啟動時初始化
    logger.info("🚀 初始化資料庫連線...")
    
    # 範例 1: SQLAlchemy Engine
    engine = await init_async_engine(config)
    logger.info(f"✅ SQLAlchemy Engine 初始化完成")
    
    # 範例 2: psycopg Pool
    try:
        # 可選：設定 schema
        async def set_schema(conn):
            await conn.execute("SET search_path TO public")
        
        pool = await init_async_pool(config, configure_callback=set_schema)
        logger.info(f"✅ psycopg Pool 初始化完成")
        
        # 範例 3: LangGraph Checkpointer
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        checkpointer = AsyncPostgresSaver(pool)
        app.state.checkpointer = checkpointer
        logger.info(f"✅ LangGraph Checkpointer 初始化完成")
    
    except ImportError:
        logger.info("⚠️  psycopg 或 langgraph 未安裝")
    
    yield
    
    # 關閉時清理
    logger.info("🔄 關閉資料庫連線...")
    await close_db_connections()
    await close_pool_connections()
    logger.info("✅ 資料庫連線已關閉")

app = FastAPI(lifespan=lifespan)
```

---

## 📊 功能對比總結

| 功能 | 用戶範例 | 我們的實現 | 改進 |
|------|---------|-----------|------|
| **SQLAlchemy 單例** | ✅ | ✅ | 無需改變 |
| **連線池配置** | ✅ | ✅ | 更靈活、類型安全 |
| **psycopg Pool** | ✅ | ✅ | 自動測試連線 |
| **configure 回調** | ✅ | ✅ | 完全支援 |
| **LangGraph** | ✅ | ✅ | 開箱即用 |
| **環境變數管理** | 手動 | ✅ | Pydantic 自動讀取 |
| **健康檢查** | ❌ | ✅ | 新增功能 |
| **FastAPI 整合** | 需手寫 | ✅ | 提供 `get_db` 依賴 |
| **錯誤處理** | 基本 | ✅ | 完整的異常處理 |
| **測試支援** | ❌ | ✅ | 完整測試套件 |

---

## 🧪 測試驗證

### 運行測試

```bash
# 測試所有真實場景
pytest tests/test_database/test_real_scenarios.py -v

# 運行驗證腳本
python examples/verify_user_examples.py
```

### 測試涵蓋範圍

- ✅ 範例 1：SQLAlchemy 配置和單例模式
- ✅ 範例 2：psycopg Pool 配置和 configure callback
- ✅ 範例 3：LangGraph Checkpointer 初始化
- ✅ 混合使用場景

---

## ✅ 結論

### 我們的實現**完全涵蓋**用戶的三個範例：

1. **範例 1（SQLAlchemy）**：
   - ✅ 相同的參數配置
   - ✅ 單例模式
   - ✅ 全域變數管理
   - ✅ 完全兼容

2. **範例 2（psycopg）**：
   - ✅ 相同的參數配置
   - ✅ 支援 configure callback
   - ✅ autocommit 和 prepare_threshold
   - ✅ 完全兼容

3. **範例 3（LangGraph）**：
   - ✅ 直接使用連線池
   - ✅ AsyncPostgresSaver 支援
   - ✅ 完全兼容

### 額外優勢：

- ✅ 更靈活的配置系統（Pydantic）
- ✅ 自動從環境變數讀取
- ✅ FastAPI 依賴注入支援
- ✅ 健康檢查功能
- ✅ 完整的測試套件
- ✅ 詳細的文檔和範例

---

**驗證腳本**：`examples/verify_user_examples.py`  
**測試文件**：`tests/test_database/test_real_scenarios.py`  
**使用文檔**：`docs/DB_PATTERNS_GUIDE.md`
