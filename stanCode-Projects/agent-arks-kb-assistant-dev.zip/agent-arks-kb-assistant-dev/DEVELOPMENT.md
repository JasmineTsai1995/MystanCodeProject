# 開發指南

> **📌 這是完整的開發參考文件**  
> 包含專案結構、開發規範、Docker 詳細說明和最佳實踐

---

## 📋 目錄

- [專案結構](#專案結構)
- [開發規範](#開發規範)
- [Docker 建置](#docker-建置)
- [本地開發](#本地開發)
- [測試指南](#測試指南)
- [最佳實踐](#最佳實踐)

---

## 📁 專案結構

### 完整目錄結構

```
fastapi_structure_standard/
├── app/                           # 應用程式主目錄
│   ├── __init__.py
│   ├── main.py                   # FastAPI 應用程式入口 ⭐
│   ├── dependencies.py           # 全域依賴注入 ⭐
│   │
│   ├── config/                   # 配置管理
│   │   ├── __init__.py
│   │   ├── settings.py          # 環境變數配置
│   │   └── prompts/             # Prompt 模板系統
│   │       ├── __init__.py
│   │       └── loader.py        # Prompt 載入器
│   │
│   ├── models/                   # 資料庫模型（ORM）
│   │   ├── __init__.py
│   │   └── base.py
│   │
│   ├── schemas/                  # Pydantic 驗證模型
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── db_common.py         # 通用 DB 請求/回應 Schema（4 種 DB 共用）
│   │   ├── db_ocp.py            # OCP 專用 Schema
│   │   ├── db_langgraph.py      # LangGraph 專用 Schema
│   │   └── sample_item.py       # 分層架構範例 Schema
│   │
│   ├── routes/                   # API 路由
│   │   ├── __init__.py
│   │   ├── db_sqlalchemy.py     # SQLAlchemy DB API（9 端點，完整 CRUD）
│   │   ├── db_psycopg.py        # psycopg DB API（8 端點，完整 CRUD）
│   │   ├── db_ocp.py            # OCP Tool API（11 端點，含 CRUD 範例）
│   │   ├── db_langgraph.py      # LangGraph Checkpoint API（6 端點）
│   │   └── sample.py            # 分層架構範例 + DB 快速操作
│   │
│   ├── services/                 # 業務邏輯層（Service Facade）
│   │   ├── __init__.py
│   │   ├── db_sqlalchemy.py     # SQLAlchemy Facade Service
│   │   ├── db_psycopg.py        # psycopg Facade Service
│   │   ├── db_ocp.py            # OCP Facade Service
│   │   ├── db_langgraph.py      # LangGraph Facade Service
│   │   └── sample_item.py       # 分層架構範例 Service
│   │
│   ├── utils/                    # 工具函數
│   │   ├── __init__.py
│   │   └── request.py           # HTTP 請求工具
│   │
│   ├── database/                 # 資料庫管理
│   │   ├── __init__.py
│   │   └── session.py
│   │
│   └── middleware/               # 中介軟體
│       ├── __init__.py
│       └── logging.py
│
├── tests/                        # 測試目錄
│   ├── __init__.py
│   ├── conftest.py              # Pytest 配置
│   ├── test_routes/             # 路由測試
│   ├── test_services/           # 服務測試
│   └── test_utils/              # 工具測試
│
├── docs/                         # 專案文件
│   ├── DB_PATTERNS_GUIDE.md     # 資料庫操作模式指南（4 種模式）
│   ├── OCP_DATABASE_GUIDE.md    # OCP Tool API 操作指南
│   ├── ORM_OPERATIONS_GUIDE.md  # 通用 ORM 操作指南
│   ├── ARCHITECTURE_EXAMPLE.md  # 完整分層架構範例
│   ├── CONFIG_STRUCTURE.md      # 配置結構說明
│   ├── IMPORT_GUIDELINES.md     # Import 規範
│   └── REQUEST_UTILS_USAGE.md   # Request 工具使用
│
├── examples/                     # 使用範例
│   └── request_examples.py      # Request 工具範例
│
├── base/                         # Docker 基礎映像
│   ├── Dockerfile               # 基礎映像配置 ⭐
│   └── requirements.txt         # Python 依賴套件 ⭐
│
├── scripts/                      # 建置腳本 ⭐
│   ├── compose-build.sh         # Docker Compose 建置（Linux/Mac）
│   ├── compose-build.bat        # Docker Compose 建置（Windows）
│   ├── docker-build.sh          # 純 Docker 建置（Linux/Mac）
│   └── docker-build.bat         # 純 Docker 建置（Windows）
│
├── Dockerfile                    # 應用映像配置 ⭐
├── docker-compose.yml            # 服務編排 ⭐
├── .dockerignore                # Docker 忽略檔案
│
├── .env.example                 # 環境變數範例
├── pytest.ini                   # Pytest 配置
└── .gitignore                   # Git 忽略檔案
```

### 目錄說明

#### `app/` - 應用程式主目錄

| 目錄/文件 | 說明 |
|---------|------|
| **`main.py`** | FastAPI 應用程式入口，包含生命週期管理、中介軟體配置、路由註冊 |
| **`dependencies.py`** | 全域依賴注入（資料庫 Session、認證、分頁等） |
| **`config/`** | 配置管理（環境變數、Prompt 模板） |
| **`models/`** | SQLAlchemy ORM 模型定義 |
| **`schemas/`** | Pydantic 資料驗證模型（API 請求/響應），含通用 DB Schema |
| **`routes/`** | FastAPI 路由端點定義（42 個端點，7 個 Swagger 分類） |
| **`services/`** | Service Facade 層 — 依賴專案 database/models，綁定本專案（帶不走） |
| **`utils/`** | 純工具函數 — 不依賴專案內部，可複製到任何專案直接用（帶得走） |
| **`database/`** | 資料庫連線和 Session 管理 |
| **`middleware/`** | 自定義中介軟體（日誌、錯誤處理等） |

#### `tests/` - 測試目錄
- `conftest.py`: Pytest 配置和共用 fixtures
- `test_routes/`: API 路由測試
- `test_services/`: 業務邏輯測試
- `test_utils/`: 工具函數測試

#### `base/` - Docker 基礎映像
- **`Dockerfile`**: 基礎映像配置（Python 環境 + 系統依賴 + 套件安裝）
- **`requirements.txt`**: Python 依賴套件（安裝在 base 層，只有套件變更時才需重建）

#### `scripts/` - 建置腳本
- 自動化建置腳本，支援 Linux/Mac 和 Windows
- `compose-build.*`: Docker Compose 建置
- `docker-build.*`: 純 Docker 命令建置

---

## 🔴 開發規範

### 1. Import 路徑規範

**不使用 `app.` 前綴**

```python
# ✅ 正確
from utils.request import make_request
from config import settings
from models.user import User
from routes import user_router

# ❌ 錯誤
from app.utils.request import make_request
from app.config import settings
from app.models.user import User
```

**原因**：Docker 容器的工作目錄是 `/app/`，Python 可以直接從頂層模組匯入。

**詳細說明**：[docs/IMPORT_GUIDELINES.md](./docs/IMPORT_GUIDELINES.md)

### 2. 日誌記錄規範

**使用 `logger` 而非 `print`**

```python
# ✅ 正確
import logging

logger = logging.getLogger(__name__)

logger.info("使用者登入成功")
logger.error(f"錯誤: {error}")
logger.debug(f"除錯資訊: {data}")

# ❌ 錯誤
print("使用者登入成功")
```

**原因**：
- 可以控制日誌級別（DEBUG, INFO, WARNING, ERROR）
- 可以輸出到檔案或外部系統
- 包含時間戳記、模組名稱等重要資訊
- 便於生產環境的日誌管理和追蹤

### 3. 分層架構原則

```
┌─────────────────────────────────────┐
│  routes/     (路由層 - API 端點)   │  ← 薄控制器，只做 HTTP 處理
├─────────────────────────────────────┤
│  schemas/    (驗證層 - 請求/回應)  │  ← Pydantic 資料驗證
├─────────────────────────────────────┤
│  services/   (業務層 - Facade)     │  ← 封裝 DB 操作複雜度
├─────────────────────────────────────┤
│  database/   (資料層 - DB 連線)    │  ← session/pool/client 管理
├─────────────────────────────────────┤
│  models/     (模型層 - ORM 定義)   │  ← SQLAlchemy ORM
└─────────────────────────────────────┘
```

**原則**：
- 路由只負責請求處理和響應（薄控制器）
- Schema 負責請求驗證和回應序列化
- Service 作為 Facade 封裝 DB 操作複雜度（session/pool/client 管理）
- 資料庫操作在 database 層
- 工具函數在 utils 層

### 4. 命名規範

- **文件名**：使用 snake_case（例如：`user_service.py`）
- **類別名**：使用 PascalCase（例如：`UserService`）
- **函數名**：使用 snake_case（例如：`get_user_by_id`）
- **常量名**：使用 UPPER_SNAKE_CASE（例如：`MAX_RETRY_COUNT`）

---

## 🐳 Docker 建置

### 兩階段建置架構

```
┌─────────────────────────────────────┐
│  base/Dockerfile                    │  建置一次，長期使用
│  ─────────────────────────────────  │
│  • FROM python:3.11-slim-bullseye            │
│  • 系統依賴（gcc, curl 等）         │
│  • Python 套件（base/requirements.txt）│
│  • 使用者和目錄設定                 │
└─────────────────────────────────────┘
                 ↓
        FROM fastapi-base:latest
                 ↓
┌─────────────────────────────────────┐
│  Dockerfile                         │  快速重建（~10秒）
│  ─────────────────────────────────  │
│  • COPY ./app /app                  │
│  • 只包含應用程式代碼               │
└─────────────────────────────────────┘
```

### 建置時間對比

| 場景 | 傳統方式 | 兩階段方式 | 改善 |
|------|---------|-----------|------|
| 首次建置 | ~5 分鐘 | ~5 分鐘 | - |
| **修改代碼** | **~5 分鐘** | **~10 秒** | **30倍** ⚡ |
| 新增套件 | ~5 分鐘 | ~5 分鐘（重建 base） | - |

### 手動建置步驟

#### Docker Compose 方式（推薦）

```bash
# 1. 建置 base 映像
docker build -t fastapi-base:latest -f base/Dockerfile .

# 2. 啟動所有服務
docker-compose up -d

# 3. 查看狀態
docker-compose ps

# 4. 查看日誌
docker-compose logs -f app

# 5. 停止服務
docker-compose down
```

#### 純 Docker 命令方式

```bash
# 1. 建立網路
docker network create fastapi_network

# 2. 建置 base 映像
docker build -t fastapi-base:latest -f base/Dockerfile .

# 3. 建置應用映像
docker build -t fastapi-app:latest .

# 4. 啟動 PostgreSQL
docker run -d \
  --name fastapi_db \
  --network fastapi_network \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=fastapi_db \
  -p 5432:5432 \
  -v postgres_data:/var/lib/postgresql/data \
  postgres:15-alpine

# 5. 啟動 FastAPI 應用
docker run -d \
  --name fastapi_app \
  --network fastapi_network \
  -e DB_HOST=fastapi_db \
  -e DB_PORT=5432 \
  -e DB_USER=postgres \
  -e DB_PASSWORD=postgres \
  -e DB_NAME=fastapi_db \
  -p 8000:8000 \
  -v "$(pwd)/app:/app" \
  -v "$(pwd)/tests:/app/tests" \
  -v "$(pwd)/pytest.ini:/app/pytest.ini" \
  -v "$(pwd)/logs:/app/logs" \
  fastapi-app:latest \
  uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 熱重載機制

```yaml
# docker-compose.yml 設定
volumes:
  - ./app:/app  # 本地代碼掛載到容器

command: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

**效果**：
- 修改本地 `app/` 下的任何文件
- 容器自動偵測變更（約 1-2 秒）
- 應用程式自動重新載入
- 新代碼立即生效 ✅

---

## 💻 本地開發

### 環境設定

```bash
# 1. 建立虛擬環境
python -m venv venv

# 2. 啟動虛擬環境
source venv/bin/activate      # Linux/Mac
venv\Scripts\activate         # Windows

# 3. 安裝依賴
pip install -r base/requirements.txt

# 4. 複製環境變數
cp .env.example .env

# 5. 編輯環境變數（設定資料庫連線等）
vim .env

# 6. 啟動應用
cd app
uvicorn main:app --reload
```

### 更新 Python 套件

```bash
# 1. 編輯 base/requirements.txt
echo "new-package==1.0.0" >> base/requirements.txt

# 2. 重建 base 映像
docker build -t fastapi-base:latest -f base/Dockerfile .

# 3. 重建應用映像
docker build -t fastapi-app:latest .

# 4. 重啟服務
docker-compose up -d --force-recreate
```

---

## 🧪 測試指南

### 執行測試

```bash
# 執行所有測試
pytest

# 執行特定測試
pytest tests/test_routes/

# 查看覆蓋率
pytest --cov=app --cov-report=html

# 開啟覆蓋率報告
open htmlcov/index.html      # Mac
start htmlcov/index.html     # Windows
```

### 建置測試

完整的建置測試清單請參考：**[BUILD_TEST_CHECKLIST.md](./BUILD_TEST_CHECKLIST.md)**

---

## ✅ 最佳實踐

### 1. 依賴注入

使用 `dependencies.py` 統一管理依賴：

```python
# app/dependencies.py
from typing import Generator
from sqlalchemy.orm import Session
from database import SessionLocal

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# app/routes/user.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from dependencies import get_db

router = APIRouter()

@router.get("/users")
def get_users(db: Session = Depends(get_db)):
    # 使用 db
    pass
```

### 2. 錯誤處理

```python
from fastapi import HTTPException, status

# ✅ 正確
@router.get("/users/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User {user_id} not found"
        )
    return user
```

### 3. 環境變數管理

```python
# config/settings.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "FastAPI App"
    database_url: str
    
    class Config:
        env_file = ".env"

settings = Settings()
```

### 4. API 文檔

```python
@router.post("/users", response_model=UserResponse, status_code=201)
def create_user(
    user: UserCreate,
    db: Session = Depends(get_db)
):
    """
    建立新使用者
    
    - **email**: 使用者 email（必填）
    - **name**: 使用者名稱（必填）
    """
    # 實作
    pass
```

---

## 📚 相關文件

### 核心文件
- **[README.md](./README.md)** - 專案概述和快速開始
- **[BUILD_TEST_CHECKLIST.md](./BUILD_TEST_CHECKLIST.md)** - 建置測試清單

### 資料庫相關
- **[docs/DB_PATTERNS_GUIDE.md](./docs/DB_PATTERNS_GUIDE.md)** - 資料庫操作模式完整指南
- **[docs/OCP_DATABASE_GUIDE.md](./docs/OCP_DATABASE_GUIDE.md)** - OCP Tool API 操作指南
- **[docs/ORM_OPERATIONS_GUIDE.md](./docs/ORM_OPERATIONS_GUIDE.md)** - 通用 ORM 操作指南
- **[docs/ARCHITECTURE_EXAMPLE.md](./docs/ARCHITECTURE_EXAMPLE.md)** - 完整分層架構範例

### 專業文件
- **[docs/CONFIG_STRUCTURE.md](./docs/CONFIG_STRUCTURE.md)** - 配置結構詳細說明
- **[docs/IMPORT_GUIDELINES.md](./docs/IMPORT_GUIDELINES.md)** - Import 路徑規範
- **[docs/REQUEST_UTILS_USAGE.md](./docs/REQUEST_UTILS_USAGE.md)** - HTTP 請求工具使用指南

---

**版本**：v3.1
**最後更新**：2026-02-12
**維護者**：FastAPI 開發團隊
