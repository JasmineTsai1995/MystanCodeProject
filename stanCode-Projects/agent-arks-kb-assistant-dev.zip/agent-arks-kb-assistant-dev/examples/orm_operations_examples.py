"""
ORM 操作模組使用範例

展示如何使用通用 ORM 函數進行資料庫操作，無需撰寫 SQL。

執行方式：
    python examples/orm_operations_examples.py
"""

import asyncio
import logging
from sqlalchemy.ext.asyncio import AsyncSession

# 匯入資料庫相關模組
from database import (
    init_async_engine,
    get_async_session,
    close_db_connections,
)
from database import orm_operations as orm  # 使用命名空間避免命名衝突
from models.user import User

# 設定日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ============================================================================
# 創建操作範例
# ============================================================================

async def example_create(db: AsyncSession):
    """範例：新增單筆資料"""
    logger.info("=== 範例：新增單筆資料 ===")
    
    # 新增一位用戶
    user = await orm.create(
        db, User,
        username="john_doe",
        email="john@example.com",
        full_name="John Doe",
        hashed_password="hashed_password_here",
        is_active=True
    )
    
    logger.info(f"新增用戶成功: {user.to_dict()}")
    return user


async def example_create_many(db: AsyncSession):
    """範例：批次新增多筆資料"""
    logger.info("=== 範例：批次新增多筆資料 ===")
    
    # 批次新增多位用戶
    users_data = [
        {
            "username": "alice",
            "email": "alice@example.com",
            "full_name": "Alice Wang",
            "hashed_password": "hashed_password",
            "is_active": True
        },
        {
            "username": "bob",
            "email": "bob@example.com",
            "full_name": "Bob Chen",
            "hashed_password": "hashed_password",
            "is_active": True
        },
        {
            "username": "charlie",
            "email": "charlie@example.com",
            "full_name": "Charlie Lin",
            "hashed_password": "hashed_password",
            "is_active": False  # 未啟用
        }
    ]
    
    users = await orm.create_many(db, User, users_data)
    
    logger.info(f"批次新增 {len(users)} 位用戶成功")
    for user in users:
        logger.info(f"  - {user.username}: {user.email}")
    
    return users


# ============================================================================
# 讀取操作範例
# ============================================================================

async def example_get(db: AsyncSession, user_id: int):
    """範例：依主鍵查詢單筆資料"""
    logger.info("=== 範例：依主鍵查詢單筆資料 ===")
    
    # 依 ID 查詢用戶
    user = await orm.get(db, User, id=user_id)
    
    if user:
        logger.info(f"查詢到用戶: {user.to_dict()}")
    else:
        logger.warning(f"找不到 ID={user_id} 的用戶")
    
    return user


async def example_get_by(db: AsyncSession):
    """範例：依條件查詢單筆資料"""
    logger.info("=== 範例：依條件查詢單筆資料 ===")
    
    # 依 username 查詢
    user = await orm.get_by(db, User, username="alice")
    
    if user:
        logger.info(f"查詢到用戶 (by username): {user.to_dict()}")
    
    # 依 email 查詢
    user = await orm.get_by(db, User, email="bob@example.com")
    
    if user:
        logger.info(f"查詢到用戶 (by email): {user.to_dict()}")
    
    # 依多個條件查詢
    user = await orm.get_by(db, User, username="charlie", is_active=False)
    
    if user:
        logger.info(f"查詢到用戶 (by multiple conditions): {user.to_dict()}")
    
    return user


async def example_get_multi(db: AsyncSession):
    """範例：查詢多筆資料（支援過濾、排序、分頁）"""
    logger.info("=== 範例：查詢多筆資料 ===")
    
    # 1. 查詢所有用戶
    all_users = await orm.get_multi(db, User)
    logger.info(f"所有用戶數量: {len(all_users)}")
    
    # 2. 過濾：只查詢啟用的用戶
    active_users = await orm.get_multi(
        db, User,
        filters={"is_active": True}
    )
    logger.info(f"啟用用戶數量: {len(active_users)}")
    
    # 3. 排序：依建立時間降序
    recent_users = await orm.get_multi(
        db, User,
        order_by=["-created_at"]
    )
    logger.info(f"最新用戶 (降序): {[u.username for u in recent_users]}")
    
    # 4. 分頁：取前 2 筆
    paginated_users = await orm.get_multi(
        db, User,
        skip=0,
        limit=2
    )
    logger.info(f"分頁結果 (前2筆): {[u.username for u in paginated_users]}")
    
    # 5. 組合查詢：過濾 + 排序 + 分頁
    result = await orm.get_multi(
        db, User,
        filters={"is_active": True},
        order_by=["-created_at", "id"],
        skip=0,
        limit=10
    )
    logger.info(f"組合查詢結果: {len(result)} 筆")
    
    return result


# ============================================================================
# 更新操作範例
# ============================================================================

async def example_update(db: AsyncSession, user_id: int):
    """範例：更新單筆資料"""
    logger.info("=== 範例：更新單筆資料 ===")
    
    # 更新用戶資料
    user = await orm.update(
        db, User, id=user_id,
        full_name="John Doe Updated",
        email="john_updated@example.com"
    )
    
    if user:
        logger.info(f"更新用戶成功: {user.to_dict()}")
    else:
        logger.warning(f"找不到 ID={user_id} 的用戶，無法更新")
    
    return user


async def example_update_many(db: AsyncSession):
    """範例：批次更新多筆資料"""
    logger.info("=== 範例：批次更新多筆資料 ===")
    
    # 將所有未啟用的用戶設為啟用
    affected = await orm.update_many(
        db, User,
        filters={"is_active": False},
        is_active=True
    )
    
    logger.info(f"批次更新 {affected} 筆用戶資料（設為啟用）")
    
    return affected


# ============================================================================
# 刪除操作範例
# ============================================================================

async def example_delete(db: AsyncSession, user_id: int):
    """範例：刪除單筆資料"""
    logger.info("=== 範例：刪除單筆資料 ===")
    
    # 刪除用戶
    success = await orm.delete(db, User, id=user_id)
    
    if success:
        logger.info(f"刪除用戶成功 (ID={user_id})")
    else:
        logger.warning(f"找不到 ID={user_id} 的用戶，無法刪除")
    
    return success


async def example_delete_many(db: AsyncSession):
    """範例：批次刪除多筆資料"""
    logger.info("=== 範例：批次刪除多筆資料 ===")
    
    # 刪除所有未啟用的用戶
    affected = await orm.delete_many(
        db, User,
        filters={"is_active": False}
    )
    
    logger.info(f"批次刪除 {affected} 筆用戶資料（未啟用）")
    
    return affected


# ============================================================================
# 工具函數範例
# ============================================================================

async def example_exists(db: AsyncSession):
    """範例：檢查資料是否存在"""
    logger.info("=== 範例：檢查資料是否存在 ===")
    
    # 檢查 username 是否存在
    is_exists = await orm.exists(db, User, username="alice")
    logger.info(f"username='alice' 是否存在: {is_exists}")
    
    # 檢查 email 是否存在
    is_exists = await orm.exists(db, User, email="notexist@example.com")
    logger.info(f"email='notexist@example.com' 是否存在: {is_exists}")
    
    # 檢查多個條件
    is_exists = await orm.exists(db, User, username="bob", is_active=True)
    logger.info(f"username='bob' AND is_active=True 是否存在: {is_exists}")
    
    return is_exists


async def example_count(db: AsyncSession):
    """範例：計算資料數量"""
    logger.info("=== 範例：計算資料數量 ===")
    
    # 計算所有用戶數量
    total = await orm.count(db, User)
    logger.info(f"所有用戶數量: {total}")
    
    # 計算啟用的用戶數量
    active_count = await orm.count(db, User, filters={"is_active": True})
    logger.info(f"啟用用戶數量: {active_count}")
    
    # 計算超級用戶數量
    superuser_count = await orm.count(db, User, filters={"is_superuser": True})
    logger.info(f"超級用戶數量: {superuser_count}")
    
    return total


# ============================================================================
# 主程式
# ============================================================================

async def main():
    """主程式：執行所有範例"""
    logger.info("開始執行 ORM 操作範例")
    
    try:
        # 初始化資料庫連線
        await init_async_engine()
        logger.info("資料庫連線初始化成功")
        
        # 取得 Session
        db = await get_async_session()
        
        # === 創建操作 ===
        user1 = await example_create(db)
        users = await example_create_many(db)
        
        # === 讀取操作 ===
        await example_get(db, user1.id)
        await example_get_by(db)
        await example_get_multi(db)
        
        # === 更新操作 ===
        await example_update(db, user1.id)
        await example_update_many(db)
        
        # === 工具函數 ===
        await example_exists(db)
        await example_count(db)
        
        # === 刪除操作（注意：會真的刪除資料）===
        # await example_delete(db, user1.id)
        # await example_delete_many(db)
        
        logger.info("所有範例執行完成")
        
    except Exception as e:
        logger.error(f"執行範例時發生錯誤: {e}", exc_info=True)
        
    finally:
        # 關閉資料庫連線
        await close_db_connections()
        logger.info("資料庫連線已關閉")


if __name__ == "__main__":
    # 執行主程式
    asyncio.run(main())
