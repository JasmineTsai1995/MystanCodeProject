"""
資料庫使用範例

示範如何在 FastAPI 應用中使用不同的資料庫連線方式
"""

import logging
from fastapi import FastAPI, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from contextlib import asynccontextmanager

# 配置 logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============================================================================
# 範例 1: 在 FastAPI 應用中初始化資料庫
# ============================================================================

from database import (
    init_async_engine,
    init_async_pool,
    close_db_connections,
    close_pool_connections,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """應用程式生命週期管理"""
    # 啟動時初始化
    logger.info("🚀 Initializing database connections...")
    
    # 方式 1: SQLAlchemy（適合 ORM 操作）
    await init_async_engine()
    
    # 方式 2: psycopg（適合原生 SQL 和 LangGraph）
    try:
        await init_async_pool()
    except ImportError:
        logger.warning("⚠️  psycopg not installed, skipping pool initialization")
    
    logger.info("✅ Database connections initialized")
    
    yield
    
    # 關閉時清理
    logger.info("🔄 Closing database connections...")
    await close_db_connections()
    await close_pool_connections()
    logger.info("✅ Database connections closed")


app = FastAPI(lifespan=lifespan)


# ============================================================================
# 範例 2: 使用 SQLAlchemy 進行 ORM 操作
# ============================================================================

from database import get_db
from sqlalchemy import select, insert, update, delete, text


@app.get("/users/sqlalchemy")
async def get_users_sqlalchemy(db: AsyncSession = Depends(get_db)):
    """使用 SQLAlchemy 查詢使用者"""
    
    # 方式 1: 使用 ORM
    # result = await db.execute(select(User))
    # users = result.scalars().all()
    
    # 方式 2: 使用原生 SQL
    result = await db.execute(text("SELECT * FROM users LIMIT 10"))
    users = result.fetchall()
    
    return {"users": [dict(user._mapping) for user in users]}


@app.post("/users/sqlalchemy")
async def create_user_sqlalchemy(
    name: str,
    email: str,
    db: AsyncSession = Depends(get_db)
):
    """使用 SQLAlchemy 建立使用者"""
    
    # 方式 1: 使用 ORM
    # user = User(name=name, email=email)
    # db.add(user)
    # await db.commit()
    # await db.refresh(user)
    
    # 方式 2: 使用原生 SQL
    result = await db.execute(
        text("INSERT INTO users (name, email) VALUES (:name, :email) RETURNING id"),
        {"name": name, "email": email}
    )
    user_id = result.scalar()
    await db.commit()
    
    return {"id": user_id, "name": name, "email": email}


# ============================================================================
# 範例 3: 使用 psycopg 進行原生 SQL 操作
# ============================================================================

from database import get_pool_connection


@app.get("/users/psycopg")
async def get_users_psycopg():
    """使用 psycopg 查詢使用者"""
    
    async with get_pool_connection() as conn:
        cursor = await conn.execute("SELECT * FROM users LIMIT 10")
        users = await cursor.fetchall()
    
    return {
        "users": [
            {"id": user[0], "name": user[1], "email": user[2]}
            for user in users
        ]
    }


@app.post("/users/psycopg")
async def create_user_psycopg(name: str, email: str):
    """使用 psycopg 建立使用者"""
    
    async with get_pool_connection() as conn:
        cursor = await conn.execute(
            "INSERT INTO users (name, email) VALUES (%(name)s, %(email)s) RETURNING id",
            {"name": name, "email": email}
        )
        user_id = (await cursor.fetchone())[0]
    
    return {"id": user_id, "name": name, "email": email}


# ============================================================================
# 範例 4: 資料庫健康檢查
# ============================================================================

from database import check_db_health


@app.get("/health/db")
async def database_health():
    """檢查資料庫健康狀態"""
    
    sqlalchemy_health = await check_db_health("sqlalchemy")
    psycopg_health = await check_db_health("psycopg")
    
    return {
        "sqlalchemy": sqlalchemy_health,
        "psycopg": psycopg_health,
    }


# ============================================================================
# 範例 5: 使用自定義配置
# ============================================================================

from database import DatabaseConfig


async def init_with_custom_config():
    """使用自定義配置初始化資料庫"""
    
    # 自定義配置
    config = DatabaseConfig(
        host="custom-db-host",
        port=5432,
        user="custom_user",
        password="custom_password",
        database="custom_db",
        pool_size=5,
        max_overflow=15,
    )
    
    # 使用自定義配置初始化
    await init_async_engine(config)
    await init_async_pool(config)


# ============================================================================
# 範例 6: LangGraph Checkpointer（使用 psycopg）
# ============================================================================

try:
    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
    
    @app.on_event("startup")
    async def setup_langgraph_checkpointer():
        """設定 LangGraph Checkpointer"""
        from database import get_async_pool
        
        try:
            pool = get_async_pool()
            checkpointer = AsyncPostgresSaver(pool)
            
            # 將 checkpointer 儲存到 app.state
            app.state.checkpointer = checkpointer
            
            logger.info("✅ LangGraph checkpointer initialized")
        except Exception as e:
            logger.warning(f"⚠️  LangGraph checkpointer initialization failed: {e}")
    
    
    @app.get("/langgraph/checkpoints")
    async def get_checkpoints():
        """
        獲取 checkpointer 狀態
        """
        if not hasattr(app.state, 'checkpointer'):
            return {"error": "Checkpointer not initialized"}
        
        return {"message": "LangGraph checkpointer is ready"}

except ImportError:
    logger.warning("⚠️  LangGraph not installed, skipping checkpointer setup")


# ============================================================================
# 範例 7: 交易管理
# ============================================================================

@app.post("/transfer/sqlalchemy")
async def transfer_money_sqlalchemy(
    from_user_id: int,
    to_user_id: int,
    amount: float,
    db: AsyncSession = Depends(get_db)
):
    """使用 SQLAlchemy 進行轉帳（交易）"""
    
    try:
        # 開始交易（get_db 已經處理了交易管理）
        
        # 扣款
        await db.execute(
            text("UPDATE accounts SET balance = balance - :amount WHERE user_id = :user_id"),
            {"amount": amount, "user_id": from_user_id}
        )
        
        # 加款
        await db.execute(
            text("UPDATE accounts SET balance = balance + :amount WHERE user_id = :user_id"),
            {"amount": amount, "user_id": to_user_id}
        )
        
        # commit 由 get_db 自動處理
        
        return {"status": "success", "amount": amount}
    
    except Exception as e:
        # rollback 由 get_db 自動處理
        raise


@app.post("/transfer/psycopg")
async def transfer_money_psycopg(
    from_user_id: int,
    to_user_id: int,
    amount: float
):
    """使用 psycopg 進行轉帳（交易）"""
    
    async with get_pool_connection() as conn:
        # psycopg 預設 autocommit=True，需要手動管理交易
        async with conn.transaction():
            # 扣款
            await conn.execute(
                "UPDATE accounts SET balance = balance - %(amount)s WHERE user_id = %(user_id)s",
                {"amount": amount, "user_id": from_user_id}
            )
            
            # 加款
            await conn.execute(
                "UPDATE accounts SET balance = balance + %(amount)s WHERE user_id = %(user_id)s",
                {"amount": amount, "user_id": to_user_id}
            )
            
            # 交易結束時自動 commit
    
    return {"status": "success", "amount": amount}


# ============================================================================
# 範例 8: 批次操作
# ============================================================================

@app.post("/users/batch/sqlalchemy")
async def create_users_batch_sqlalchemy(
    users: list[dict],
    db: AsyncSession = Depends(get_db)
):
    """使用 SQLAlchemy 批次建立使用者"""
    
    # 批次插入
    await db.execute(
        insert("users"),
        users
    )
    await db.commit()
    
    return {"created": len(users)}


@app.post("/users/batch/psycopg")
async def create_users_batch_psycopg(users: list[dict]):
    """使用 psycopg 批次建立使用者"""
    
    async with get_pool_connection() as conn:
        async with conn.cursor() as cursor:
            # 使用 executemany 批次插入
            await cursor.executemany(
                "INSERT INTO users (name, email) VALUES (%(name)s, %(email)s)",
                users
            )
    
    return {"created": len(users)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
