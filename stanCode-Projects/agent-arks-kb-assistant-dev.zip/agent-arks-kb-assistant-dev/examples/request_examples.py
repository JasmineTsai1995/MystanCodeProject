"""
HTTP 請求工具使用範例

展示 utils/request.py 的各種使用方式
"""

import logging
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any

from utils import request

# 設定日誌
logger = logging.getLogger(__name__)


# ============================================================================
# 範例 1: 基本使用
# ============================================================================

def example_basic_usage():
    """基本使用範例"""
    logger.info("=== 範例 1: 基本使用 ===")
    
    # 方式 1: 使用 request.make_request
    logger.info("1. 使用 request.make_request")
    result = request.make_request("https://jsonplaceholder.typicode.com/posts/1")
    logger.info(f"   結果: {result}")
    
    # 方式 2: 使用便捷函數
    logger.info("2. 使用便捷函數")
    result = request.get("https://jsonplaceholder.typicode.com/posts/1")
    logger.info(f"   結果: {result}")
    
    # POST 請求
    logger.info("3. POST 請求")
    new_post = request.post(
        "https://jsonplaceholder.typicode.com/posts",
        json_data={
            "title": "測試文章",
            "body": "這是測試內容",
            "userId": 1
        }
    )
    logger.info(f"   結果: {new_post}")


# ============================================================================
# 範例 2: 使用 Pydantic Schema 驗證
# ============================================================================

class PostInput(BaseModel):
    """文章輸入 Schema"""
    title: str = Field(..., min_length=1, max_length=200)
    body: str = Field(..., min_length=1)
    userId: int = Field(..., gt=0)


class PostOutput(BaseModel):
    """文章輸出 Schema"""
    id: int
    title: str
    body: str
    userId: int


def example_with_schema():
    """使用 Schema 驗證的範例"""
    logger.info("=== 範例 2: 使用 Schema 驗證 ===")
    
    # 帶 Schema 驗證的 POST 請求
    result = request.post(
        "https://jsonplaceholder.typicode.com/posts",
        json_data={
            "title": "測試文章",
            "body": "這是測試內容",
            "userId": 1
        },
        input_schema=PostInput,
        output_schema=PostOutput
    )
    
    # result 是 PostOutput 的實例
    logger.info(f"文章 ID: {result.id}")
    logger.info(f"標題: {result.title}")
    logger.info(f"內容: {result.body}")
    logger.info(f"使用者 ID: {result.userId}")


# ============================================================================
# 範例 3: 使用 request.RequestClient
# ============================================================================

def example_request_client():
    """使用 request.RequestClient 的範例"""
    logger.info("=== 範例 3: 使用 request.RequestClient ===")
    
    # 建立客戶端
    client = request.RequestClient(
        base_url="https://jsonplaceholder.typicode.com",
        default_timeout=30
    )
    
    # 發送多個請求
    logger.info("1. 獲取文章列表")
    posts = client.get("/posts", params={"_limit": 5})
    logger.info(f"   獲取了 {len(posts)} 篇文章")
    
    logger.info("2. 獲取單篇文章")
    post = client.get("/posts/1")
    logger.info(f"   文章標題: {post['title']}")
    
    logger.info("3. 建立新文章")
    new_post = client.post(
        "/posts",
        json_data={
            "title": "新文章",
            "body": "文章內容",
            "userId": 1
        }
    )
    logger.info(f"   新文章 ID: {new_post['id']}")
    
    # 關閉客戶端
    client.close()


# ============================================================================
# 範例 4: 使用 Context Manager
# ============================================================================

def example_context_manager():
    """使用 Context Manager 的範例"""
    logger.info("=== 範例 4: 使用 Context Manager ===")
    
    # 使用 with 語句自動管理 Session
    with request.RequestClient(base_url="https://jsonplaceholder.typicode.com") as client:
        posts = client.get("/posts", params={"_limit": 3})
        logger.info(f"獲取了 {len(posts)} 篇文章")
        
        for post in posts:
            logger.info(f"  - {post['title']}")
    
    logger.info("Session 已自動關閉")


# ============================================================================
# 範例 5: 錯誤處理
# ============================================================================

def example_error_handling():
    """錯誤處理範例"""
    logger.info("=== 範例 5: 錯誤處理 ===")
    
    # 處理 404 錯誤
    logger.info("1. 處理 404 錯誤")
    try:
        result = request.get("https://jsonplaceholder.typicode.com/posts/99999")
    except request.HTTPError as e:
        if e.status_code == 404:
            logger.warning("   資源不存在")
        else:
            logger.error(f"   HTTP 錯誤: {e}")
    
    # 處理超時
    logger.info("2. 處理超時")
    try:
        result = request.get(
            "https://httpbin.org/delay/10",
            timeout=2  # 2 秒超時
        )
    except request.HTTPError as e:
        if "超時" in str(e):
            logger.warning("   請求超時")
        else:
            logger.error(f"   錯誤: {e}")


# ============================================================================
# 範例 6: 實際應用 - 使用者服務
# ============================================================================

class User(BaseModel):
    """使用者模型"""
    id: int
    name: str
    username: str
    email: EmailStr


class UserService:
    """使用者服務"""
    
    def __init__(self, base_url: str):
        self.client = request.RequestClient(base_url=base_url)
        logger.info(f"UserService 初始化完成，base_url: {base_url}")
    
    def get_user(self, user_id: int) -> User:
        """獲取使用者"""
        logger.debug(f"獲取使用者: {user_id}")
        result = self.client.get(f"/users/{user_id}", output_schema=User)
        return result
    
    def get_users(self, limit: int = 10) -> List[User]:
        """獲取使用者列表"""
        logger.debug(f"獲取使用者列表，限制: {limit}")
        results = self.client.get("/users", params={"_limit": limit})
        return [User(**user) for user in results]
    
    def create_user(self, user_data: Dict[str, Any]) -> User:
        """建立使用者"""
        logger.debug(f"建立使用者: {user_data}")
        result = self.client.post("/users", json_data=user_data, output_schema=User)
        return result
    
    def close(self):
        """關閉客戶端"""
        self.client.close()
        logger.info("UserService 已關閉")


def example_user_service():
    """使用者服務範例"""
    logger.info("=== 範例 6: 使用者服務 ===")
    
    # 建立服務
    user_service = UserService(base_url="https://jsonplaceholder.typicode.com")
    
    # 獲取使用者
    logger.info("1. 獲取單個使用者")
    user = user_service.get_user(1)
    logger.info(f"   姓名: {user.name}")
    logger.info(f"   Email: {user.email}")
    
    # 獲取使用者列表
    logger.info("2. 獲取使用者列表")
    users = user_service.get_users(limit=5)
    logger.info(f"   獲取了 {len(users)} 個使用者")
    for user in users:
        logger.info(f"   - {user.name} ({user.email})")
    
    # 關閉服務
    user_service.close()


# ============================================================================
# 範例 7: 帶認證的請求
# ============================================================================

def example_authentication():
    """認證範例"""
    logger.info("=== 範例 7: 帶認證的請求 ===")
    
    # Bearer Token 認證
    logger.info("1. Bearer Token 認證")
    client = request.RequestClient(
        base_url="https://api.example.com",
        default_headers={"Authorization": "Bearer your_token_here"}
    )
    logger.info("   客戶端已設定 Bearer Token")
    
    # Basic Auth 認證
    logger.info("2. Basic Auth 認證")
    # result = get(
    #     "https://api.example.com/protected",
    #     auth=("username", "password")
    # )
    logger.info("   使用 auth 參數傳遞使用者名稱和密碼")
    
    # API Key 認證
    logger.info("3. API Key 認證")
    client = request.RequestClient(
        base_url="https://api.example.com",
        default_headers={"X-API-Key": "your_api_key_here"}
    )
    logger.info("   客戶端已設定 API Key")


# ============================================================================
# 範例 8: 批次請求
# ============================================================================

def example_batch_requests():
    """批次請求範例"""
    logger.info("=== 範例 8: 批次請求 ===")
    
    client = request.RequestClient(base_url="https://jsonplaceholder.typicode.com")
    
    # 批次獲取多個使用者
    user_ids = [1, 2, 3, 4, 5]
    users = []
    
    logger.info("批次獲取使用者")
    for user_id in user_ids:
        user = client.get(f"/users/{user_id}")
        users.append(user)
        logger.info(f"  - 獲取使用者 {user_id}: {user['name']}")
    
    logger.info(f"總共獲取了 {len(users)} 個使用者")
    
    client.close()


# ============================================================================
# 主程式
# ============================================================================

def main():
    """執行所有範例"""
    # 設定日誌格式
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    logger.info("=" * 70)
    logger.info("HTTP 請求工具使用範例")
    logger.info("=" * 70)
    
    try:
        # 執行範例
        example_basic_usage()
        example_with_schema()
        example_request_client()
        example_context_manager()
        example_error_handling()
        example_user_service()
        example_authentication()
        example_batch_requests()
        
        logger.info("=" * 70)
        logger.info("所有範例執行完成！")
        logger.info("=" * 70)
        
    except Exception as e:
        logger.exception(f"執行範例時發生錯誤: {e}")


if __name__ == "__main__":
    main()
