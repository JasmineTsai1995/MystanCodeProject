"""
OCP Tool API 使用範例

展示如何使用 OCP Tool API 進行資料庫操作。

執行前請確保：
1. 已設定環境變數（.env 檔案）
2. OCP API 端點可訪問
"""

import asyncio
import sys
import logging
from pathlib import Path

# 添加 app 目錄到 Python 路徑
sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

from database import (
    OCPClient,
    OCPConfig,
    execute_ocp_query,
    execute_ocp_select,
    execute_ocp_dml,
    OCPError,
)

# 配置 logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


# ============================================================================
# 範例 1: 基本 SELECT 查詢
# ============================================================================

def example_1_basic_select():
    """範例 1: 基本 SELECT 查詢"""
    logger.info("\n" + "="*80)
    logger.info("範例 1: 基本 SELECT 查詢")
    logger.info("="*80)
    
    try:
        # 建立客戶端
        client = OCPClient()
        
        # 執行 SELECT 查詢（根據您提供的範例）
        sql = "SELECT * FROM datbatch.judgement_body_embedding LIMIT 2"
        result = client.execute_select(sql)
        
        logger.info(f"✅ 查詢成功！")
        logger.info(f"   查詢時間: {result.query_time:.3f} 秒")
        logger.info(f"   資料筆數: {result.row_count}")
        logger.info(f"   欄位: {result.columns}")
        logger.info(f"\n資料內容:")
        for i, row in enumerate(result.data, 1):
            logger.info(f"   {i}. {row}")
        
        # 轉換為字典格式
        dict_list = result.to_dict_list()
        logger.info(f"\n字典格式:")
        for i, item in enumerate(dict_list, 1):
            logger.info(f"   {i}. {item}")
        
    except OCPError as e:
        logger.error(f"❌ 查詢失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 2: INSERT 操作
# ============================================================================

def example_2_insert():
    """範例 2: INSERT 操作"""
    logger.info("\n" + "="*80)
    logger.info("範例 2: INSERT 操作")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 執行 INSERT（根據您提供的範例）
        sql = "INSERT INTO public.test2(test1) VALUES ('TEST')"
        result = client.execute_dml(sql)
        
        logger.info(f"✅ INSERT 成功！")
        logger.info(f"   執行時間: {result.query_time:.3f} 秒")
        logger.info(f"   影響筆數: {result.affected_rows}")
        
    except OCPError as e:
        logger.error(f"❌ INSERT 失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 3: UPDATE 操作
# ============================================================================

def example_3_update():
    """範例 3: UPDATE 操作"""
    logger.info("\n" + "="*80)
    logger.info("範例 3: UPDATE 操作")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 執行 UPDATE
        sql = "UPDATE public.test2 SET test1='UPDATED' WHERE test1='TEST'"
        result = client.execute_dml(sql)
        
        logger.info(f"✅ UPDATE 成功！")
        logger.info(f"   執行時間: {result.query_time:.3f} 秒")
        logger.info(f"   影響筆數: {result.affected_rows}")
        
    except OCPError as e:
        logger.error(f"❌ UPDATE 失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 4: DELETE 操作
# ============================================================================

def example_4_delete():
    """範例 4: DELETE 操作"""
    logger.info("\n" + "="*80)
    logger.info("範例 4: DELETE 操作")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 執行 DELETE
        sql = "DELETE FROM public.test2 WHERE test1='TEST'"
        result = client.execute_dml(sql)
        
        logger.info(f"✅ DELETE 成功！")
        logger.info(f"   執行時間: {result.query_time:.3f} 秒")
        logger.info(f"   影響筆數: {result.affected_rows}")
        
    except OCPError as e:
        logger.error(f"❌ DELETE 失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 5: 自動判斷查詢類型
# ============================================================================

def example_5_auto_detect():
    """範例 5: 自動判斷查詢類型"""
    logger.info("\n" + "="*80)
    logger.info("範例 5: 自動判斷查詢類型")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 自動判斷 SELECT
        sql1 = "SELECT 1 AS test"
        result1 = client.execute_query(sql1)
        logger.info(f"✅ 查詢 1 (SELECT):")
        logger.info(f"   類型: {type(result1).__name__}")
        logger.info(f"   結果: {result1.data if hasattr(result1, 'data') else result1.affected_rows}")
        
        # 自動判斷 INSERT
        sql2 = "INSERT INTO public.test2(test1) VALUES ('AUTO_TEST')"
        result2 = client.execute_query(sql2)
        logger.info(f"\n✅ 查詢 2 (INSERT):")
        logger.info(f"   類型: {type(result2).__name__}")
        logger.info(f"   影響筆數: {result2.affected_rows}")
        
    except OCPError as e:
        logger.error(f"❌ 查詢失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 6: 使用便捷函數
# ============================================================================

def example_6_convenience_functions():
    """範例 6: 使用便捷函數"""
    logger.info("\n" + "="*80)
    logger.info("範例 6: 使用便捷函數")
    logger.info("="*80)
    
    try:
        # 使用便捷函數執行 SELECT
        sql = "SELECT current_database(), current_user"
        result = execute_ocp_select(sql)
        
        logger.info(f"✅ 使用 execute_ocp_select():")
        logger.info(f"   查詢時間: {result.query_time:.3f} 秒")
        logger.info(f"   欄位: {result.columns}")
        logger.info(f"   資料: {result.data}")
        
    except OCPError as e:
        logger.error(f"❌ 查詢失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 7: 指定不同的資料庫
# ============================================================================

def example_7_different_database():
    """範例 7: 指定不同的資料庫"""
    logger.info("\n" + "="*80)
    logger.info("範例 7: 指定不同的資料庫")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 使用預設資料庫
        sql = "SELECT current_database()"
        result1 = client.execute_select(sql)
        logger.info(f"✅ 預設資料庫:")
        logger.info(f"   {result1.data}")
        
        # 指定其他資料庫（如果有的話）
        # result2 = client.execute_select(sql, database="other_database")
        # logger.info(f"\n✅ 指定資料庫 'other_database':")
        # logger.info(f"   {result2.data}")
        
    except OCPError as e:
        logger.error(f"❌ 查詢失敗: {e}")
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 8: 測試連線
# ============================================================================

def example_8_test_connection():
    """範例 8: 測試連線"""
    logger.info("\n" + "="*80)
    logger.info("範例 8: 測試 OCP API 連線")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 測試連線
        success = client.test_connection()
        
        if success:
            logger.info(f"✅ OCP API 連線正常！")
            logger.info(f"   API URL: {client.config.api_url}")
            logger.info(f"   預設資料庫: {client.config.default_database}")
        else:
            logger.error(f"❌ OCP API 連線失敗")
        
    except Exception as e:
        logger.error(f"❌ 連線測試異常: {e}")


# ============================================================================
# 範例 9: 自訂配置
# ============================================================================

def example_9_custom_config():
    """範例 9: 使用自訂配置"""
    logger.info("\n" + "="*80)
    logger.info("範例 9: 使用自訂配置（動態環境）")
    logger.info("="*80)
    
    try:
        # 方式 1: 使用環境參數（推薦）
        logger.info("方式 1: 使用環境參數")
        
        for env in ["sit", "uat", "prod"]:
            config = OCPConfig(
                env=env,  # 動態設定環境
                default_database="datdatcm",
                timeout=60,
                max_retries=5
            )
            logger.info(f"\n  環境 {env.upper()}:")
            logger.info(f"  API URL: {config.api_url}")
        
        # 方式 2: 直接指定 URL（進階）
        logger.info("\n\n方式 2: 直接指定完整 URL")
        custom_config = OCPConfig(
            api_url="http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocpsit.intranet.tw/execute_query_postgresql",
            default_database="datdatcm",
            timeout=60,
            max_retries=5
        )
        
        # 使用自訂配置建立客戶端
        client = OCPClient(config=custom_config)
        
        logger.info(f"\n✅ 自訂配置建立成功！")
        logger.info(f"   環境: {client.config.env}")
        logger.info(f"   API URL: {client.config.api_url}")
        logger.info(f"   預設資料庫: {client.config.default_database}")
        logger.info(f"   超時時間: {client.config.timeout} 秒")
        logger.info(f"   最大重試: {client.config.max_retries} 次")
        
        # 測試連線
        logger.info(f"\n測試 SIT 環境連線...")
        if client.test_connection():
            logger.info(f"✅ 連線測試成功！")
        
    except Exception as e:
        logger.error(f"❌ 異常: {e}")


# ============================================================================
# 範例 10: 批次查詢
# ============================================================================

def example_10_batch_queries():
    """範例 10: 批次查詢"""
    logger.info("\n" + "="*80)
    logger.info("範例 10: 批次執行多個查詢")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 準備多個查詢
        queries = [
            "SELECT 1 AS num",
            "SELECT current_database()",
            "SELECT current_user",
            "SELECT version()"
        ]
        
        logger.info(f"執行 {len(queries)} 個查詢...\n")
        
        for i, sql in enumerate(queries, 1):
            try:
                result = client.execute_select(sql)
                logger.info(f"✅ 查詢 {i}: 成功")
                logger.info(f"   SQL: {sql}")
                logger.info(f"   執行時間: {result.query_time:.3f} 秒")
                logger.info(f"   結果: {result.data[0] if result.data else 'N/A'}\n")
            except OCPError as e:
                logger.error(f"❌ 查詢 {i}: 失敗")
                logger.error(f"   SQL: {sql}")
                logger.error(f"   錯誤: {e}\n")
        
    except Exception as e:
        logger.error(f"❌ 批次查詢異常: {e}")


# ============================================================================
# 範例 11: 錯誤處理
# ============================================================================

def example_11_error_handling():
    """範例 11: 錯誤處理示範"""
    logger.info("\n" + "="*80)
    logger.info("範例 11: 錯誤處理")
    logger.info("="*80)
    
    try:
        client = OCPClient()
        
        # 故意執行一個錯誤的 SQL
        sql = "SELECT * FROM non_existent_table"
        result = client.execute_select(sql)
        
    except OCPError as e:
        logger.info(f"✅ 成功捕獲 OCPError:")
        logger.info(f"   錯誤訊息: {e}")
        logger.info(f"   錯誤代碼: {e.return_code}")
        logger.info(f"   錯誤描述: {e.return_desc}")
    except Exception as e:
        logger.info(f"✅ 捕獲其他異常:")
        logger.info(f"   類型: {type(e).__name__}")
        logger.info(f"   訊息: {e}")


# ============================================================================
# 主程式
# ============================================================================

def main():
    """執行所有範例"""
    logger.info("\n" + "="*80)
    logger.info("OCP Tool API 使用範例")
    logger.info("="*80)
    
    examples = [
        ("測試連線", example_8_test_connection),
        ("基本 SELECT 查詢", example_1_basic_select),
        ("INSERT 操作", example_2_insert),
        ("UPDATE 操作", example_3_update),
        ("DELETE 操作", example_4_delete),
        ("自動判斷查詢類型", example_5_auto_detect),
        ("使用便捷函數", example_6_convenience_functions),
        ("指定不同的資料庫", example_7_different_database),
        ("自訂配置", example_9_custom_config),
        ("批次查詢", example_10_batch_queries),
        ("錯誤處理", example_11_error_handling),
    ]
    
    logger.info("\n可用範例:")
    for i, (name, _) in enumerate(examples, 1):
        logger.info(f"  {i}. {name}")
    
    logger.info("\n選擇:")
    logger.info("  0 - 執行所有範例")
    logger.info("  1-11 - 執行指定範例")
    logger.info("  q - 退出")
    
    try:
        choice = input("\n請選擇 (預設 0): ").strip() or "0"
        
        if choice.lower() == 'q':
            logger.info("退出")
            return
        
        choice_num = int(choice)
        
        if choice_num == 0:
            # 執行所有範例
            for name, func in examples:
                func()
        elif 1 <= choice_num <= len(examples):
            # 執行指定範例
            name, func = examples[choice_num - 1]
            func()
        else:
            logger.warning(f"無效的選擇: {choice_num}")
    
    except ValueError:
        logger.error(f"無效的輸入")
    except KeyboardInterrupt:
        logger.info("\n\n使用者中斷")
    except Exception as e:
        logger.error(f"\n執行錯誤: {e}")


if __name__ == "__main__":
    main()
