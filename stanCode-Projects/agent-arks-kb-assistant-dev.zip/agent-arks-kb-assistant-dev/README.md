# Databricks App 部署（Agent Server）

將 Arks Agent 部署為 Databricks App，透過 DABs（Databricks Asset Bundles）管理。

## 前置需求

- Databricks CLI >= 0.240
- uv（Python package manager）
- 已完成 `databricks auth login --host https://dbc-3e71f336-822f.cloud.databricks.com --profile ut`

```bash
databricks --version
uv --version
databricks auth login --host https://dbc-3e71f336-822f.cloud.databricks.com --profile ut
databricks auth profiles
```

`databricks.yml` 的 `ut` target 部署到 UT workspace，使用 `profile: ut`，
因此本機 `~/.databrickscfg` 必須有 `[ut]` profile。若要部署到其他
workspace，請改用對應的 profile，或在 bundle 指令加上 `--profile <profile>` 覆蓋。

## 設定檔

| 檔案 | 用途 |
|------|------|
| `databricks.yml` | DABs 主設定（resources、env vars、targets） |
| `app/app.yaml` | App 啟動指令（`uv run start-app`） |
| `app/config/config.yaml` | Agent 應用層設定 |
| `pyproject.toml` | Python 依賴 + `start-app` script 定義 |

## 架構

DABs 管理以下資源：

| 資源 | 類型 | 說明 |
|------|------|------|
| `arks_agent` | App | Agent Server（MLflow AgentServer） |
| `arks_lakebase` | Postgres Project | Lakebase Autoscaling（對話記憶） |
| `arks_experiment` | Experiment | MLflow 實驗追蹤 |
| `arks_setup_lakebase` | Job | Lakebase SP 權限設定 |
| `arks_setup_mlflow` | Job | MLflow / Prompt Registry UC 權限設定 |
| `arks_start_dev_resources` | Job | 排程：工作日 08:30 啟動資源 |
| `arks_stop_dev_resources` | Job | 排程：工作日 19:00 停止資源 |

### Lakebase Autoscaling

Agent 使用 Lakebase Autoscaling（Databricks managed PostgreSQL）儲存對話記憶。
DABs 會自動建立 Lakebase project 並綁定為 App resource。

- Project ID: `arks-lakebase-v2`
- Branch: `production`
- Database: `databricks-postgres`
- App resource permission: `CAN_CONNECT_AND_CREATE`

Checkpoint tables（`checkpoints`, `checkpoint_blobs`, `checkpoint_writes`, `checkpoint_migrations`）
由 App 啟動時的 `AsyncCheckpointSaver.setup()` 自動建立，**App SP 是 table owner**，
確保後續 migration 不會遇到 `must be owner` 權限問題。

可用以下指令確認線上 App 已掛上 Lakebase resource：

```bash
databricks apps get arks-agent --profile ut --output json
```

輸出中的 `resources` 應包含：

```json
{
  "name": "lakebase",
  "postgres": {
    "branch": "projects/arks-lakebase-v2/branches/production",
    "database": "projects/arks-lakebase-v2/branches/production/databases/databricks-postgres",
    "permission": "CAN_CONNECT_AND_CREATE"
  }
}
```

## 部署流程

### 一鍵部署

```bash
./scripts/deploy.sh           # 部署到 ut（預設）
./scripts/deploy.sh ut        # 部署到 ut
./scripts/deploy.sh prod      # 部署到 prod
./scripts/deploy.sh ut --run  # 部署 + 啟動 App
```

### 手動步驟

```bash
# 在 repo root 執行

# Step 1: 驗證
databricks bundle validate -t ut

# Step 2: 部署（建立 App、Lakebase Project、Experiment、Jobs）
databricks bundle deploy -t ut

# Step 3: 設定 Lakebase 權限（首次部署或 SP 變更時必須執行）
#   - 建立 App SP 的 PostgreSQL role
#   - 授權 CREATE, USAGE on schema public
#   - 刪除 deployer-owned 的舊 checkpoint tables（如有）
databricks bundle run arks_setup_lakebase -t ut

# Step 4: 設定 MLflow 權限（首次部署或 SP 變更時必須執行）
#   - 授權 App SP 存取 UC Prompt Registry
#   - 建立/授權 dev_gaia_experiments.arks，並將 App experiment traces 綁到 dev_gaia_experiments.arks.arks_agent*
databricks bundle run arks_setup_mlflow -t ut
databricks bundle run arks_setup_mlflow -t ut --params skip_uc_grants=true # ut 以上環境 job identity 無法授權 uc


# Step 5: 啟動 App
databricks bundle run arks_agent -t ut
```

### LiteLLM Provider

The `ut` bundle now deploys the app with `LLM_PROVIDER=litellm`.

Before deploying, store the LiteLLM API key in the `arks` secret scope:

```powershell
databricks secrets create-scope arks
databricks secrets put-secret arks litellm-api-key
```

Deploy with your LiteLLM proxy URL and model route:

```powershell
databricks bundle deploy -t ut --var "litellm_endpoint=<OPENAI_COMPATIBLE_BASE_URL>,litellm_model=<MODEL_ROUTE>"
```

### 何時需要重跑 Setup Job

| 情境 | `arks_setup_lakebase` | `arks_setup_mlflow` |
|------|------|------|
| 一般程式碼更新 deploy | 不需要 | 不需要 |
| 首次部署 | **需要** | **需要** |
| App 被 destroy 後重建（SP 會變） | **需要** | **需要** |
| Lakebase project 重建 | **需要** | 不需要 |
| Checkpoint tables schema 錯誤需重建 | **需要**（會 DROP 舊表） | 不需要 |
| Prompt Registry 權限異常 | 不需要 | **需要** |

### Prompt Registry 權限

App SP 需要 Unity Catalog 的 Prompt Registry 存取權限。
`arks_setup_mlflow` job 會自動嘗試執行 GRANT。

若部署者權限不足，job 會印出需手動執行的 SQL，請 **Account Admin** 執行：

```sql
CREATE SCHEMA IF NOT EXISTS dev_gaia_experiments.arks;
GRANT USE CATALOG ON CATALOG dev_gaia_experiments TO `<app_sp_client_id>`;
GRANT USE SCHEMA ON SCHEMA dev_gaia_experiments.arks TO `<app_sp_client_id>`;
GRANT ALL PRIVILEGES ON SCHEMA dev_gaia_experiments.arks TO `<app_sp_client_id>`;
```

MLflow traces use UC table-prefix storage. The main App prefix is
`dev_gaia_experiments.arks.arks_agent`; review endpoint traces use
`dev_gaia_experiments.arks.arks_review`.

The identity running `arks_setup_mlflow` must have `CREATE SCHEMA` on
`dev_gaia_experiments`, or a catalog owner must create
`dev_gaia_experiments.arks` before this job runs. The same identity must also
be allowed to grant schema access to the App service principal.

If a catalog owner grants the permissions manually, rerun setup with:

```powershell
databricks bundle run arks_setup_mlflow -t ut --params skip_uc_grants=true
```

MLflow Prompt Registry prompts are not SQL functions. Do not run
`ALTER FUNCTION ... OWNER TO ...` for prompt names; `ROUTINE_NOT_FOUND` in old
setup logs only means the old script used the wrong SQL object type.

> App SP client_id 可從 setup job 輸出、Databricks UI → Apps → arks-agent → Overview、或 App log 取得。
> 每次 App 被 destroy 重建後 SP 會變，需重跑 setup job 或手動重新授權。
> 若未授權，App 會 fallback 到 YAML 中的 prompt 定義（功能正常但無法使用 Prompt Registry 的版本管理）。

## 驗證

部署完成後取得 App URL，可透過以下方式測試。
`databricks auth token` 只適合部署者或開發者做 POC / smoke test。
Windows Terminal（PowerShell）請使用 `curl.exe`，避免 `curl` 被解析成 PowerShell alias。
JSON body 先寫入暫存檔再交給 `curl.exe`，避免 PowerShell 呼叫 native exe 時移除 JSON 雙引號。

```powershell
# Databricks workspace URL，不是 App URL
$env:DATABRICKS_HOST = "https://<your-workspace-host>"
$env:APP_URL = "https://<your-app-url>"

$env:ACCESS_TOKEN = (databricks auth token --host $env:DATABRICKS_HOST --output json | ConvertFrom-Json).access_token
```

```powershell
# 基本測試
$body = @'
{
  "input": [
    {
      "role": "user",
      "content": "我想要保我的特斯拉，有什麼情況有可能不能保"
    }
  ]
}
'@
$bodyFile = Join-Path $env:TEMP "arks-responses-basic.json"
[System.IO.File]::WriteAllText($bodyFile, $body, (New-Object System.Text.UTF8Encoding $false))

curl.exe -X POST "$($env:APP_URL)/responses" `
  -H "Authorization: Bearer $($env:ACCESS_TOKEN)" `
  -H "Content-Type: application/json" `
  -H "x-mlflow-return-trace-id: true" `
  --data-binary "@$bodyFile"
```

```powershell
# 含 custom_inputs
$body = @'
{
  "input": [
    {
      "role": "user",
      "content": "我想要保我的特斯拉，有什麼情況有可能不能保"
    }
  ],
  "custom_inputs": {
    "system_code": "arks",
    "role": ["0001", "0002"],
    "insurance_department": {
      "car": ["claim", "underwriting"],
      "fire": ["claim"]
    },
    "cathay_no": "E12345",
    "query_timestamp": "2026-05-14T09:30:15.123Z"
  }
}
'@
$bodyFile = Join-Path $env:TEMP "arks-responses-custom-inputs.json"
[System.IO.File]::WriteAllText($bodyFile, $body, (New-Object System.Text.UTF8Encoding $false))

curl.exe -X POST "$($env:APP_URL)/responses" `
  -H "Authorization: Bearer $($env:ACCESS_TOKEN)" `
  -H "Content-Type: application/json" `
  -H "x-mlflow-return-trace-id: true" `
  --data-binary "@$bodyFile"
```

```powershell
# Streaming
$body = @'
{
  "input": [
    {
      "role": "user",
      "content": "我想要保我的特斯拉，有什麼情況有可能不能保"
    }
  ],
  "stream": true,
  "custom_inputs": {
    "system_code": "arks",
    "role": "0001",
    "insurance_department": { "car": ["claim", "underwriting"] },
    "cathay_no": "E12345",
    "query_timestamp": "2026-05-14T09:30:15.123Z"
  }
}
'@
$bodyFile = Join-Path $env:TEMP "arks-responses-streaming.json"
[System.IO.File]::WriteAllText($bodyFile, $body, (New-Object System.Text.UTF8Encoding $false))

curl.exe -N -X POST "$($env:APP_URL)/responses" `
  -H "Authorization: Bearer $($env:ACCESS_TOKEN)" `
  -H "Content-Type: application/json" `
  -H "Accept: text/event-stream" `
  -H "x-mlflow-return-trace-id: true" `
  --data-binary "@$bodyFile"
```

## API 端點

| 端點 | 方法 | 說明 |
|------|------|------|
| `/responses` | POST | 同步呼叫或 streaming |
| `/responses` | POST（`background=true`） | 非同步呼叫，回傳 `{id, status}` |
| `/responses/{id}` | GET | 取得 background task 結果 |
| `/invocations` | POST | `/responses` 的 compatibility alias |
| `/` | GET | 未提供 UI，回傳 `404 Not Found` |

## 正式串接建議

建議架構：

```text
其他部門 frontend
  -> 其他部門 backend / BFF
    -> Databricks App API route (/api/...)
      -> Arks Agent
```

後端 / BFF 負責：

- 使用 service principal OAuth M2M 取得 Databricks access token
- 以 `Authorization: Bearer <token>` 呼叫 Databricks App
- 串流回傳 SSE 給前端
- 管理 request ID、稽核紀錄、錯誤格式與權限邊界

本 repo 另有 `apps/agent_proxy/` 範例，提供 `/api/agent/stream` proxy route，
可作為正式串接或 POC frontend 的參考。

## 環境切換

```bash
databricks bundle deploy              # ut（預設）
databricks bundle deploy -t prod      # production
```

## 常用指令

```bash
# 查看 App logs
databricks apps logs arks-agent

# 銷毀所有資源（Lakebase project 除外）
databricks bundle destroy -t ut

# 手動刪除 Lakebase project
databricks postgres delete-project projects/arks-lakebase-v2
```

## Troubleshooting

| 問題 | 原因 | 解法 |
|------|------|------|
| `must be owner of table checkpoint_*` | Checkpoint tables 不是 App SP 建的 | 重跑 `arks_setup_lakebase`（會 DROP 舊表讓 App 重建） |
| `Prompt fallback to YAML: PERMISSION_DENIED` | App SP 缺少 Unity Catalog 權限 | 請 Admin 執行 GRANT 語句（見上方） |
| `relation "checkpoints" does not exist` | Checkpoint tables 尚未建立 | 確認 `arks_setup_lakebase` 已成功執行，重啟 App |
| App deploy 後 Lakebase resource 消失 | 舊版問題，現已透過 DABs `postgres_projects` 管理 | 確認 `databricks.yml` 有 `postgres_projects` 區塊 |

## Legacy：Serving Endpoint 部署

舊的 Serving Endpoint 部署流程已棄用，相關腳本已註解保留：
- `app/services/scripts/log_to_databricks.py` — UC Model 打包（已註解）
- `app/services/scripts/deploy_to_databricks.py` — Endpoint 部署（已註解）

---
