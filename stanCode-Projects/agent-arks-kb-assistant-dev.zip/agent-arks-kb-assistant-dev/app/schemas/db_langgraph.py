"""
LangGraph Checkpoint 專用 Schema

LangGraph PostgresSaver 相關的請求/回應 Schema。

使用範例：
    from schemas.db_langgraph import CheckpointSaveRequest, CheckpointResponse
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ============================================================================
# 請求 Schema
# ============================================================================

class CheckpointSaveRequest(BaseModel):
    """儲存 Checkpoint 請求"""
    thread_id: str = Field(..., min_length=1, description="對話或工作流程的唯一 ID")
    state: Dict[str, Any] = Field(..., description="要儲存的狀態資料")


# ============================================================================
# 回應 Schema
# ============================================================================

class CheckpointResponse(BaseModel):
    """單筆 Checkpoint 回應"""
    checkpoint_id: str
    state: Any
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None


class CheckpointSaveResponse(BaseModel):
    """儲存 Checkpoint 回應"""
    status: str
    message: str
    thread_id: str
    checkpoint_id: str


class CheckpointDetailResponse(BaseModel):
    """讀取 Checkpoint 回應"""
    status: str
    thread_id: str
    checkpoint: CheckpointResponse


class CheckpointHistoryResponse(BaseModel):
    """Checkpoint 歷史回應"""
    status: str
    thread_id: str
    count: int
    history: List[CheckpointResponse]


class CheckpointDeleteResponse(BaseModel):
    """刪除 Checkpoint 回應"""
    status: str
    message: str
    thread_id: str
    deleted_count: int
