"""
Pydantic 驗證模型模組

匯出所有 Schema：
- db_common: 四種 DB 共用的通用請求/回應 Schema
- db_ocp: OCP Tool API 專用 Schema
- db_langgraph: LangGraph Checkpoint 專用 Schema
- ocp: OCP 底層 Client Schema
- sample_item: 完整分層架構範例 Schema
"""

# 通用 DB Schema
from schemas.db_common import (
    RawSQLRequest,
    TableInsertRequest,
    TableQueryRequest,
    TableUpdateRequest,
    TableDeleteRequest,
    TableDDLRequest,
    HealthCheckResponse,
    InitResponse,
    QueryResultResponse,
    ExecuteResultResponse,
    InfoResponse,
)

# OCP Route 專用 Schema
from schemas.db_ocp import (
    OCPQueryExecuteRequest,
    OCPSelectResponse,
    OCPDMLResponse,
    OCPBatchResultItem,
    OCPBatchResponse,
)

# LangGraph 專用 Schema
from schemas.db_langgraph import (
    CheckpointSaveRequest,
    CheckpointResponse,
    CheckpointSaveResponse,
    CheckpointDetailResponse,
    CheckpointHistoryResponse,
    CheckpointDeleteResponse,
)

# OCP 底層 Client Schema
from schemas.ocp import (
    OCPQueryRequest,
    OCPMWHeader,
    OCPTransactionResult,
    OCPQueryResponse,
    OCPSelectResult,
    OCPDMLResult,
)

# SampleItem Schema
from schemas.sample_item import (
    SampleItemCreate,
    SampleItemUpdate,
    SampleItemResponse,
    SampleItemListResponse,
)

__all__ = [
    # 通用 DB Schema
    "RawSQLRequest",
    "TableInsertRequest",
    "TableQueryRequest",
    "TableUpdateRequest",
    "TableDeleteRequest",
    "TableDDLRequest",
    "HealthCheckResponse",
    "InitResponse",
    "QueryResultResponse",
    "ExecuteResultResponse",
    "InfoResponse",

    # OCP Route Schema
    "OCPQueryExecuteRequest",
    "OCPSelectResponse",
    "OCPDMLResponse",
    "OCPBatchResultItem",
    "OCPBatchResponse",

    # LangGraph Schema
    "CheckpointSaveRequest",
    "CheckpointResponse",
    "CheckpointSaveResponse",
    "CheckpointDetailResponse",
    "CheckpointHistoryResponse",
    "CheckpointDeleteResponse",

    # OCP Client Schema
    "OCPQueryRequest",
    "OCPMWHeader",
    "OCPTransactionResult",
    "OCPQueryResponse",
    "OCPSelectResult",
    "OCPDMLResult",

    # SampleItem Schema
    "SampleItemCreate",
    "SampleItemUpdate",
    "SampleItemResponse",
    "SampleItemListResponse",
]
