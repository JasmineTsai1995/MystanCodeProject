"""
範例 Pydantic Schema - SampleItem

展示請求驗證和回應序列化的標準定義方式。
"""

from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict


# ============================================================================
# 請求 Schema
# ============================================================================

class SampleItemCreate(BaseModel):
    """建立 SampleItem 的請求"""
    title: str = Field(..., min_length=1, max_length=200, description="標題")
    description: Optional[str] = Field(None, description="描述")


class SampleItemUpdate(BaseModel):
    """更新 SampleItem 的請求（所有欄位皆為可選）"""
    title: Optional[str] = Field(None, min_length=1, max_length=200, description="標題")
    description: Optional[str] = Field(None, description="描述")
    is_done: Optional[bool] = Field(None, description="是否完成")


# ============================================================================
# 回應 Schema
# ============================================================================

class SampleItemResponse(BaseModel):
    """單筆 SampleItem 回應"""
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: Optional[str] = None
    is_done: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SampleItemListResponse(BaseModel):
    """SampleItem 列表回應"""
    total: int
    items: List[SampleItemResponse]
