"""
通用資料庫操作 Schema

提供四種 DB 連線方式（SQLAlchemy / psycopg / OCP / LangGraph）共用的請求/回應 Schema。
設計為通用化：使用 table_name + data dict，不綁定特定領域。

使用範例：
    from schemas.db_common import RawSQLRequest, TableInsertRequest, QueryResultResponse
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ============================================================================
# 通用請求 Schema
# ============================================================================

class RawSQLRequest(BaseModel):
    """通用原生 SQL 請求（適用所有 DB 連線方式）"""
    sql: str = Field(..., min_length=1, description="SQL 語句")
    params: Optional[Dict[str, Any]] = Field(None, description="SQL 參數")


class TableInsertRequest(BaseModel):
    """通用資料插入請求"""
    table_name: str = Field(..., min_length=1, description="資料表名稱")
    data: Dict[str, Any] = Field(
        ..., description="欄位與值的對應",
        json_schema_extra={"example": {"name": "Alice", "email": "alice@example.com"}},
    )


class TableQueryRequest(BaseModel):
    """通用資料查詢請求"""
    table_name: str = Field(..., min_length=1, description="資料表名稱")
    columns: Optional[List[str]] = Field(None, description="查詢欄位（None=全部）")
    filters: Optional[Dict[str, Any]] = Field(None, description="過濾條件")
    order_by: Optional[str] = Field(None, description="排序欄位（前綴 - 為降序）")
    skip: int = Field(0, ge=0, description="跳過筆數")
    limit: int = Field(10, ge=1, le=100, description="每頁筆數")


class TableUpdateRequest(BaseModel):
    """通用資料更新請求"""
    table_name: str = Field(..., min_length=1, description="資料表名稱")
    filters: Dict[str, Any] = Field(..., description="WHERE 條件")
    data: Dict[str, Any] = Field(..., description="要更新的欄位與值")


class TableDeleteRequest(BaseModel):
    """通用資料刪除請求"""
    table_name: str = Field(..., min_length=1, description="資料表名稱")
    filters: Dict[str, Any] = Field(..., description="WHERE 條件")


class TableDDLRequest(BaseModel):
    """通用 DDL 請求（建表/刪表）"""
    table_name: str = Field(..., min_length=1, description="資料表名稱")
    ddl_sql: Optional[str] = Field(None, description="自訂 DDL SQL（可選）")


# ============================================================================
# 通用回應 Schema
# ============================================================================

class HealthCheckResponse(BaseModel):
    """通用健康檢查回應"""
    status: str
    connection_type: str
    database: Optional[str] = None
    host: Optional[str] = None
    detail: Optional[Dict[str, Any]] = None


class InitResponse(BaseModel):
    """通用初始化回應"""
    status: str
    message: str
    info: Optional[Dict[str, Any]] = None


class QueryResultResponse(BaseModel):
    """通用查詢結果回應"""
    status: str
    row_count: int = 0
    columns: Optional[List[str]] = None
    data: Optional[List[Dict[str, Any]]] = None
    message: Optional[str] = None


class ExecuteResultResponse(BaseModel):
    """通用 DML 執行結果回應（INSERT/UPDATE/DELETE）"""
    status: str
    affected_rows: int = 0
    returning_data: Optional[Dict[str, Any]] = None
    message: Optional[str] = None


class InfoResponse(BaseModel):
    """通用功能說明回應"""
    status: str
    features: List[str]
    examples: List[Dict[str, str]]
    message: Optional[str] = None
