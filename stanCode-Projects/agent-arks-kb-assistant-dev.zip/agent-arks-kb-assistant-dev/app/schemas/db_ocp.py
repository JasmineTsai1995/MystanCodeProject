"""
OCP Tool API 專用 Schema

OCP 特有的請求/回應格式，通用部分繼承自 db_common。
底層 OCP Client 的 Schema 在 schemas/ocp.py，本檔案是 Route 層使用的 Schema。

使用範例：
    from schemas.db_ocp import OCPQueryExecuteRequest, OCPSelectResponse
"""

from typing import Optional, List, Any
from pydantic import BaseModel, Field

from schemas.db_common import RawSQLRequest


# ============================================================================
# 請求 Schema
# ============================================================================

class OCPQueryExecuteRequest(RawSQLRequest):
    """OCP 查詢請求（擴展通用 SQL 請求，加上 database 欄位）"""
    database: Optional[str] = Field(None, description="資料庫名稱（預設使用環境變數設定）")


# ============================================================================
# 回應 Schema
# ============================================================================

class OCPSelectResponse(BaseModel):
    """OCP SELECT 查詢回應"""
    status: str
    query_time: float
    row_count: int
    columns: List[str]
    data: List[List[Any]]


class OCPDMLResponse(BaseModel):
    """OCP DML 操作回應"""
    status: str
    query_time: float
    affected_rows: int


class OCPBatchResultItem(BaseModel):
    """OCP 批次查詢單筆結果"""
    index: int
    status: str
    query_time: Optional[float] = None
    row_count: Optional[int] = None
    columns: Optional[List[str]] = None
    data: Optional[List[List[Any]]] = None
    error: Optional[str] = None


class OCPBatchResponse(BaseModel):
    """OCP 批次查詢回應"""
    status: str
    total: int
    success: int
    failed: int
    results: List[OCPBatchResultItem]
