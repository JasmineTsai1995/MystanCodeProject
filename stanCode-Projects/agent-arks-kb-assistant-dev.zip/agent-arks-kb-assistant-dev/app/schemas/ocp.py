"""
OCP Tool API Pydantic 驗證模型

定義 OCP Tool API 相關的請求和回應 Schema
"""

from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


# ============================================================================
# 請求 Schema
# ============================================================================

class OCPQueryRequest(BaseModel):
    """OCP 查詢請求 Schema"""
    database: str = Field(..., description="資料庫名稱")
    sql: str = Field(..., description="SQL 查詢語句")


# ============================================================================
# 回應 Schema (對應 OCP API 原始格式)
# ============================================================================

class OCPMWHeader(BaseModel):
    """OCP API 回應標頭"""
    RETURNCODE: str = Field(..., description="回應代碼（0000 為成功）")
    RETURNDESC: str = Field(..., description="回應描述")


class OCPTransactionResult(BaseModel):
    """OCP 交易結果"""
    status: str = Field(..., description="執行狀態")
    session_type: Optional[Any] = Field(None, description="Session 類型")
    query_time: float = Field(..., description="查詢執行時間（秒）")
    result: List[Any] = Field(..., description="查詢結果")


class OCPQueryResponse(BaseModel):
    """OCP 查詢回應 Schema"""
    MWHEADER: OCPMWHeader = Field(..., description="API 狀態標頭")
    TRANRS: OCPTransactionResult = Field(..., description="交易結果")


# ============================================================================
# 解析後的結果 Schema
# ============================================================================

class OCPSelectResult(BaseModel):
    """SELECT 查詢解析結果"""
    success: bool = Field(..., description="是否執行成功")
    query_time: float = Field(..., description="查詢時間（秒）")
    data: List[List[Any]] = Field(..., description="查詢資料（二維陣列）")
    columns: List[str] = Field(..., description="欄位名稱列表")
    row_count: int = Field(..., description="返回的資料筆數")
    
    def to_dict_list(self) -> List[Dict[str, Any]]:
        """
        將結果轉換為字典列表格式
        
        Returns:
            [{"col1": value1, "col2": value2, ...}, ...]
        """
        return [
            {col: row[i] for i, col in enumerate(self.columns)}
            for row in self.data
        ]


class OCPDMLResult(BaseModel):
    """DML 操作（INSERT/UPDATE/DELETE）解析結果"""
    success: bool = Field(..., description="是否執行成功")
    query_time: float = Field(..., description="查詢時間（秒）")
    affected_rows: int = Field(..., description="影響的資料筆數")
