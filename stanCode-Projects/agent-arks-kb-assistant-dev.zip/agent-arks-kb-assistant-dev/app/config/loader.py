"""
Config Loader

Single entry point for all application configuration.
Reads app/config/config.yaml at import time; environment variables override yaml values.

Usage:
    from config.loader import cfg, cfg_int, cfg_float, cfg_bool

    provider  = cfg("llm.provider", "LLM_PROVIDER", "openrouter")
    top_k     = cfg_int("retrieval.qa_top_k", "QA_RETRIEVE_TOP_K", default=10)
    temp      = cfg_float("llm.temperature", "AGENT_TEMPERATURE", default=0.0)
    is_hybrid = cfg_bool("retrieval.hybrid", default=False)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

load_dotenv()

# Project root = three levels up from app/config/loader.py
PROJECT_DIR: Path = Path(__file__).resolve().parents[2]

_YAML_PATH = Path(__file__).parent / "config.yaml"
with _YAML_PATH.open(encoding="utf-8") as _f:
    _CFG: dict = yaml.safe_load(_f) or {}


def _get_yaml(path: str, default: Any = None) -> Any:
    node: Any = _CFG
    for key in path.split("."):
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return node if node is not None else default


def cfg(yaml_path: str, env_key: str | None = None, default: Any = None) -> Any:
    """Return config value with priority: env var > yaml > default."""
    yaml_val = _get_yaml(yaml_path, default)
    if env_key is None:
        return yaml_val
    return os.getenv(env_key, yaml_val)


def cfg_int(yaml_path: str, env_key: str | None = None, default: int = 0) -> int:
    return int(cfg(yaml_path, env_key, default))


def cfg_float(yaml_path: str, env_key: str | None = None, default: float = 0.0) -> float:
    return float(cfg(yaml_path, env_key, default))


def cfg_bool(yaml_path: str, env_key: str | None = None, default: bool = False) -> bool:
    val = cfg(yaml_path, env_key, default)
    if isinstance(val, bool):
        return val
    return str(val).lower() in ("true", "1", "yes")
