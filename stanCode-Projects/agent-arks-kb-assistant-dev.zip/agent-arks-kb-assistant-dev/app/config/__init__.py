"""
配置管理模組

此模組包含應用程式的所有配置設定和 Prompt 模板管理。

- settings   — FastAPI 基礎設施設定 (DB, CORS, logging)
- cfg / cfg_* — 應用程式 config.yaml 存取器 (LLM, MongoDB, retrieval ...)
- prompts    — Prompt 模板 (app/config/prompts/prompts.yaml)
"""

from .loader import cfg, cfg_bool, cfg_float, cfg_int
from .settings import settings

__all__ = ["settings", "cfg", "cfg_int", "cfg_float", "cfg_bool"]
