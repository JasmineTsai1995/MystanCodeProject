"""Canonical runtime prompts captured for immutable review endpoint releases."""

from __future__ import annotations

import os


def uc_catalog_schema() -> str:
    catalog = os.getenv("ARKS_UC_CATALOG", "dev_gaia_experiments").strip()
    schema = os.getenv("ARKS_UC_SCHEMA", "arks").strip()
    return f"{catalog}.{schema}"


_UC = uc_catalog_schema()

REVIEW_RUNTIME_PROMPTS = {
    "agent": f"{_UC}.arks_agent",
    "reflection.review": f"{_UC}.arks_reflection_review",
    "reflection.judge": f"{_UC}.arks_reflection_judge",
    "reflection.revise": f"{_UC}.arks_reflection_revise",
    "followup.system": f"{_UC}.arks_followup_system",
    "followup.questions": f"{_UC}.arks_followup_questions",
}

