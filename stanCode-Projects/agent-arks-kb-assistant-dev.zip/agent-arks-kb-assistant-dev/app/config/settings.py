"""
應用程式設定管理

使用 os.getenv() 讀取環境變數，保持簡單直接。
"""

import os
from typing import List


class Settings:
    """應用程式設定類別"""
    
    def __init__(self):
        # 應用程式基本設定
        self.app_name: str = os.getenv("APP_NAME", "FastAPI Standard Structure")
        self.app_version: str = os.getenv("APP_VERSION", "1.0.0")
        self.app_env: str = os.getenv("APP_ENV", os.getenv("ENVIRONMENT", "development"))
        self.debug: bool = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")
        self.api_prefix: str = os.getenv("API_PREFIX", "/api/v1")
        
        # 資料庫配置
        self.db_host: str = os.getenv("DB_HOST", "db")
        self.db_port: int = int(os.getenv("DB_PORT", "5432"))
        self.db_user: str = os.getenv("DB_USER", "postgres")
        self.db_password: str = os.getenv("DB_PASSWORD", "postgres")
        self.db_name: str = os.getenv("DB_NAME", "fastapi_db")
        
        # 資料庫 URL（組合）
        self.database_url: str = (
            f"postgresql+asyncpg://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )
        
        # 資料庫連線池配置（統一管理）
        self.db_pool_min_size: int = int(os.getenv("DB_POOL_MIN_SIZE", "2"))
        self.db_pool_max_size: int = int(os.getenv("DB_POOL_MAX_SIZE", "10"))
        self.db_pool_pre_ping: bool = os.getenv("DB_POOL_PRE_PING", "true").lower() in ("true", "1", "yes")
        self.db_pool_timeout: int = int(os.getenv("DB_POOL_TIMEOUT", "30"))
        self.db_pool_recycle: int = int(os.getenv("DB_POOL_RECYCLE", "3600"))
        self.db_pool_max_idle: int = int(os.getenv("DB_POOL_MAX_IDLE", "300"))
        self.db_pool_max_lifetime: int = int(os.getenv("DB_POOL_MAX_LIFETIME", "3600"))

        # OCP Tool API 配置
        self.ocp_env: str = os.getenv("OCP_ENV", "sit")
        self.ocp_api_url: str = os.getenv("OCP_API_URL", "")
        self.ocp_default_database: str = os.getenv("OCP_DEFAULT_DATABASE", "datdatcm")
        self.ocp_timeout: int = int(os.getenv("OCP_TIMEOUT", "30"))
        self.ocp_verify_ssl: bool = os.getenv("OCP_VERIFY_SSL", "True").lower() in ("true", "1", "yes")
        self.ocp_max_retries: int = int(os.getenv("OCP_MAX_RETRIES", "3"))
        self.ocp_retry_delay: float = float(os.getenv("OCP_RETRY_DELAY", "1.0"))
        
        # CORS 設定
        self.cors_origins: List[str] = self._parse_list(
            os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:8000")
        )
        self.cors_allow_credentials: bool = os.getenv("CORS_ALLOW_CREDENTIALS", "True").lower() in ("true", "1", "yes")
        self.cors_allow_methods: List[str] = self._parse_list(os.getenv("CORS_ALLOW_METHODS", "*"))
        self.cors_allow_headers: List[str] = self._parse_list(os.getenv("CORS_ALLOW_HEADERS", "*"))
        
        # 日誌設定
        self.log_level: str = os.getenv("LOG_LEVEL", "INFO")
        self.log_file: str = os.getenv("LOG_FILE", "./logs/app.log")
        
        # psycopg 連線 URL
        self.psycopg_url: str = (
            f"postgresql://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

        # 時區
        self.timezone: str = os.getenv("TIMEZONE", "Asia/Taipei")
    
    def _parse_list(self, value: str) -> List[str]:
        """解析逗號分隔的字串為列表"""
        if value == "*":
            return ["*"]
        return [item.strip() for item in value.split(",") if item.strip()]
    
    @property
    def is_production(self) -> bool:
        """判斷是否為生產環境"""
        return self.app_env.lower() == "production"
    
    @property
    def is_development(self) -> bool:
        """判斷是否為開發環境"""
        return self.app_env.lower() == "development"
    
    @property
    def is_testing(self) -> bool:
        """判斷是否為測試環境"""
        return self.app_env.lower() == "testing"


# 建立全域設定實例
settings = Settings()
