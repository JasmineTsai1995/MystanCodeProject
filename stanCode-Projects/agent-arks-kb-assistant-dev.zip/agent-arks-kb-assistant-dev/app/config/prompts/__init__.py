"""
Prompts Package

Single source of truth for all prompt strings.

Agent / Reflection / Follow-up prompts are loaded from MLflow Prompt Registry
(prompts:/<name>@production) with automatic fallback to prompts.yaml when the
registry is unreachable (local dev, CI, etc.).

Use the get_* functions in long-running services so Prompt Registry alias
changes can be picked up without restarting the process.

KB Processing prompts are always loaded from prompts.yaml — they are pipeline
utilities unrelated to the agent runtime and do not need registry versioning.
"""

import os

from langchain_core.prompts import ChatPromptTemplate

from .loader import PromptSnapshot, get, load_snapshot

def _uc_catalog_schema() -> str:
    catalog = os.getenv("ARKS_UC_CATALOG", "dev_gaia_experiments").strip()
    schema = os.getenv("ARKS_UC_SCHEMA", "arks").strip()
    return f"{catalog}.{schema}"


_UC = _uc_catalog_schema()


def get_agent_system_prompt_snapshot() -> PromptSnapshot:
    return load_snapshot(f"{_UC}.arks_agent", fallback_key="agent")


def get_agent_system_prompt() -> str:
    return get_agent_system_prompt_snapshot().template


def get_reflection_review_prompt() -> str:
    return load_snapshot(
        f"{_UC}.arks_reflection_review",
        fallback_key="reflection.review",
    ).template


def get_judge_prompt() -> str:
    return load_snapshot(
        f"{_UC}.arks_reflection_judge",
        fallback_key="reflection.judge",
    ).template


def get_revise_prompt() -> str:
    return load_snapshot(
        f"{_UC}.arks_reflection_revise",
        fallback_key="reflection.revise",
    ).template


def get_followup_system_prompt() -> str:
    return load_snapshot(
        f"{_UC}.arks_followup_system",
        fallback_key="followup.system",
    ).template


def get_followup_questions_prompt() -> str:
    return load_snapshot(
        f"{_UC}.arks_followup_questions",
        fallback_key="followup.questions",
    ).template


# --- Agent -------------------------------------------------------------------
AGENT_SYSTEM_PROMPT: str = get_agent_system_prompt()

# --- Reflection --------------------------------------------------------------
REFLECTION_REVIEW_PROMPT: str = get_reflection_review_prompt()
JUDGE_PROMPT: str             = get_judge_prompt()
REVISE_PROMPT: str            = get_revise_prompt()

# --- Follow-up ---------------------------------------------------------------
FOLLOWUP_SYSTEM_PROMPT: str    = get_followup_system_prompt()
FOLLOWUP_QUESTIONS_PROMPT: str = get_followup_questions_prompt()

# --- KB Processing (always from YAML) ----------------------------------------
summary_prompt = ChatPromptTemplate([
    ("system", get("kb_processing.summary")),
    ("user", "{input}"),
])

mermaid_summary_prompt = ChatPromptTemplate([
    ("system", get("kb_processing.mermaid")),
    ("user", "{input}"),
])

__all__ = [
    "AGENT_SYSTEM_PROMPT",
    "REFLECTION_REVIEW_PROMPT",
    "JUDGE_PROMPT",
    "REVISE_PROMPT",
    "FOLLOWUP_SYSTEM_PROMPT",
    "FOLLOWUP_QUESTIONS_PROMPT",
    "get_agent_system_prompt_snapshot",
    "get_agent_system_prompt",
    "get_reflection_review_prompt",
    "get_judge_prompt",
    "get_revise_prompt",
    "get_followup_system_prompt",
    "get_followup_questions_prompt",
    "summary_prompt",
    "mermaid_summary_prompt",
]
