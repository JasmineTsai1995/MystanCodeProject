"""
Prompt Loader

Two loading strategies:

1. get(key)
   Reads prompts.yaml once at import time and returns the string at the
   given dot-notation key, e.g.:

       get("reflection.judge")        -> str
       get("followup.system")         -> str
       get("kb_processing.summary")   -> str

2. load_snapshot(registry_name, fallback_key)
   Tries to load the prompt template from MLflow Prompt Registry
   (prompts:/<registry_name>@production).  Falls back to get(fallback_key)
   if the registry is unreachable (local dev, missing env vars, etc.).

   Registry lookups are cached for ARKS_PROMPT_CACHE_TTL_SECONDS seconds
   (default 60). This lets long-running apps pick up alias changes without
   a process restart while avoiding a registry call on every request.

3. ARKS_PROMPT_MODE=deployment_snapshot
   Resolves prompts from the immutable review_prompt_snapshot module packaged
   with a review model artifact. Missing or corrupted snapshots fail closed.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import logging
import os
from pathlib import Path
import threading
import time

import yaml

logger = logging.getLogger(__name__)

_YAML_PATH = Path(__file__).parent / "prompts.yaml"
_PROMPT_ALIAS = "production"
_DEFAULT_CACHE_TTL_SECONDS = 60.0
_CACHE_LOCK = threading.RLock()
_CACHE: dict[tuple[str, str], "PromptSnapshot"] = {}

with _YAML_PATH.open(encoding="utf-8") as _f:
    _data: dict = yaml.safe_load(_f)


def get(key: str) -> str:
    """Return the prompt string at the given dot-notation key from prompts.yaml.

    Raises KeyError if the key does not exist.
    """
    node: dict | str = _data
    for part in key.split("."):
        if not isinstance(node, dict):
            raise KeyError(f"Key '{key}' not found: '{part}' is not a mapping.")
        node = node[part]
    if not isinstance(node, str):
        raise TypeError(f"Key '{key}' resolves to {type(node).__name__}, expected str.")
    return node


@dataclass(frozen=True)
class PromptSnapshot:
    """Resolved prompt plus metadata for logging and change detection."""

    template: str
    source: str
    registry_name: str
    fallback_key: str
    alias: str = _PROMPT_ALIAS
    version: str | None = None
    digest: str | None = None
    loaded_at: float = 0.0

    @property
    def identity(self) -> tuple[str, str | None, str]:
        return (self.source, self.version, self.registry_name)


def _cache_ttl_seconds() -> float:
    raw = os.environ.get("ARKS_PROMPT_CACHE_TTL_SECONDS", "").strip()
    if not raw:
        return _DEFAULT_CACHE_TTL_SECONDS
    try:
        return max(0.0, float(raw))
    except ValueError:
        logger.warning(
            "Invalid ARKS_PROMPT_CACHE_TTL_SECONDS=%r; using default %.0fs.",
            raw,
            _DEFAULT_CACHE_TTL_SECONDS,
        )
        return _DEFAULT_CACHE_TTL_SECONDS


def _is_cache_valid(snapshot: PromptSnapshot, now: float, ttl_seconds: float) -> bool:
    return ttl_seconds > 0 and now - snapshot.loaded_at < ttl_seconds


def _load_deployment_snapshot(
    registry_name: str,
    fallback_key: str,
    now: float,
) -> PromptSnapshot:
    """Load an immutable prompt bundled into the review model artifact."""
    try:
        from review_prompt_snapshot import SNAPSHOTS
    except ImportError as exc:
        raise RuntimeError(
            "ARKS_PROMPT_MODE=deployment_snapshot but review_prompt_snapshot is not packaged."
        ) from exc

    entry = SNAPSHOTS.get(registry_name)
    if entry is None:
        raise RuntimeError(f"Prompt is missing from deployment snapshot: {registry_name}")
    template = entry["template"]
    digest = hashlib.sha256(template.encode("utf-8")).hexdigest()
    if digest != entry["digest"]:
        raise RuntimeError(f"Prompt snapshot digest mismatch: {registry_name}")
    return PromptSnapshot(
        template=template,
        source="mlflow_snapshot",
        registry_name=registry_name,
        fallback_key=fallback_key,
        alias=entry.get("alias", _PROMPT_ALIAS),
        version=str(entry["version"]),
        digest=digest,
        loaded_at=now,
    )


def _load_uncached(
    registry_name: str,
    fallback_key: str,
    now: float,
    previous: PromptSnapshot | None = None,
) -> PromptSnapshot:
    try:
        import mlflow

        prompt = mlflow.genai.load_prompt(
            f"prompts:/{registry_name}@{_PROMPT_ALIAS}",
            cache_ttl_seconds=0,
        )
        version = str(getattr(prompt, "version", "") or "")
        snapshot = PromptSnapshot(
            template=prompt.template,
            source="mlflow",
            registry_name=registry_name,
            fallback_key=fallback_key,
            version=version or None,
            loaded_at=now,
        )
        logger.info(
            "Prompt loaded from MLflow Registry: name=%s alias=%s version=%s",
            registry_name,
            _PROMPT_ALIAS,
            snapshot.version or "unknown",
        )
        return snapshot
    except Exception as exc:
        if previous is not None and previous.source == "mlflow":
            logger.warning(
                "Prompt refresh failed; keeping cached MLflow prompt: "
                "name=%s alias=%s version=%s reason=%s",
                registry_name,
                _PROMPT_ALIAS,
                previous.version or "unknown",
                exc,
            )
            return PromptSnapshot(
                template=previous.template,
                source=previous.source,
                registry_name=previous.registry_name,
                fallback_key=previous.fallback_key,
                alias=previous.alias,
                version=previous.version,
                loaded_at=now,
            )

        snapshot = PromptSnapshot(
            template=get(fallback_key),
            source="yaml",
            registry_name=registry_name,
            fallback_key=fallback_key,
            loaded_at=now,
        )
        logger.warning(
            "Prompt fallback to YAML: name=%s fallback_key=%s reason=%s",
            registry_name,
            fallback_key,
            exc,
        )
        return snapshot


def load_snapshot(registry_name: str, fallback_key: str) -> PromptSnapshot:
    """Load a prompt from the configured runtime source.

    By default, attempts to fetch ``prompts:/<registry_name>@production`` from
    the MLflow Prompt Registry. On any error (no tracking URI, prompt not yet
    registered, network issues) it falls back to ``get(fallback_key)`` so that
    local development and CI work without a live Databricks connection.

    When ``ARKS_PROMPT_MODE=deployment_snapshot``, it instead reads the
    immutable prompt packaged into the review model artifact and raises if the
    snapshot is missing or invalid; it never falls back to YAML.

    Dynamic registry results are cached for ``ARKS_PROMPT_CACHE_TTL_SECONDS``
    seconds. Set that value to ``0`` to force a registry lookup on every call.

    Args:
        registry_name: Name of the prompt in MLflow Registry (e.g. "arks_agent").
        fallback_key:  Dot-notation key in prompts.yaml (e.g. "agent").

    Returns:
        PromptSnapshot containing the template and source metadata.
    """
    key = (registry_name, fallback_key)
    now = time.monotonic()
    if os.getenv("ARKS_PROMPT_MODE", "").strip().lower() == "deployment_snapshot":
        return _load_deployment_snapshot(registry_name, fallback_key, now)

    ttl_seconds = _cache_ttl_seconds()

    with _CACHE_LOCK:
        snapshot = _CACHE.get(key)
        if snapshot is not None and _is_cache_valid(snapshot, now, ttl_seconds):
            logger.debug(
                "Prompt cache hit: source=%s name=%s alias=%s version=%s ttl=%ss",
                snapshot.source,
                registry_name,
                _PROMPT_ALIAS,
                snapshot.version or "none",
                ttl_seconds,
            )
            return snapshot

        snapshot = _load_uncached(registry_name, fallback_key, now, previous=snapshot)
        _CACHE[key] = snapshot
        return snapshot


def load(registry_name: str, fallback_key: str) -> str:
    """Compatibility wrapper returning only the prompt template string."""
    return load_snapshot(registry_name, fallback_key).template
