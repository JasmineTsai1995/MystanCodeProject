"""
FastAPI 應用程式入口

這是 FastAPI 應用程式的主要入口點，負責：
- 應用程式初始化
- 中介軟體配置
- 路由註冊
- 生命週期事件處理
"""

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from config import settings

# 設定日誌
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ============================================================================
# 生命週期事件
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    """
    應用程式生命週期管理
    
    啟動時執行：
    - 資料庫連線初始化
    - 快取連線初始化
    - 其他資源初始化
    
    關閉時執行：
    - 資料庫連線關閉
    - 快取連線關閉
    - 清理資源
    """
    # 啟動時執行
    logger.info("=" * 60)
    logger.info("FastAPI 應用程式啟動中...")
    logger.info(f"環境: {settings.app_env}")
    logger.info(f"版本: {settings.app_version}")
    logger.info("=" * 60)
    
    # TODO: 初始化資料庫連線
    # await init_database()
    
    # TODO: 初始化 Redis 連線
    # await init_redis()
    
    logger.info("所有服務已啟動")
    
    yield
    
    # 關閉時執行
    logger.info("=" * 60)
    logger.info("FastAPI 應用程式關閉中...")
    
    # TODO: 關閉資料庫連線
    # await close_database()
    
    # TODO: 關閉 Redis 連線
    # await close_redis()
    
    logger.info("所有服務已關閉")
    logger.info("=" * 60)


# ============================================================================
# 應用程式初始化
# ============================================================================

app = FastAPI(
    title=settings.app_name,
    description="FastAPI 專案標準結構範例",
    version=settings.app_version,
    docs_url="/docs" if settings.app_env != "production" else None,
    redoc_url="/redoc" if settings.app_env != "production" else None,
    lifespan=lifespan
)


# ============================================================================
# 中介軟體配置
# ============================================================================

# CORS 中介軟體
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# GZip 壓縮中介軟體
app.add_middleware(GZipMiddleware, minimum_size=1000)

# TODO: 添加其他中介軟體
# from middleware.logging import LoggingMiddleware
# app.add_middleware(LoggingMiddleware)

# from middleware.auth import AuthMiddleware
# app.add_middleware(AuthMiddleware)


# ============================================================================
# 路由註冊
# ============================================================================

# 健康檢查端點
@app.get("/health", tags=["Health"])
async def health_check():
    """健康檢查端點"""
    return {
        "status": "healthy",
        "environment": settings.app_env,
        "version": settings.app_version
    }

# 根路徑
@app.get("/", tags=["Root"])
async def root():
    """根路徑"""
    return {
        "message": "歡迎使用 FastAPI 應用程式",
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health"
    }

# API 路由
from routes import sample
from routes import db_sqlalchemy, db_psycopg, db_ocp, db_langgraph

# 整合範例（精簡版：所有 DB 連線 + 完整 ORM 分層）
app.include_router(sample.router)

# 獨立 DB 範例（每種連線方式的完整 Route → Service → Database 範例）
app.include_router(db_sqlalchemy.router)
app.include_router(db_psycopg.router)
app.include_router(db_ocp.router)
app.include_router(db_langgraph.router)


# ============================================================================
# 全域異常處理
# ============================================================================

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """全域異常處理器"""
    logger.error(f"全域異常: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "伺服器發生錯誤，請稍後再試"
        }
    )


# ============================================================================
# 應用程式啟動
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.app_env == "development",
        log_level=settings.log_level.lower()
    )
