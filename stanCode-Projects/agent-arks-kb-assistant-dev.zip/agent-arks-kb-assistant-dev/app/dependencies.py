"""
全域依賴注入

提供可在整個應用程式中重用的依賴項，包括：
- 資料庫 Session 管理
- 服務層依賴注入
- 分頁參數
"""

from typing import Annotated

from fastapi import Depends, Query


# ============================================================================
# 資料庫依賴
# ============================================================================

async def get_db_session():
    """
    獲取資料庫 AsyncSession（異步）
    
    使用依賴注入提供資料庫 AsyncSession，用於異步資料庫操作
    所有服務層依賴都使用這個統一的 DB Session
    
    Yields:
        AsyncSession: 資料庫 AsyncSession
        
    Note:
        直接委託給 database.get_db()，避免重複實作
    """
    from database import get_db as database_get_db
    
    # 委託給 database 模組的 get_db 函數
    async for session in database_get_db():
        yield session


# ============================================================================
# 服務層依賴（簡化設計）
# 
# 設計原則：
# 1. dependencies.py 只提供「通用」的 get_db_session()
# 2. routes 中直接實例化需要的 Service，不需要為每個服務建立依賴函數
# 3. 所有服務共用同一個 DB Session
# 
# 使用方式：
#   @router.post("/users/")
#   async def create_user(
#       user_data: UserCreate,
#       db: AsyncSession = Depends(get_db_session)  # 直接注入 DB
#   ):
#       service = UserService(db)  # 在 route 中實例化
#       return await service.create_user(user_data)
# 
# 優點：
#   - 不需要為每個服務建立 get_xxx_service() 函數
#   - dependencies.py 保持簡潔，只管理基礎設施
#   - 新增服務時只需建立 service 類別，不需修改 dependencies.py
# ============================================================================


# ============================================================================
# 分頁依賴
# ============================================================================

class PaginationParams:
    """分頁參數"""
    
    def __init__(
        self,
        page: int = Query(1, ge=1, description="頁碼"),
        page_size: int = Query(10, ge=1, le=100, description="每頁數量")
    ):
        self.page = page
        self.page_size = page_size
        self.skip = (page - 1) * page_size
        self.limit = page_size


async def get_pagination(
    page: int = Query(1, ge=1, description="頁碼"),
    page_size: int = Query(10, ge=1, le=100, description="每頁數量")
) -> PaginationParams:
    """
    獲取分頁參數
    
    提供統一的分頁參數處理，支援頁碼和每頁數量驗證
    
    Args:
        page: 頁碼（從 1 開始）
        page_size: 每頁數量（1-100）
        
    Returns:
        PaginationParams: 分頁參數物件
        
    Example:
        ```python
        @app.get("/users")
        async def get_users(
            pagination: PaginationParams = Depends(get_pagination)
        ):
            users = await service.get_users(
                skip=pagination.skip,
                limit=pagination.limit
            )
            return users
        ```
    """
    return PaginationParams(page=page, page_size=page_size)


# ============================================================================
# 類型別名（使用 Annotated 提高可讀性）
# ============================================================================

# 分頁依賴
Pagination = Annotated[PaginationParams, Depends(get_pagination)]
