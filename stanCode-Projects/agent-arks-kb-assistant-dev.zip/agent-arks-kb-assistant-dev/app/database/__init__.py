"""
資料庫管理模組

支援多種資料庫連線方式：
- SQLAlchemy AsyncEngine (ORM)
- psycopg AsyncConnectionPool (原生 SQL)
"""

from .session import (
    # SQLAlchemy
    init_async_engine,
    get_async_engine,
    get_async_session,
    get_db,
    close_db_connections,
    
    # psycopg
    init_async_pool,
    get_async_pool,
    get_pool_connection,
    close_pool_connections,
    
    # 健康檢查
    check_db_health,
)

from .connection import (
    DatabaseConfig,
    ConnectionType,
    OCPConfig,
    get_ocp_config,
)

from schemas.ocp import (
    # OCP Schemas
    OCPQueryRequest,
    OCPQueryResponse,
    OCPSelectResult,
    OCPDMLResult,
)

from .ocp_client import (
    # OCP Client
    OCPClient,
    OCPError,
    
    # OCP 便捷函數
    execute_ocp_query,
    execute_ocp_select,
    execute_ocp_dml,
)

from .orm_operations import (
    # 創建操作
    create,
    create_many,
    
    # 讀取操作
    get,
    get_by,
    get_multi,
    
    # 更新操作
    update,
    update_many,
    
    # 刪除操作
    delete,
    delete_many,
    
    # 工具函數
    exists,
    count,
)

__all__ = [
    # SQLAlchemy
    "init_async_engine",
    "get_async_engine",
    "get_async_session",
    "get_db",
    "close_db_connections",
    
    # psycopg
    "init_async_pool",
    "get_async_pool",
    "get_pool_connection",
    "close_pool_connections",
    
    # 健康檢查
    "check_db_health",
    
    # 配置
    "DatabaseConfig",
    "ConnectionType",
    "OCPConfig",
    "get_ocp_config",
    
    # OCP Client
    "OCPClient",
    
    # OCP Schemas
    "OCPQueryRequest",
    "OCPQueryResponse",
    "OCPSelectResult",
    "OCPDMLResult",
    "OCPError",
    
    # OCP 便捷函數
    "execute_ocp_query",
    "execute_ocp_select",
    "execute_ocp_dml",
    
    # ORM 操作（通用 CRUD）
    "create",
    "create_many",
    "get",
    "get_by",
    "get_multi",
    "update",
    "update_many",
    "delete",
    "delete_many",
    "exists",
    "count",
]
