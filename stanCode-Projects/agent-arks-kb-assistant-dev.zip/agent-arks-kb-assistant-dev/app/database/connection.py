"""
資料庫連線配置和工具

所有參數統一由 config/settings.py 管理，
DatabaseConfig 和 OCPConfig 透過 from_settings() 取得設定值。
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class ConnectionType(str, Enum):
    """資料庫連線類型"""
    SQLALCHEMY = "sqlalchemy"  # SQLAlchemy AsyncEngine
    PSYCOPG = "psycopg"        # psycopg AsyncConnectionPool
    OCP = "ocp"                # OCP Tool API（HTTP-based PostgreSQL）


class DatabaseConfig(BaseModel):
    """
    資料庫配置

    所有參數由 config/settings.py 統一管理，
    使用 DatabaseConfig.from_settings() 建立實例。
    """

    # 基本連線資訊
    host: str
    port: int = 5432
    user: str
    password: str
    database: str

    # 連線池配置
    pool_min_size: int = Field(default=2, description="最小連線數")
    pool_max_size: int = Field(default=10, description="最大連線數")
    pool_pre_ping: bool = Field(default=True, description="連線前 ping 測試")
    pool_timeout: int = Field(default=30, description="取得連線的超時時間（秒）")
    pool_recycle: int = Field(default=3600, description="連線回收時間（秒）")
    pool_max_idle: int = Field(default=300, description="連線最大空閒時間（秒）")
    pool_max_lifetime: int = Field(default=3600, description="連線最大生命週期（秒）")

    # SSL 配置
    ssl_mode: str = Field(default="disable", description="SSL 模式")

    # Schema
    schema: Optional[str] = Field(default=None, description="資料庫 Schema")

    @classmethod
    def from_settings(cls) -> "DatabaseConfig":
        """從 config/settings 建立 DatabaseConfig 實例"""
        from config import settings
        return cls(
            host=settings.db_host,
            port=settings.db_port,
            user=settings.db_user,
            password=settings.db_password,
            database=settings.db_name,
            pool_min_size=settings.db_pool_min_size,
            pool_max_size=settings.db_pool_max_size,
            pool_pre_ping=settings.db_pool_pre_ping,
            pool_timeout=settings.db_pool_timeout,
            pool_recycle=settings.db_pool_recycle,
            pool_max_idle=settings.db_pool_max_idle,
            pool_max_lifetime=settings.db_pool_max_lifetime,
        )

    # SQLAlchemy 相容屬性
    @property
    def pool_size(self) -> int:
        """SQLAlchemy pool_size"""
        return self.pool_min_size

    @property
    def max_overflow(self) -> int:
        """SQLAlchemy max_overflow"""
        return self.pool_max_size - self.pool_min_size

    # psycopg 相容屬性
    @property
    def min_size(self) -> int:
        """psycopg min_size"""
        return self.pool_min_size

    @property
    def max_size(self) -> int:
        """psycopg max_size"""
        return self.pool_max_size

    @property
    def max_idle(self) -> int:
        """psycopg max_idle"""
        return self.pool_max_idle

    @property
    def max_lifetime(self) -> int:
        """psycopg max_lifetime"""
        return self.pool_max_lifetime

    def get_sqlalchemy_url(self, async_driver: bool = True) -> str:
        """
        獲取 SQLAlchemy 連線 URL

        Args:
            async_driver: 是否使用異步驅動（asyncpg）
        """
        driver = "postgresql+asyncpg" if async_driver else "postgresql+psycopg2"
        return f"{driver}://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"

    def get_psycopg_url(self) -> str:
        """獲取 psycopg 連線 URL"""
        url = f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
        if self.ssl_mode:
            url += f"?sslmode={self.ssl_mode}"
        return url

    def get_connection_info(self) -> dict:
        """獲取連線資訊字典"""
        return {
            "host": self.host,
            "port": self.port,
            "user": self.user,
            "password": self.password,
            "database": self.database,
        }


def get_database_config() -> DatabaseConfig:
    """獲取資料庫配置實例（從 settings 取值）"""
    return DatabaseConfig.from_settings()


class OCPConfig(BaseModel):
    """
    OCP Tool API 配置

    所有參數由 config/settings.py 統一管理，
    使用 OCPConfig.from_settings() 建立實例。
    """

    env: str = Field(default="sit", description="OCP 環境 (sit, uat, prod)")
    api_url: Optional[str] = Field(default=None, description="OCP Tool API 端點 URL")
    default_database: str = Field(default="datdatcm", description="預設資料庫名稱")
    timeout: int = Field(default=30, description="請求超時時間（秒）")
    verify_ssl: bool = Field(default=True, description="是否驗證 SSL 證書")
    max_retries: int = Field(default=3, description="最大重試次數")
    retry_delay: float = Field(default=1.0, description="重試延遲時間（秒）")

    @classmethod
    def from_settings(cls) -> "OCPConfig":
        """從 config/settings 建立 OCPConfig 實例"""
        from config import settings
        return cls(
            env=settings.ocp_env,
            api_url=settings.ocp_api_url or None,
            default_database=settings.ocp_default_database,
            timeout=settings.ocp_timeout,
            verify_ssl=settings.ocp_verify_ssl,
            max_retries=settings.ocp_max_retries,
            retry_delay=settings.ocp_retry_delay,
        )

    def __init__(self, **data):
        """初始化配置，若未提供 api_url 則根據 env 動態組合"""
        super().__init__(**data)
        if not self.api_url:
            self.api_url = self._build_api_url()

    def _build_api_url(self) -> str:
        """根據環境參數動態組合 OCP API URL"""
        env_lower = self.env.lower()
        url_template = "http://dat-cm-rs-ocp-tool.dat-py-dat-cm.apps.ocp{env}.intranet.tw/execute_query_postgresql"
        return url_template.format(env=env_lower)

    def get_request_payload(self, sql: str, database: Optional[str] = None) -> dict:
        """構建 OCP API 請求 payload"""
        return {
            "database": database or self.default_database,
            "sql": sql
        }


def get_ocp_config() -> OCPConfig:
    """獲取 OCP 配置實例（從 settings 取值）"""
    return OCPConfig.from_settings()
