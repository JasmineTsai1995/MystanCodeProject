"""
通用 ORM CRUD 操作模組

提供統一的資料庫操作介面，避免開發者直接撰寫 SQL 語法。
支援任何 SQLAlchemy ORM Model 的基礎 CRUD 操作。

主要功能：
- create：新增單筆資料
- create_many：批次新增
- get：依主鍵查詢單筆
- get_by：依條件查詢單筆
- get_multi：查詢多筆（支援過濾、排序、分頁）
- update：更新資料
- update_many：批次更新
- delete：刪除資料
- delete_many：批次刪除
- exists：檢查資料是否存在
- count：計算資料數量

使用範例：
    ```python
    from database.orm_operations import create, get, get_multi
    from models.user import User
    
    # 新增
    user = await create(db, User, username="john", email="john@example.com")
    
    # 查詢
    user = await get(db, User, id=1)
    
    # 查詢多筆
    users = await get_multi(
        db, User,
        filters={"is_active": True},
        order_by=["-created_at"],
        skip=0, limit=10
    )
    ```
"""

import logging
from typing import TypeVar, Type, Optional, List, Dict, Any, Union
from sqlalchemy import select, update as sa_update, delete as sa_delete, func, asc, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

logger = logging.getLogger(__name__)

# 泛型類型，代表任何 SQLAlchemy Model
ModelType = TypeVar("ModelType")


# ============================================================================
# 創建操作（Create）
# ============================================================================

async def create(
    db: AsyncSession,
    model: Type[ModelType],
    **kwargs
) -> ModelType:
    """
    新增單筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        **kwargs: 欄位名稱和值
        
    Returns:
        新建立的 Model 實例
        
    Example:
        ```python
        user = await create(
            db, User,
            username="john",
            email="john@example.com",
            is_active=True
        )
        ```
    """
    try:
        # 建立 Model 實例
        db_obj = model(**kwargs)
        
        # 新增到 Session
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        
        logger.info(f"Created {model.__name__}: {db_obj}")
        return db_obj
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error creating {model.__name__}: {e}")
        raise


async def create_many(
    db: AsyncSession,
    model: Type[ModelType],
    items: List[Dict[str, Any]]
) -> List[ModelType]:
    """
    批次新增多筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        items: 資料字典列表
        
    Returns:
        新建立的 Model 實例列表
        
    Example:
        ```python
        users = await create_many(db, User, [
            {"username": "john", "email": "john@example.com"},
            {"username": "jane", "email": "jane@example.com"},
        ])
        ```
    """
    try:
        # 建立 Model 實例列表
        db_objs = [model(**item) for item in items]
        
        # 批次新增
        db.add_all(db_objs)
        await db.commit()
        
        # 刷新所有實例
        for obj in db_objs:
            await db.refresh(obj)
        
        logger.info(f"Created {len(db_objs)} {model.__name__} records")
        return db_objs
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error batch creating {model.__name__}: {e}")
        raise


# ============================================================================
# 讀取操作（Read）
# ============================================================================

async def get(
    db: AsyncSession,
    model: Type[ModelType],
    id: Any,
    id_field: str = "id"
) -> Optional[ModelType]:
    """
    依主鍵查詢單筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        id: 主鍵值
        id_field: 主鍵欄位名稱（預設為 "id"）
        
    Returns:
        Model 實例或 None
        
    Example:
        ```python
        user = await get(db, User, id=1)
        user = await get(db, User, id="uuid-string", id_field="uuid")
        ```
    """
    try:
        stmt = select(model).where(getattr(model, id_field) == id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()
        
    except Exception as e:
        logger.error(f"Error getting {model.__name__} with {id_field}={id}: {e}")
        raise


async def get_by(
    db: AsyncSession,
    model: Type[ModelType],
    **filters
) -> Optional[ModelType]:
    """
    依條件查詢單筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        **filters: 過濾條件（欄位名稱和值）
        
    Returns:
        Model 實例或 None
        
    Example:
        ```python
        user = await get_by(db, User, username="john")
        user = await get_by(db, User, email="john@example.com", is_active=True)
        ```
    """
    try:
        stmt = select(model)
        
        # 加入過濾條件
        for field, value in filters.items():
            if hasattr(model, field):
                stmt = stmt.where(getattr(model, field) == value)
        
        result = await db.execute(stmt)
        return result.scalar_one_or_none()
        
    except Exception as e:
        logger.error(f"Error getting {model.__name__} by {filters}: {e}")
        raise


async def get_multi(
    db: AsyncSession,
    model: Type[ModelType],
    filters: Optional[Dict[str, Any]] = None,
    order_by: Optional[List[str]] = None,
    skip: int = 0,
    limit: int = 100,
    load_relationships: Optional[List[str]] = None
) -> List[ModelType]:
    """
    查詢多筆資料（支援過濾、排序、分頁）
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        filters: 過濾條件字典 {"欄位名": 值}
        order_by: 排序欄位列表，前綴 "-" 表示降序（例如：["-created_at", "id"]）
        skip: 跳過筆數（用於分頁）
        limit: 限制筆數（用於分頁）
        load_relationships: 需要預載的關聯欄位列表
        
    Returns:
        Model 實例列表
        
    Example:
        ```python
        # 基本查詢
        users = await get_multi(db, User, skip=0, limit=10)
        
        # 帶過濾條件
        users = await get_multi(
            db, User,
            filters={"is_active": True, "is_superuser": False}
        )
        
        # 帶排序（降序）
        users = await get_multi(
            db, User,
            order_by=["-created_at", "id"]
        )
        
        # 完整範例
        users = await get_multi(
            db, User,
            filters={"is_active": True},
            order_by=["-created_at"],
            skip=0,
            limit=10,
            load_relationships=["posts", "comments"]
        )
        ```
    """
    try:
        stmt = select(model)
        
        # 加入過濾條件
        if filters:
            for field, value in filters.items():
                if hasattr(model, field):
                    stmt = stmt.where(getattr(model, field) == value)
        
        # 加入排序
        if order_by:
            for field in order_by:
                # 檢查是否為降序（前綴 "-"）
                if field.startswith("-"):
                    field_name = field[1:]
                    if hasattr(model, field_name):
                        stmt = stmt.order_by(desc(getattr(model, field_name)))
                else:
                    if hasattr(model, field):
                        stmt = stmt.order_by(asc(getattr(model, field)))
        
        # 加入關聯預載（避免 N+1 問題）
        if load_relationships:
            for rel in load_relationships:
                if hasattr(model, rel):
                    stmt = stmt.options(selectinload(getattr(model, rel)))
        
        # 分頁
        stmt = stmt.offset(skip).limit(limit)
        
        result = await db.execute(stmt)
        return list(result.scalars().all())
        
    except Exception as e:
        logger.error(f"Error getting multi {model.__name__}: {e}")
        raise


# ============================================================================
# 更新操作（Update）
# ============================================================================

async def update(
    db: AsyncSession,
    model: Type[ModelType],
    id: Any,
    id_field: str = "id",
    **kwargs
) -> Optional[ModelType]:
    """
    更新單筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        id: 主鍵值
        id_field: 主鍵欄位名稱（預設為 "id"）
        **kwargs: 要更新的欄位名稱和值
        
    Returns:
        更新後的 Model 實例或 None（若資料不存在）
        
    Example:
        ```python
        user = await update(
            db, User, id=1,
            username="john_updated",
            email="john_new@example.com"
        )
        ```
    """
    try:
        # 查詢資料
        db_obj = await get(db, model, id, id_field)
        if not db_obj:
            logger.warning(f"{model.__name__} with {id_field}={id} not found")
            return None
        
        # 更新欄位
        for field, value in kwargs.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        await db.commit()
        await db.refresh(db_obj)
        
        logger.info(f"Updated {model.__name__} {id_field}={id}")
        return db_obj
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error updating {model.__name__} {id_field}={id}: {e}")
        raise


async def update_many(
    db: AsyncSession,
    model: Type[ModelType],
    filters: Dict[str, Any],
    **kwargs
) -> int:
    """
    批次更新多筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        filters: 過濾條件字典（決定要更新哪些資料）
        **kwargs: 要更新的欄位名稱和值
        
    Returns:
        受影響的資料筆數
        
    Example:
        ```python
        # 將所有未啟用的用戶設為啟用
        count = await update_many(
            db, User,
            filters={"is_active": False},
            is_active=True
        )
        ```
    """
    try:
        stmt = sa_update(model)
        
        # 加入過濾條件
        for field, value in filters.items():
            if hasattr(model, field):
                stmt = stmt.where(getattr(model, field) == value)
        
        # 設定更新值
        stmt = stmt.values(**kwargs)
        
        result = await db.execute(stmt)
        await db.commit()
        
        affected_rows = result.rowcount
        logger.info(f"Updated {affected_rows} {model.__name__} records")
        return affected_rows
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error batch updating {model.__name__}: {e}")
        raise


# ============================================================================
# 刪除操作（Delete）
# ============================================================================

async def delete(
    db: AsyncSession,
    model: Type[ModelType],
    id: Any,
    id_field: str = "id"
) -> bool:
    """
    刪除單筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        id: 主鍵值
        id_field: 主鍵欄位名稱（預設為 "id"）
        
    Returns:
        是否成功刪除（True/False）
        
    Example:
        ```python
        success = await delete(db, User, id=1)
        ```
    """
    try:
        # 查詢資料
        db_obj = await get(db, model, id, id_field)
        if not db_obj:
            logger.warning(f"{model.__name__} with {id_field}={id} not found")
            return False
        
        # 刪除
        await db.delete(db_obj)
        await db.commit()
        
        logger.info(f"Deleted {model.__name__} {id_field}={id}")
        return True
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error deleting {model.__name__} {id_field}={id}: {e}")
        raise


async def delete_many(
    db: AsyncSession,
    model: Type[ModelType],
    filters: Dict[str, Any]
) -> int:
    """
    批次刪除多筆資料
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        filters: 過濾條件字典（決定要刪除哪些資料）
        
    Returns:
        刪除的資料筆數
        
    Example:
        ```python
        # 刪除所有未啟用的用戶
        count = await delete_many(
            db, User,
            filters={"is_active": False}
        )
        ```
    """
    try:
        stmt = sa_delete(model)
        
        # 加入過濾條件
        for field, value in filters.items():
            if hasattr(model, field):
                stmt = stmt.where(getattr(model, field) == value)
        
        result = await db.execute(stmt)
        await db.commit()
        
        affected_rows = result.rowcount
        logger.info(f"Deleted {affected_rows} {model.__name__} records")
        return affected_rows
        
    except Exception as e:
        await db.rollback()
        logger.error(f"Error batch deleting {model.__name__}: {e}")
        raise


# ============================================================================
# 工具函數
# ============================================================================

async def exists(
    db: AsyncSession,
    model: Type[ModelType],
    **filters
) -> bool:
    """
    檢查資料是否存在
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        **filters: 過濾條件（欄位名稱和值）
        
    Returns:
        是否存在（True/False）
        
    Example:
        ```python
        exists = await exists(db, User, username="john")
        exists = await exists(db, User, email="john@example.com", is_active=True)
        ```
    """
    try:
        stmt = select(model)
        
        # 加入過濾條件
        for field, value in filters.items():
            if hasattr(model, field):
                stmt = stmt.where(getattr(model, field) == value)
        
        stmt = stmt.limit(1)
        result = await db.execute(stmt)
        return result.scalar_one_or_none() is not None
        
    except Exception as e:
        logger.error(f"Error checking existence of {model.__name__}: {e}")
        raise


async def count(
    db: AsyncSession,
    model: Type[ModelType],
    filters: Optional[Dict[str, Any]] = None
) -> int:
    """
    計算資料數量
    
    Args:
        db: 資料庫 Session
        model: SQLAlchemy Model 類別
        filters: 過濾條件字典（可選）
        
    Returns:
        資料筆數
        
    Example:
        ```python
        # 計算所有用戶
        total = await count(db, User)
        
        # 計算啟用的用戶
        active_users = await count(db, User, filters={"is_active": True})
        ```
    """
    try:
        stmt = select(func.count()).select_from(model)
        
        # 加入過濾條件
        if filters:
            for field, value in filters.items():
                if hasattr(model, field):
                    stmt = stmt.where(getattr(model, field) == value)
        
        result = await db.execute(stmt)
        return result.scalar_one()
        
    except Exception as e:
        logger.error(f"Error counting {model.__name__}: {e}")
        raise
