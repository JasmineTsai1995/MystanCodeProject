"""
資料庫 Session 管理

支援兩種連線方式：
1. SQLAlchemy AsyncEngine - 適合 ORM 操作
2. psycopg AsyncConnectionPool - 適合原生 SQL 和 LangGraph
"""

import logging
from typing import AsyncGenerator, Optional
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    create_async_engine,
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
)
from sqlalchemy import text

try:
    from psycopg_pool import AsyncConnectionPool
    PSYCOPG_AVAILABLE = True
except ImportError:
    PSYCOPG_AVAILABLE = False
    AsyncConnectionPool = None

from .connection import DatabaseConfig

logger = logging.getLogger(__name__)

# ============================================================================
# 全域變數
# ============================================================================

_async_engine: Optional[AsyncEngine] = None
_async_session_maker: Optional[async_sessionmaker] = None
_async_pool: Optional[AsyncConnectionPool] = None
_db_config: Optional[DatabaseConfig] = None


# ============================================================================
# SQLAlchemy AsyncEngine 方式
# ============================================================================

async def init_async_engine(config: Optional[DatabaseConfig] = None) -> AsyncEngine:
    """
    初始化 SQLAlchemy AsyncEngine
    
    Args:
        config: 資料庫配置，若為 None 則從環境變數讀取
        
    Returns:
        AsyncEngine 實例
    """
    global _async_engine, _async_session_maker, _db_config
    
    if _async_engine is not None:
        logger.info("AsyncEngine already initialized")
        return _async_engine
    
    # 獲取配置
    if config is None:
        config = DatabaseConfig.from_settings()
    _db_config = config
    
    # 建立 Engine
    db_url = config.get_sqlalchemy_url(async_driver=True)
    
    logger.info(f"Initializing AsyncEngine: {config.host}:{config.port}/{config.database}")
    
    _async_engine = create_async_engine(
        db_url,
        pool_size=config.pool_size,
        max_overflow=config.max_overflow,
        pool_pre_ping=config.pool_pre_ping,
        pool_recycle=config.pool_recycle,
        pool_timeout=config.pool_timeout,
        echo=False,  # 生產環境設為 False
    )
    
    # 建立 Session Maker
    _async_session_maker = async_sessionmaker(
        _async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    
    logger.info("AsyncEngine initialized successfully")
    return _async_engine


def get_async_engine() -> AsyncEngine:
    """
    獲取 AsyncEngine 實例
    
    Returns:
        AsyncEngine 實例
        
    Raises:
        RuntimeError: 如果 Engine 尚未初始化
    """
    if _async_engine is None:
        raise RuntimeError(
            "AsyncEngine not initialized. "
            "Please call init_async_engine() first or use it in FastAPI lifespan."
        )
    return _async_engine


async def get_async_session() -> AsyncSession:
    """
    獲取 AsyncSession 實例（用於手動管理）
    
    Returns:
        AsyncSession 實例
    """
    if _async_session_maker is None:
        await init_async_engine()
    
    return _async_session_maker()


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    獲取資料庫 Session（用於 FastAPI 依賴注入）
    
    Yields:
        AsyncSession 實例
        
    Example:
        ```python
        from fastapi import Depends
        from sqlalchemy.ext.asyncio import AsyncSession
        from database import get_db
        
        @app.get("/users")
        async def get_users(db: AsyncSession = Depends(get_db)):
            result = await db.execute(select(User))
            return result.scalars().all()
        ```
    """
    if _async_session_maker is None:
        await init_async_engine()
    
    async with _async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def close_db_connections():
    """關閉所有 SQLAlchemy 資料庫連線"""
    global _async_engine, _async_session_maker
    
    if _async_engine is not None:
        logger.info("Closing AsyncEngine connections...")
        await _async_engine.dispose()
        _async_engine = None
        _async_session_maker = None
        logger.info("AsyncEngine connections closed")


# ============================================================================
# psycopg AsyncConnectionPool 方式
# ============================================================================

async def init_async_pool(
    config: Optional[DatabaseConfig] = None,
    configure_callback: Optional[callable] = None,
) -> AsyncConnectionPool:
    """
    初始化 psycopg AsyncConnectionPool
    
    Args:
        config: 資料庫配置，若為 None 則從環境變數讀取
        configure_callback: 連線配置回調函數（如設定 schema）
        
    Returns:
        AsyncConnectionPool 實例
        
    Raises:
        ImportError: 如果 psycopg 未安裝
        
    Example:
        ```python
        async def set_schema(conn):
            await conn.execute("SET search_path TO my_schema")
        
        pool = await init_async_pool(configure_callback=set_schema)
        ```
    """
    global _async_pool, _db_config
    
    if not PSYCOPG_AVAILABLE:
        raise ImportError(
            "psycopg and psycopg_pool are required for AsyncConnectionPool. "
            "Install with: pip install psycopg[binary] psycopg_pool"
        )
    
    if _async_pool is not None:
        logger.info("AsyncConnectionPool already initialized")
        return _async_pool
    
    # 獲取配置
    if config is None:
        config = DatabaseConfig.from_settings()
    _db_config = config
    
    # 建立連線池
    db_url = config.get_psycopg_url()
    
    logger.info(f"Initializing AsyncConnectionPool: {config.host}:{config.port}/{config.database}")
    
    _async_pool = AsyncConnectionPool(
        conninfo=db_url,
        min_size=config.min_size,
        max_size=config.max_size,
        max_idle=config.max_idle,
        max_lifetime=config.max_lifetime,
        configure=configure_callback,
        kwargs={
            "autocommit": True,
            "prepare_threshold": 0,
        },
    )
    
    # 測試連線
    try:
        async with _async_pool.connection() as conn:
            await conn.execute("SELECT 1")
        logger.info("AsyncConnectionPool initialized and tested successfully")
    except Exception as e:
        logger.error(f"AsyncConnectionPool test failed: {e}")
        _async_pool = None
        raise
    
    return _async_pool


def get_async_pool() -> AsyncConnectionPool:
    """
    獲取 AsyncConnectionPool 實例
    
    Returns:
        AsyncConnectionPool 實例
        
    Raises:
        RuntimeError: 如果連線池尚未初始化
    """
    if _async_pool is None:
        raise RuntimeError(
            "AsyncConnectionPool not initialized. "
            "Please call init_async_pool() first or use it in FastAPI lifespan."
        )
    return _async_pool


@asynccontextmanager
async def get_pool_connection():
    """
    獲取連線池的連線（用於上下文管理）
    
    Yields:
        psycopg AsyncConnection 實例
        
    Example:
        ```python
        async with get_pool_connection() as conn:
            result = await conn.execute("SELECT * FROM users")
            rows = await result.fetchall()
        ```
    """
    if _async_pool is None:
        await init_async_pool()
    
    async with _async_pool.connection() as conn:
        yield conn


async def close_pool_connections():
    """關閉 psycopg AsyncConnectionPool"""
    global _async_pool
    
    if _async_pool is not None:
        logger.info("Closing AsyncConnectionPool...")
        await _async_pool.close()
        _async_pool = None
        logger.info("AsyncConnectionPool closed")


# ============================================================================
# 健康檢查
# ============================================================================

async def check_db_health(connection_type: str = "sqlalchemy") -> dict:
    """
    檢查資料庫連線健康狀態
    
    Args:
        connection_type: 連線類型 ("sqlalchemy" 或 "psycopg")
        
    Returns:
        健康狀態資訊
        
    Example:
        ```python
        health = await check_db_health("sqlalchemy")
        # {"status": "healthy", "connection_type": "sqlalchemy", "database": "fastapi_db"}
        ```
    """
    try:
        if connection_type == "sqlalchemy":
            engine = get_async_engine()
            async with engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            
            return {
                "status": "healthy",
                "connection_type": "sqlalchemy",
                "database": _db_config.database if _db_config else "unknown",
                "host": _db_config.host if _db_config else "unknown",
            }
        
        elif connection_type == "psycopg":
            if not PSYCOPG_AVAILABLE:
                return {
                    "status": "unavailable",
                    "connection_type": "psycopg",
                    "error": "psycopg not installed",
                }
            
            pool = get_async_pool()
            async with pool.connection() as conn:
                await conn.execute("SELECT 1")
            
            return {
                "status": "healthy",
                "connection_type": "psycopg",
                "database": _db_config.database if _db_config else "unknown",
                "host": _db_config.host if _db_config else "unknown",
                "pool_size": pool.get_stats().get("pool_size", 0),
            }
        
        else:
            return {
                "status": "error",
                "error": f"Unknown connection type: {connection_type}",
            }
    
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return {
            "status": "unhealthy",
            "connection_type": connection_type,
            "error": str(e),
        }


# ============================================================================
# 工具函數
# ============================================================================

async def execute_raw_sql(
    sql: str,
    params: Optional[dict] = None,
    connection_type: str = "sqlalchemy",
):
    """
    執行原生 SQL 查詢
    
    Args:
        sql: SQL 語句
        params: 查詢參數
        connection_type: 連線類型
        
    Returns:
        查詢結果
        
    Example:
        ```python
        # SQLAlchemy 方式
        result = await execute_raw_sql(
            "SELECT * FROM users WHERE id = :id",
            params={"id": 1},
            connection_type="sqlalchemy"
        )
        
        # psycopg 方式
        result = await execute_raw_sql(
            "SELECT * FROM users WHERE id = %(id)s",
            params={"id": 1},
            connection_type="psycopg"
        )
        ```
    """
    if connection_type == "sqlalchemy":
        engine = get_async_engine()
        async with engine.connect() as conn:
            result = await conn.execute(text(sql), params or {})
            return result.fetchall()
    
    elif connection_type == "psycopg":
        async with get_pool_connection() as conn:
            cursor = await conn.execute(sql, params or {})
            return await cursor.fetchall()
    
    else:
        raise ValueError(f"Unknown connection type: {connection_type}")
