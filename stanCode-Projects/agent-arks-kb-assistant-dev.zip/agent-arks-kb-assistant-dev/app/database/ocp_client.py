"""
OCP Tool API 客戶端

提供統一的 OCP Tool API 資料庫操作介面，支援：
- SELECT 查詢（返回資料和欄位）
- DML 操作（INSERT, UPDATE, DELETE - 返回影響筆數）
- 完整的錯誤處理和日誌記錄
- 自動重試機制
"""

import logging
import time
from typing import Optional, Dict, Any, List, Union

from utils.request import make_request, HTTPError
from .connection import OCPConfig, get_ocp_config
from schemas.ocp import (
    OCPQueryRequest,
    OCPMWHeader,
    OCPTransactionResult,
    OCPQueryResponse,
    OCPSelectResult,
    OCPDMLResult,
)

logger = logging.getLogger(__name__)


class OCPError(Exception):
    """OCP API 錯誤"""
    def __init__(
        self,
        message: str,
        return_code: Optional[str] = None,
        return_desc: Optional[str] = None,
        original_error: Optional[Exception] = None
    ):
        super().__init__(message)
        self.return_code = return_code
        self.return_desc = return_desc
        self.original_error = original_error


# ============================================================================
# OCP Client
# ============================================================================

class OCPClient:
    """
    OCP Tool API 客戶端
    
    提供與 OCP Tool API 互動的統一介面，支援各種資料庫操作。
    
    Attributes:
        config: OCP 配置實例
    
    Examples:
        >>> client = OCPClient()
        >>> 
        >>> # SELECT 查詢
        >>> result = client.execute_select("SELECT * FROM users LIMIT 10")
        >>> print(f"查詢到 {result.row_count} 筆資料")
        >>> print(result.columns)
        >>> print(result.data)
        >>> 
        >>> # INSERT 操作
        >>> result = client.execute_dml(
        ...     "INSERT INTO users(name, email) VALUES ('John', 'john@example.com')"
        ... )
        >>> print(f"插入 {result.affected_rows} 筆資料")
    """
    
    def __init__(self, config: Optional[OCPConfig] = None):
        """
        初始化 OCP 客戶端
        
        Args:
            config: OCP 配置，若為 None 則從環境變數讀取
        """
        self.config = config or get_ocp_config()
        logger.info(f"OCPClient 初始化完成，API URL: {self.config.api_url}")
    
    def _make_request(
        self,
        sql: str,
        database: Optional[str] = None,
        retry_count: int = 0
    ) -> OCPQueryResponse:
        """
        發送 OCP API 請求（內部方法）
        
        Args:
            sql: SQL 查詢語句
            database: 資料庫名稱
            retry_count: 當前重試次數
            
        Returns:
            OCP 查詢回應
            
        Raises:
            OCPError: 當請求失敗或回應異常
        """
        payload = self.config.get_request_payload(sql, database)
        
        try:
            logger.info(f"發送 OCP 請求: {payload['database']}")
            logger.debug(f"SQL: {sql[:100]}...")  # 只記錄前 100 字元
            
            response_data = make_request(
                url=self.config.api_url,
                method="POST",
                json_data=payload,
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
                output_schema=OCPQueryResponse,
                log_request=False,  # 已在上面記錄
                log_response=False  # 避免重複記錄
            )
            
            # 檢查 API 狀態
            if response_data.MWHEADER.RETURNCODE != "0000":
                raise OCPError(
                    message=f"OCP API 返回錯誤: {response_data.MWHEADER.RETURNDESC}",
                    return_code=response_data.MWHEADER.RETURNCODE,
                    return_desc=response_data.MWHEADER.RETURNDESC
                )
            
            logger.info(f"OCP 請求成功，執行時間: {response_data.TRANRS.query_time:.3f}秒")
            return response_data
            
        except HTTPError as e:
            error_msg = f"OCP API HTTP 錯誤: {str(e)}"
            logger.error(error_msg)
            
            # 重試邏輯
            if retry_count < self.config.max_retries:
                logger.warning(f"準備重試 ({retry_count + 1}/{self.config.max_retries})...")
                time.sleep(self.config.retry_delay)
                return self._make_request(sql, database, retry_count + 1)
            
            raise OCPError(error_msg, original_error=e)
            
        except Exception as e:
            error_msg = f"OCP API 請求失敗: {str(e)}"
            logger.error(error_msg)
            raise OCPError(error_msg, original_error=e)
    
    def execute_select(
        self,
        sql: str,
        database: Optional[str] = None
    ) -> OCPSelectResult:
        """
        執行 SELECT 查詢
        
        Args:
            sql: SELECT SQL 語句
            database: 資料庫名稱，若為 None 則使用預設值
            
        Returns:
            SELECT 查詢結果（包含 data 和 columns）
            
        Raises:
            OCPError: 當查詢失敗
            
        Examples:
            >>> client = OCPClient()
            >>> result = client.execute_select(
            ...     "SELECT id, name FROM users WHERE id < 100"
            ... )
            >>> print(result.columns)  # ['id', 'name']
            >>> print(result.data)     # [[1, 'Alice'], [2, 'Bob'], ...]
            >>> print(result.row_count)  # 2
            >>> 
            >>> # 轉換為字典列表
            >>> dict_list = result.to_dict_list()
            >>> print(dict_list)  # [{'id': 1, 'name': 'Alice'}, ...]
        """
        response = self._make_request(sql, database)
        
        # 解析 SELECT 結果
        result_data = response.TRANRS.result
        
        if len(result_data) != 2:
            raise OCPError(
                f"SELECT 結果格式異常，期望 2 個元素（data, columns），實際 {len(result_data)} 個"
            )
        
        data = result_data[0]  # [[row1], [row2], ...]
        columns = result_data[1]  # ['col1', 'col2', ...]
        
        return OCPSelectResult(
            success=True,
            query_time=response.TRANRS.query_time,
            data=data,
            columns=columns,
            row_count=len(data)
        )
    
    def execute_dml(
        self,
        sql: str,
        database: Optional[str] = None
    ) -> OCPDMLResult:
        """
        執行 DML 操作（INSERT, UPDATE, DELETE）
        
        Args:
            sql: DML SQL 語句
            database: 資料庫名稱，若為 None 則使用預設值
            
        Returns:
            DML 操作結果（包含 affected_rows）
            
        Raises:
            OCPError: 當操作失敗
            
        Examples:
            >>> client = OCPClient()
            >>> 
            >>> # INSERT
            >>> result = client.execute_dml(
            ...     "INSERT INTO users(name) VALUES ('Alice')"
            ... )
            >>> print(f"插入 {result.affected_rows} 筆")
            >>> 
            >>> # UPDATE
            >>> result = client.execute_dml(
            ...     "UPDATE users SET name='Bob' WHERE id=1"
            ... )
            >>> print(f"更新 {result.affected_rows} 筆")
            >>> 
            >>> # DELETE
            >>> result = client.execute_dml(
            ...     "DELETE FROM users WHERE id=1"
            ... )
            >>> print(f"刪除 {result.affected_rows} 筆")
        """
        response = self._make_request(sql, database)
        
        # 解析 DML 結果
        result_data = response.TRANRS.result
        
        if len(result_data) != 1 or not isinstance(result_data[0], int):
            raise OCPError(
                f"DML 結果格式異常，期望 [affected_rows]，實際 {result_data}"
            )
        
        affected_rows = result_data[0]
        
        return OCPDMLResult(
            success=True,
            query_time=response.TRANRS.query_time,
            affected_rows=affected_rows
        )
    
    def execute_query(
        self,
        sql: str,
        database: Optional[str] = None,
        auto_detect: bool = True
    ) -> Union[OCPSelectResult, OCPDMLResult]:
        """
        自動判斷並執行查詢（SELECT 或 DML）
        
        Args:
            sql: SQL 語句
            database: 資料庫名稱
            auto_detect: 是否自動判斷查詢類型（預設 True）
            
        Returns:
            查詢結果（SELECT 或 DML）
            
        Examples:
            >>> client = OCPClient()
            >>> 
            >>> # 自動判斷為 SELECT
            >>> result = client.execute_query("SELECT * FROM users")
            >>> if isinstance(result, OCPSelectResult):
            ...     print(result.columns)
            >>> 
            >>> # 自動判斷為 INSERT
            >>> result = client.execute_query(
            ...     "INSERT INTO users(name) VALUES ('Alice')"
            ... )
            >>> if isinstance(result, OCPDMLResult):
            ...     print(f"影響 {result.affected_rows} 筆")
        """
        if auto_detect:
            # 簡單的 SQL 類型判斷
            sql_upper = sql.strip().upper()
            if sql_upper.startswith("SELECT"):
                return self.execute_select(sql, database)
            else:
                return self.execute_dml(sql, database)
        else:
            # 嘗試 SELECT，失敗則嘗試 DML
            try:
                return self.execute_select(sql, database)
            except OCPError:
                return self.execute_dml(sql, database)
    
    def test_connection(self, database: Optional[str] = None) -> bool:
        """
        測試 OCP API 連線
        
        Args:
            database: 資料庫名稱
            
        Returns:
            連線是否成功
            
        Examples:
            >>> client = OCPClient()
            >>> if client.test_connection():
            ...     print("連線成功")
        """
        try:
            result = self.execute_select("SELECT 1 AS test", database)
            return result.success
        except OCPError as e:
            logger.error(f"連線測試失敗: {e}")
            return False


# ============================================================================
# 便捷函數
# ============================================================================

def execute_ocp_query(
    sql: str,
    database: Optional[str] = None,
    config: Optional[OCPConfig] = None
) -> Union[OCPSelectResult, OCPDMLResult]:
    """
    執行 OCP 查詢的便捷函數
    
    Args:
        sql: SQL 語句
        database: 資料庫名稱
        config: OCP 配置
        
    Returns:
        查詢結果
        
    Examples:
        >>> # 簡單使用
        >>> result = execute_ocp_query("SELECT * FROM users LIMIT 10")
        >>> 
        >>> # 指定資料庫
        >>> result = execute_ocp_query(
        ...     "SELECT * FROM products",
        ...     database="datdatcm"
        ... )
    """
    client = OCPClient(config)
    return client.execute_query(sql, database)


def execute_ocp_select(
    sql: str,
    database: Optional[str] = None,
    config: Optional[OCPConfig] = None
) -> OCPSelectResult:
    """
    執行 OCP SELECT 查詢的便捷函數
    
    Args:
        sql: SELECT SQL 語句
        database: 資料庫名稱
        config: OCP 配置
        
    Returns:
        SELECT 查詢結果
    """
    client = OCPClient(config)
    return client.execute_select(sql, database)


def execute_ocp_dml(
    sql: str,
    database: Optional[str] = None,
    config: Optional[OCPConfig] = None
) -> OCPDMLResult:
    """
    執行 OCP DML 操作的便捷函數
    
    Args:
        sql: DML SQL 語句
        database: 資料庫名稱
        config: OCP 配置
        
    Returns:
        DML 操作結果
    """
    client = OCPClient(config)
    return client.execute_dml(sql, database)
