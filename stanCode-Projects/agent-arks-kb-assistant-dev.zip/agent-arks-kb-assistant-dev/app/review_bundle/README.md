# Arks Review Endpoint Bundle

This bundle deploys only the Model Serving review path. It does not deploy or
run the existing `arks-agent` Databricks App.

## Managed Resources

- MLflow experiment: `arks-agent-review-experiment`
- MLflow trace table prefix: `dev_gaia_experiments.arks.arks_review`
- Job: `arks_deploy_review_endpoint`
- Job: `arks_setup_review_lakebase`
- Job: `arks_finalize_review_endpoint`
- Job: `arks_verify_review_endpoint`

The deploy job packages the source under `../app` as an MLflow
`ResponsesAgent`, resolves the current MLflow `@production` runtime prompts
into an immutable snapshot bundled with the model, registers it in Unity
Catalog, deploys or updates the `arks-agent-review` endpoint, and connects
that endpoint to the MLflow Review App Chat UI.

## Prerequisites

The deploying identity must be able to:

- create/edit the configured MLflow experiment and registered model
- create/write trace tables under `dev_gaia_experiments.arks.arks_review*`
- read the `dev_gaia_experiments.arks.*@production` prompts during the deploy job
- query `databricks-gpt-5-4`
- use the `mcp-cm-kb-mongodb` Databricks App
- access the `arks-lakebase-v2` Lakebase Autoscaling project with the
  permissions required by automatic authentication passthrough
- create or update Model Serving endpoints

## Deploy

This deployment registers a new `dev_gaia_experiments.arks.arks_agent_review` model
version and updates the existing `arks-agent-review` endpoint. The MLflow
Review App URL does not change. Review traces are bound to the UC table prefix
`dev_gaia_experiments.arks.arks_review`.

From this directory:

```powershell
cd app/review_bundle

databricks auth login --host https://dbc-3e71f336-822f.cloud.databricks.com --profile ut
databricks bundle validate -t review
databricks bundle deploy -t review

$releaseId = "arks-review-$(git rev-parse --short HEAD)-$(Get-Date -Format 'yyyyMMddHHmmss')"
$gitSha = git rev-parse HEAD

databricks bundle run arks_deploy_review_endpoint -t review --params "review_deployment_id=$releaseId,git_commit=$gitSha"
```

To grant Chat UI access in the same deployment run, add an actual Databricks
account user email or group name:

```powershell
databricks bundle run arks_deploy_review_endpoint -t review --params "review_deployment_id=$releaseId,git_commit=$gitSha,reviewers=<BU_ACCOUNT_EMAIL_OR_GROUP>"
```

The job output prints the Model Serving query endpoint and the Review App Chat
UI URL.

Each successful deploy registers a new UC model version and updates the same
endpoint. If a production prompt alias changes, rerun this deploy job to
capture a new immutable snapshot; do not create a new Review App endpoint.

### Lakebase Resource

The review endpoint must use the same Lakebase Autoscaling project as the
`arks-agent` Databricks App:

- Project ID: `arks-lakebase-v2`
- Branch: `production`
- Runtime env: `DATABRICKS_LAKEBASE_NAME=arks-lakebase-v2`
- Runtime env: `DATABRICKS_LAKEBASE_BRANCH=production`
- MLflow model resources intentionally do **not** include
  `DatabricksLakebase(...)` for this Autoscaling project. The runtime connects
  through `CheckpointSaver(project="arks-lakebase-v2", branch="production")`.

If the endpoint still has old served entities with
`DATABRICKS_LAKEBASE_NAME=arks-lakebase`, the endpoint update can fail before
runtime starts because the old Lakebase instance no longer exists. Deploy a new
review model version with the defaults in `review_bundle/databricks.yml`, then
remove stale served entities from the endpoint config if Databricks keeps them
in `pending_config`.

### Lakebase Grants For Serving

The review endpoint also needs a PostgreSQL OAuth role for the actual Model
Serving served entity identity. If inference fails with:

```text
psycopg_pool.PoolTimeout: couldn't get a connection after 30.00 sec
ERROR: password authentication failed for user '<uuid>'
```

read the served entity logs and grant the reported `<uuid>`:

```powershell
databricks serving-endpoints logs arks-agent-review <served_entity_name> --profile ut --output text

databricks bundle run arks_setup_review_lakebase -t review --params serving_sp_client_id=<uuid_from_logs>
```

For the latest observed v13 runtime, the required identity was:

```powershell
databricks bundle run arks_setup_review_lakebase -t review --params serving_sp_client_id=aee44c5b-6320-4f83-bd50-bc0983ae0772
```

Model Serving may rotate this identity after a new served entity deployment or
runtime restart. Prefer the `<uuid_from_logs>` workflow above when the error
reappears.

This job creates the Lakebase PostgreSQL role, grants schema/table/sequence
permissions, and preserves existing LangGraph checkpoint tables. It should not
be replaced with the main `arks-agent` Lakebase setup job because that job may
drop checkpoint tables during initial App setup.

### Get Review App URL

The Review App is an **MLflow Review App**, not a Databricks App. It will not
appear in the Databricks Apps UI. To get the URL, run the following in a
Databricks notebook:

```python
from mlflow.genai.labeling import get_review_app

review_app = get_review_app("<experiment_id>")
print(review_app.url)
```

Replace `<experiment_id>` with the MLflow experiment ID (visible in the
experiment URL). The chat UI is at `{review_app.url}/chat`.

If an earlier deploy run already created the endpoint but failed while it was
still starting, do not deploy a new model version. Finalize that endpoint
after it becomes ready:

```powershell
$reviewDeploymentId = "arks-review-$(git rev-parse --short HEAD)"
databricks bundle run arks_finalize_review_endpoint -t review --params "review_deployment_id=$reviewDeploymentId"
```

The smoke test queries a `ResponsesAgent` endpoint through the official
OpenAI-compatible Responses API. It does not use the custom pyfunc
`serving_endpoints.query(inputs=...)` request envelope. It also rejects a
release unless the new trace reports `arks.prompt.source=mlflow_snapshot` with
the resolved prompt version and digest. Trace lookup searches
`dev_gaia_experiments.arks.arks_review`, not only the MLflow experiment ID.

The deployment job runs a smoke request by default. To run verification again:

```powershell
$reviewDeploymentId = "arks-review-$(git rev-parse --short HEAD)"
databricks bundle run arks_verify_review_endpoint -t review --params "review_deployment_id=$reviewDeploymentId"
```

## Override Environment Values

The defaults match the existing App configuration. The review endpoint uses
`LLM_PROVIDER=litellm` by default and injects `LITELLM_API_KEY` from
`{{secrets/arks/litellm-api-key}}`.

Create or update the secret before deploying:

```powershell
databricks secrets create-scope arks
databricks secrets put-secret arks litellm-api-key
```

Override values at deploy time only when the corresponding existing App
dependency has changed:

```powershell
databricks bundle deploy -t review --var "litellm_endpoint=<url>,litellm_model=<model>,mcp_app_url=<url>,lakebase_name=<project>,lakebase_branch=<branch>"
```
UT