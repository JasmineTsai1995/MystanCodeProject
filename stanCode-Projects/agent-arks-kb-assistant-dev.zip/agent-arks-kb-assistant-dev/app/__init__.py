"""
FastAPI 應用程式主模組
"""

__version__ = "1.0.0"
