import json
import logging
import os
from typing import AsyncIterator

import httpx
from databricks.sdk.core import Config
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse


logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("agent_proxy")


def _parse_csv(value: str) -> list[str]:
    if value.strip() == "*":
        return ["*"]
    return [item.strip() for item in value.split(",") if item.strip()]


APP_NAME = os.getenv("APP_NAME", "arks-agent-proxy")
APP_VERSION = os.getenv("APP_VERSION", "0.1.0")
ALLOWED_ORIGINS = _parse_csv(os.getenv("ALLOWED_ORIGINS", "http://localhost:4200"))
ALLOWED_METHODS = _parse_csv(os.getenv("ALLOWED_METHODS", "POST,OPTIONS"))
ALLOWED_HEADERS = _parse_csv(
    os.getenv(
        "ALLOWED_HEADERS",
        "Authorization,Content-Type,X-Requested-With,X-Request-Id",
    )
)
EXPOSE_HEADERS = _parse_csv(
    os.getenv(
        "EXPOSE_HEADERS",
        "X-App-Name,X-Proxy-Version,X-Request-Id",
    )
)


app = FastAPI(title=APP_NAME, version=APP_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=ALLOWED_METHODS,
    allow_headers=ALLOWED_HEADERS,
    expose_headers=EXPOSE_HEADERS,
)


def _get_sdk_config() -> Config:
    return Config()


def _get_endpoint_name() -> str:
    endpoint = os.getenv("SERVING_ENDPOINT_NAME", "").strip()
    if not endpoint:
        raise RuntimeError(
            "SERVING_ENDPOINT_NAME is not set. Add a serving-endpoint resource in app settings."
        )
    return endpoint


def _get_invocations_url() -> str:
    cfg = _get_sdk_config()
    endpoint = _get_endpoint_name()
    host = (cfg.host or "").rstrip("/")
    if not host:
        raise RuntimeError("Databricks host is not available from app authentication config.")
    if not host.startswith(("http://", "https://")):
        host = f"https://{host}"
    return f"{host}/serving-endpoints/{endpoint}/invocations"


def _json_sse(event: str, payload: dict) -> bytes:
    body = json.dumps(payload, ensure_ascii=False)
    return f"event: {event}\ndata: {body}\n\n".encode("utf-8")


@app.get("/health", tags=["health"])
async def health() -> dict:
    return {
        "status": "ok",
        "app": APP_NAME,
        "version": APP_VERSION,
        "serving_endpoint": os.getenv("SERVING_ENDPOINT_NAME", ""),
    }


@app.get("/", tags=["root"])
async def root() -> dict:
    return {
        "message": "Databricks App proxy for arks-agent SSE streaming",
        "health": "/health",
        "stream_route": "/api/agent/stream",
    }


@app.post("/api/agent/stream", tags=["agent"])
async def proxy_agent_stream(request: Request) -> StreamingResponse:
    request_payload = await request.json()
    request_id = request.headers.get("x-request-id", "")

    cfg = _get_sdk_config()
    url = _get_invocations_url()
    auth_headers = cfg.authenticate()

    upstream_headers = {
        **auth_headers,
        "Accept": "text/event-stream",
        "Content-Type": "application/json",
    }
    if request_id:
        upstream_headers["X-Request-Id"] = request_id

    async def event_generator() -> AsyncIterator[bytes]:
        logger.info("Proxying SSE request to %s", url)
        timeout = httpx.Timeout(connect=30.0, read=None, write=30.0, pool=None)

        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream(
                "POST",
                url,
                headers=upstream_headers,
                json=request_payload,
            ) as upstream_response:
                if upstream_response.status_code >= 400:
                    error_text = await upstream_response.aread()
                    logger.error(
                        "Upstream returned %s: %s",
                        upstream_response.status_code,
                        error_text.decode("utf-8", errors="replace"),
                    )
                    yield _json_sse(
                        "error",
                        {
                            "status_code": upstream_response.status_code,
                            "message": "Upstream serving endpoint returned an error.",
                            "body": error_text.decode("utf-8", errors="replace"),
                        },
                    )
                    return

                async for chunk in upstream_response.aiter_raw():
                    if chunk:
                        yield chunk

    response_headers = {
        "X-Accel-Buffering": "no",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-App-Name": APP_NAME,
        "X-Proxy-Version": APP_VERSION,
    }
    if request_id:
        response_headers["X-Request-Id"] = request_id

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers=response_headers,
    )


@app.exception_handler(Exception)
async def handle_exception(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled proxy error")
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "message": str(exc),
        },
    )
