# Arks Agent Proxy App

Databricks App used as an API proxy in front of the `arks-agent` serving endpoint.

## Purpose

This app exists to solve the browser CORS limitation when a company frontend needs
to call a Databricks `agent/v1/responses` endpoint from a different domain.

Architecture:

```text
Company frontend
  -> Databricks App (/api/agent/stream)
    -> arks-agent serving endpoint (/serving-endpoints/<name>/invocations)
```

The app handles:

- CORS for the company frontend
- SSE passthrough for `agent/v1/responses`
- Databricks app auth when calling the upstream endpoint
- anti-buffering headers required for streaming

## Files

- `app.py`: FastAPI proxy app
- `app.yaml`: Databricks Apps runtime config
- `requirements.txt`: extra dependencies for deployment

## Resource Setup

In the Databricks Apps UI, add one resource:

- Type: `Serving endpoint`
- Permission: `Can Query`
- Key used by `app.yaml`: `serving-endpoint`

`app.yaml` injects the endpoint name into:

- `SERVING_ENDPOINT_NAME`

## Important Behavior

This proxy assumes the upstream `arks-agent` endpoint uses SSE streaming.

The route:

- `POST /api/agent/stream`

returns:

- `Content-Type: text/event-stream`

and forwards the upstream response chunk-by-chunk.

It also sets:

- `X-Accel-Buffering: no`
- `Cache-Control: no-cache`
- `Connection: keep-alive`

to reduce proxy buffering and preserve streaming behavior.

## CORS

By default, `app.yaml` allows:

- `http://localhost:4200`

Update `ALLOWED_ORIGINS` before production, for example:

```yaml
- name: ALLOWED_ORIGINS
  value: "https://portal.company.com,https://agent.company.com"
```

## Request Shape

The proxy forwards the incoming JSON body to the upstream serving endpoint as-is.

That means the frontend must send the payload expected by `arks-agent`.

## Frontend Usage

Example:

```javascript
const response = await fetch("https://<app-url>/api/agent/stream", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-Request-Id": crypto.randomUUID(),
  },
  body: JSON.stringify({
    input: [
      {
        role: "user",
        content: [{ type: "input_text", text: "請幫我摘要保單重點" }],
      },
    ],
    stream: true,
  }),
});
```

Read the response with `ReadableStream` and parse SSE events line-by-line.

## Recommended Integration Modes

There are two realistic ways for a frontend to call this app.

### Mode A: fastest path for internal delivery

```text
Browser frontend
  -> company backend / BFF
    -> Databricks App (/api/agent/stream)
      -> arks-agent
```

This is the recommended path if the goal is:

- ship something quickly
- let the frontend team integrate now
- avoid putting Databricks auth logic in the browser

Why this is the fastest practical option:

- the frontend only needs to call one company-owned API
- the backend/BFF can safely hold Databricks credentials
- no browser-side token exchange is required
- no Databricks token is exposed to frontend JavaScript

Recommended backend/BFF behavior:

- authenticate to Databricks using OAuth M2M with a service principal
- call this Databricks App with `Authorization: Bearer <token>`
- stream the SSE response back to the frontend
- optionally normalize headers, request IDs, and audit logs

This mode keeps the Databricks App as the Databricks-facing proxy and uses the
company backend as the browser-facing auth boundary.

### Mode B: browser calls Databricks App directly

```text
Browser frontend
  -> Databricks App (/api/agent/stream)
    -> arks-agent
```

This is possible, but not the recommended "quickest safe" path.

Why:

- Databricks App `/api/*` endpoints require OAuth 2.0 Bearer token auth
- a browser app must obtain a token that is valid for the Databricks App
- browser-side token handling is more complex and easier to get wrong
- putting long-lived credentials in frontend code is not acceptable

Use this only if you are intentionally building a user-authenticated browser app
with a proper OAuth flow and token lifecycle management.

## What we validated

The following is already confirmed working:

- this app can call `arks-agent`
- SSE streaming is preserved end-to-end
- notebook access works after token exchange to an audience-scoped token

This means the proxy itself is valid. The remaining design question is how the
frontend obtains a token to call the app.

## Current Recommendation

For the current phase, recommend the frontend team integrate against:

```text
company frontend -> company BFF -> Databricks App -> arks-agent
```

This gives you:

- fastest delivery
- simplest frontend integration
- no Databricks credential exposure in the browser
- a clean upgrade path later if you decide to support direct browser OAuth

## POC Frontend Integration

This section is for **POC / dev use only**.

If the goal is simply:

- let the frontend team connect now
- validate UI behavior
- validate SSE streaming
- avoid building a BFF first

then the frontend can temporarily accept a user-supplied OAuth Bearer token and
send it to this app in the `Authorization` header.

Do not treat this as the production design.

### POC assumptions

- the frontend runs on a dev origin already allowed by `ALLOWED_ORIGINS`
- the caller has `CAN USE` permission on this Databricks App
- the token is an OAuth access token accepted by Databricks Apps
- the token is provided manually or via local dev config, not committed to git

### Minimal frontend request example

```javascript
async function callAgent({ appUrl, accessToken, prompt }) {
  const response = await fetch(`${appUrl}/api/agent/stream`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Request-Id": crypto.randomUUID(),
    },
    body: JSON.stringify({
      input: [
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: prompt,
            },
          ],
        },
      ],
      stream: true,
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`HTTP ${response.status}: ${text}`);
  }

  return response;
}
```

### SSE parser example

This proxy returns `text/event-stream`. The frontend should read the response as
an SSE stream, not as a normal JSON response.

```javascript
async function readAgentStream(response, onEvent) {
  if (!response.body) {
    throw new Error("ReadableStream is not available");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });

    let boundaryIndex;
    while ((boundaryIndex = buffer.indexOf("\n\n")) !== -1) {
      const rawEvent = buffer.slice(0, boundaryIndex);
      buffer = buffer.slice(boundaryIndex + 2);

      const lines = rawEvent.split(/\r?\n/);
      const dataLines = [];

      for (const line of lines) {
        if (line.startsWith("data:")) {
          dataLines.push(line.slice(5).trim());
        }
      }

      const dataText = dataLines.join("\n");
      if (!dataText) continue;

      let parsed;
      try {
        parsed = JSON.parse(dataText);
      } catch {
        parsed = dataText;
      }

      onEvent(parsed);
    }
  }
}
```

### End-to-end browser example

```javascript
async function runPocDemo() {
  const appUrl = "https://arks-agent-proxy-2269228939259303.aws.databricksapps.com";
  const accessToken = window.localStorage.getItem("dbx_app_token");
  const prompt = "我想要保我的特斯拉，有什麼情況不能保";

  const response = await callAgent({ appUrl, accessToken, prompt });

  let fullText = "";
  await readAgentStream(response, (event) => {
    const item = event?.item;
    const blocks = item?.content || [];
    for (const block of blocks) {
      if (block.type === "output_text" && block.text) {
        fullText += block.text;
        console.log(fullText);
      }
    }
  });
}
```

### Recommended POC UI

For the frontend team, the simplest POC UI is:

- one input field for `Databricks OAuth token`
- one textarea for the prompt
- one output panel that appends streamed text
- one warning label that the token is for dev use only

## How to get a token for POC

For Databricks App API routes, use an **OAuth Bearer token**.

### Option 1: from local machine using Databricks CLI

Log in first:

```bash
databricks auth login --host https://<workspace-url> --profile my-env
```

Then request a token:

```bash
databricks auth token --profile my-env
```

Use the returned access token as:

```text
Authorization: Bearer <ACCESS_TOKEN>
```

### Option 2: from Python using Databricks SDK

```python
from databricks.sdk.core import Config

config = Config(profile="my-env")
token = config.oauth_token().access_token
print(token)
```

### Option 3: from a Databricks notebook

Notebook access to Databricks Apps is different. You must first exchange the
notebook token into an audience-scoped OAuth token for the app.

```python
import requests
from databricks.sdk import WorkspaceClient

APP_NAME = "arks-agent-proxy"

w = WorkspaceClient()
app_client_id = w.apps.get(APP_NAME).oauth2_app_client_id

notebook_token = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .apiToken()
    .get()
)

workspace_host = w.config.host
if not workspace_host.startswith("https://"):
    workspace_host = f"https://{workspace_host}"

response = requests.post(
    f"{workspace_host}/oidc/v1/token",
    data={
        "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
        "subject_token": notebook_token,
        "subject_token_type": "urn:databricks:params:oauth:token-type:personal-access-token",
        "requested_token_type": "urn:ietf:params:oauth:token-type:access_token",
        "scope": "all-apis",
        "audience": app_client_id,
    },
    timeout=60,
)
response.raise_for_status()

audience_token = response.json()["access_token"]
print(audience_token)
```

Use `audience_token` as the Bearer token for this app.

## CLI / curl examples

### curl with Bearer token

```bash
ACCESS_TOKEN="<paste-oauth-token-here>"

curl -N \
  -X POST "https://arks-agent-proxy-2269228939259303.aws.databricksapps.com/api/agent/stream" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "input": [
      {
        "role": "user",
        "content": [
          {
            "type": "input_text",
            "text": "我想要保我的特斯拉，有什麼情況不能保"
          }
        ]
      }
    ],
    "stream": true
  }'
```

### curl with token from Databricks CLI

If you prefer one flow in local development, first run:

```bash
databricks auth token --profile my-env
```

Copy the returned token, then call:

```bash
curl -N \
  -X POST "https://arks-agent-proxy-2269228939259303.aws.databricksapps.com/api/agent/stream" \
  -H "Authorization: Bearer <ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "input": [
      {
        "role": "user",
        "content": [
          {
            "type": "input_text",
            "text": "請幫我摘要保單重點"
          }
        ]
      }
    ],
    "stream": true
  }'
```

### Python requests example

```python
import requests

APP_URL = "https://arks-agent-proxy-2269228939259303.aws.databricksapps.com/api/agent/stream"
ACCESS_TOKEN = "<paste-oauth-token-here>"

payload = {
    "input": [
        {
            "role": "user",
            "content": [
                {
                    "type": "input_text",
                    "text": "我想要保我的特斯拉，有什麼情況不能保",
                }
            ],
        }
    ],
    "stream": True,
}

with requests.post(
    APP_URL,
    headers={
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    },
    json=payload,
    stream=True,
    timeout=300,
) as resp:
    print("status:", resp.status_code)
    print("content-type:", resp.headers.get("content-type"))
    for chunk in resp.iter_content(chunk_size=None):
        if chunk:
            print(chunk.decode("utf-8", errors="replace"), end="")
```

## POC guardrails

If you use direct token entry in the frontend for POC, keep these limits:

- use only in local/dev environments
- do not commit tokens to git
- do not embed tokens into frontend build output
- prefer short-lived OAuth tokens
- remove this flow before production rollout

## Browser-Side Auth Reality

Databricks App API routes are not meant to be called anonymously. For browser
traffic, the caller needs a valid OAuth Bearer token that the app accepts.

Important implications:

- CORS is solved by this app
- app authentication is still required
- solving CORS does not remove the need for OAuth

That is why a direct browser call without token returns `401`, while notebook
access succeeds only after token exchange to an app-scoped OAuth token.

## Best Practice for Production

For production, choose one of these patterns explicitly.

### Best practice 1: company BFF in front of Databricks App

Use when:

- your frontend already has a backend
- you want central audit, rate limiting, session handling, and auth
- you do not want frontend code to handle Databricks OAuth directly

Recommended properties:

- service principal + OAuth M2M
- short-lived access tokens
- request ID propagation
- SSE passthrough from BFF to browser
- centralized access logging and rate limiting

### Best practice 2: direct browser auth to Databricks App

Use when:

- you intentionally want a fully browser-to-Databricks integration
- you have a proper OAuth user flow
- your security team accepts browser-side token handling for this app

Recommended properties:

- OAuth U2M only
- explicit scope design
- no PAT in browser
- no client secret in browser
- token refresh handled by an approved auth flow

## Official Databricks references

These docs informed the guidance above:

- `Connect to an API Databricks app using token authentication`
  - https://docs.databricks.com/aws/en/dev-tools/databricks-apps/connect-local
- `Configure authorization in a Databricks app`
  - https://docs.databricks.com/aws/en/dev-tools/databricks-apps/auth

Key takeaway from the docs:

- Databricks App API routes use OAuth Bearer tokens
- notebooks require token exchange for app-scoped access
- local and external callers should use supported OAuth methods
- `CAN USE` permission on the app is still required

## Deploy

Example CLI flow:

```bash
databricks apps create arks-agent-proxy

databricks workspace mkdirs /Workspace/Users/allen.wu@cathay-ins.com.tw/ARKS/apps/arks-agent-proxy

databricks workspace import-dir \
  dev/apps/agent_proxy \
  /Workspace/Users/allen.wu@cathay-ins.com.tw/ARKS/apps/arks-agent-proxy \
  --overwrite

databricks apps deploy arks-agent-proxy \
  --source-code-path /Workspace/Users/allen.wu@cathay-ins.com.tw/ARKS/apps/arks-agent-proxy
```

Then add the `Serving endpoint` resource in the Apps UI and redeploy if needed.

## Notes

- This app is intentionally separate from `dev/app/` so it can be deployed,
  permissioned, and rolled back independently.
- Keep this app focused on proxy responsibilities only. Do not mix it with the
  MCP retriever app under `ARKS-kb/app/mcp/`.
