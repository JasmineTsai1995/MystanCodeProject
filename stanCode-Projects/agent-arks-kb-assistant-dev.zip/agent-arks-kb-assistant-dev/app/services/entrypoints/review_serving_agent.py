"""MLflow Model Serving entrypoint for the Arks review endpoint.

The existing Databricks App owns the agent execution logic. This module only
adapts the synchronous MLflow ``ResponsesAgent`` contract to that app's async
``@invoke`` and ``@stream`` handlers.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import os
import queue
import threading
import uuid
from collections.abc import AsyncGenerator, Callable, Coroutine, Generator
from concurrent.futures import Future
from typing import Any

import mlflow
from mlflow.pyfunc import ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
)

_LOGGING_MODE = os.getenv("SKIP_MCP_TOOL_INIT", "").lower() in {"1", "true", "yes"}
_DUMMY_RESPONSE_TEXT = "Review endpoint model packaging validation succeeded."
_STREAM_END = object()
_logger = logging.getLogger(__name__)


def _app_agent_module():
    """Import the active App implementation only when actual inference starts."""
    from services.core import databricks_agent

    return databricks_agent


def _prepare_review_request(request: ResponsesAgentRequest) -> ResponsesAgentRequest:
    """Namespace review memory without changing the production App implementation."""
    custom_inputs = dict(request.custom_inputs or {})
    current_session = custom_inputs.get("session_id")
    conversation_id = getattr(getattr(request, "context", None), "conversation_id", None)
    session_seed = str(current_session or conversation_id or uuid.uuid4())
    prefix = os.getenv("ARKS_REVIEW_SESSION_PREFIX", "review").strip("-") or "review"
    expected_prefix = f"{prefix}-"
    if not session_seed.startswith(expected_prefix):
        session_seed = f"{expected_prefix}{session_seed}"
    custom_inputs["session_id"] = session_seed
    return request.model_copy(update={"custom_inputs": custom_inputs})


def _update_review_trace(app_agent: Any) -> None:
    """Record release and resolved prompt identity on the current review trace."""
    tags = {
        "arks.surface": "review_endpoint",
        "arks.review_deployment_id": os.getenv("ARKS_REVIEW_DEPLOYMENT_ID", "unknown"),
        "arks.git.commit": os.getenv("ARKS_GIT_COMMIT", "unknown"),
        "arks.runtime.adapter": "review_serving_agent",
        "arks.session_source": "review_namespace",
    }
    prompt_snapshot = getattr(app_agent, "_agent_prompt_snapshot", None)
    prompt_identity = getattr(app_agent, "_agent_prompt_identity", None)
    if prompt_snapshot:
        tags.update(
            {
                "arks.prompt.source": str(prompt_snapshot.source),
                "arks.prompt.name": str(prompt_snapshot.registry_name),
                "arks.prompt.alias": str(prompt_snapshot.alias),
                "arks.prompt.version": str(prompt_snapshot.version or "unknown"),
                "arks.prompt.digest": str(prompt_snapshot.digest or "unknown"),
            }
        )
    elif prompt_identity:
        source, version, name = prompt_identity
        tags.update(
            {
                "arks.prompt.source": str(source),
                "arks.prompt.name": str(name),
                "arks.prompt.version": str(version or "unknown"),
            }
        )
    try:
        mlflow.update_current_trace(tags=tags)
    except Exception:
        _logger.warning("Could not annotate current review trace.", exc_info=True)


class _PersistentAsyncRunner:
    """Run App coroutines on one event loop for process-scoped async clients."""

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._startup_lock = threading.Lock()

    def _ensure_started(self) -> asyncio.AbstractEventLoop:
        with self._startup_lock:
            if self._loop is not None:
                return self._loop

            ready = threading.Event()

            def run_loop() -> None:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                self._loop = loop
                ready.set()
                loop.run_forever()

            self._thread = threading.Thread(
                target=run_loop,
                name="arks-review-agent-event-loop",
                daemon=True,
            )
            self._thread.start()
            ready.wait()
            assert self._loop is not None
            return self._loop

    def submit(self, create_coro: Callable[[], Coroutine[Any, Any, Any]]) -> Future[Any]:
        """Schedule a coroutine while preserving MLflow's request trace context."""
        loop = self._ensure_started()
        request_context = contextvars.copy_context()
        result: Future[Any] = Future()

        def schedule() -> None:
            try:
                task = loop.create_task(create_coro())
            except BaseException as exc:
                result.set_exception(exc)
                return

            def finish(done: asyncio.Task[Any]) -> None:
                try:
                    result.set_result(done.result())
                except BaseException as exc:
                    result.set_exception(exc)

            task.add_done_callback(finish)

        loop.call_soon_threadsafe(schedule, context=request_context)
        return result


class ArksReviewAgent(ResponsesAgent):
    """Expose the active Databricks App implementation to Model Serving."""

    def __init__(self) -> None:
        self._runner = _PersistentAsyncRunner()

    def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        if _LOGGING_MODE:
            return ResponsesAgentResponse(
                output=[self.create_text_output_item(text=_DUMMY_RESPONSE_TEXT, id="msg_1")]
            )

        app_agent = _app_agent_module()

        async def invoke() -> ResponsesAgentResponse:
            response = await app_agent.invoke_handler(_prepare_review_request(request))
            _update_review_trace(app_agent)
            return response

        return self._runner.submit(invoke).result()

    def predict_stream(
        self, request: ResponsesAgentRequest
    ) -> Generator[ResponsesAgentStreamEvent, None, None]:
        if _LOGGING_MODE:
            yield ResponsesAgentStreamEvent(
                type="response.output_item.done",
                item=self.create_text_output_item(text=_DUMMY_RESPONSE_TEXT, id="msg_1"),
            )
            return

        app_agent = _app_agent_module()
        events: queue.Queue[ResponsesAgentStreamEvent | BaseException | object] = queue.Queue()

        async def forward_stream() -> None:
            try:
                handler_result: AsyncGenerator[ResponsesAgentStreamEvent, None] = (
                    app_agent.stream_handler(_prepare_review_request(request))
                )
                async for event in handler_result:
                    events.put(event)
                _update_review_trace(app_agent)
            except BaseException as exc:
                events.put(exc)
            finally:
                events.put(_STREAM_END)

        completion = self._runner.submit(forward_stream)
        while True:
            event = events.get()
            if event is _STREAM_END:
                completion.result()
                return
            if isinstance(event, BaseException):
                completion.result()
                raise event
            yield event


mlflow.models.set_model(ArksReviewAgent())
