"""Deployment-specific entrypoints for the shared Arks agent runtime."""
