import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine
from langchain_core.documents import Document
from langchain_text_splitters import TextSplitter, MarkdownHeaderTextSplitter  # v1.1.0 路徑
from datetime import datetime
from zoneinfo import ZoneInfo
from markdown_it import MarkdownIt

PARENT_ONLY_METADATA_KEYS = {"raw_assets"}


@dataclass
class MermaidSection:
    raw_block: str
    mermaid_code: str
    info: str
    line_begin: Optional[int]
    line_end: Optional[int]
    title: Optional[str]
    heading_level: Optional[int]


class MarkdownContentProcessor:
    TABLE_PATTERN = re.compile(
        r"""(
            ^\s*\|.+\|[ \t]*\n         # 表頭
            ^\s*\|[-:\s|]+\|[ \t]*\n   # 分隔
            (^\s*\|.*(?:\n(?!\s*\|[-:\s|]+\|).*)*\|[ \t]*\n)+  # 表格內容
        )""",
        re.MULTILINE | re.VERBOSE
    )
    HEADER_PATTERN = re.compile(r'^(#{1,6})\s+(.+)$', re.MULTILINE)

    def __init__(
        self,
        db_engine: Optional[AsyncEngine] = None,
        md_table: Optional[str] = None,
        file_table: Optional[str] = None,
    ):
        self.engine = db_engine
        self.md_table = md_table
        self.file_table = file_table

    async def load_markdown_from_db(
        self,
        file_id: str,
        document_version: Optional[str] = None,
    ) -> tuple[str, dict, str]:
        """
        從資料庫讀取 markdown 與 metadata。
        若未指定 document_version，預設取該 document_id 最新版本。
        """
        if self.engine is None or self.md_table is None or self.file_table is None:
            raise ValueError("❌ DB-backed markdown loading requires engine, md_table, and file_table.")

        base_query = f"""
            SELECT parse_table.document_id AS document_id,
                   file_table.document_name AS document_name,
                   parse_table.parses_content,
                   parse_table.document_version
            FROM {self.md_table} AS parse_table
                INNER JOIN {self.file_table} AS file_table
                ON parse_table.document_id = file_table.document_id
            WHERE parse_table.document_id = :file_id
        """

        params = {"file_id": file_id}
        if document_version is not None:
            # cast to str to avoid type mismatches when column is text
            params["document_version"] = str(document_version)
            base_query += " AND parse_table.document_version = :document_version"

        query = base_query + " ORDER BY parse_table.document_version DESC LIMIT 1"

        async with self.engine.begin() as conn:
            result = await conn.execute(text(query), params)
            row = result.fetchone()

        if not row:
            raise ValueError(f"❌ file_id {file_id} not found in {self.md_table}")

        file_id, filename, markdown, _ = row
        filename = filename.split('.')[0]
        metadata = {"filename": filename, "file_id": file_id}
        return markdown, metadata, filename

    def process(
        self,
        markdown: str,
        metadata: dict,
        summary_chain=None,
        mermaid_summary_chain=None,
        table_summary_chain=None,
    ) -> Document:
        """將 markdown 中的表格與 Mermaid 圖摘要後包裝成 Document。"""
        updated_content = markdown
        table_chain = table_summary_chain or summary_chain
        raw_table_blocks = self._extract_table_sections(markdown)
        raw_mermaid_sections = self._extract_mermaid_sections(markdown)

        if table_chain is not None:
            table_blocks = self._extract_table_sections(updated_content)
            if table_blocks:
                table_inputs = [{"input": block} for block in table_blocks]
                summaries = table_chain.batch(table_inputs)
                summaries = self._extract_contents_from_llm_output(summaries)
                updated_content = self._replace_tables_with_summary(updated_content, table_blocks, summaries)

        if mermaid_summary_chain is not None:
            mermaid_sections = self._extract_mermaid_sections(updated_content)
            if mermaid_sections:
                mermaid_inputs = [
                    {"input": self._build_mermaid_summary_input(section)}
                    for section in mermaid_sections
                ]
                mermaid_summaries = mermaid_summary_chain.batch(mermaid_inputs)
                mermaid_summaries = self._extract_contents_from_llm_output(mermaid_summaries)
                updated_content = self._replace_mermaid_with_summary(
                    updated_content,
                    mermaid_sections,
                    mermaid_summaries,
                )

        final_metadata = {
            **metadata,
            "raw_assets": self._build_raw_assets_payload(raw_table_blocks, raw_mermaid_sections),
        }
        return Document(page_content=updated_content, metadata=final_metadata)

    def _extract_table_sections(self, text: str) -> List[str]:
        headers = [(m.start(), m.end(), m.group(0)) for m in self.HEADER_PATTERN.finditer(text)]
        sections = []
        for i in range(len(headers)):
            start = headers[i][0]
            end = headers[i + 1][0] if i + 1 < len(headers) else len(text)
            section_text = text[start:end]
            sections.append(section_text)
        matched_sections = [sec.strip() for sec in sections if self.TABLE_PATTERN.search(sec)]
        return matched_sections

    def _extract_contents_from_llm_output(self, llm_output: Union[list, str]) -> List[str]:
        if isinstance(llm_output, list):
            return [msg.content if hasattr(msg, "content") else str(msg) for msg in llm_output]
        return [llm_output.content if hasattr(llm_output, "content") else str(llm_output)]

    def _replace_tables_with_summary(self, original_text: str, table_blocks: List[str], summaries: List[str]) -> str:
        new_text = original_text
        for table, summary in zip(table_blocks, summaries):
            new_text = new_text.replace(table, summary, 1)
        return new_text

    def _extract_mermaid_sections(self, text: str) -> List[MermaidSection]:
        md = MarkdownIt("commonmark", {"html": True})
        tokens = md.parse(text)
        line_offsets = self._build_line_offsets(text)
        headings = [
            (match.start(), len(match.group(1)), match.group(2).strip())
            for match in self.HEADER_PATTERN.finditer(text)
        ]
        sections: List[MermaidSection] = []

        for token in tokens:
            if token.type != "fence":
                continue

            info = (token.info or "").strip()
            lang = info.split()[0].lower() if info else ""
            if lang != "mermaid":
                continue

            if token.map:
                start = line_offsets[token.map[0]]
                end = line_offsets[token.map[1]] if token.map[1] < len(line_offsets) else len(text)
                raw_block = text[start:end]
                line_begin = token.map[0] + 1
                line_end = token.map[1]
            else:
                raw_block = f"```mermaid\n{token.content or ''}```\n"
                line_begin = None
                line_end = None

            title, heading_level = self._find_nearest_heading(headings, start if token.map else 0)
            sections.append(
                MermaidSection(
                    raw_block=raw_block,
                    mermaid_code=token.content or "",
                    info=token.info or "",
                    line_begin=line_begin,
                    line_end=line_end,
                    title=title,
                    heading_level=heading_level,
                )
            )
        return sections

    def _build_line_offsets(self, text: str) -> List[int]:
        offsets = [0]
        for line in text.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        return offsets

    def _find_nearest_heading(
        self,
        headings: List[tuple[int, int, str]],
        position: int,
    ) -> tuple[Optional[str], Optional[int]]:
        title = None
        level = None
        for heading_pos, heading_level, heading_title in headings:
            if heading_pos > position:
                break
            title = heading_title
            level = heading_level
        return title, level

    def _build_mermaid_summary_input(self, section: MermaidSection) -> str:
        title = section.title or "Mermaid 圖表"
        return (
            f"title: {title}\n"
            f"heading_level: {section.heading_level or 3}\n"
            "raw_mermaid:\n"
            "```mermaid\n"
            f"{section.mermaid_code.rstrip()}\n"
            "```"
        )

    def _replace_mermaid_with_summary(
        self,
        original_text: str,
        mermaid_sections: List[MermaidSection],
        summaries: List[str],
    ) -> str:
        new_text = original_text
        for section, summary in zip(mermaid_sections, summaries):
            new_text = new_text.replace(section.raw_block, summary.rstrip() + "\n", 1)
        return new_text

    def _build_raw_assets_payload(
        self,
        table_blocks: List[str],
        mermaid_sections: List[MermaidSection],
    ) -> Dict[str, List[Dict[str, Any]]]:
        return {
            "tables": [self._build_table_asset(block) for block in table_blocks],
            "mermaids": [self._build_mermaid_asset(section) for section in mermaid_sections],
        }

    def _build_table_asset(self, table_block: str) -> Dict[str, Any]:
        title = None
        heading_level = None
        first_line = table_block.splitlines()[0].strip() if table_block.splitlines() else ""
        heading_match = self.HEADER_PATTERN.match(first_line)
        if heading_match:
            heading_level = len(heading_match.group(1))
            title = heading_match.group(2).strip()
        return {
            "title": title,
            "heading_level": heading_level,
            "raw_block": table_block,
        }

    def _build_mermaid_asset(self, section: MermaidSection) -> Dict[str, Any]:
        return {
            "title": section.title,
            "heading_level": section.heading_level,
            "line_begin": section.line_begin,
            "line_end": section.line_end,
            "info": section.info,
            "raw_block": section.raw_block,
            "mermaid_code": section.mermaid_code,
        }


class MarkdownTableProcessor(MarkdownContentProcessor):
    """Backward-compatible alias for the previous DB-capable processor."""


class TableProcessor(MarkdownContentProcessor):
    """Table summarizer for in-memory markdown (no DB dependency)."""

    def __init__(self):
        super().__init__()


class MDHeaderTextSplitter(MarkdownHeaderTextSplitter, TextSplitter):
    def split_documents(self, documents: List[Document]) -> List[Document]:
        split_docs = []
        updated_at_ts = datetime.now(ZoneInfo("Asia/Taipei")).strftime("%Y-%m-%d %H:%M:%S.%f")

        for doc in documents:
            split = self.split_text(doc.page_content)

            for sdoc in split:
                merged_metadata = {**doc.metadata, **sdoc.metadata}

                for sep, name in self.headers_to_split_on:
                    if name in merged_metadata:
                        merged_metadata[f"{name}_level"] = sep.count("#")
                merged_metadata["updated_at"] = updated_at_ts
                split_docs.append(
                    Document(page_content=sdoc.page_content, metadata=merged_metadata)
                )
        return split_docs


def strip_parent_only_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in metadata.items() if k not in PARENT_ONLY_METADATA_KEYS}
