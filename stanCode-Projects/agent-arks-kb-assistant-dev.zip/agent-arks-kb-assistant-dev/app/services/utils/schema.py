
import asyncio
import os
from datetime import datetime
from typing import Optional, List, Sequence, Dict, Tuple, Iterator

from pymongo.collection import Collection
from sqlalchemy import Column, Text, String, and_, delete, select, MetaData, Table, DateTime
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession
from sqlalchemy.orm import declarative_base, Session
from langchain_community.storage import SQLStore
from langchain_core.documents import Document
from langchain_core.stores import BaseStore

from .config import PARENT_TABLE

# metadata = MetaData(schema=os.environ["SCHEMA_NAME"])
# Base = declarative_base(metadata=metadata)
Base = declarative_base()
# Parent Doc Schema
class ParentSQLStoreSchema(Base):
    """Table used to save values."""
    __tablename__ = PARENT_TABLE 
    key = Column(Text, primary_key=True, index=True, nullable=False) # parent_id # 欄位名稱建議不動
    value = Column(String, nullable=False) # parent chunk # 欄位名稱建議不動
    file_id = Column(String, nullable=False) # IT的file_id
    filename = Column(String, nullable=False) # IT的filename
    updated_at = Column(DateTime, nullable=False) # 更新的datetime
    cmetadata = Column(JSONB, nullable=True) # metadata已經被保留，所以取名cmetadata

    
class CustomParentSQLStore(SQLStore):
    def __init__(self, engine: Optional[AsyncEngine] = None):
        super().__init__(namespace="", engine=engine)
        
    async def amset(self, key_value_pairs: Sequence[Tuple[str, bytes]]) -> None:
        async with self._make_async_session() as session:
            await self._amdelete([key for key, _ in key_value_pairs], session)
            session.add_all(
                [
                    ParentSQLStoreSchema(
                        key=k,
                        value=v.page_content,
                        file_id=v.metadata["file_id"],
                        filename=v.metadata["filename"],
                        updated_at=v.metadata["updated_at"],
                        cmetadata={
                            **v.metadata,
                            "updated_at": v.metadata["updated_at"].strftime("%Y-%m-%d %H:%M:%S.%f")
                        }
                        )
                    for k, v in key_value_pairs
                ]
            )
            await session.commit()

    def mset(self, key_value_pairs: Sequence[Tuple[str, bytes]]) -> None:
        values: Dict[str, bytes] = dict(key_value_pairs)
        with self._make_sync_session() as session:
            self._mdelete(list(values.keys()), session)
            session.add_all(
                [
                    ParentSQLStoreSchema(
                        key=k, 
                        value=v.page_content, 
                        file_id=v.metadata["file_id"],
                        filename=v.metadata["filename"],
                        updated_at=v.metadata["updated_at"],
                        cmetadata={
                            **v.metadata,
                            "updated_at": v.metadata["updated_at"].strftime("%Y-%m-%d %H:%M:%S.%f")
                        },
                        )
                    for k, v in values.items()
                ]
            )
            session.commit()

    async def amget(self, keys: Sequence[str]) -> List[Optional[bytes]]:
        assert isinstance(self.engine, AsyncEngine)
        result: Dict[str, bytes] = {}
        async with self._make_async_session() as session:
            stmt = select(ParentSQLStoreSchema).filter(
                and_(
                    ParentSQLStoreSchema.key.in_(keys),
                )
            )
            for v in await session.scalars(stmt):
                result[v.key] = Document(page_content=v.value,
                                         metadata=v.cmetadata)
        return [result.get(key) for key in keys]
        
    def mget(self, keys: Sequence[str]) -> List[Optional[bytes]]:
        result = {}

        with self._make_sync_session() as session:
            stmt = select(ParentSQLStoreSchema).filter(
                and_(
                    ParentSQLStoreSchema.key.in_(keys),
                )
            )
            for v in session.scalars(stmt):
                result[v.key] = Document(page_content=v.value,
                                         metadata=v.cmetadata)
        return [result.get(key) for key in keys]
    
    def _mdelete(self, keys: Sequence[str], session: Session) -> None:
        stmt = delete(ParentSQLStoreSchema).filter(
            and_(
                ParentSQLStoreSchema.key.in_(keys),
            )
        )
        session.execute(stmt)

    async def _amdelete(self, keys: Sequence[str], session: AsyncSession) -> None:
        stmt = delete(ParentSQLStoreSchema).filter(
            and_(
                ParentSQLStoreSchema.key.in_(keys),
            )
        )
        await session.execute(stmt)

    def mdelete(self, keys: Sequence[str]) -> None:
        with self._make_sync_session() as session:
            self._mdelete(keys, session)
            session.commit()

    async def amdelete(self, keys: Sequence[str]) -> None:
        async with self._make_async_session() as session:
            await self._amdelete(keys, session)
            await session.commit()


class MongoParentDocumentStore(BaseStore[str, Document]):
    def __init__(self, collection: Collection):
        self._collection = collection

    @staticmethod
    def _format_updated_at(value):
        if isinstance(value, datetime):
            return value.strftime("%Y-%m-%d %H:%M:%S.%f")
        return value

    def _record_from_document(self, key: str, document: Document) -> dict:
        metadata = {
            **document.metadata,
            "updated_at": self._format_updated_at(document.metadata.get("updated_at")),
        }
        return {
            "key": key,
            "value": document.page_content,
            "file_id": metadata.get("file_id"),
            "filename": metadata.get("filename"),
            "updated_at": metadata.get("updated_at"),
            "cmetadata": metadata,
        }

    def _to_document(self, record: dict) -> Optional[Document]:
        if not record:
            return None
        return Document(page_content=record["value"], metadata=record["cmetadata"])

    def _replace_documents(self, key_value_pairs: Sequence[Tuple[str, Document]]) -> None:
        keys = [key for key, _ in key_value_pairs]
        if keys:
            self._collection.delete_many({"key": {"$in": keys}})
            docs = [self._record_from_document(key, value) for key, value in key_value_pairs]
            if docs:
                self._collection.insert_many(docs)

    def _fetch_records(self, keys: Sequence[str]) -> Dict[str, dict]:
        if not keys:
            return {}
        cursor = self._collection.find({"key": {"$in": list(keys)}})
        return {record["key"]: record for record in cursor}

    async def amset(self, key_value_pairs: Sequence[Tuple[str, Document]]) -> None:
        if not key_value_pairs:
            return
        await asyncio.to_thread(self._replace_documents, key_value_pairs)

    def mset(self, key_value_pairs: Sequence[Tuple[str, Document]]) -> None:
        if not key_value_pairs:
            return
        self._replace_documents(key_value_pairs)

    async def amget(self, keys: Sequence[str]) -> List[Optional[Document]]:
        if not keys:
            return []
        records = await asyncio.to_thread(self._fetch_records, keys)
        return [self._to_document(records.get(key)) for key in keys]

    def mget(self, keys: Sequence[str]) -> List[Optional[Document]]:
        if not keys:
            return []
        records = self._fetch_records(keys)
        return [self._to_document(records.get(key)) for key in keys]

    async def amdelete(self, keys: Sequence[str]) -> None:
        if not keys:
            return
        await asyncio.to_thread(self._collection.delete_many, {"key": {"$in": keys}})

    def mdelete(self, keys: Sequence[str]) -> None:
        if not keys:
            return
        self._collection.delete_many({"key": {"$in": keys}})

    def yield_keys(self, *, prefix: Optional[str] = None):
        query = {}
        if prefix:
            query["key"] = {"$regex": f"^{prefix}"}
        cursor = self._collection.find(query, {"key": 1})
        for record in cursor:
            yield record["key"]

    async def ayield_keys(self, *, prefix: Optional[str] = None):
        iterator = self.yield_keys(prefix=prefix)
        for key in iterator:
            yield key
