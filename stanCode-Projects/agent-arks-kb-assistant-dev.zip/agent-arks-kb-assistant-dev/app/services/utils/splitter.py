import json
import re
from typing import Dict, List

from langchain_core.documents import Document
from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_experimental.text_splitter import SemanticChunker
from langchain_text_splitters import RecursiveCharacterTextSplitter, TextSplitter

from .preprocess import MDHeaderTextSplitter, strip_parent_only_metadata


def _safe_parse_list(text: str) -> List[str]:
    text = text.strip()

    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            return [str(x).strip() for x in obj if str(x).strip()]
        if isinstance(obj, dict) and "propositions" in obj and isinstance(obj["propositions"], list):
            return [str(x).strip() for x in obj["propositions"] if str(x).strip()]
    except Exception:
        pass

    match = re.search(r"\[\s*.*\s*\]", text, flags=re.S)
    if match:
        try:
            arr = json.loads(match.group(0))
            if isinstance(arr, list):
                return [str(x).strip() for x in arr if str(x).strip()]
        except Exception:
            pass

    lines = []
    for line in text.splitlines():
        line = line.strip()
        line = re.sub(r"^(\d+[\).\s]+|[-*•]\s+)", "", line).strip()
        if line:
            lines.append(line)

    return lines


class PropositionChunkingTextSplitter(TextSplitter):
    def __init__(
        self,
        llm: BaseChatModel,
        language: str = "zh-TW",
        max_propositions: int = 60,
        min_chars: int = 12,
        include_source_text: bool = False,
    ):
        super().__init__()
        self.llm = llm
        self.language = language
        self.max_propositions = max_propositions
        self.min_chars = min_chars
        self.include_source_text = include_source_text

        self.prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    (
                        "You are an assistant specialized in splitting text into thematically consistent sections. "
                        "Your task is to identify the points where splits should occur, such that consecutive chunks of similar themes stay together. "
                        "Do NOT split the text sentence by sentence. Each split must correspond to a meaningful thematic boundary. "
                        "Each resulting section should represent a complete, self-contained idea or discussion unit, not a fragment. "
                        "Only introduce a split when the topic, intent, or conceptual focus clearly shifts to a new theme. "
                        "A paragraph or section may contain multiple sentences, as long as they contribute to the same coherent meaning. "
                        "Avoid over-segmentation: do not split merely because of stylistic changes or minor elaborations. "
                        "Ensure that each segment can be understood independently without requiring context from adjacent segments. "
                        "Prefer fewer, semantically complete sections over many small, partially meaningful fragments. "
                        "Splits should reflect logical discourse structure (e.g., background vs. method vs. implication), not grammatical boundaries. "
                    ),
                ),
                (
                    "human",
                    (
                        "Language: {language}\n\n"
                        "Text:\n{text}\n\n"
                        "Return ONLY a JSON array of strings.\n"
                        "Guidelines:\n"
                        "- Each item is one proposition.\n"
                        "- Avoid pronouns when possible; make propositions standalone.\n"
                        "- Preserve important numbers/dates/conditions.\n"
                        "- Do not add information not present in the text.\n"
                    ),
                ),
            ]
        )
        self.chain = self.prompt | self.llm | StrOutputParser()

    def split_text(self, text: str) -> List[str]:
        raw = self.chain.invoke({"language": self.language, "text": text})
        propositions = _safe_parse_list(raw)
        propositions = [p for p in propositions if len(p) >= self.min_chars]
        return propositions[: self.max_propositions]

    def split_documents(self, documents: List[Document]) -> List[Document]:
        out: List[Document] = []
        for doc in documents:
            raw = self.chain.invoke({"language": self.language, "text": doc.page_content})
            propositions = _safe_parse_list(raw)
            propositions = [p for p in propositions if len(p) >= self.min_chars]
            propositions = propositions[: self.max_propositions]
            base_metadata = strip_parent_only_metadata(dict(doc.metadata or {}))

            for idx, proposition in enumerate(propositions):
                md = dict(base_metadata)
                md.update(
                    {
                        "child_chunk_type": "proposition",
                        "proposition_index": idx,
                    }
                )
                if self.include_source_text:
                    md["source_text"] = doc.page_content
                out.append(Document(page_content=proposition, metadata=md))
        return out


class SemanticChunkerAdapter(TextSplitter):
    def __init__(self, semantic_chunker: SemanticChunker):
        super().__init__()
        self.semantic_chunker = semantic_chunker

    def split_documents(self, documents: List[Document]) -> List[Document]:
        split_docs = self.semantic_chunker.split_documents(documents)
        return [
            Document(
                page_content=doc.page_content,
                metadata=strip_parent_only_metadata(dict(doc.metadata or {})),
            )
            for doc in split_docs
        ]

    def split_text(self, text: str) -> List[str]:
        return self.semantic_chunker.split_text(text)


class MetadataStrippingTextSplitter(TextSplitter):
    def __init__(self, inner_splitter: TextSplitter):
        super().__init__()
        self.inner_splitter = inner_splitter

    def split_documents(self, documents: List[Document]) -> List[Document]:
        split_docs = self.inner_splitter.split_documents(documents)
        return [
            Document(
                page_content=doc.page_content,
                metadata=strip_parent_only_metadata(dict(doc.metadata or {})),
            )
            for doc in split_docs
        ]

    def split_text(self, text: str) -> List[str]:
        return self.inner_splitter.split_text(text)


def build_splitter(
    splitter_name: str,
    embeddings,
    chat_llm,
    *,
    recursive_chunk_size: int = 128,
    recursive_chunk_overlap: int = 10,
    semantic_threshold_type: str = "percentile",
    semantic_threshold_amount: float | None = None,
    proposition_max: int = 60,
    proposition_min_chars: int = 12,
    proposition_include_source_text: bool = False,
) -> TextSplitter:
    if splitter_name == "recursive":
        return MetadataStrippingTextSplitter(
            RecursiveCharacterTextSplitter(
                separators=["", "、", "，", "。"],
                chunk_size=recursive_chunk_size,
                chunk_overlap=recursive_chunk_overlap,
            )
        )

    if splitter_name == "semantic":
        semantic_kwargs = {"breakpoint_threshold_type": semantic_threshold_type}
        if semantic_threshold_amount is not None:
            semantic_kwargs["breakpoint_threshold_amount"] = semantic_threshold_amount
        semantic_child_chunker = SemanticChunker(embeddings, **semantic_kwargs)
        return SemanticChunkerAdapter(semantic_child_chunker)

    if splitter_name == "propositions":
        return MetadataStrippingTextSplitter(
            PropositionChunkingTextSplitter(
                llm=chat_llm,
                language="zh-TW",
                max_propositions=proposition_max,
                min_chars=proposition_min_chars,
                include_source_text=proposition_include_source_text,
            )
        )

    raise ValueError(f"Unknown child_splitter: {splitter_name}")


def build_parent_splitter() -> MDHeaderTextSplitter:
    headers_to_split_on_list = [
        ("#", "H1"),
        ("##", "H2"),
        ("###", "H3"),
    ]
    return MDHeaderTextSplitter(
        headers_to_split_on=headers_to_split_on_list,
        return_each_line=False,
        strip_headers=True,
    )


def build_splitters(
    embeddings,
    chat_llm,
    *,
    recursive_chunk_size: int = 128,
    recursive_chunk_overlap: int = 10,
    semantic_threshold_type: str = "percentile",
    semantic_threshold_amount: float | None = None,
    proposition_max: int = 60,
    proposition_min_chars: int = 12,
    proposition_include_source_text: bool = False,
) -> tuple[MDHeaderTextSplitter, Dict[str, TextSplitter]]:
    parent_splitter = build_parent_splitter()

    child_splitter_map = {
        "recursive": build_splitter(
            "recursive",
            embeddings,
            chat_llm,
            recursive_chunk_size=recursive_chunk_size,
            recursive_chunk_overlap=recursive_chunk_overlap,
        ),
        "semantic": build_splitter(
            "semantic",
            embeddings,
            chat_llm,
            semantic_threshold_type=semantic_threshold_type,
            semantic_threshold_amount=semantic_threshold_amount,
        ),
        "propositions": build_splitter(
            "propositions",
            embeddings,
            chat_llm,
            proposition_max=proposition_max,
            proposition_min_chars=proposition_min_chars,
            proposition_include_source_text=proposition_include_source_text,
        ),
    }

    return parent_splitter, child_splitter_map
