from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy import text
import pandas as pd

async def check_table_exist(schema_name, table_name, async_engine):
    """
    確認表格是否存在
    """
    query = text("""
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.tables 
            WHERE table_schema = :schema
              AND table_name = :table
        )
    """)

    async with async_engine.connect() as conn:
        result = await conn.execute(query, {"schema": schema_name, "table": table_name})
        exists = result.scalar()
    return exists

async def aget_ids_by_file_id(async_engine: AsyncEngine, file_id: str, schema_name: str, table_name: str) -> list[str]:
    query = text(f"""
        SELECT array_agg(id) AS uuid_list
        FROM {schema_name}.{table_name}
        WHERE file_id = :file_id
    """)
    async with async_engine.connect() as conn:
        result = await conn.execute(query, {"file_id": file_id})
        row = result.fetchone()
        if row and row[0]:
            return [str(u) for u in row[0]]
        return []


async def aget_ids_and_parent_ids_by_file_id(
    async_engine: AsyncEngine,
    file_id: str,
    schema_name: str,
    child_table_name: str
) -> tuple[list[str], list[str]]:
    """ 
    for parent document
    """
    query = text(f"""
        SELECT DISTINCT id, metadata->>'doc_id' AS doc_id
        FROM {schema_name}.{child_table_name}
        WHERE file_id = :file_id AND metadata::json->>'doc_id' IS NOT NULL
    """)
    async with async_engine.connect() as conn:
        result = await conn.execute(query, {"file_id": file_id})
        rows = result.fetchall()

    ids = {str(row[0]) for row in rows if row[0]}
    doc_ids = {str(row[1]) for row in rows if row[1]}

    return list(ids), list(doc_ids)

class DictPostgreManager():
    def __init__(self, async_engine: AsyncEngine, schema_name: str, table_name: str):
        self.async_engine = async_engine
        self.schema_name = schema_name
        self.table_name = table_name

    async def adelete_by_file_id(self, file_id: str):
        async with self.async_engine.begin() as conn:
            await conn.execute(
                text(f"DELETE FROM {self.schema_name}.{self.table_name} WHERE file_id = :file_id"),
                {"file_id": file_id}
            )
        print(f"✅ Deleted from {self.schema_name}.{self.table_name} where file_id = '{file_id}'")

    async def aadd_by_file_id(self, df: pd.DataFrame, file_id: str):
        if df.empty:
            print("⚠️ DataFrame is empty, skipping insert.")
            return
        async with self.async_engine.begin() as conn:
            await conn.execute(
                text(f"DELETE FROM {self.schema_name}.{self.table_name} WHERE file_id = :file_id"),
                {"file_id": file_id}
            )
            columns = df.columns.tolist()
            col_sql = ", ".join(columns)
            placeholders = ", ".join([f":{col}" for col in columns])
            insert_sql = text(f"INSERT INTO {self.schema_name}.{self.table_name} ({col_sql}) VALUES ({placeholders})")
            await conn.execute(insert_sql, df.to_dict(orient="records"))
        print(f"✅ Overwrote {len(df)} rows to '{self.schema_name}.{self.table_name}' where file_id = '{file_id}'")
