"""
Services Config

Re-exports typed constants from app/config/config.yaml via config.loader.
All downstream code (tools, scripts, splitter, etc.) imports from here.
"""

from __future__ import annotations

from pathlib import Path

from config.loader import PROJECT_DIR, cfg, cfg_bool, cfg_float, cfg_int

# Project-root-relative base for path resolution
_BASE_DIR: Path = PROJECT_DIR

# -----------------------------------------------------------------------------
# Internal OCP API (LiteLLM proxy)
# Environment selected by OCP_ENV (sit | uat | prod), default: sit
# env: OCP_API_KEY overrides the yaml value for the active environment
# env: OCP_ENDPOINT overrides the yaml value for the active environment
# -----------------------------------------------------------------------------
import os as _os

_OCP_ENV     = _os.getenv("OCP_ENV", "sit")
API_KEY      = cfg(f"api.{_OCP_ENV}.key",      "OCP_API_KEY")
API_ENDPOINT = cfg(f"api.{_OCP_ENV}.endpoint",  "OCP_ENDPOINT")

# -----------------------------------------------------------------------------
# Data validation
# -----------------------------------------------------------------------------
REQUIRED_COLS = cfg("required_cols", default={})
NON_NULL_COLS = cfg("non_null_cols", default={})

# -----------------------------------------------------------------------------
# Retrieval
# -----------------------------------------------------------------------------
QC_RETRIEVE_THRESHOLD = cfg_float("retrieval.qc_threshold", default=0.2)
QC_RETRIEVE_TOP_K     = cfg_int("retrieval.qc_top_k",       default=20)
QC_RERANK_TOP_N       = cfg_int("retrieval.qc_rerank_top_n", default=10)
QA_RETRIEVE_THRESHOLD = cfg_float("retrieval.qa_threshold", default=0.5)
QA_RETRIEVE_TOP_K     = cfg_int("retrieval.qa_top_k",       "QA_RETRIEVE_TOP_K", default=10)
QA_RERANK_TOP_N       = cfg_int("retrieval.qa_rerank_top_n", default=3)
RETRIEVE_HYBRID       = cfg_bool("retrieval.hybrid",         default=False)
RETRIEVE_TYPES        = cfg("retrieval.types",               default=["vector"])

# -----------------------------------------------------------------------------
# KB ingestion models
# -----------------------------------------------------------------------------
LLM_MODEL_NAME    = cfg("llm.kb_ingest.model_name",      "MODEL_NAME",       "gemini-2.5-flash-lite")
EMBED_MODEL_NAME  = cfg("llm.kb_ingest.embed_model_name", "EMBED_MODEL_NAME", "google/gemini-embedding-001")
EMBED_DIM         = cfg_int("llm.kb_ingest.embed_dim",    "EMBED_DIM",        3072)
RERANK_MODEL_NAME = cfg("llm.kb_ingest.rerank_model_name")
INFERENCE_TOP_P   = cfg_float("llm.kb_ingest.top_p",       default=0.8)
INFERENCE_TEMPERATURE = cfg_float("llm.kb_ingest.temperature", default=0.1)

# -----------------------------------------------------------------------------
# Internal PostgreSQL (OCP service)
# env: PG_HOST, PG_DATABASE, PG_USER, PG_PASSWORD, PG_PORT
# -----------------------------------------------------------------------------
DB_CONFIG = {
    "host":     _os.getenv("PG_HOST",     cfg("postgresql.config.host",     "")),
    "database": _os.getenv("PG_DATABASE", cfg("postgresql.config.database", "")),
    "user":     _os.getenv("PG_USER",     cfg("postgresql.config.user",     "")),
    "password": _os.getenv("PG_PASSWORD", cfg("postgresql.config.password", "")),
    "port":     int(_os.getenv("PG_PORT", str(cfg("postgresql.config.port", "5432")))),
}
DB_SCHEMA = cfg("postgresql.schema", default={"ARKS": "dbarks"})

# -----------------------------------------------------------------------------
# MongoDB (RAG knowledge base)
# -----------------------------------------------------------------------------
MONGODB_URI = cfg("mongodb.uri", "MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB  = cfg("mongodb.db",  "MONGODB_DB",  "dbarks")

PARENT_TABLE = cfg("mongodb.tables.parent", default="km_document_parent")
CHILD_TABLE  = cfg("mongodb.tables.child",  default="km_document_child")
FAQ_TABLE    = cfg("mongodb.tables.faq",    default="km_faq_vectorstore")
DICT_TABLE   = cfg("mongodb.tables.dict",   default="km_dictionary")

# -----------------------------------------------------------------------------
# File paths
# -----------------------------------------------------------------------------
DATASET_DIR         = (_BASE_DIR / cfg("paths.dataset_dir",        default="data/poc_md")).resolve()
TEST_SET_PATH       = (_BASE_DIR / cfg("paths.test_set_path",      default="data/poc_testset.csv")).resolve()
KB_INGEST_FILE_PATH = (_BASE_DIR / cfg("paths.kb_ingest_file_path", default="data/poc_md/sample.md")).resolve()
GROUND_TRUTH_PATH   = (_BASE_DIR / cfg("paths.ground_truth_path",  default="data/result/poc_truth/header_bu_ground_truth.json")).resolve()

# -----------------------------------------------------------------------------
# Text splitter (KB ingestion)
# -----------------------------------------------------------------------------
CHILD_SPLITTERS          = cfg("splitter.child_splitters",       default=["recursive", "semantic", "propositions"])
RECURSIVE_CHUNK_SIZE     = cfg_int("splitter.recursive_chunk_size",    default=128)
RECURSIVE_CHUNK_OVERLAP  = cfg_int("splitter.recursive_chunk_overlap", default=10)
SEMANTIC_THRESHOLD_TYPE  = cfg("splitter.semantic_threshold_type",     default="percentile")
SEMANTIC_THRESHOLD_AMOUNT = cfg_float("splitter.semantic_threshold_amount", default=70)
PROPOSITION_MAX          = cfg_int("splitter.proposition_max",         default=64)
PROPOSITION_MIN_CHARS    = cfg_int("splitter.proposition_min_chars",   default=20)
