"""
Agent server entry point for Databricks App deployment.

Uses mlflow AgentServer (basic) to serve @invoke/@stream handlers
registered in services.core.databricks_agent.

Lakebase Autoscaling is used only by the agent checkpointer
(memory/store.py) for conversation persistence, not by the server itself.

Usage:
    uvicorn services.start_server:app --host 0.0.0.0 --port 8000
"""

# ruff: noqa: E402
import sys
from pathlib import Path

from dotenv import load_dotenv

# Load .env before any other imports (agent needs auth config)
load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env", override=True)

# Ensure app/ is on sys.path
_APP_DIR = Path(__file__).resolve().parent.parent  # app/
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

import logging

from mlflow.genai.agent_server import AgentServer

logger = logging.getLogger(__name__)

# Import agent module to register @invoke / @stream handlers with MLflow
import services.core.databricks_agent  # noqa: F401


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

agent_server = AgentServer("ResponsesAgent")
app = agent_server.app


def main():
    agent_server.run(app_import_string="services.start_server:app")


if __name__ == "__main__":
    main()
