"""Log and register the Arks Model Serving model used by the Review App."""

from __future__ import annotations

import argparse
import hashlib
import inspect
import importlib.util
import json
import os
import pprint
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import mlflow
from mlflow.models.resources import DatabricksApp, DatabricksServingEndpoint


def _current_script_dir() -> Path:
    """Return this script directory even when Databricks Jobs omits __file__."""
    filename = globals().get("__file__")
    if not filename:
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Could not resolve register_review_agent.py location.")
        filename = frame.f_code.co_filename
    return Path(filename).resolve().parent


_SCRIPT_DIR = _current_script_dir()
_APP_DIR = _SCRIPT_DIR.parents[1]
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))
_REVIEW_MODEL_FILE = _APP_DIR / "services" / "entrypoints" / "review_serving_agent.py"
_DEFAULT_REQUIREMENTS_FILE = _APP_DIR / "requirements.txt"
_PROMPT_MANIFEST_FILE = _APP_DIR / "config" / "prompt_manifest.py"
_PROMPT_ALIAS = "production"

from services.integrations.mlflow.trace_location import configure_experiment_trace_location


@dataclass(frozen=True)
class ReviewModelRegistration:
    model_name: str
    model_version: str
    model_uri: str
    run_id: str
    git_commit: str
    requirements_digest: str
    agent_prompt_version: str
    agent_prompt_digest: str
    prompt_snapshot_digest: str


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=_APP_DIR.parent,
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return os.getenv("GIT_COMMIT", "unknown")


def _requirements(requirements_file: Path) -> tuple[list[str], str]:
    text = requirements_file.read_text(encoding="utf-8")
    requirements = [
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    # UC table-prefix trace locations require MLflow with Databricks trace_location support.
    requirements = [
        requirement
        for requirement in requirements
        if not requirement.lower().startswith("mlflow")
    ]
    requirements.append("mlflow[databricks]>=3.8.0")
    digest = hashlib.sha256("\n".join(sorted(requirements)).encode("utf-8")).hexdigest()
    return requirements, digest


def _runtime_prompts() -> dict[str, str]:
    spec = importlib.util.spec_from_file_location("_arks_prompt_manifest", _PROMPT_MANIFEST_FILE)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.REVIEW_RUNTIME_PROMPTS


def _capture_prompt_snapshot() -> tuple[dict[str, dict[str, str]], str]:
    snapshots: dict[str, dict[str, str]] = {}
    for fallback_key, registry_name in _runtime_prompts().items():
        prompt = mlflow.genai.load_prompt(
            f"prompts:/{registry_name}@{_PROMPT_ALIAS}",
            cache_ttl_seconds=0,
        )
        version = str(getattr(prompt, "version", "") or "")
        if not version:
            raise RuntimeError(f"Prompt Registry did not return a version for {registry_name}")
        template = prompt.template
        snapshots[registry_name] = {
            "fallback_key": fallback_key,
            "alias": _PROMPT_ALIAS,
            "version": version,
            "digest": hashlib.sha256(template.encode("utf-8")).hexdigest(),
            "template": template,
        }
    snapshot_digest = hashlib.sha256(
        json.dumps(snapshots, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return snapshots, snapshot_digest


def _write_snapshot_module(directory: Path, snapshots: dict[str, dict[str, str]]) -> Path:
    snapshot_file = directory / "review_prompt_snapshot.py"
    snapshot_file.write_text(
        "# Generated during review model registration. Do not edit.\n"
        f"SNAPSHOTS = {pprint.pformat(snapshots, sort_dicts=True)}\n",
        encoding="utf-8",
    )
    return snapshot_file


def register_review_model(args: argparse.Namespace) -> ReviewModelRegistration:
    requirements_file = (
        Path(args.requirements_file) if args.requirements_file else _DEFAULT_REQUIREMENTS_FILE
    )
    requirements, requirements_digest = _requirements(requirements_file)
    git_commit = args.git_commit or _git_commit()
    uc_catalog = getattr(args, "uc_catalog", "dev_gaia_experiments")
    uc_schema = getattr(args, "uc_schema", "arks")
    trace_table_prefix = getattr(args, "trace_table_prefix", "arks_review")
    llm_provider = str(getattr(args, "llm_provider", "litellm")).strip().lower()
    if llm_provider not in {"databricks", "litellm"}:
        raise ValueError(
            f"Unsupported --llm-provider {llm_provider!r}; expected databricks or litellm."
        )

    os.environ["SKIP_MCP_TOOL_INIT"] = "true"
    os.environ["ARKS_UC_CATALOG"] = uc_catalog
    os.environ["ARKS_UC_SCHEMA"] = uc_schema
    os.environ["ARKS_TRACE_TABLE_PREFIX"] = trace_table_prefix
    mlflow.set_tracking_uri("databricks")
    mlflow.set_registry_uri("databricks-uc")
    mlflow.set_experiment(args.experiment_name)
    configure_experiment_trace_location(
        experiment_name=args.experiment_name,
        catalog=uc_catalog,
        schema=uc_schema,
        table_prefix=trace_table_prefix,
        required=True,
    )
    snapshots, prompt_snapshot_digest = _capture_prompt_snapshot()
    agent_prompt = snapshots[_runtime_prompts()["agent"]]

    resources = [DatabricksApp(app_name=args.mcp_app_name)]
    if llm_provider == "databricks":
        resources.insert(0, DatabricksServingEndpoint(endpoint_name=args.llm_endpoint))

    tags = {
        "arks.review_deployment_id": args.review_deployment_id,
        "arks.surface": "review_endpoint",
        "arks.environment": "review",
        "arks.git.commit": git_commit,
        "arks.prompt.source": "mlflow_snapshot",
        "arks.prompt.alias": _PROMPT_ALIAS,
        "arks.prompt.agent.version": agent_prompt["version"],
        "arks.prompt.agent.digest": agent_prompt["digest"],
        "arks.prompt.snapshot_digest": prompt_snapshot_digest,
        "arks.uc.catalog": uc_catalog,
        "arks.uc.schema": uc_schema,
        "arks.trace.table_prefix": trace_table_prefix,
        "arks.llm_provider": llm_provider,
        "arks.llm_endpoint": args.llm_endpoint,
        "arks.litellm_model": getattr(args, "litellm_model", ""),
        "arks.litellm_endpoint": getattr(args, "litellm_endpoint", ""),
        "arks.retrieval_provider": "mcp",
        "arks.mcp_app_name": args.mcp_app_name,
        "arks.lakebase_name": args.lakebase_name,
        "arks.dependency_digest": requirements_digest,
    }

    input_example = {
        "input": [{"role": "user", "content": "Review endpoint packaging test"}],
        "custom_inputs": {"session_id": "review-model-packaging-test"},
    }
    with tempfile.TemporaryDirectory(prefix="arks-review-prompts-") as snapshot_dir:
        snapshot_module = _write_snapshot_module(Path(snapshot_dir), snapshots)
        with mlflow.start_run(tags=tags) as run:
            model_info = mlflow.pyfunc.log_model(
                name="agent",
                python_model=str(_REVIEW_MODEL_FILE),
                code_paths=[
                    str(_APP_DIR / "config"),
                    str(_APP_DIR / "models"),
                    str(_APP_DIR / "services"),
                    str(snapshot_module),
                ],
                resources=resources,
                pip_requirements=requirements,
                input_example=input_example,
            )
            registered = mlflow.register_model(
                model_uri=model_info.model_uri,
                name=args.registered_model_name,
            )

    result = ReviewModelRegistration(
        model_name=args.registered_model_name,
        model_version=str(registered.version),
        model_uri=model_info.model_uri,
        run_id=run.info.run_id,
        git_commit=git_commit,
        requirements_digest=requirements_digest,
        agent_prompt_version=agent_prompt["version"],
        agent_prompt_digest=agent_prompt["digest"],
        prompt_snapshot_digest=prompt_snapshot_digest,
    )
    print(json.dumps(result.__dict__, indent=2))
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-deployment-id", required=True)
    parser.add_argument("--experiment-name", required=True)
    parser.add_argument("--registered-model-name", required=True)
    parser.add_argument("--llm-provider", default="litellm")
    parser.add_argument("--llm-endpoint", default="databricks-gpt-5-4")
    parser.add_argument("--litellm-model", default="gpt-5.5")
    parser.add_argument("--litellm-endpoint", default="")
    parser.add_argument("--mcp-app-name", default="mcp-cm-kb-mongodb")
    parser.add_argument("--uc-catalog", default="dev_gaia_experiments")
    parser.add_argument("--uc-schema", default="arks")
    parser.add_argument("--trace-table-prefix", default="arks_review")
    parser.add_argument("--lakebase-name", default="arks-lakebase-v2")
    parser.add_argument("--requirements-file", default=str(_DEFAULT_REQUIREMENTS_FILE))
    parser.add_argument("--git-commit")
    return parser


def main(argv: list[str] | None = None) -> ReviewModelRegistration:
    return register_review_model(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
