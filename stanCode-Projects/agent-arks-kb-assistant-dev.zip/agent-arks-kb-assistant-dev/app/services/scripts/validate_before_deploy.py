"""
Pre-Deploy Validation — run between log_to_databricks and deploy_to_databricks.

Usage (Databricks notebook):
    _version = "22"  # from log_to_databricks output
    exec(open("/Workspace/.../validate_before_deploy.py").read())

Checks:
    1. Model version exists and is READY
    2. Model resources — Lakebase absent (InMemory mode) or present (Lakebase mode)
    3. Lakebase Autoscaling project available (skipped when EXPECTED_LAKEBASE is empty)
    4. CheckpointSaver connection (skipped when EXPECTED_LAKEBASE is empty)
    5. Endpoint state is clean (no stale served entities)
    6. Required pip packages are importable
"""

from __future__ import annotations

import sys

# ---------------------------------------------------------------------------
# Config — keep in sync with log_to_databricks.py / deploy_to_databricks.py
# ---------------------------------------------------------------------------
CATALOG        = "gaia_experiments"
SCHEMA         = "arks"
MODEL_NAME     = "arks_agent"
ENDPOINT_NAME  = "arks-agent"
UC_MODEL_PATH  = f"{CATALOG}.{SCHEMA}.{MODEL_NAME}"

# Set to the Lakebase Autoscaling project name when using persistent memory,
# or leave empty ("") to use InMemorySaver (no Lakebase dependency).
EXPECTED_LAKEBASE = ""
EXPECTED_LAKEBASE_BRANCH = "production"

# Model version — must be set before running
if "_version" not in dir() and len(sys.argv) > 1:
    _version = sys.argv[1]

try:
    MODEL_VERSION = str(int(_version))  # type: ignore[name-defined]
except Exception:
    print("ERROR: Set _version before running this script.")
    print("  Example: _version = '22'")
    raise SystemExit(1)

_passed = 0
_failed = 0


def _check(name: str, ok: bool, detail: str = ""):
    global _passed, _failed
    status = "PASS" if ok else "FAIL"
    msg = f"  [{status}] {name}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    if ok:
        _passed += 1
    else:
        _failed += 1


def _skip(name: str, reason: str = ""):
    msg = f"  [SKIP] {name}"
    if reason:
        msg += f" — {reason}"
    print(msg)


print(f"Validating {UC_MODEL_PATH} version {MODEL_VERSION} for endpoint '{ENDPOINT_NAME}'")
if EXPECTED_LAKEBASE:
    print(f"Memory mode: Lakebase ({EXPECTED_LAKEBASE})")
else:
    print("Memory mode: InMemory (no Lakebase dependency)")
print("=" * 70)

# ---------------------------------------------------------------------------
# 1. Model version exists and is READY
# ---------------------------------------------------------------------------
print("\n1. Model Version")
try:
    from mlflow import MlflowClient
    import mlflow
    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()
    mv = client.get_model_version(name=UC_MODEL_PATH, version=MODEL_VERSION)
    _check("Model version exists", True, f"version={mv.version}")
    _check("Model status is READY", mv.status == "READY", f"status={mv.status}")
except Exception as e:
    _check("Model version exists", False, str(e))

# ---------------------------------------------------------------------------
# 2. Model resources — verify Lakebase presence matches memory mode
# ---------------------------------------------------------------------------
print("\n2. Model Resources")
try:
    from pathlib import Path
    import tempfile

    local_path = mlflow.artifacts.download_artifacts(
        artifact_uri=f"models:/{UC_MODEL_PATH}/{MODEL_VERSION}",
        dst_path=tempfile.mkdtemp(),
    )
    mlmodel_path = Path(local_path) / "MLmodel"
    if mlmodel_path.exists():
        content = mlmodel_path.read_text()
        has_lakebase = "lakebase" in content.lower() or "database_instance" in content.lower()

        if EXPECTED_LAKEBASE:
            # Lakebase mode: resource must be present
            if EXPECTED_LAKEBASE in content:
                _check("Lakebase resource present", True, f"found '{EXPECTED_LAKEBASE}'")
            else:
                _check("Lakebase resource present", False,
                       "not found in MLmodel — re-run log_to_databricks with DATABRICKS_LAKEBASE_NAME set")
        else:
            # InMemory mode: Lakebase resource must NOT be present (causes PERMISSION_DENIED)
            _check("No Lakebase resource (InMemory mode)", not has_lakebase,
                   "Lakebase found in MLmodel — re-run log_to_databricks with lakebase_name empty"
                   if has_lakebase else "")
    else:
        _check("MLmodel file found", False, "artifact download may have failed")
except Exception as e:
    _check("Model resources check", False, str(e))

# ---------------------------------------------------------------------------
# 3. Lakebase Autoscaling project is AVAILABLE (skipped in InMemory mode)
# ---------------------------------------------------------------------------
print("\n3. Lakebase Project")
if not EXPECTED_LAKEBASE:
    _skip("Lakebase project", "InMemory mode — no Lakebase configured")
else:
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient()
        project = w.postgres.get_project(name=f"projects/{EXPECTED_LAKEBASE}")
        _check("Project exists", True, f"name={project.name}")
        endpoints = list(w.postgres.list_endpoints(
            parent=f"projects/{EXPECTED_LAKEBASE}/branches/{EXPECTED_LAKEBASE_BRANCH}"
        ))
        if endpoints:
            ep = w.postgres.get_endpoint(name=endpoints[0].name)
            host = getattr(getattr(ep, "status", None), "hosts", None)
            host_str = getattr(host, "host", None) if host else None
            _check("Endpoint exists", True, f"endpoint={endpoints[0].name}")
            _check("Host available", bool(host_str), f"host={host_str}")
        else:
            _check("Endpoint exists", False, "no endpoints found on branch")
    except Exception as e:
        _check("Project exists", False, str(e))

# ---------------------------------------------------------------------------
# 4. CheckpointSaver connection (skipped in InMemory mode)
# ---------------------------------------------------------------------------
print("\n4. CheckpointSaver Connection")
if not EXPECTED_LAKEBASE:
    _skip("CheckpointSaver", "InMemory mode — using langgraph InMemorySaver")
else:
    try:
        from databricks_langchain import CheckpointSaver
        saver = CheckpointSaver(project=EXPECTED_LAKEBASE, branch=EXPECTED_LAKEBASE_BRANCH)
        _check("CheckpointSaver connects", True)
    except ImportError as e:
        _check("CheckpointSaver connects", False, f"import error: {e}")
    except Exception as e:
        _check("CheckpointSaver connects", False, str(e))

# ---------------------------------------------------------------------------
# 5. Endpoint state — check for stale served entities
# ---------------------------------------------------------------------------
print("\n5. Endpoint State")
try:
    from databricks.sdk import WorkspaceClient
    w = WorkspaceClient()
    ep_raw = w.api_client.do("GET", f"/api/2.0/serving-endpoints/{ENDPOINT_NAME}")
    state = ep_raw.get("state", {})
    config_update = state.get("config_update", "NOT_UPDATING")
    _check("Endpoint not updating", config_update == "NOT_UPDATING", f"config_update={config_update}")

    served = ep_raw.get("config", {}).get("served_models", [])
    pending = ep_raw.get("pending_config", {}).get("served_models", [])
    _check("Served entities count", True, f"active={len(served)}, pending={len(pending)}")

    for sm in served + pending:
        v = sm.get("model_version")
        name = sm.get("name")
        if str(v) != MODEL_VERSION:
            _check(f"Old entity: {name}", False, f"version={v} (expected {MODEL_VERSION})")
except Exception as e:
    if "RESOURCE_DOES_NOT_EXIST" in str(e) or "NOT_FOUND" in str(e):
        _check("Endpoint exists", True, "not found — will be created fresh by agents.deploy()")
    else:
        _check("Endpoint state", False, str(e))

# ---------------------------------------------------------------------------
# 6. Required packages
# ---------------------------------------------------------------------------
print("\n6. Required Packages")
_required = [
    ("mlflow", "mlflow"),
    ("databricks_langchain", "databricks-langchain"),
    ("databricks.agents", "databricks-agents"),
    ("langgraph", "langgraph"),
    ("langchain", "langchain"),
]
for mod_name, pip_name in _required:
    try:
        __import__(mod_name)
        _check(f"{pip_name}", True)
    except ImportError:
        _check(f"{pip_name}", False, f"run: %pip install {pip_name}")

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print(f"Results: {_passed} passed, {_failed} failed")
if _failed > 0:
    print("\nFix the FAIL items before running deploy_to_databricks.py")
else:
    print("\nAll checks passed — safe to deploy.")
