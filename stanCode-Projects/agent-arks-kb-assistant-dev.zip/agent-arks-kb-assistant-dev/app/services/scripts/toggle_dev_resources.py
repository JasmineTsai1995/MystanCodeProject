"""Start or stop Arks development Databricks resources.

This script is intended to run from Databricks Jobs on serverless compute.
It toggles the Databricks Apps used by the agent stack and the Lakebase
Autoscaling project used for development memory.
"""

from __future__ import annotations

import argparse
import time
from typing import Literal

from databricks.sdk import WorkspaceClient


APP_NAMES = ("arks-agent", "mcp-cm-kb-mongodb")
LAKEBASE_INSTANCE = "arks-lakebase-v2"
LAKEBASE_PROJECT = "projects/arks-lakebase-v2"
# Autoscale endpoint CU range — prevents reset to default 4-8 CU on start
LAKEBASE_MIN_CU = 0.5
LAKEBASE_MAX_CU = 1.0


def _state_name(state: object) -> str:
    value = getattr(state, "value", None)
    if value:
        return str(value).split(".")[-1].upper()

    name = getattr(state, "name", None)
    if name:
        return str(name).split(".")[-1].upper()

    return str(state or "").split(".")[-1].upper()


def _get_databricks_app(w: WorkspaceClient, app_name: str):
    get_app = getattr(w.apps, "get", None)
    if callable(get_app):
        return get_app(name=app_name)

    list_apps = getattr(w.apps, "list", None)
    if callable(list_apps):
        for app in list_apps():
            if getattr(app, "name", None) == app_name:
                return app

    return w.api_client.do(
        method="GET",
        path=f"/api/2.0/apps/{app_name}",
    )


def _get_app_state(w: WorkspaceClient, app_name: str) -> str:
    app = _get_databricks_app(w, app_name)
    compute_status = app.get("compute_status") if isinstance(app, dict) else getattr(app, "compute_status", None)
    state = compute_status.get("state") if isinstance(compute_status, dict) else getattr(compute_status, "state", None)
    return _state_name(state)


def _is_redundant_app_action_error(
    error: Exception,
    desired_state: str,
) -> bool:
    message = str(error)
    return (
        desired_state == "STOPPED"
        and "compute is in STOPPED state" in message
    ) or (
        desired_state == "ACTIVE"
        and "compute is in ACTIVE state" in message
    )


def _wait_for_app_state(
    w: WorkspaceClient,
    app_name: str,
    desired_state: str,
    timeout_seconds: int,
) -> None:
    deadline = time.monotonic() + timeout_seconds
    last_state = ""
    while time.monotonic() < deadline:
        last_state = _get_app_state(w, app_name)
        if last_state == desired_state:
            print(f"App {app_name}: {last_state}")
            return
        print(f"App {app_name}: waiting for {desired_state}, current={last_state}")
        time.sleep(15)
    raise TimeoutError(f"App {app_name} did not reach {desired_state}; last={last_state}")


def _toggle_apps(
    w: WorkspaceClient,
    action: Literal["start", "stop"],
    timeout_seconds: int,
) -> None:
    desired_state = "ACTIVE" if action == "start" else "STOPPED"
    verb = "Starting" if action == "start" else "Stopping"
    for app_name in APP_NAMES:
        current_state = _get_app_state(w, app_name)
        if current_state == desired_state:
            print(f"App {app_name}: already {desired_state}")
            continue

        print(f"{verb} app {app_name}")
        try:
            if action == "start":
                w.apps.start(app_name)
            else:
                w.apps.stop(app_name)
        except Exception as exc:
            if _is_redundant_app_action_error(exc, desired_state):
                print(f"App {app_name}: already {desired_state}")
                continue
            raise

        _wait_for_app_state(w, app_name, desired_state, timeout_seconds)


def _set_lakebase_endpoint_cu(w: WorkspaceClient) -> None:
    """Set the autoscale endpoint CU range after instance start.

    The Database Instance API stop/start resets the autoscale endpoint
    settings to defaults derived from instance capacity.  This restores
    the desired CU range via the Postgres API.
    """
    try:
        endpoints = list(w.postgres.list_endpoints(parent=f"{LAKEBASE_PROJECT}/branches/production"))
    except Exception as exc:
        print(f"Warning: could not list Lakebase endpoints: {exc}")
        return

    for ep in endpoints:
        ep_name = ep.name
        try:
            w.api_client.do(
                "PATCH",
                f"/api/2.0/postgres/endpoints/{ep_name}",
                body={
                    "autoscaling_limit_min_cu": LAKEBASE_MIN_CU,
                    "autoscaling_limit_max_cu": LAKEBASE_MAX_CU,
                },
            )
            print(
                f"Lakebase endpoint {ep_name}: "
                f"CU set to {LAKEBASE_MIN_CU}-{LAKEBASE_MAX_CU}"
            )
        except Exception as exc:
            print(f"Warning: could not set CU for endpoint {ep_name}: {exc}")


def _toggle_lakebase(w: WorkspaceClient, action: Literal["start", "stop"]) -> None:
    """Start or stop the Lakebase Autoscaling project's compute endpoint.

    Uses the Postgres API to suspend/resume the primary endpoint on the
    production branch.  After resume, restores the desired CU range.
    """
    verb = "Starting" if action == "start" else "Stopping"
    try:
        endpoints = list(w.postgres.list_endpoints(
            parent=f"{LAKEBASE_PROJECT}/branches/production"
        ))
    except Exception as exc:
        print(f"Warning: could not list Lakebase endpoints: {exc}")
        return

    if not endpoints:
        print(f"Warning: no endpoints found for {LAKEBASE_PROJECT}")
        return

    for ep in endpoints:
        ep_name = ep.name
        current_state = getattr(getattr(ep, "status", None), "current_state", None)
        print(f"{verb} Lakebase endpoint {ep_name} (current_state={current_state})")
        try:
            if action == "stop":
                w.postgres.suspend_endpoint(name=ep_name).wait()
            else:
                w.postgres.resume_endpoint(name=ep_name).wait()
        except Exception as exc:
            msg = str(exc)
            if "already" in msg.lower() or "INVALID_STATE" in msg:
                print(f"Lakebase endpoint {ep_name}: already {'suspended' if action == 'stop' else 'active'}")
            else:
                print(f"Warning: could not {action} endpoint {ep_name}: {exc}")

    # After start, restore the desired autoscale endpoint CU range
    if action == "start":
        _set_lakebase_endpoint_cu(w)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("start", "stop"))
    parser.add_argument("--app-timeout-seconds", type=int, default=1200)
    args = parser.parse_args()

    w = WorkspaceClient()

    if args.action == "start":
        _toggle_lakebase(w, "start")
        _toggle_apps(w, "start", args.app_timeout_seconds)
    else:
        _toggle_apps(w, "stop", args.app_timeout_seconds)
        _toggle_lakebase(w, "stop")


if __name__ == "__main__":
    main()
