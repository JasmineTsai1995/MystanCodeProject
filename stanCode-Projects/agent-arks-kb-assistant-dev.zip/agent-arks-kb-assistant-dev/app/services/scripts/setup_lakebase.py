"""Set up Lakebase Autoscaling for Arks Agent.

Creates the App SP's Postgres role and grants schema permissions so the
App can create and own checkpoint tables at startup.

This script runs as the deploying user (project owner) who has full
PostgreSQL privileges.  It must run AFTER the Lakebase project and App
are created by DABs deploy.

Table creation is intentionally left to the App's AsyncCheckpointSaver
.setup() — this ensures the SP owns the tables and can run future
migrations without "must be owner" errors.

Usage (Databricks Job via DABs):
    spark_python_task:
      python_file: ./app/services/scripts/setup_lakebase.py
      parameters:
        - --project
        - arks-lakebase-v2
        - --app-name
        - arks-agent

Usage (CLI):
    python setup_lakebase.py --project arks-lakebase-v2 --app-name arks-agent
    python setup_lakebase.py --project arks-lakebase-v2 \
        --sp-client-id <serving-endpoint-sp-client-id> \
        --grant-table-privileges --skip-drop-checkpoint-tables
"""

from __future__ import annotations

import argparse

import psycopg
from databricks.sdk import WorkspaceClient


def get_app_sp_client_id(w: WorkspaceClient, app_name: str) -> str:
    """Resolve the App's auto-generated Service Principal client ID."""
    app = w.apps.get(name=app_name)
    sp_id = getattr(app, "service_principal_client_id", None)
    if not sp_id:
        sp_id = getattr(app, "service_principal_id", None)
    if not sp_id:
        raise RuntimeError(
            f"Could not find service_principal_client_id on app '{app_name}'. "
            "Ensure the app has been deployed first."
        )
    return str(sp_id)


def get_lakebase_connection(
    w: WorkspaceClient, project: str, branch: str = "production"
) -> psycopg.Connection:
    """Connect to Lakebase Autoscaling as the current user (owner)."""
    branch_path = f"projects/{project}/branches/{branch}"
    endpoints = list(w.postgres.list_endpoints(parent=branch_path))
    if not endpoints:
        raise RuntimeError(f"No endpoints found for {branch_path}")

    ep = w.postgres.get_endpoint(name=endpoints[0].name)
    host = ep.status.hosts.host

    cred = w.postgres.generate_database_credential(endpoint=endpoints[0].name)
    username = w.current_user.me().user_name

    conn_string = (
        f"host={host} "
        f"dbname=databricks_postgres "
        f"user={username} "
        f"password={cred.token} "
        f"sslmode=require"
    )
    return psycopg.connect(conn_string, autocommit=True)


def setup_sp_role(
    conn: psycopg.Connection,
    sp_client_id: str,
    grant_table_privileges: bool = False,
) -> None:
    """Create Postgres role for the SP and grant schema permissions."""
    cur = conn.cursor()

    # Ensure databricks_auth extension is available
    cur.execute("CREATE EXTENSION IF NOT EXISTS databricks_auth")
    print("  Extension databricks_auth: OK")

    # Create OAuth role for the SP (idempotent — ignores if exists)
    try:
        cur.execute(
            "SELECT databricks_create_role(%s, 'service_principal')",
            (sp_client_id,),
        )
        print(f"  Role created: {sp_client_id}")
    except Exception as exc:
        if "already exists" in str(exc).lower():
            print(f"  Role already exists: {sp_client_id}")
        else:
            raise

    # Grant CONNECT on database
    cur.execute(
        f'GRANT CONNECT ON DATABASE databricks_postgres TO "{sp_client_id}"'
    )
    print("  GRANT CONNECT: OK")

    # Grant CREATE + USAGE on schema public (allows CREATE TABLE)
    cur.execute(
        f'GRANT CREATE, USAGE ON SCHEMA public TO "{sp_client_id}"'
    )
    print("  GRANT CREATE, USAGE ON SCHEMA public: OK")

    if grant_table_privileges:
        cur.execute(
            f'GRANT SELECT, INSERT, UPDATE, DELETE '
            f'ON ALL TABLES IN SCHEMA public TO "{sp_client_id}"'
        )
        print("  GRANT DML ON ALL TABLES IN SCHEMA public: OK")

        cur.execute(
            f'GRANT USAGE, SELECT, UPDATE '
            f'ON ALL SEQUENCES IN SCHEMA public TO "{sp_client_id}"'
        )
        print("  GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES: OK")

        cur.execute(
            f'ALTER DEFAULT PRIVILEGES IN SCHEMA public '
            f'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO "{sp_client_id}"'
        )
        print("  ALTER DEFAULT PRIVILEGES FOR TABLES: OK")

        cur.execute(
            f'ALTER DEFAULT PRIVILEGES IN SCHEMA public '
            f'GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO "{sp_client_id}"'
        )
        print("  ALTER DEFAULT PRIVILEGES FOR SEQUENCES: OK")

    cur.close()


_CHECKPOINT_TABLES = [
    "checkpoint_writes",
    "checkpoint_blobs",
    "checkpoints",
    "checkpoint_migrations",
]


def drop_owner_checkpoint_tables(conn: psycopg.Connection) -> None:
    """Drop checkpoint tables owned by the deploying user (if any).

    Tables created by the deploying user cause "must be owner" errors
    when the App SP tries to run migrations.  Dropping them lets the SP
    recreate them as the owner via AsyncCheckpointSaver.setup().
    """
    cur = conn.cursor()
    cur.execute(
        "SELECT tablename FROM pg_tables "
        "WHERE schemaname='public' AND tablename = ANY(%s)",
        (list(_CHECKPOINT_TABLES),),
    )
    existing = [row[0] for row in cur.fetchall()]
    if not existing:
        print("  No existing checkpoint tables to drop")
        cur.close()
        return

    for table in _CHECKPOINT_TABLES:
        if table in existing:
            cur.execute(f"DROP TABLE IF EXISTS {table} CASCADE")
            print(f"  Dropped: {table}")
    cur.close()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, help="Lakebase project ID")
    parser.add_argument("--branch", default="production")
    parser.add_argument("--app-name", help="Databricks App name")
    parser.add_argument(
        "--sp-client-id",
        help="Service principal client ID to grant directly",
    )
    parser.add_argument(
        "--grant-table-privileges",
        action="store_true",
        help="Grant DML on existing public schema tables to the SP",
    )
    parser.add_argument(
        "--skip-drop-checkpoint-tables",
        action="store_true",
        help="Do not drop existing LangGraph checkpoint tables",
    )
    args = parser.parse_args(argv)

    if not args.app_name and not args.sp_client_id:
        parser.error("one of --app-name or --sp-client-id is required")

    w = WorkspaceClient()

    print("=" * 60)
    target = f"app={args.app_name}" if args.app_name else f"sp={args.sp_client_id}"
    print(f"Lakebase Setup — project={args.project}, {target}")
    print("=" * 60)

    # 1. Resolve App SP
    if args.sp_client_id:
        print("\n1. Using provided Service Principal client ID...")
        sp_client_id = args.sp_client_id
        print(f"  SP client_id: {sp_client_id}")
    else:
        print("\n1. Resolving App Service Principal...")
        sp_client_id = get_app_sp_client_id(w, args.app_name or "")
        print(f"  App SP client_id: {sp_client_id}")

    # 2. Connect to Lakebase as owner
    print("\n2. Connecting to Lakebase as owner...")
    conn = get_lakebase_connection(w, args.project, args.branch)
    print("  Connected")

    # 3. Create SP role and grant schema permissions
    print("\n3. Setting up SP Postgres role...")
    setup_sp_role(conn, sp_client_id, args.grant_table_privileges)

    # 4. Drop checkpoint tables owned by deploying user (if any)
    #    The App SP will recreate them via AsyncCheckpointSaver.setup()
    #    so that the SP owns them and can run future migrations.
    if args.skip_drop_checkpoint_tables:
        print("\n4. Skipping checkpoint table drop")
    else:
        print("\n4. Dropping deployer-owned checkpoint tables (if any)...")
        drop_owner_checkpoint_tables(conn)

    conn.close()

    print("\n" + "=" * 60)
    print("Setup complete.")
    print("  - SP role created with CREATE, USAGE on schema public")
    if args.grant_table_privileges:
        print("  - Existing table and sequence privileges granted")
    if args.skip_drop_checkpoint_tables:
        print("  - Existing checkpoint tables preserved")
    else:
        print("  - Old checkpoint tables dropped (App will recreate on startup)")
    print("=" * 60)


if __name__ == "__main__":
    main()
