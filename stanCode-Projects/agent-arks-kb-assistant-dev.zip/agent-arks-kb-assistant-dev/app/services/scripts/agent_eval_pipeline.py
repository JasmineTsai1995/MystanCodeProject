"""
Shared helpers for the MLflow GenAI evaluation pipeline.

This module keeps the agent-evaluation path local to the codebase:
  1. Build the current Arks agent in-process.
  2. Wrap it in a predict_fn compatible with mlflow.genai.evaluate().
  3. Load JSON datasets or MLflow-managed datasets.
  4. Pick a sensible default scorer set based on dataset contents.

Typical usage:
    from services.scripts.agent_eval_pipeline import (
        build_local_predict_fn,
        build_default_scorers,
        load_json_records,
    )
"""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Iterable

import mlflow
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from mlflow.genai.scorers import (
    Correctness,
    ExpectationsGuidelines,
    Guidelines,
    RelevanceToQuery,
    Safety,
)

from config.prompts import AGENT_SYSTEM_PROMPT
from services.core.agent import create_core_agent
from services.core.memory.store import get_checkpointer
from services.integrations.mlflow.trace_location import configure_experiment_trace_location
from services.tools.registry import get_tools


def configure_mlflow(tracking_uri: str | None = None, experiment: str | None = None) -> None:
    """Apply MLflow tracking settings and enable LangChain autologging."""
    if tracking_uri:
        mlflow.set_tracking_uri(tracking_uri)
    if experiment:
        mlflow.set_experiment(experiment)
        configure_experiment_trace_location(experiment_name=experiment, required=False)
    mlflow.langchain.autolog()


def load_json_records(path: str | Path) -> list[dict[str, Any]]:
    """Load evaluation records from a JSON file."""
    dataset_path = Path(path)
    records = json.loads(dataset_path.read_text(encoding="utf-8"))
    if not isinstance(records, list):
        raise ValueError(f"{dataset_path} must contain a JSON list of evaluation records.")
    validated = [normalize_record(record, index=i) for i, record in enumerate(records)]
    return validated


def normalize_record(record: dict[str, Any], index: int = 0) -> dict[str, Any]:
    """Validate one MLflow GenAI dataset record."""
    if not isinstance(record, dict):
        raise ValueError(f"Record #{index} must be an object.")

    inputs = record.get("inputs")
    if not isinstance(inputs, dict):
        raise ValueError(f"Record #{index} must contain an object field named 'inputs'.")

    if "messages" not in inputs and "query" not in inputs:
        raise ValueError(
            f"Record #{index} must provide either inputs.messages or inputs.query."
        )

    expectations = record.get("expectations")
    if expectations is not None and not isinstance(expectations, dict):
        raise ValueError(f"Record #{index} expectations must be an object when provided.")

    outputs = record.get("outputs")
    if outputs is not None and not isinstance(outputs, dict):
        raise ValueError(f"Record #{index} outputs must be an object when provided.")

    return record


def _get_message_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                text = block.get("text")
                if text:
                    parts.append(str(text))
            elif isinstance(block, str):
                parts.append(block)
        return "\n".join(parts).strip()
    return str(content)


def _extract_final_response(messages: Iterable[Any]) -> str:
    for message in reversed(list(messages)):
        if isinstance(message, AIMessage):
            return _get_message_text(message.content)
        if isinstance(message, BaseMessage) and getattr(message, "type", "") == "ai":
            return _get_message_text(message.content)
        if isinstance(message, dict) and message.get("role") == "assistant":
            return _get_message_text(message.get("content", ""))
    return ""


def _to_langchain_messages(inputs: dict[str, Any]) -> list[Any]:
    if "messages" in inputs:
        return inputs["messages"]
    return [HumanMessage(content=str(inputs["query"]))]


def _run_coro_sync(coro: Any) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    with ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(lambda: asyncio.run(coro)).result()


def build_local_agent(
    *,
    skip_mcp_tool_init: bool = False,
    use_reflection: bool = True,
    use_followup: bool = False,
):
    """Construct the local agent used by evaluation."""
    if skip_mcp_tool_init:
        os.environ["SKIP_MCP_TOOL_INIT"] = "true"

    tools = get_tools()
    return create_core_agent(
        tools=tools,
        system_prompt=AGENT_SYSTEM_PROMPT,
        checkpointer=get_checkpointer(),
        use_reflection=use_reflection,
        use_followup=use_followup,
    )


def build_local_predict_fn(
    *,
    skip_mcp_tool_init: bool = False,
    use_reflection: bool = True,
    use_followup: bool = False,
):
    """Return a predict_fn compatible with mlflow.genai.evaluate()."""
    agent = build_local_agent(
        skip_mcp_tool_init=skip_mcp_tool_init,
        use_reflection=use_reflection,
        use_followup=use_followup,
    )

    @mlflow.trace(name="arks_agent_predict")
    def predict_fn(**inputs: Any) -> dict[str, str]:
        messages = _to_langchain_messages(inputs)
        thread_id = str(inputs.get("thread_id") or f"eval-{uuid.uuid4()}")
        result = _run_coro_sync(
            agent.ainvoke(
                {"messages": messages},
                config={"configurable": {"thread_id": thread_id}},
            )
        )
        response = _extract_final_response(result["messages"])
        return {"response": response}

    return predict_fn


def build_default_scorers(
    records: list[dict[str, Any]],
    *,
    judge_model: str | None = None,
    include_groundedness: bool = False,
) -> list[Any]:
    """Build a scorer list that matches the available expectations."""
    scorer_kwargs = {}
    if judge_model:
        scorer_kwargs["model"] = judge_model

    scorers: list[Any] = [
        Safety(**scorer_kwargs),
        RelevanceToQuery(**scorer_kwargs),
        Guidelines(
            name="helpful_and_actionable",
            guidelines=[
                "The response must directly answer the user's request.",
                "The response must stay grounded in available tool results or agent knowledge.",
                "The response should be specific and practical, not vague filler.",
            ],
            **scorer_kwargs,
        ),
    ]

    has_expected_response = any(
        isinstance(record.get("expectations"), dict)
        and (
            record["expectations"].get("expected_response")
            or record["expectations"].get("expected_facts")
        )
        for record in records
    )
    if has_expected_response:
        scorers.append(Correctness(**scorer_kwargs))

    has_guidelines = any(
        isinstance(record.get("expectations"), dict)
        and record["expectations"].get("guidelines")
        for record in records
    )
    if has_guidelines:
        scorers.append(ExpectationsGuidelines())

    if include_groundedness:
        from mlflow.genai.scorers import RetrievalGroundedness

        scorers.append(RetrievalGroundedness(**scorer_kwargs))

    return scorers


def get_managed_dataset(uc_table_name: str):
    """Return an MLflow-managed dataset object."""
    import mlflow.genai.datasets as datasets

    return datasets.get_dataset(uc_table_name)
