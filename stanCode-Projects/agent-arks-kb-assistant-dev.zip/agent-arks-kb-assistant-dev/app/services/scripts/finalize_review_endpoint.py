"""Wait for a review endpoint, bind it to the Review App, and verify traces."""

from __future__ import annotations

import argparse
from datetime import timedelta
import inspect
from pathlib import Path
import sys

import mlflow
from databricks import agents
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import EndpointStateReady
from mlflow.genai.labeling import get_review_app


def _current_script_dir() -> Path:
    """Return this script directory even when Databricks Jobs omits __file__."""
    filename = globals().get("__file__")
    if not filename:
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Could not resolve finalize_review_endpoint.py location.")
        filename = frame.f_code.co_filename
    return Path(filename).resolve().parent


_SCRIPT_DIR = _current_script_dir()
_APP_DIR = _SCRIPT_DIR.parents[1]
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

from verify_review_endpoint import main as verify_review_endpoint
from services.integrations.mlflow.trace_location import configure_experiment_trace_location


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-deployment-id", required=True)
    parser.add_argument("--experiment-name", required=True)
    parser.add_argument("--registered-model-name", required=True)
    parser.add_argument("--endpoint-name", default="arks-agent-review")
    parser.add_argument("--uc-catalog", default="dev_gaia_experiments")
    parser.add_argument("--uc-schema", default="arks")
    parser.add_argument("--trace-table-prefix", default="arks_review")
    parser.add_argument(
        "--reviewers",
        help="Comma-separated account user emails or groups granted CAN_QUERY.",
    )
    parser.add_argument("--endpoint-timeout-minutes", type=int, default=60)
    parser.add_argument("--skip-smoke-test", action="store_true")
    parser.add_argument("--trace-wait-seconds", type=int, default=10)
    parser.add_argument("--expected-prompt-version")
    parser.add_argument("--expected-prompt-digest")
    return parser


def wait_for_endpoint_ready(endpoint_name: str, timeout_minutes: int) -> None:
    """Wait until an endpoint update has completed and it accepts queries."""
    client = WorkspaceClient()
    print(f"Waiting for Model Serving endpoint to become ready: {endpoint_name}")
    endpoint = client.serving_endpoints.wait_get_serving_endpoint_not_updating(
        name=endpoint_name,
        timeout=timedelta(minutes=timeout_minutes),
    )
    if endpoint.state is None or endpoint.state.ready != EndpointStateReady.READY:
        state = endpoint.state.as_dict() if endpoint.state else {}
        raise RuntimeError(f"Endpoint is no longer updating but is not ready: {state}")
    print(f"Model Serving endpoint is ready: {endpoint_name}")


def finalize_review_endpoint(args: argparse.Namespace) -> None:
    uc_catalog = getattr(args, "uc_catalog", "dev_gaia_experiments")
    uc_schema = getattr(args, "uc_schema", "arks")
    trace_table_prefix = getattr(args, "trace_table_prefix", "arks_review")
    wait_for_endpoint_ready(args.endpoint_name, args.endpoint_timeout_minutes)

    mlflow.set_tracking_uri("databricks")
    mlflow.set_experiment(args.experiment_name)
    configure_experiment_trace_location(
        experiment_name=args.experiment_name,
        catalog=uc_catalog,
        schema=uc_schema,
        table_prefix=trace_table_prefix,
        required=True,
    )
    if not args.skip_smoke_test:
        verify_review_endpoint(
            [
                "--endpoint-name",
                args.endpoint_name,
                "--experiment-name",
                args.experiment_name,
                "--review-deployment-id",
                args.review_deployment_id,
                "--uc-catalog",
                uc_catalog,
                "--uc-schema",
                uc_schema,
                "--trace-table-prefix",
                trace_table_prefix,
                "--wait-seconds",
                str(args.trace_wait_seconds),
                *(
                    ["--expected-prompt-version", args.expected_prompt_version]
                    if args.expected_prompt_version
                    else []
                ),
                *(
                    ["--expected-prompt-digest", args.expected_prompt_digest]
                    if args.expected_prompt_digest
                    else []
                ),
            ]
        )

    review_app = get_review_app()
    review_app.add_agent(
        agent_name=args.endpoint_name,
        model_serving_endpoint=args.endpoint_name,
    )

    reviewers = [value.strip() for value in (args.reviewers or "").split(",") if value.strip()]
    if reviewers:
        agents.set_permissions(
            model_name=args.registered_model_name,
            users=reviewers,
            permission_level=agents.PermissionLevel.CAN_QUERY,
        )

    print(f"Endpoint: {args.endpoint_name}")
    print(f"Review App: {review_app.url}/chat")
    print(f"Experiment: {args.experiment_name}")


def main(argv: list[str] | None = None) -> None:
    finalize_review_endpoint(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
