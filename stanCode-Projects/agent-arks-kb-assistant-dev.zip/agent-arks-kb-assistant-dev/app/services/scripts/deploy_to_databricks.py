"""
[LEGACY — Serving Endpoint deployment]

This script was used to deploy the registered UC model to a Model Serving
endpoint via agents.deploy(). It has been superseded by Databricks App
deployment using DABs (Databricks Asset Bundles).

New deployment flow:
    databricks bundle validate
    databricks bundle deploy
    databricks bundle run arks_agent

The original code is preserved below (commented out) for reference / rollback.
"""

# ===========================================================================
# [LEGACY — Serving Endpoint deployment code]
# ===========================================================================
#
# """
# Phase 3 — Deploy Agent to Databricks Model Serving
#
# Deploys the registered UC model to a Model Serving endpoint via agents.deploy().
# Deployment takes ~15 minutes.
#
# Run options:
#
#   Option A — Directly in a Databricks notebook (synchronous, waits ~15 min):
#       %pip install -U databricks-agents
#       exec(open("/Workspace/.../deploy_to_databricks.py").read())
#
#   Option B — As a Databricks Job (recommended, non-blocking):
#       1. Upload this file to your Workspace.
#       2. Create a job with spark_python_task pointing to this file.
#       3. Pass MODEL_VERSION as a job parameter if needed.
#       4. Trigger the job and monitor via the Jobs UI.
#
# Before running:
#     Ensure CATALOG / SCHEMA / MODEL_NAME / ENDPOINT_NAME match your setup.
#     These should match what was used in log_to_databricks.py.
# """
#
# from __future__ import annotations
#
# import sys
#
# from databricks import agents
# from databricks.sdk import WorkspaceClient
#
# # -----------------------------------------------------------------------------
# # Deployment target — keep in sync with log_to_databricks.py
# # -----------------------------------------------------------------------------
# CATALOG       = "gaia_experiments"
# SCHEMA        = "arks"
# MODEL_NAME    = "arks_agent"
# ENDPOINT_NAME = "arks-agent"           # Explicit name avoids auto-generated surprises
#
# # Model version to deploy — override via command-line arg: python deploy_to_databricks.py 2
# # Fall back to "1" if argv[1] is not a valid integer (e.g. notebook flags like -f)
# def _parse_version() -> str:
#     if len(sys.argv) > 1:
#         try:
#             return str(int(sys.argv[1]))
#         except ValueError:
#             pass
#     return "1"
#
# MODEL_VERSION = _parse_version()
#
# UC_MODEL_PATH = f"{CATALOG}.{SCHEMA}.{MODEL_NAME}"
#
# # -----------------------------------------------------------------------------
# # Extra environment variables to apply after deploy
# # agents.deploy() resets env vars, so we patch them back via SDK.
# # Secrets are referenced as {{secrets/<scope>/<key>}}.
# # -----------------------------------------------------------------------------
# EXTRA_ENV_VARS = {
#     "MCP_APP_URL": "{{secrets/arks/mcp_app_url}}",
#     "AGENT_STREAMING_ENABLED": "true",
#     "DATABRICKS_LAKEBASE_NAME": "arks-lakebase",
# }
#
# # -----------------------------------------------------------------------------
# # Deploy
# # -----------------------------------------------------------------------------
# print(f"Deploying {UC_MODEL_PATH} version {MODEL_VERSION} → endpoint '{ENDPOINT_NAME}' ...")
# print("This takes ~15 minutes. Grab a coffee.")
#
# deployment = agents.deploy(
#     UC_MODEL_PATH,
#     MODEL_VERSION,
#     endpoint_name=ENDPOINT_NAME,
#     tags={"source": "deploy_to_databricks.py"},
# )
#
# # Patch env vars back via REST API (agents.deploy resets env vars to defaults).
# # Must wait for the deployment to finish before updating config.
# if EXTRA_ENV_VARS:
#     import time
#
#     w = WorkspaceClient()
#
#     # Wait for endpoint to be ready (deployment takes ~15 min)
#     print("Waiting for endpoint deployment to complete before patching env vars...")
#     while True:
#         ep_raw = w.api_client.do("GET", f"/api/2.0/serving-endpoints/{ENDPOINT_NAME}")
#         state = ep_raw.get("state", {}).get("config_update", "NOT_UPDATING")
#         if state == "NOT_UPDATING":
#             break
#         print(f"  Endpoint state: {state} — checking again in 60s...")
#         time.sleep(60)
#
#     config = ep_raw.get("config", {})
#     all_versions = [sm.get("model_version") for sm in config.get("served_models", [])]
#     stale = [v for v in all_versions if v != MODEL_VERSION]
#     if stale:
#         print(f"  Removing stale versions: {stale}")
#
#     # Keep only the current version; patch env vars at the same time.
#     target_sm = next(
#         (sm for sm in config.get("served_models", []) if sm.get("model_version") == MODEL_VERSION),
#         None,
#     )
#     if target_sm is None:
#         print("  WARNING: target version not found in config — skipping env var patch")
#     else:
#         env = dict(target_sm.get("environment_vars") or {})
#         env.update(EXTRA_ENV_VARS)
#         target_sm["environment_vars"] = env
#         body: dict = {
#             "served_models": [target_sm],
#             "traffic_config": {"routes": [{"served_model_name": target_sm["name"], "traffic_percentage": 100}]},
#         }
#         w.api_client.do(
#             "PUT",
#             f"/api/2.0/serving-endpoints/{ENDPOINT_NAME}/config",
#             body=body,
#         )
#         print(f"  Env vars patched: {list(EXTRA_ENV_VARS.keys())}")
#         print(f"  Active version  : {MODEL_VERSION} (stale removed: {stale or 'none'})")
#
# print()
# print(f"Deployment complete.")
# print(f"  Endpoint name : {deployment.endpoint_name}")
# print(f"  Query URL     : {deployment.query_endpoint}")
# print()
# print("Test with:")
# print(f'  query_serving_endpoint(name="{deployment.endpoint_name}", messages=[{{"role": "user", "content": "你好"}}])')
