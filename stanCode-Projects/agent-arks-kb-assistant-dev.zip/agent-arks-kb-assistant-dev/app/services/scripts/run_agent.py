"""
Run Agent Script

Multi-turn CLI REPL for the core agent with short-term memory.
Each session gets a unique thread_id so conversation history
is preserved across turns within the same process.

Usage (from project root):
    PYTHONPATH=app python -m services.scripts.run_agent

    # Pass an optional fixed thread_id to resume a previous session:
    PYTHONPATH=app python -m services.scripts.run_agent --thread my-session
"""

import logging
import uuid
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parents[3] / ".env")

import argparse

from langchain_core.messages import HumanMessage

from services.core.agent import create_core_agent
from services.core.logging_callback import AgentLoggingCallbackHandler
from services.core.memory.store import get_checkpointer
from config.prompts import AGENT_SYSTEM_PROMPT
from services.tools.retrievers import MongoVectorSearchTool

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s - %(message)s",
    datefmt="%H:%M:%S",
)
# Suppress noisy library loggers
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("pymongo").setLevel(logging.WARNING)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Run the core agent REPL")
    parser.add_argument(
        "--thread",
        default=None,
        help="Thread ID for conversation continuity (default: new UUID per session)",
    )
    args = parser.parse_args()

    thread_id = args.thread or str(uuid.uuid4())
    checkpointer = get_checkpointer()
    tools = [MongoVectorSearchTool.build()]
    agent = create_core_agent(
        tools=tools,
        system_prompt=AGENT_SYSTEM_PROMPT,
        checkpointer=checkpointer,
        use_reflection=True,
    )

    logging_callback = AgentLoggingCallbackHandler()
    config = {
        "configurable": {"thread_id": thread_id},
        "callbacks": [logging_callback],
    }

    print(f"\n[Session] thread_id={thread_id}")
    print("[Type 'exit' or Ctrl-C to quit]\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nBye!")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            print("Bye!")
            break

        result = agent.invoke(
            {"messages": [HumanMessage(content=user_input)]},
            config=config,
        )

        final_message = result["messages"][-1]
        print(f"Agent: {final_message.content}\n")


if __name__ == "__main__":
    main()
