"""Set up MLflow-related resources for Arks Agent.

1. Registers prompts from prompts.yaml to UC Prompt Registry (idempotent).
2. Grants the App Service Principal access to UC Prompt Registry.

This script runs as the deploying user who has ownership of the UC
schema and GRANT privileges.  It must run AFTER the App is created
by DABs deploy.

Usage (Databricks Job via DABs):
    spark_python_task:
      python_file: ./app/services/scripts/setup_mlflow.py
      parameters:
        - --app-name
        - arks-agent

Usage (CLI):
    python setup_mlflow.py --app-name arks-agent
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
from pathlib import Path
import sys
import time
from typing import Any

import yaml
from databricks.sdk import WorkspaceClient

def _current_script_dir() -> Path:
    """Return this script directory even when Databricks Jobs omits __file__."""
    filename = globals().get("__file__")
    if not filename:
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Could not resolve setup_mlflow.py location.")
        filename = frame.f_code.co_filename
    return Path(filename).resolve().parent


_SCRIPT_DIR = _current_script_dir()
_APP_DIR = _SCRIPT_DIR.parents[1]
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))
_PROMPTS_YAML = _SCRIPT_DIR.parents[1] / "config" / "prompts" / "prompts.yaml"

from services.integrations.mlflow.trace_location import configure_experiment_trace_location

# Mapping: prompt function name → dot-notation key in prompts.yaml
_PROMPT_REGISTRY = {
    "arks_agent":               "agent",
    "arks_reflection_review":   "reflection.review",
    "arks_reflection_judge":    "reflection.judge",
    "arks_reflection_revise":   "reflection.revise",
    "arks_followup_system":     "followup.system",
    "arks_followup_questions":  "followup.questions",
}

_PROMPT_ALIAS = "production"


# -- Helpers ---------------------------------------------------------------

class PromptRegistryDisabled(RuntimeError):
    """Raised when the workspace organization has Prompt Registry disabled."""


def _is_prompt_registry_disabled(exc: Exception) -> bool:
    message = str(exc)
    return "FEATURE_DISABLED" in message and "Prompt registry is not enabled" in message

def get_app_sp_client_id(w: WorkspaceClient, app_name: str) -> str:
    """Resolve the App's auto-generated Service Principal client ID."""
    app = w.apps.get(name=app_name)
    sp_id = getattr(app, "service_principal_client_id", None)
    if not sp_id:
        sp_id = getattr(app, "service_principal_id", None)
    if not sp_id:
        raise RuntimeError(
            f"Could not find service_principal_client_id on app '{app_name}'. "
            "Ensure the app has been deployed first."
        )
    return str(sp_id)


def find_warehouse_id(w: WorkspaceClient, preferred_id: str | None = None) -> str:
    """Find a usable SQL warehouse ID."""
    if preferred_id:
        return preferred_id
    warehouses = list(w.warehouses.list())
    running = [wh for wh in warehouses if str(getattr(wh, "state", "")).upper() == "RUNNING"]
    candidates = running or warehouses
    if not candidates:
        raise RuntimeError("No SQL warehouse found. Provide --warehouse-id explicitly.")
    return candidates[0].id


def _statement_state(response: Any) -> str:
    status = getattr(response, "status", None)
    state = getattr(status, "state", None)
    return str(state or "").upper()


def _statement_error(response: Any) -> str:
    status = getattr(response, "status", None)
    error = getattr(status, "error", None)
    if error is None:
        return ""
    message = getattr(error, "message", None)
    return str(message or error)


def _get_statement(w: WorkspaceClient, statement_id: str) -> Any:
    getter = w.statement_execution.get_statement
    try:
        return getter(statement_id=statement_id)
    except TypeError:
        return getter(statement_id)


def _execute_sql(w: WorkspaceClient, warehouse_id: str, stmt: str, label: str) -> bool:
    """Execute a SQL statement and print result. Returns True on success."""
    try:
        response = w.statement_execution.execute_statement(
            statement=stmt,
            warehouse_id=warehouse_id,
            wait_timeout="30s",
        )
        statement_id = str(getattr(response, "statement_id", "") or "")
        for _ in range(30):
            state = _statement_state(response)
            if "SUCCEEDED" in state:
                print(f"  {label}: OK")
                return True
            if any(failed_state in state for failed_state in ("FAILED", "CANCELED", "CANCELLED")):
                error = _statement_error(response)
                print(f"  {label}: failed ({error or state})")
                print(f"    Run manually: {stmt}")
                return False
            if not statement_id:
                break
            time.sleep(2)
            response = _get_statement(w, statement_id)
        state = _statement_state(response) or "UNKNOWN"
        print(f"  {label}: timed out waiting for SQL statement ({state})")
        print(f"    Statement ID: {statement_id or '<unknown>'}")
        print(f"    Run manually: {stmt}")
        return False
    except Exception as exc:
        print(f"  {label}: failed ({exc})")
        print(f"    Run manually: {stmt}")
        return False


def _exception_contains(exc: Exception, *needles: str) -> bool:
    message = str(exc).lower()
    return any(needle.lower() in message for needle in needles)


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _schema_exists(w: WorkspaceClient, catalog: str, schema: str) -> bool:
    schemas_api = getattr(w, "schemas", None)
    if schemas_api is None:
        return False
    full_name = f"{catalog}.{schema}"
    try:
        try:
            schemas_api.get(full_name=full_name)
        except TypeError:
            schemas_api.get(full_name)
        return True
    except Exception as exc:
        if _exception_contains(exc, "not_found", "does not exist", "not exist"):
            return False
        raise


def _wait_for_schema(
    w: WorkspaceClient,
    catalog: str,
    schema: str,
    timeout_seconds: int = 30,
) -> bool:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _schema_exists(w, catalog, schema):
            return True
        time.sleep(2)
    return _schema_exists(w, catalog, schema)


def _read_yaml_key(data: dict, key: str) -> str:
    """Traverse dot-notation key in parsed YAML data."""
    node: Any = data
    for part in key.split("."):
        node = node[part]
    if not isinstance(node, str):
        raise TypeError(f"Key '{key}' is not a string in prompts.yaml")
    return node


# -- Step: Register prompts ------------------------------------------------

def register_prompts(catalog: str, schema: str) -> list[str]:
    """Register prompts from prompts.yaml to UC Prompt Registry.

    Idempotent: skips registration if the prompt already exists with
    the same template content. Always ensures the production alias is set.

    Returns list of registered function names.
    """
    import mlflow

    mlflow.set_tracking_uri("databricks")
    mlflow.set_registry_uri("databricks-uc")

    with _PROMPTS_YAML.open(encoding="utf-8") as f:
        prompts_data = yaml.safe_load(f)

    registered = []
    for func_name, yaml_key in _PROMPT_REGISTRY.items():
        registry_name = f"{catalog}.{schema}.{func_name}"
        template = _read_yaml_key(prompts_data, yaml_key)
        template_digest = hashlib.sha256(template.encode("utf-8")).hexdigest()[:12]

        # Check if prompt already exists with same content
        try:
            existing = mlflow.genai.load_prompt(
                f"prompts:/{registry_name}@{_PROMPT_ALIAS}",
                cache_ttl_seconds=0,
            )
            existing_digest = hashlib.sha256(
                existing.template.encode("utf-8")
            ).hexdigest()[:12]
            if existing_digest == template_digest:
                print(f"  {func_name}: unchanged (digest={template_digest})")
                continue
            print(f"  {func_name}: template changed, registering new version...")
        except Exception as exc:
            if _is_prompt_registry_disabled(exc):
                raise PromptRegistryDisabled(str(exc)) from exc
            print(f"  {func_name}: not found, registering...")

        try:
            version = mlflow.genai.register_prompt(
                name=registry_name,
                template=template,
                commit_message="registered by setup_mlflow.py",
            )
        except Exception as exc:
            if _is_prompt_registry_disabled(exc):
                raise PromptRegistryDisabled(str(exc)) from exc
            raise
        mlflow.genai.set_prompt_alias(
            name=registry_name,
            alias=_PROMPT_ALIAS,
            version=version.version,
        )
        print(f"  {func_name}: v{version.version} → {_PROMPT_ALIAS}")
        registered.append(func_name)

    return registered


# -- Step: Grant permissions -----------------------------------------------

_UC_SCHEMA_GRANTS = [
    "GRANT USE CATALOG ON CATALOG {catalog} TO `{sp}`",
    "GRANT USE SCHEMA ON SCHEMA {catalog}.{schema} TO `{sp}`",
    "GRANT ALL PRIVILEGES ON SCHEMA {catalog}.{schema} TO `{sp}`",
]


def ensure_uc_schema(w: WorkspaceClient, warehouse_id: str, catalog: str, schema: str) -> None:
    """Create the UC schema used by prompts, registered models, and traces."""
    full_name = f"{catalog}.{schema}"
    schemas_api = getattr(w, "schemas", None)
    if schemas_api is not None:
        if _schema_exists(w, catalog, schema):
            print(f"  SCHEMA {full_name}: exists")
            return
        try:
            try:
                schemas_api.create(name=schema, catalog_name=catalog)
            except TypeError:
                schemas_api.create(schema, catalog)
            if not _wait_for_schema(w, catalog, schema):
                raise RuntimeError(f"UC schema {full_name} was created but is not visible yet.")
            print(f"  SCHEMA {full_name}: created")
            return
        except Exception as exc:
            if _exception_contains(exc, "already exists", "already_exist"):
                print(f"  SCHEMA {full_name}: exists")
                return
            print(f"  SDK create schema failed ({exc}); trying SQL fallback")

    if not _execute_sql(
        w,
        warehouse_id,
        f"CREATE SCHEMA IF NOT EXISTS {full_name}",
        f"SCHEMA {full_name}",
    ):
        raise RuntimeError(
            f"Could not create UC schema {full_name}. "
            "The deployer must have CREATE SCHEMA on the catalog."
        )

    if schemas_api is not None and not _wait_for_schema(w, catalog, schema):
        raise RuntimeError(
            f"CREATE SCHEMA reported success, but UC schema {full_name} is still not visible."
        )


def grant_uc_schema_access(
    w: WorkspaceClient,
    sp_client_id: str,
    warehouse_id: str,
    catalog: str,
    schema: str,
) -> None:
    """Grant UC schema permissions to the App SP."""
    failed: list[str] = []
    for template in _UC_SCHEMA_GRANTS:
        stmt = template.format(sp=sp_client_id, catalog=catalog, schema=schema)
        label = stmt.split("GRANT ")[1].split(" TO")[0]
        if not _execute_sql(w, warehouse_id, stmt, label):
            failed.append(label)
    if failed:
        raise RuntimeError(
            "Could not grant UC schema access to the App SP. "
            f"Failed grants: {', '.join(failed)}"
        )


# -- Main ------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app-name", required=True, help="Databricks App name")
    parser.add_argument("--warehouse-id", default=None, help="SQL warehouse ID")
    parser.add_argument("--experiment-id", default=None, help="MLflow experiment ID to bind traces to UC")
    parser.add_argument("--experiment-name", default=None, help="MLflow experiment name to bind traces to UC")
    parser.add_argument(
        "--prompt-catalog", default="dev_gaia_experiments",
        help="UC catalog containing Arks resources (default: dev_gaia_experiments)",
    )
    parser.add_argument(
        "--prompt-schema", default="arks",
        help="UC schema containing prompts (default: arks)",
    )
    parser.add_argument(
        "--trace-table-prefix", default="arks_agent",
        help="UC table prefix for MLflow traces (default: arks_agent)",
    )
    parser.add_argument(
        "--skip-uc-grants",
        default="false",
        help="Skip UC grants when privileges were already granted manually.",
    )
    args = parser.parse_args(argv)
    skip_uc_grants = _as_bool(args.skip_uc_grants)

    w = WorkspaceClient()

    print("=" * 60)
    print(f"MLflow Setup — app={args.app_name}")
    print("=" * 60)

    # 1. Resolve App SP
    print("\n1. Resolving App Service Principal...")
    sp_client_id = get_app_sp_client_id(w, args.app_name)
    print(f"  App SP client_id: {sp_client_id}")

    # 2. Find SQL warehouse
    print("\n2. Finding SQL warehouse...")
    warehouse_id = find_warehouse_id(w, args.warehouse_id)
    print(f"  Warehouse ID: {warehouse_id}")

    # 3. Create and grant UC schema
    print(f"\n3. Ensuring UC schema ({args.prompt_catalog}.{args.prompt_schema})...")
    ensure_uc_schema(w, warehouse_id, args.prompt_catalog, args.prompt_schema)

    if skip_uc_grants:
        print("\n4. Granting UC schema access: skipped (--skip-uc-grants=true)")
    else:
        print("\n4. Granting UC schema access...")
        grant_uc_schema_access(
            w, sp_client_id, warehouse_id,
            catalog=args.prompt_catalog,
            schema=args.prompt_schema,
        )

    # 5. Bind app experiment traces to a UC table prefix when the experiment is known.
    if args.experiment_id or args.experiment_name:
        print("\n5. Binding MLflow experiment traces to UC table prefix...")
        trace_config = configure_experiment_trace_location(
            experiment_id=args.experiment_id,
            experiment_name=args.experiment_name,
            catalog=args.prompt_catalog,
            schema=args.prompt_schema,
            table_prefix=args.trace_table_prefix,
            required=True,
        )
        print(f"  Trace location: {trace_config.search_location}")
    else:
        print(
            "\n5. Binding MLflow experiment traces to UC table prefix: "
            "skipped (no experiment provided)"
        )

    # 6. Register prompts from prompts.yaml
    print(f"\n6. Registering prompts ({args.prompt_catalog}.{args.prompt_schema})...")
    prompt_registry_enabled = True
    try:
        registered = register_prompts(
            catalog=args.prompt_catalog,
            schema=args.prompt_schema,
        )
    except PromptRegistryDisabled as exc:
        prompt_registry_enabled = False
        registered = []
        print("  Prompt Registry is disabled for this Databricks organization.")
        print("  Skipping prompt registration.")
        print("  App runtime will use prompts.yaml fallback definitions.")
        print(f"  Details: {exc}")

    if prompt_registry_enabled:
        print(
            "\n  Prompt ownership transfer: skipped "
            "(MLflow prompts are not SQL routines)."
        )

    print("\n" + "=" * 60)
    print("MLflow setup complete.")
    if registered:
        print(f"  Prompts registered: {', '.join(registered)}")
    elif prompt_registry_enabled:
        print("  All prompts up to date.")
    else:
        print("  Prompt registration skipped because Prompt Registry is disabled.")
    print(f"  UC schema: {args.prompt_catalog}.{args.prompt_schema}")
    print(
        "  Trace table prefix: "
        f"{args.prompt_catalog}.{args.prompt_schema}.{args.trace_table_prefix}"
    )
    print("=" * 60)


if __name__ == "__main__":
    main()
