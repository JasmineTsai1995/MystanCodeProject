"""
Run MLflow GenAI evaluation against the local Arks agent.

The preferred path is:
  1. Build or sync a managed dataset in Unity Catalog.
  2. Run this script against that dataset.
  3. Schedule the same command in a Databricks Job.

Examples:
    PYTHONPATH=app python -m services.scripts.run_agent_eval \
      --dataset-json data/evals/agent_eval_dataset.sample.json \
      --experiment /Shared/arks-agent-evals

    PYTHONPATH=app python -m services.scripts.run_agent_eval \
      --uc-table-name dev_gaia_experiments.arks.agent_eval_dataset_v1 \
      --experiment /Shared/arks-agent-evals \
      --judge-model databricks:/databricks-gpt-5-4
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import mlflow

from config.loader import PROJECT_DIR
from services.scripts.agent_eval_pipeline import (
    build_default_scorers,
    build_local_predict_fn,
    configure_mlflow,
    get_managed_dataset,
    load_json_records,
)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run MLflow GenAI evaluation on the local Arks agent.")
    parser.add_argument("--dataset-json", help="Project-relative or absolute JSON dataset path.")
    parser.add_argument("--uc-table-name", help="Managed MLflow dataset table name in Unity Catalog.")
    parser.add_argument(
        "--experiment",
        default=None,
        help="MLflow experiment path. Falls back to the active MLflow experiment if omitted.",
    )
    parser.add_argument(
        "--tracking-uri",
        default=None,
        help="MLflow tracking URI. Example: databricks",
    )
    parser.add_argument(
        "--judge-model",
        default=None,
        help="Optional judge model for built-in GenAI scorers, e.g. databricks:/databricks-gpt-5-4",
    )
    parser.add_argument(
        "--max-rows",
        type=int,
        default=0,
        help="Limit the number of dataset rows for a dry run. Zero means use the full dataset.",
    )
    parser.add_argument(
        "--run-name",
        default="agent_eval_pipeline",
        help="MLflow parent run name.",
    )
    parser.add_argument(
        "--skip-mcp-tool-init",
        action="store_true",
        help="Disable MCP tool initialization for smoke tests when remote tool infra is unavailable.",
    )
    parser.add_argument(
        "--include-groundedness",
        action="store_true",
        help="Add RetrievalGroundedness scorer. Use only when the agent emits retriever spans.",
    )
    return parser


def _load_records(args: argparse.Namespace) -> tuple[Any, list[dict[str, Any]]]:
    if bool(args.dataset_json) == bool(args.uc_table_name):
        raise ValueError("Choose exactly one of --dataset-json or --uc-table-name.")

    if args.dataset_json:
        dataset_path = Path(args.dataset_json)
        if not dataset_path.is_absolute():
            dataset_path = PROJECT_DIR / dataset_path
        records = load_json_records(dataset_path)
        return records, records

    managed_dataset = get_managed_dataset(args.uc_table_name)
    records = list(managed_dataset.to_df().to_dict(orient="records"))
    return managed_dataset, records


def _trim_records(records: list[dict[str, Any]], max_rows: int) -> list[dict[str, Any]]:
    if max_rows <= 0:
        return records
    return records[:max_rows]


def _write_summary(results, output_path: Path) -> None:
    traces_df = mlflow.search_traces(run_id=results.run_id)
    summary = {
        "run_id": results.run_id,
        "metrics": results.metrics,
        "trace_count": int(len(traces_df)),
    }
    output_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    configure_mlflow(tracking_uri=args.tracking_uri, experiment=args.experiment)
    data, records = _load_records(args)
    dry_run_records = _trim_records(records, args.max_rows)

    if args.max_rows > 0:
        data = dry_run_records
    elif args.dataset_json:
        data = dry_run_records

    scorers = build_default_scorers(
        dry_run_records,
        judge_model=args.judge_model,
        include_groundedness=args.include_groundedness,
    )
    predict_fn = build_local_predict_fn(skip_mcp_tool_init=args.skip_mcp_tool_init)

    with mlflow.start_run(run_name=args.run_name):
        results = mlflow.genai.evaluate(
            data=data,
            predict_fn=predict_fn,
            scorers=scorers,
        )

    report_path = PROJECT_DIR / "data" / "evals" / "latest_agent_eval_summary.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    _write_summary(results, report_path)

    print(f"Evaluation run_id: {results.run_id}")
    print(f"Metrics: {json.dumps(results.metrics, ensure_ascii=False, indent=2)}")
    print(f"Summary report: {report_path}")


if __name__ == "__main__":
    main()
