# Databricks Operational Scripts

此目錄放的是 bundle-managed jobs 使用的維運腳本。現在正式部署方式是
Databricks App + DABs，Lakebase 使用 Autoscaling project `arks-lakebase-v2`。

## Bundle Jobs

| Job | Script | 用途 |
|---|---|---|
| `arks_setup_lakebase` | `setup_lakebase.py` | 建立 App SP 的 Postgres role，授權 Lakebase schema，清掉 owner 錯誤的 checkpoint tables |
| `arks_setup_mlflow` | `setup_mlflow.py` | 授權 App SP 存取 MLflow Prompt Registry / UC prompt schema |
| `arks_start_dev_resources` | `toggle_dev_resources.py` | 工作日早上啟動 Lakebase endpoint 與 Apps |
| `arks_stop_dev_resources` | `toggle_dev_resources.py` | 工作日晚間停止 Apps 與 suspend Lakebase endpoint |

## Managed Resources

`toggle_dev_resources.py` 目前管理：

- Databricks Apps: `arks-agent`, `mcp-cm-kb-mongodb`
- Lakebase Autoscaling project: `projects/arks-lakebase-v2`
- Lakebase branch: `production`
- Autoscale CU range after resume: `0.5` to `1.0`

若 resource name 變更，請同步更新：

- `APP_NAMES`
- `LAKEBASE_INSTANCE`
- `LAKEBASE_PROJECT`
- `databricks.yml` 裡 `postgres_projects.arks_lakebase.project_id`
- `databricks.yml` 裡 App `lakebase` postgres resource

## Deploy

From the bundle root:

```bash
databricks bundle validate -t ut
databricks bundle deploy -t ut
```

部署會建立或更新 App、Lakebase project、experiment 與 jobs。首次部署或 App SP
變更後，需接著跑 setup jobs：

```bash
databricks bundle run arks_setup_lakebase -t ut
databricks bundle run arks_setup_mlflow -t ut
```

## Schedule

排程定義在 `databricks.yml`：

- Start: 08:30 Asia/Taipei, Monday to Friday
- Stop: 19:00 Asia/Taipei, Monday to Friday

變更 `quartz_cron_expression`、`timezone_id` 或 `pause_status` 後，重新
`databricks bundle deploy -t ut`。

## Manual Use

從 Databricks Jobs UI 可手動執行：

- `Arks Setup Lakebase`
- `Arks Setup MLflow`
- `Arks Start Dev Resources`
- `Arks Stop Dev Resources`

從 CLI 執行：

```bash
databricks bundle run arks_setup_lakebase -t ut
databricks bundle run arks_setup_mlflow -t ut
databricks bundle run arks_start_dev_resources -t ut
databricks bundle run arks_stop_dev_resources -t ut
```

直接在 Databricks job/notebook 環境執行腳本時，需要能初始化
`databricks.sdk.WorkspaceClient`：

```bash
python app/services/scripts/setup_lakebase.py --project arks-lakebase-v2 --app-name arks-agent
python app/services/scripts/toggle_dev_resources.py start
python app/services/scripts/toggle_dev_resources.py stop
```
