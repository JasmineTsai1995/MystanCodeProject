"""
Create or update an MLflow-managed agent evaluation dataset in Unity Catalog.

Usage:
    PYTHONPATH=app python -m services.scripts.create_agent_eval_dataset \
      --source data/evals/agent_eval_dataset.sample.json \
      --uc-table-name dev_gaia_experiments.arks.agent_eval_dataset_v1

Environment:
    MLFLOW_TRACKING_URI       Optional. Example: databricks
    MLFLOW_EXPERIMENT_ID      Optional, not required for dataset creation
"""

from __future__ import annotations

import argparse
from pathlib import Path

from config.loader import PROJECT_DIR
from services.scripts.agent_eval_pipeline import load_json_records


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create or update an MLflow GenAI dataset.")
    parser.add_argument(
        "--source",
        required=True,
        help="Project-relative or absolute path to a JSON file containing dataset records.",
    )
    parser.add_argument(
        "--uc-table-name",
        required=True,
        help="Unity Catalog table name for the managed dataset, e.g. dev_gaia_experiments.arks.agent_eval_dataset_v1",
    )
    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    source_path = Path(args.source)
    if not source_path.is_absolute():
        source_path = PROJECT_DIR / source_path

    records = load_json_records(source_path)

    from databricks.connect import DatabricksSession
    import mlflow.genai.datasets as datasets

    DatabricksSession.builder.remote(serverless=True).getOrCreate()
    dataset = datasets.create_dataset(uc_table_name=args.uc_table_name)
    dataset.merge_records(records)

    print(f"Dataset table: {args.uc_table_name}")
    print(f"Merged records: {len(records)}")
    print(f"Source file: {source_path}")


if __name__ == "__main__":
    main()
