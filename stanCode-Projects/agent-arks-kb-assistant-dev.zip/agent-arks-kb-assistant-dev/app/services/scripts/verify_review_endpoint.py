"""Send a smoke request to the review endpoint and verify MLflow traces exist."""

from __future__ import annotations

import argparse
import inspect
from pathlib import Path
import sys
import time
import uuid

import mlflow
from databricks_openai import DatabricksOpenAI


def _current_script_dir() -> Path:
    """Return this script directory even when Databricks Jobs omits __file__."""
    filename = globals().get("__file__")
    if not filename:
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Could not resolve verify_review_endpoint.py location.")
        filename = frame.f_code.co_filename
    return Path(filename).resolve().parent


_SCRIPT_DIR = _current_script_dir()
_APP_DIR = _SCRIPT_DIR.parents[1]
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

from services.integrations.mlflow.trace_location import configure_experiment_trace_location


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint-name", default="arks-agent-review")
    parser.add_argument("--experiment-name", required=True)
    parser.add_argument("--review-deployment-id", required=True)
    parser.add_argument("--uc-catalog", default="dev_gaia_experiments")
    parser.add_argument("--uc-schema", default="arks")
    parser.add_argument("--trace-table-prefix", default="arks_review")
    parser.add_argument("--wait-seconds", type=int, default=10)
    parser.add_argument("--expected-prompt-version")
    parser.add_argument("--expected-prompt-digest")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    mlflow.set_tracking_uri("databricks")
    experiment = mlflow.get_experiment_by_name(args.experiment_name)
    if experiment is None:
        raise RuntimeError(f"Experiment not found: {args.experiment_name}")

    trace_config = configure_experiment_trace_location(
        experiment_id=experiment.experiment_id,
        catalog=args.uc_catalog,
        schema=args.uc_schema,
        table_prefix=args.trace_table_prefix,
        required=True,
    )
    trace_locations = [trace_config.search_location]
    previous_traces = mlflow.search_traces(
        locations=trace_locations,
        return_type="list",
        include_spans=False,
    )
    previous_trace_ids = {trace.info.trace_id for trace in previous_traces}
    smoke_request_id = f"review-smoke-{args.review_deployment_id}-{uuid.uuid4().hex}"

    input_messages = [{"role": "user", "content": "請用繁體中文簡短說明強制險保障什麼"}]
    custom_inputs = {
        "session_id": f"review-smoke-{args.review_deployment_id}",
        "client_request_id": smoke_request_id,
        "system_code": "arks-review",
        "cathay_no": "REVIEW_SMOKE_TEST",
    }

    client = DatabricksOpenAI()
    response = client.responses.create(
        model=args.endpoint_name,
        input=input_messages,
        extra_body={"custom_inputs": custom_inputs},
    )
    print(f"Endpoint response received: {response}")

    time.sleep(args.wait_seconds)
    traces = mlflow.search_traces(
        locations=trace_locations,
        return_type="list",
        include_spans=False,
    )
    new_traces = [
        trace
        for trace in traces
        if trace.info.trace_id not in previous_trace_ids
        and trace.info.tags.get("client_request_id") == smoke_request_id
    ]
    if not new_traces:
        raise RuntimeError(
            "No new trace found in review experiment after endpoint query: "
            f"{args.experiment_name} (before={len(previous_traces)}, after={len(traces)})"
        )
    trace_tags = new_traces[0].info.tags
    source = trace_tags.get("arks.prompt.source")
    version = trace_tags.get("arks.prompt.version")
    digest = trace_tags.get("arks.prompt.digest")
    if source != "mlflow_snapshot" or not version or not digest or digest == "unknown":
        raise RuntimeError(
            "Review endpoint did not use an immutable MLflow prompt snapshot: "
            f"source={source}, version={version}, digest={digest}"
        )
    if args.expected_prompt_version and version != args.expected_prompt_version:
        raise RuntimeError(
            "Review prompt version does not match deployment snapshot: "
            f"expected={args.expected_prompt_version}, actual={version}"
        )
    if args.expected_prompt_digest and digest != args.expected_prompt_digest:
        raise RuntimeError(
            "Review prompt digest does not match deployment snapshot: "
            f"expected={args.expected_prompt_digest}, actual={digest}"
        )
    print(
        "Review trace verification succeeded: "
        f"{len(new_traces)} new trace(s), prompt_version={version}, prompt_digest={digest}."
    )


if __name__ == "__main__":
    main()
