"""
[LEGACY — Serving Endpoint deployment]

This script was used to log & register the ArksAgent to MLflow / Unity Catalog
as a pyfunc model, which was then deployed via deploy_to_databricks.py.

It has been superseded by Databricks App deployment using DABs.
In App mode, the agent runs directly from source code — no UC model
packaging or registration is needed.

New deployment flow:
    databricks bundle validate
    databricks bundle deploy
    databricks bundle run arks_agent

The original code is preserved below (commented out) for reference / rollback.
"""

# ===========================================================================
# [LEGACY — Serving Endpoint model logging code]
# ===========================================================================
#
# """
# Phase 2 — Log & Register Agent to Databricks Unity Catalog
#
# Logs ArksAgent to MLflow and registers it to Unity Catalog.
# Run this script on a Databricks cluster (not locally).
#
# Usage (Databricks notebook):
#     %pip install -U mlflow databricks-langchain[memory] langgraph>=1.0.0 langchain>=1.0.0
#     dbutils.library.restartPython()
#
#     import importlib.util
#     _path = "/Workspace/Users/.../app/services/scripts/log_to_databricks.py"
#     spec  = importlib.util.spec_from_file_location("log_to_databricks", _path)
#     mod   = importlib.util.module_from_spec(spec)
#     spec.loader.exec_module(mod)
#
# Before running:
#     1. Set CATALOG / SCHEMA / MODEL_NAME below to match your UC structure.
#     2. Ensure config.yaml llm.databricks.* values are correct,
#        or override via env vars (DATABRICKS_LLM_ENDPOINT, etc.).
# """
#
# from __future__ import annotations
#
# import os
# import sys
# from pathlib import Path
#
# # Ensure app/ is on sys.path so config.* and services.* imports resolve
# _SCRIPT_DIR = Path(__file__).resolve().parent   # app/services/scripts/
# _APP_DIR    = _SCRIPT_DIR.parents[1]            # app/
# if str(_APP_DIR) not in sys.path:
#     sys.path.insert(0, str(_APP_DIR))
#
# # During MLflow model logging, skip live MCP tool initialization so input-example
# # validation does not depend on external Databricks App auth/availability.
# os.environ.setdefault("SKIP_MCP_TOOL_INIT", "true")
#
# import mlflow
# from mlflow.models.resources import (
#     DatabricksFunction,
#     DatabricksLakebase,
#     DatabricksServingEndpoint,
#     DatabricksVectorSearchIndex,
# )
#
# from config.loader import cfg
#
# # -----------------------------------------------------------------------------
# # Unity Catalog target — adjust to your workspace structure
# # -----------------------------------------------------------------------------
# CATALOG    = "gaia_experiments"
# SCHEMA     = "arks"
# MODEL_NAME = "arks_agent"
#
# # -----------------------------------------------------------------------------
# # Resolve config values (yaml < env var priority)
# # -----------------------------------------------------------------------------
# LLM_ENDPOINT  = cfg("llm.databricks.llm_endpoint", "DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-4")
# LAKEBASE_NAME = cfg("llm.databricks.lakebase_name", "DATABRICKS_LAKEBASE_NAME", "")
# VS_INDEX      = cfg("llm.databricks.vs_index_name",  "DATABRICKS_VS_INDEX_NAME",  "")
# UC_FUNCTIONS  = cfg("llm.databricks.uc_functions",   "DATABRICKS_UC_FUNCTIONS",   "")
#
# # -----------------------------------------------------------------------------
# # Resources — Databricks auto-provisions credentials for these at serving time
# # -----------------------------------------------------------------------------
# resources = [
#     DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT),
# ]
#
# if LAKEBASE_NAME:
#     resources.append(DatabricksLakebase(database_instance_name=LAKEBASE_NAME))
#
# if VS_INDEX:
#     resources.append(DatabricksVectorSearchIndex(index_name=VS_INDEX))
#
# if UC_FUNCTIONS:
#     for fn in [f.strip() for f in UC_FUNCTIONS.split(",") if f.strip()]:
#         resources.append(DatabricksFunction(function_name=fn))
#
# # -----------------------------------------------------------------------------
# # File paths
# # -----------------------------------------------------------------------------
# _SCRIPT_DIR = Path(__file__).resolve().parent          # app/services/scripts/
# _APP_DIR    = _SCRIPT_DIR.parents[1]                   # app/
# _AGENT_FILE = str(_APP_DIR / "services" / "core" / "databricks_agent.py")
#
# # -----------------------------------------------------------------------------
# # Log model
# # -----------------------------------------------------------------------------
# mlflow.set_registry_uri("databricks-uc")
#
# with mlflow.start_run():
#     model_info = mlflow.pyfunc.log_model(
#         name="agent",
#         python_model=_AGENT_FILE,
#         # Pass each top-level package in app/ separately so MLflow places them
#         # directly under code/ (e.g. code/config/, code/services/).
#         # MLflow adds code/ to sys.path, so `import config` / `import services` work.
#         code_paths=[str(p) for p in sorted(_APP_DIR.iterdir())
#                     if p.is_dir() and not p.name.startswith((".", "_"))],
#         resources=resources,
#         pip_requirements=[
#             # MLflow serving runtime
#             "mlflow>=3.0.0",
#             # Databricks integrations (LLM, Vector Search, UC Functions, Lakebase memory)
#             "databricks-langchain[memory]",
#             "databricks-sdk>=0.102.0",
#             # LangChain / LangGraph — must match pyproject.toml versions
#             "langchain>=1.0.0",
#             "langchain-core>=1.0.0",
#             "langgraph>=1.1.0",  # version="v2" stream format requires >= 1.1
#             # MCP retriever client
#             "langchain-mcp-adapters>=0.2.2",
#             "httpx>=0.27.0",
#             # Config loading
#             "pydantic>=2.7.4",
#             "pyyaml",
#             "python-dotenv",
#         ],
#         input_example={
#             "input": [{"role": "user", "content": "你好，請問有什麼可以幫你？"}]
#         },
#     )
#     print(f"Model logged: {model_info.model_uri}")
#
# # -----------------------------------------------------------------------------
# # Register to Unity Catalog
# # -----------------------------------------------------------------------------
# uc_model_info = mlflow.register_model(
#     model_uri=model_info.model_uri,
#     name=f"{CATALOG}.{SCHEMA}.{MODEL_NAME}",
# )
# print(f"Registered: {uc_model_info.name}  version {uc_model_info.version}")
