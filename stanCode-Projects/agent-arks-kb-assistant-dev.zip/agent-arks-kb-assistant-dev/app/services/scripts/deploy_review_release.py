"""Register, deploy, and connect the Arks review endpoint to the Review App."""

from __future__ import annotations

import argparse
from datetime import timedelta
import inspect
from pathlib import Path
import sys

import mlflow
from databricks import agents
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import ResourceDoesNotExist
from databricks.sdk.service.serving import EndpointTag


def _current_script_dir() -> Path:
    """Return this script directory even when Databricks Jobs omits __file__."""
    filename = globals().get("__file__")
    if not filename:
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Could not resolve deploy_review_release.py location.")
        filename = frame.f_code.co_filename
    return Path(filename).resolve().parent


_SCRIPT_DIR = _current_script_dir()
_APP_DIR = _SCRIPT_DIR.parents[1]
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

from finalize_review_endpoint import finalize_review_endpoint
from register_review_agent import register_review_model
from services.integrations.mlflow.trace_location import configure_experiment_trace_location


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-deployment-id", required=True)
    parser.add_argument("--experiment-name", required=True)
    parser.add_argument("--registered-model-name", required=True)
    parser.add_argument("--endpoint-name", default="arks-agent-review")
    parser.add_argument("--llm-provider", default="litellm")
    parser.add_argument("--llm-endpoint", default="databricks-gpt-5-4")
    parser.add_argument("--litellm-model", default="gpt-5.5")
    parser.add_argument("--litellm-endpoint", default="")
    parser.add_argument("--litellm-secret-scope", default="arks")
    parser.add_argument("--litellm-secret-key", default="litellm-api-key")
    parser.add_argument("--mcp-app-name", default="mcp-cm-kb-mongodb")
    parser.add_argument("--mcp-app-url", required=True)
    parser.add_argument("--uc-catalog", default="dev_gaia_experiments")
    parser.add_argument("--uc-schema", default="arks")
    parser.add_argument("--trace-table-prefix", default="arks_review")
    parser.add_argument("--lakebase-name", default="arks-lakebase-v2")
    parser.add_argument("--lakebase-branch", default="production")
    parser.add_argument("--requirements-file")
    parser.add_argument("--git-commit")
    parser.add_argument(
        "--reviewers",
        help="Comma-separated account user emails or groups granted CAN_QUERY.",
    )
    parser.add_argument("--scale-to-zero", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--skip-smoke-test", action="store_true")
    parser.add_argument("--trace-wait-seconds", type=int, default=10)
    parser.add_argument("--endpoint-timeout-minutes", type=int, default=60)
    return parser


def wait_for_existing_endpoint_update(endpoint_name: str, timeout_minutes: int) -> None:
    """Avoid registering a new version while an earlier endpoint update is active."""
    client = WorkspaceClient()
    try:
        endpoint = client.serving_endpoints.get(name=endpoint_name)
    except ResourceDoesNotExist:
        return

    state = endpoint.state
    config_update = getattr(state, "config_update", None) if state else None
    if "UPDATE_FAILED" in str(config_update):
        print(
            f"Existing endpoint is in UPDATE_FAILED state; continuing so the "
            f"new deployment can replace the failed config: {endpoint_name}"
        )
        return

    print(f"Waiting for existing endpoint update to finish before deployment: {endpoint_name}")
    client.serving_endpoints.wait_get_serving_endpoint_not_updating(
        name=endpoint_name,
        timeout=timedelta(minutes=timeout_minutes),
    )


def update_endpoint_release_tags(endpoint_name: str, release_tags: dict[str, str]) -> None:
    """Update mutable release tags without sending overlapping add/delete keys."""
    client = WorkspaceClient()
    endpoint = client.serving_endpoints.get(name=endpoint_name)
    current_tags = {tag.key: tag.value for tag in endpoint.tags or []}
    changed_keys = sorted(
        key
        for key, value in release_tags.items()
        if key in current_tags and current_tags[key] != value
    )
    if changed_keys:
        client.serving_endpoints.patch(name=endpoint_name, delete_tags=changed_keys)

    tags_to_add = [
        EndpointTag(key=key, value=value)
        for key, value in release_tags.items()
        if current_tags.get(key) != value
    ]
    if tags_to_add:
        client.serving_endpoints.patch(name=endpoint_name, add_tags=tags_to_add)


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    args.llm_provider = args.llm_provider.strip().lower()
    if args.llm_provider not in {"databricks", "litellm"}:
        raise ValueError(
            f"Unsupported --llm-provider {args.llm_provider!r}; "
            "expected databricks or litellm."
        )
    wait_for_existing_endpoint_update(args.endpoint_name, args.endpoint_timeout_minutes)
    register_args = argparse.Namespace(
        review_deployment_id=args.review_deployment_id,
        experiment_name=args.experiment_name,
        registered_model_name=args.registered_model_name,
        llm_provider=args.llm_provider,
        llm_endpoint=args.llm_endpoint,
        litellm_model=args.litellm_model,
        litellm_endpoint=args.litellm_endpoint,
        mcp_app_name=args.mcp_app_name,
        uc_catalog=args.uc_catalog,
        uc_schema=args.uc_schema,
        trace_table_prefix=args.trace_table_prefix,
        lakebase_name=args.lakebase_name,
        lakebase_branch=args.lakebase_branch,
        requirements_file=args.requirements_file,
        git_commit=args.git_commit,
    )
    registration = register_review_model(register_args)

    # This experiment becomes the MLflow 3 trace destination for the deployment.
    mlflow.set_experiment(args.experiment_name)
    configure_experiment_trace_location(
        experiment_name=args.experiment_name,
        catalog=args.uc_catalog,
        schema=args.uc_schema,
        table_prefix=args.trace_table_prefix,
        required=True,
    )
    environment_vars = {
        "MLFLOW_TRACKING_URI": "databricks",
        "MLFLOW_REGISTRY_URI": "databricks-uc",
        "ARKS_UC_CATALOG": args.uc_catalog,
        "ARKS_UC_SCHEMA": args.uc_schema,
        "ARKS_TRACE_TABLE_PREFIX": args.trace_table_prefix,
        "LLM_PROVIDER": args.llm_provider,
        "DATABRICKS_LLM_ENDPOINT": args.llm_endpoint,
        "RETRIEVAL_PROVIDER": "mcp",
        "MCP_APP_URL": args.mcp_app_url,
        "DATABRICKS_LAKEBASE_NAME": args.lakebase_name,
        "DATABRICKS_LAKEBASE_BRANCH": args.lakebase_branch,
        "ARKS_REVIEW_DEPLOYMENT_ID": args.review_deployment_id,
        "ARKS_GIT_COMMIT": registration.git_commit,
        "ARKS_REVIEW_SESSION_PREFIX": "review",
        "ARKS_PROMPT_MODE": "deployment_snapshot",
        "AGENT_STREAMING_ENABLED": "true",
    }
    if args.llm_provider == "litellm":
        environment_vars.update(
            {
                "LITELLM_MODEL": args.litellm_model,
                "LITELLM_ENDPOINT": args.litellm_endpoint,
                "LITELLM_API_KEY": (
                    f"{{{{secrets/{args.litellm_secret_scope}/{args.litellm_secret_key}}}}}"
                ),
            }
        )
    release_tags = {
        "arks_review_deployment_id": args.review_deployment_id,
        "arks_git_commit": registration.git_commit,
        "arks_prompt_source": "mlflow_snapshot",
        "arks_prompt_agent_version": registration.agent_prompt_version,
        "arks_prompt_agent_digest": registration.agent_prompt_digest,
        "arks_prompt_snapshot_digest": registration.prompt_snapshot_digest,
        "arks_uc_catalog": args.uc_catalog,
        "arks_uc_schema": args.uc_schema,
        "arks_trace_table_prefix": args.trace_table_prefix,
        "arks_llm_provider": args.llm_provider,
    }
    deployment = agents.deploy(
        registration.model_name,
        int(registration.model_version),
        endpoint_name=args.endpoint_name,
        scale_to_zero=args.scale_to_zero,
        environment_vars=environment_vars,
        description="Arks review endpoint for MLflow Review App Chat UI.",
    )

    print(f"Query endpoint: {deployment.query_endpoint}")
    finalize_review_endpoint(
        argparse.Namespace(
            endpoint_name=args.endpoint_name,
            endpoint_timeout_minutes=args.endpoint_timeout_minutes,
            experiment_name=args.experiment_name,
            registered_model_name=registration.model_name,
            review_deployment_id=args.review_deployment_id,
            uc_catalog=args.uc_catalog,
            uc_schema=args.uc_schema,
            trace_table_prefix=args.trace_table_prefix,
            reviewers=args.reviewers,
            skip_smoke_test=args.skip_smoke_test,
            trace_wait_seconds=args.trace_wait_seconds,
            expected_prompt_version=registration.agent_prompt_version,
            expected_prompt_digest=registration.agent_prompt_digest,
        )
    )
    update_endpoint_release_tags(args.endpoint_name, release_tags)


if __name__ == "__main__":
    main()
