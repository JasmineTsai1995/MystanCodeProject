"""
LLM Model Adapter — re-export from canonical location.

Canonical source: app/models/llm_adapter.py
"""

from models.llm_adapter import OPENROUTER_BASE_URL, _openai_compatible_base_url, get_llm  # noqa: F401

__all__ = ["get_llm", "OPENROUTER_BASE_URL", "_openai_compatible_base_url"]
