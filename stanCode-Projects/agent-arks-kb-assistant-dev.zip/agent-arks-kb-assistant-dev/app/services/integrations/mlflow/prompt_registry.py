"""
MLflow Prompt Registry Utilities

Helper functions for managing Arks prompts in the MLflow Prompt Registry.
Intended to be called from Databricks Notebooks (notebooks/prompt_management.ipynb),
not at agent runtime.

Usage:
    from services.integrations.mlflow.prompt_registry import (
        register_all_from_yaml,
        register_one,
        promote,
        list_versions,
    )
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

_YAML_PATH = Path(__file__).parents[3] / "config" / "prompts" / "prompts.yaml"

def uc_catalog_schema() -> str:
    catalog = os.getenv("ARKS_UC_CATALOG", "dev_gaia_experiments").strip()
    schema = os.getenv("ARKS_UC_SCHEMA", "arks").strip()
    return f"{catalog}.{schema}"


# Unity Catalog location for all Arks prompts
UC_CATALOG_SCHEMA = uc_catalog_schema()

# Mapping: full UC registry name → dot-notation key in prompts.yaml
REGISTRY_KEYS: dict[str, str] = {
    f"{UC_CATALOG_SCHEMA}.arks_agent":               "agent",
    f"{UC_CATALOG_SCHEMA}.arks_reflection_review":   "reflection.review",
    f"{UC_CATALOG_SCHEMA}.arks_reflection_judge":    "reflection.judge",
    f"{UC_CATALOG_SCHEMA}.arks_reflection_revise":   "reflection.revise",
    f"{UC_CATALOG_SCHEMA}.arks_followup_system":     "followup.system",
    f"{UC_CATALOG_SCHEMA}.arks_followup_questions":  "followup.questions",
}


def _read_yaml_key(key: str) -> str:
    with _YAML_PATH.open(encoding="utf-8") as f:
        data = yaml.safe_load(f)
    node: Any = data
    for part in key.split("."):
        node = node[part]
    if not isinstance(node, str):
        raise TypeError(f"Key '{key}' is not a string.")
    return node


def register_one(
    registry_name: str,
    template: str,
    commit_message: str = "",
    promote_to_production: bool = False,
) -> Any:
    """Register a single prompt version in MLflow Registry.

    Args:
        registry_name:          Registry name (e.g. "arks_agent").
        template:               Prompt template string.
        commit_message:         Human-readable description of the change.
        promote_to_production:  If True, immediately set the 'production' alias.

    Returns:
        The registered prompt version object.
    """
    import mlflow

    version = mlflow.genai.register_prompt(
        name=registry_name,
        template=template,
        commit_message=commit_message,
    )
    status = f"v{version.version}"
    if promote_to_production:
        mlflow.genai.set_prompt_alias(
            name=registry_name,
            alias="production",
            version=version.version,
        )
        status += " → production"
    print(f"[prompt_registry] {registry_name} registered {status}")
    return version


def register_all_from_yaml(
    commit_message: str = "migration from prompts.yaml",
    promote_to_production: bool = True,
) -> dict[str, Any]:
    """Register all REGISTRY_KEYS prompts from prompts.yaml.

    Typically run once during initial migration.

    Args:
        commit_message:         Applied to all registered versions.
        promote_to_production:  If True, set 'production' alias for each version.

    Returns:
        Dict mapping registry_name → version object.
    """
    results = {}
    for registry_name, yaml_key in REGISTRY_KEYS.items():
        template = _read_yaml_key(yaml_key)
        results[registry_name] = register_one(
            registry_name=registry_name,
            template=template,
            commit_message=commit_message,
            promote_to_production=promote_to_production,
        )
    return results


def promote(registry_name: str, version: int, alias: str = "production") -> None:
    """Set an alias on an existing prompt version.

    Args:
        registry_name:  Registry name (e.g. "arks_agent").
        version:        Version number to promote.
        alias:          Alias to set (default: "production").
    """
    import mlflow

    mlflow.genai.set_prompt_alias(name=registry_name, alias=alias, version=version)
    print(f"[prompt_registry] {registry_name} v{version} → {alias}")


def list_versions(registry_name: str) -> None:
    """Print all versions and their aliases for a given prompt."""
    import mlflow

    client = mlflow.MlflowClient()
    versions = client.search_prompt_versions(name=registry_name)
    if not versions:
        print(f"[prompt_registry] No versions found for '{registry_name}'.")
        return
    print(f"\n{'version':<10} {'aliases':<20} message")
    print("-" * 60)
    for v in versions:
        aliases = ", ".join(v.aliases) if v.aliases else "—"
        print(f"v{v.version:<9} {aliases:<20} {v.description or ''}")
