"""MLflow trace-location helpers for Unity Catalog-backed trace storage."""

from __future__ import annotations

from dataclasses import dataclass
import inspect
import logging
import os
from typing import Any


DEFAULT_UC_CATALOG = "dev_gaia_experiments"
DEFAULT_UC_SCHEMA = "arks"
DEFAULT_TRACE_TABLE_PREFIX = "arks_agent"


@dataclass(frozen=True)
class UCTraceConfig:
    catalog: str
    schema: str
    table_prefix: str

    @property
    def schema_full_name(self) -> str:
        return f"{self.catalog}.{self.schema}"

    @property
    def search_location(self) -> str:
        return f"{self.schema_full_name}.{self.table_prefix}"

    @property
    def full_name(self) -> str:
        return self.search_location


def uc_trace_config_from_env(
    catalog: str | None = None,
    schema: str | None = None,
    table_prefix: str | None = None,
) -> UCTraceConfig:
    return UCTraceConfig(
        catalog=(catalog or os.getenv("ARKS_UC_CATALOG") or DEFAULT_UC_CATALOG).strip(),
        schema=(schema or os.getenv("ARKS_UC_SCHEMA") or DEFAULT_UC_SCHEMA).strip(),
        table_prefix=(
            table_prefix
            or os.getenv("ARKS_TRACE_TABLE_PREFIX")
            or DEFAULT_TRACE_TABLE_PREFIX
        ).strip(),
    )


def _is_already_configured(exc: Exception) -> bool:
    message = str(exc).lower()
    return "already" in message and (
        "trace location" in message
        or "trace destination" in message
        or "destination" in message
        or "storage location" in message
        or "linked" in message
    )


def _unity_catalog_location(config: UCTraceConfig) -> Any:
    def build(location_class: Any) -> Any:
        for kwargs in (
            {
                "catalog_name": config.catalog,
                "schema_name": config.schema,
                "table_prefix": config.table_prefix,
            },
            {
                "catalog": config.catalog,
                "schema": config.schema,
                "table_prefix": config.table_prefix,
            },
        ):
            try:
                return location_class(**kwargs)
            except TypeError:
                continue
        return location_class(config.catalog, config.schema, config.table_prefix)

    for module_name in ("mlflow.entities", "mlflow.entities.trace_location"):
        try:
            module = __import__(module_name, fromlist=["UnityCatalog"])
            return build(getattr(module, "UnityCatalog"))
        except Exception:
            continue

    raise RuntimeError(
        "MLflow does not expose UnityCatalog trace locations. "
        "Use mlflow[databricks]>=3.8.0 in Databricks jobs and Apps."
    )


def _set_experiment_with_trace_location(
    mlflow_module: Any,
    *,
    experiment_name: str | None,
    experiment_id: str | None,
    location: Any,
) -> str:
    setter = mlflow_module.set_experiment
    signature = inspect.signature(setter)
    parameters = signature.parameters
    accepts_kwargs = any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in parameters.values()
    )
    kwargs: dict[str, Any] = {}

    if "trace_location" not in parameters and not accepts_kwargs:
        raise RuntimeError(
            "mlflow.set_experiment does not support trace_location. "
            "Use mlflow[databricks]>=3.8.0."
        )
    kwargs["trace_location"] = location

    if experiment_id and ("experiment_id" in parameters or accepts_kwargs):
        kwargs["experiment_id"] = experiment_id
        experiment = setter(**kwargs)
    elif experiment_name and ("experiment_name" in parameters or accepts_kwargs):
        kwargs["experiment_name"] = experiment_name
        experiment = setter(**kwargs)
    elif experiment_name:
        experiment = setter(experiment_name, trace_location=location)
    else:
        raise RuntimeError("No MLflow experiment_id or experiment_name was provided.")

    resolved_experiment_id = getattr(experiment, "experiment_id", None)
    return str(resolved_experiment_id or experiment_id or "")


def configure_experiment_trace_location(
    *,
    experiment_name: str | None = None,
    experiment_id: str | None = None,
    catalog: str | None = None,
    schema: str | None = None,
    table_prefix: str | None = None,
    tracking_uri: str | None = "databricks",
    required: bool = False,
    logger: logging.Logger | None = None,
) -> UCTraceConfig | None:
    """Bind an MLflow experiment's traces to a Unity Catalog table prefix.

    Databricks no longer enables creating schema-level trace locations in all
    workspaces. MLflow's table-prefix location maps traces to UC tables under
    ``catalog.schema.table_prefix*`` and can be searched with the same
    three-part prefix.
    """
    log = logger or logging.getLogger(__name__)
    config = uc_trace_config_from_env(
        catalog=catalog,
        schema=schema,
        table_prefix=table_prefix,
    )
    try:
        import mlflow

        if tracking_uri:
            mlflow.set_tracking_uri(tracking_uri)

        resolved_experiment_id = _set_experiment_with_trace_location(
            mlflow_module=mlflow,
            experiment_name=experiment_name,
            experiment_id=str(experiment_id or "").strip() or None,
            location=_unity_catalog_location(config),
        )
        log.info(
            "MLflow experiment %s traces are configured for UC table prefix %s.",
            resolved_experiment_id or "<unknown>",
            config.search_location,
        )
        return config
    except Exception as exc:
        if _is_already_configured(exc):
            log.info(
                "MLflow experiment traces are already configured for UC table prefix %s.",
                config.search_location,
            )
            return config
        if required:
            raise
        log.warning(
            "Could not configure MLflow UC trace location %s: %s",
            config.search_location,
            exc,
        )
        return None
