"""
Databricks MCP client helpers for Arks agent.

This module centralizes the official LangChain MCP adapter integration so the
agent can load remote MCP tools from the Databricks App without maintaining
custom BaseTool wrappers in the main execution path.

Current behavior:
  - Reads MCP_APP_URL from environment.
  - Uses langchain-mcp-adapters MultiServerMCPClient over HTTP transport.
  - Injects Databricks auth headers on every tool call.

Future customization hooks belong here:
  - custom auth strategy
  - custom headers / tracing headers
  - request payload shaping
  - response normalization
"""
from __future__ import annotations

import asyncio
import os
from collections.abc import Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.interceptors import MCPToolCallRequest, MCPToolCallResult

_SERVER_NAME = "arks_mcp"


def get_mcp_server_url() -> str:
    """Return the MCP retriever App URL with the /mcp suffix."""
    app_url = os.environ.get("MCP_APP_URL", "").rstrip("/")
    if not app_url:
        raise ValueError("MCP_APP_URL env var is not set. Add it to the serving endpoint config.")
    return f"{app_url}/mcp"


def get_mcp_server_urls() -> list[str]:
    """Backward-compatible helper retained for existing callers."""
    return [get_mcp_server_url()]


def _get_databricks_auth_headers() -> dict[str, str]:
    """Resolve Databricks auth headers lazily for each tool invocation."""
    from databricks.sdk import WorkspaceClient

    return WorkspaceClient().config.authenticate()


class DatabricksAuthInterceptor:
    """Inject Databricks auth headers for each MCP tool call.

    Keep auth/header customization here rather than reintroducing per-tool
    wrapper classes.
    """

    async def __call__(
        self,
        request: MCPToolCallRequest,
        handler: Callable[[MCPToolCallRequest], Awaitable[MCPToolCallResult]],
    ) -> MCPToolCallResult:
        headers = _get_databricks_auth_headers()
        merged_headers = {**headers, **dict(request.headers or {})}
        return await handler(request.override(headers=merged_headers))


async def get_mcp_tools() -> list[BaseTool]:
    """Load LangChain tools from the remote Databricks MCP server.

    The server uses FastMCP streamable_http_app() (Streamable HTTP transport,
    not SSE).  Auth headers are required for both the initial tool-discovery
    request and subsequent tool calls — pass them in the transport config AND
    via the interceptor.
    """
    auth_headers = _get_databricks_auth_headers()
    client = MultiServerMCPClient(
        {
            _SERVER_NAME: {
                "transport": "streamable_http",
                "url": get_mcp_server_url(),
                "headers": auth_headers,
            }
        },
        tool_interceptors=[DatabricksAuthInterceptor()],
        tool_name_prefix=False,
    )
    return await client.get_tools(server_name=_SERVER_NAME)


def _run_coro_in_new_loop(coro: Any) -> Any:
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(lambda: asyncio.run(coro))
        return future.result()


def get_mcp_tools_sync() -> list[BaseTool]:
    """Sync bridge for loading MCP tools during synchronous agent startup."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(get_mcp_tools())
    return _run_coro_in_new_loop(get_mcp_tools())
