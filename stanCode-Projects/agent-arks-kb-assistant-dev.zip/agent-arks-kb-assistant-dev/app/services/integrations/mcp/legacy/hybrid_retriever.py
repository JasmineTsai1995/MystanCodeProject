"""
Legacy manual MCP wrapper for hybrid retrieval.

This module is intentionally not used by the runtime anymore.
It was moved under `services.integrations.mcp.legacy` on purpose.
The active integration path lives in `services.integrations.mcp.client`
and uses `langchain-mcp-adapters` to load MCP tools directly.

The old BaseTool implementation is kept below as comments because future
requirements may need lower-level customization for:
  - custom authentication flows
  - custom headers
  - custom MCP request shaping
  - custom response post-processing
"""

# from __future__ import annotations
#
# import json
# import logging
# from typing import Optional
#
# import httpx
# from langchain_core.callbacks import CallbackManagerForToolRun
# from langchain_core.tools import BaseTool
# from pydantic import ConfigDict
#
# logger = logging.getLogger(__name__)
#
#
# class MCPHybridSearchTool(BaseTool):
#     """LangChain wrapper that calls search_kb_hybrid on the remote MCP server."""
#
#     name: str = "search_kb_hybrid"
#     description: str = (
#         "搜尋保險知識庫（Hybrid Search：向量 + 全文 BM25 + RRF）。"
#         "適合包含條款編號、專有術語、精確名詞的保險問題。"
#         "輸入使用者問題原文即可。"
#     )
#     model_config = ConfigDict(arbitrary_types_allowed=True)
#
#     top_k: int = 10
#     vector_penalty: float = 60.0
#     fulltext_penalty: float = 60.0
#     splitter: str = "recursive"
#
#     def _run(
#         self,
#         query: str,
#         run_manager: Optional[CallbackManagerForToolRun] = None,
#     ) -> str:
#         try:
#             return self._call_mcp(query)
#         except Exception as exc:
#             logger.error("MCPHybridSearchTool error: %s", exc)
#             return f"搜尋時發生錯誤，請稍後再試。(error: {exc})"
#
#     def _call_mcp(self, query: str) -> str:
#         payload = {
#             "jsonrpc": "2.0",
#             "method": "tools/call",
#             "id": 1,
#             "params": {
#                 "name": "search_kb_hybrid",
#                 "arguments": {
#                     "query": query,
#                     "top_k": self.top_k,
#                     "vector_penalty": self.vector_penalty,
#                     "fulltext_penalty": self.fulltext_penalty,
#                     "splitter": self.splitter,
#                 },
#             },
#         }
#         from databricks.sdk import WorkspaceClient
#         from services.integrations.mcp.client import get_mcp_server_urls
#
#         auth_headers = WorkspaceClient().config.authenticate()
#         mcp_url = get_mcp_server_urls()[0]
#
#         with httpx.Client(timeout=60.0) as client:
#             resp = client.post(
#                 mcp_url,
#                 json=payload,
#                 headers={
#                     **auth_headers,
#                     "Content-Type": "application/json",
#                     "Accept": "application/json, text/event-stream",
#                 },
#             )
#             resp.raise_for_status()
#
#         result = resp.json().get("result", {})
#         content = result.get("content", [])
#
#         if not content:
#             return "No relevant documents found."
#
#         try:
#             tool_output = json.loads(content[0]["text"])
#             docs = tool_output.get("results", [])
#             logger.info(
#                 "MCPHybridSearchTool | retrieved=%d query=%r",
#                 len(docs),
#                 query[:80],
#             )
#             return "\n\n---\n\n".join(
#                 f"[{doc['rank']}] {doc['content']}" for doc in docs
#             ) or "No relevant documents found."
#         except Exception as exc:
#             logger.warning("MCPHybridSearchTool parse error: %s", exc)
#             return str(content[0].get("text", "No relevant documents found."))
#
#
# def build_mcp_hybrid_tool(
#     top_k: int = 10,
#     vector_penalty: float = 60.0,
#     fulltext_penalty: float = 60.0,
#     splitter: str = "recursive",
# ) -> MCPHybridSearchTool:
#     """Construct the MCP hybrid search tool. URL is resolved lazily at call time."""
#     return MCPHybridSearchTool(
#         top_k=top_k,
#         vector_penalty=vector_penalty,
#         fulltext_penalty=fulltext_penalty,
#         splitter=splitter,
#     )
