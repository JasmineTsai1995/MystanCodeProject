"""
Legacy MCP wrapper references.

These modules are intentionally excluded from the active runtime.
The current MCP integration uses `services.integrations.mcp.client`
with `langchain-mcp-adapters`.
"""
