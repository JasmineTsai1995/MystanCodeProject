"""
Legacy manual MCP wrapper for vector retrieval.

This module is intentionally not used by the runtime anymore.
It was moved under `services.integrations.mcp.legacy` on purpose.
The active integration path lives in `services.integrations.mcp.client`
and uses `langchain-mcp-adapters` to load MCP tools directly.

The old BaseTool implementation is kept below as comments because future
requirements may need lower-level customization for:
  - custom authentication flows
  - custom headers
  - custom MCP request shaping
  - custom response post-processing
"""

# from __future__ import annotations
#
# import json
# import logging
# from typing import Optional
#
# import httpx
# from langchain_core.callbacks import CallbackManagerForToolRun
# from langchain_core.tools import BaseTool
# from pydantic import ConfigDict
#
# logger = logging.getLogger(__name__)
#
#
# class MCPVectorSearchTool(BaseTool):
#     """LangChain wrapper that calls search_kb_vector on the remote MCP server."""
#
#     name: str = "search_kb_vector"
#     description: str = (
#         "搜尋保險知識庫（語意向量搜尋）。"
#         "適合語意模糊、問法多樣的一般保險問題，包含保單條款、申請流程、理賠規定等。"
#         "輸入使用者問題原文即可，系統自動找出最相關段落。"
#     )
#     model_config = ConfigDict(arbitrary_types_allowed=True)
#
#     top_k: int = 10
#     splitter: str = "recursive"
#
#     def _run(
#         self,
#         query: str,
#         run_manager: Optional[CallbackManagerForToolRun] = None,
#     ) -> str:
#         try:
#             return self._call_mcp(query)
#         except Exception as exc:
#             logger.error("MCPVectorSearchTool error: %s", exc)
#             return f"搜尋時發生錯誤，請稍後再試。(error: {exc})"
#
#     def _call_mcp(self, query: str) -> str:
#         payload = {
#             "jsonrpc": "2.0",
#             "method": "tools/call",
#             "id": 1,
#             "params": {
#                 "name": "search_kb_vector",
#                 "arguments": {
#                     "query": query,
#                     "top_k": self.top_k,
#                     "splitter": self.splitter,
#                 },
#             },
#         }
#         from databricks.sdk import WorkspaceClient
#         from services.integrations.mcp.client import get_mcp_server_urls
#
#         auth_headers = WorkspaceClient().config.authenticate()
#         mcp_url = get_mcp_server_urls()[0]
#
#         with httpx.Client(timeout=60.0) as client:
#             resp = client.post(
#                 mcp_url,
#                 json=payload,
#                 headers={
#                     **auth_headers,
#                     "Content-Type": "application/json",
#                     "Accept": "application/json, text/event-stream",
#                 },
#             )
#             resp.raise_for_status()
#
#         result = resp.json().get("result", {})
#         content = result.get("content", [])
#
#         if not content:
#             return "No relevant documents found."
#
#         try:
#             tool_output = json.loads(content[0]["text"])
#             docs = tool_output.get("results", [])
#             logger.info(
#                 "MCPVectorSearchTool | retrieved=%d query=%r",
#                 len(docs),
#                 query[:80],
#             )
#             return "\n\n---\n\n".join(
#                 f"[{doc['rank']}] {doc['content']}" for doc in docs
#             ) or "No relevant documents found."
#         except Exception as exc:
#             logger.warning("MCPVectorSearchTool parse error: %s", exc)
#             return str(content[0].get("text", "No relevant documents found."))
#
#
# def build_mcp_vector_tool(
#     top_k: int = 10,
#     splitter: str = "recursive",
# ) -> MCPVectorSearchTool:
#     """Construct the MCP vector search tool. URL is resolved lazily at call time."""
#     return MCPVectorSearchTool(
#         top_k=top_k,
#         splitter=splitter,
#     )
