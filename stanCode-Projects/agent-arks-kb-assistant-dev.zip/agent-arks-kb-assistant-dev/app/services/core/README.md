# Arks Agent Core

此目錄是 `arks-agent` Databricks App 內的 Agent runtime。現在正式部署方式是
Databricks App + DABs，App 直接從 `app/` source code 啟動，不再使用舊的
MLflow UC model logging / Model Serving endpoint 部署流程。

## Runtime 架構

```text
Databricks App: arks-agent
  POST /responses
    -> services.start_server:app
    -> services.core.databricks_agent
    -> create_core_agent()
       -> LLM endpoint: databricks-gpt-5-4
       -> MCP retriever App: mcp-cm-kb-mongodb
       -> Lakebase Autoscaling checkpointer: arks-lakebase-v2
       -> MLflow tracing
```

## 主要檔案

| 檔案 | 說明 |
|---|---|
| `databricks_agent.py` | AgentServer runtime 入口，處理 `/responses` 呼叫 |
| `agent.py` | 建立 LangChain agent 與工具串接 |
| `runtime_config.py` | 統一 runtime request/config 正規化 |
| `memory/store.py` | 依 provider 建立 LangGraph checkpointer |
| `memory/snapshot.py` | 讀取 thread-level 對話記憶 |
| `memory/updater.py` | 更新 checkpointer 狀態 |

## 設定來源

主要設定在 `app/config/config.yaml`，部署時由 `databricks.yml` 的 App env 覆蓋。

| 設定 | 環境變數 | 目前線上值 |
|---|---|---|
| LLM provider | `LLM_PROVIDER` | `databricks` |
| LLM endpoint | `DATABRICKS_LLM_ENDPOINT` | `databricks-gpt-5-4` |
| Lakebase project | `DATABRICKS_LAKEBASE_NAME` | `arks-lakebase-v2` |
| Lakebase branch | `DATABRICKS_LAKEBASE_BRANCH` | `production` |
| Retrieval provider | `RETRIEVAL_PROVIDER` | `mcp` |
| MCP App URL | `MCP_APP_URL` | `mcp-cm-kb-mongodb` App URL |
| Streaming | `AGENT_STREAMING_ENABLED` | `true` |

## Lakebase 記憶

短期記憶使用 Lakebase Autoscaling project `arks-lakebase-v2`：

- Branch: `production`
- Database: `databricks_postgres`
- App resource permission: `CAN_CONNECT_AND_CREATE`
- Checkpoint tables: `checkpoints`, `checkpoint_blobs`, `checkpoint_writes`, `checkpoint_migrations`

部署後，`arks_setup_lakebase` job 會：

1. 讀取 `arks-agent` 自動產生的 App Service Principal client ID。
2. 連到 `projects/arks-lakebase-v2/branches/production`。
3. 建立 App SP 的 PostgreSQL role。
4. 授權 `CONNECT`、`CREATE`、`USAGE`。
5. 刪除由 deployer 建出的舊 checkpoint tables，讓 App SP 在啟動時重新建立並成為 owner。

App 啟動時，`memory/store.py` 會建立 `AsyncCheckpointSaver` 並執行 `setup()`。
table owner 必須是 App SP，否則日後 migration 可能出現 `must be owner` 錯誤。

## 部署與初始化

主流程在 bundle root 執行：

```bash
databricks bundle validate -t ut
databricks bundle deploy -t ut
databricks bundle run arks_setup_lakebase -t ut
databricks bundle run arks_setup_mlflow -t ut
databricks bundle run arks_agent -t ut
```

一般程式碼更新只需要 `bundle deploy` 與重新啟動 App。只有以下情況需要重跑 setup jobs：

| 情境 | 需要動作 |
|---|---|
| 首次部署 | 跑 `arks_setup_lakebase`、`arks_setup_mlflow` |
| App destroy 後重建 | 跑兩個 setup jobs，因 App SP 會變 |
| Lakebase project 重建 | 跑 `arks_setup_lakebase` |
| Checkpoint table owner 錯誤 | 跑 `arks_setup_lakebase` 後重啟 App |
| Prompt Registry 權限異常 | 跑 `arks_setup_mlflow` 或請 admin 手動 grant |

## 驗證

查看 App resource 是否已掛上 Lakebase：

```bash
databricks apps get arks-agent --profile ut --output json
```

輸出中應包含：

```json
{
  "name": "lakebase",
  "postgres": {
    "branch": "projects/arks-lakebase-v2/branches/production",
    "database": "projects/arks-lakebase-v2/branches/production/databases/databricks-postgres",
    "permission": "CAN_CONNECT_AND_CREATE"
  }
}
```

查看 runtime logs：

```bash
databricks apps logs arks-agent --profile ut
```

正常情況下，`POST /responses` 應回 `200 OK`，且不應出現 Lakebase permission
denied、connection refused、或 `must be owner` 錯誤。

## Legacy

以下腳本保留為舊 Model Serving 流程參考，不是目前線上 `arks-agent` 的部署方式：

- `app/services/scripts/log_to_databricks.py`
- `app/services/scripts/deploy_to_databricks.py`
- `app/services/scripts/validate_before_deploy.py`

## LiteLLM Provider

The Databricks App bundle defaults to `LLM_PROVIDER=litellm`.

Required runtime environment variables:

- `LITELLM_MODEL`: model route name exposed by the LiteLLM proxy.
- `LITELLM_ENDPOINT`: OpenAI-compatible LiteLLM base URL. `/v1` is appended by the adapter if omitted.
- `LITELLM_API_KEY`: injected from the Databricks secret resource `arks/litellm-api-key`.

Databricks fallback remains available by setting `LLM_PROVIDER=databricks` and `DATABRICKS_LLM_ENDPOINT=<endpoint>`.
