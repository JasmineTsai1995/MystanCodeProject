"""
Core Agent Runtime

Builds and exposes a LangChain 1.0 create_agent-based agent.

Short-term memory is enabled by passing a checkpointer.
Each unique thread_id maintains its own conversation history.

    agent = create_core_agent(tools=[...], checkpointer=get_checkpointer())
    agent.invoke(
        {"messages": [HumanMessage("hi")]},
        config={"configurable": {"thread_id": "session-1"}}
    )

Middleware is injected at build time. Supported hooks:
    before_agent / after_agent — once per invocation
    before_model / after_model — before/after each LLM call
    wrap_model_call            — intercept the LLM call itself
    wrap_tool_call             — intercept each tool execution

Built-in optional middleware:
    use_reflection — LLM-as-judge grades the final answer; rewrites in-place
                     if quality is insufficient (ReflectionMiddleware).
    use_followup   — Appends 2-3 suggested follow-up questions to each response
                     (FollowUpMiddleware).
"""

from __future__ import annotations

from langchain.agents import create_agent

from services.core.runtime_config import runtime_config
from services.integrations.model.llm_adapter import get_llm


def create_core_agent(
    tools: list | None = None,
    system_prompt: str = "You are a helpful assistant.",
    middleware: list | None = None,
    checkpointer=None,
    use_reflection: bool = False,
    use_followup: bool = False,
):
    """Build and return a compiled LangChain 1.0 agent.

    Args:
        tools:          LangChain-compatible tool objects.
        system_prompt:  System prompt string.
        middleware:     List of AgentMiddleware instances or decorator functions.
                        Runs before any built-in middleware added by the flags below.
        checkpointer:   LangGraph checkpointer for short-term memory.
                        Use get_checkpointer() from core.memory.store.
                        If None, each invocation is stateless.
        use_reflection: When True, appends ReflectionMiddleware which grades the
                        final answer with an LLM judge and rewrites it in-place if
                        the quality is insufficient.
        use_followup:   When True, appends FollowUpMiddleware which generates 2-3
                        follow-up question suggestions and appends them to the
                        final response.

    Returns:
        A compiled agent ready to invoke / stream.
    """
    llm = get_llm(
        model=runtime_config.model_name,
        temperature=runtime_config.temperature,
    )

    all_middleware: list = list(middleware or [])

    if use_reflection:
        from services.orchestration.reflection_loop import ReflectionMiddleware
        all_middleware.append(ReflectionMiddleware())

    if use_followup:
        from services.orchestration.followup_manager import FollowUpMiddleware
        all_middleware.append(FollowUpMiddleware())

    kwargs: dict = dict(
        model=llm,
        tools=tools or [],
        system_prompt=system_prompt,
        middleware=all_middleware,
    )
    if checkpointer is not None:
        kwargs["checkpointer"] = checkpointer

    return create_agent(**kwargs)
