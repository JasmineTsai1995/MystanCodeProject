"""
Databricks Agent — MLflow entry point.

=== Databricks App mode (active) ===
Uses @invoke / @stream decorators with LongRunningAgentServer.
Fully async — no ThreadPoolExecutor workarounds needed.

=== Serving Endpoint mode (legacy, commented out below) ===
The original ArksAgent(ResponsesAgent) class is preserved in comments
at the bottom of this file for reference / rollback.

Memory:  AsyncCheckpointSaver via get_async_checkpointer()
         (Lakebase Autoscaling when LLM_PROVIDER=databricks + DATABRICKS_LAKEBASE_NAME set,
          InMemorySaver otherwise)
Tools:   Resolved via services.tools.registry.get_tools()
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, AsyncGenerator, Sequence

# Ensure app/ is on sys.path for local development.
_THIS = Path(__file__).resolve()
for _candidate in _THIS.parents:
    if (_candidate / "config").is_dir():
        if str(_candidate) not in sys.path:
            sys.path.insert(0, str(_candidate))
        break

import mlflow
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages
from mlflow.genai.agent_server import invoke, stream
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
    create_text_output_item,
    to_chat_completions_input,
)
from typing_extensions import Annotated, TypedDict

from config.loader import cfg
from config.prompts import get_agent_system_prompt_snapshot
from services.core.agent import create_core_agent
from services.core.memory.store import get_async_checkpointer
from services.integrations.mlflow.trace_location import configure_experiment_trace_location
from services.tools.registry import get_tools

logger = logging.getLogger(__name__)
_SESSION_ROUTING_VERSION = "eval-routing-v2"

if not os.environ.get("SKIP_MCP_TOOL_INIT"):
    configure_experiment_trace_location(
        experiment_id=os.getenv("MLFLOW_EXPERIMENT_ID"),
        required=False,
        logger=logger,
    )
    mlflow.langchain.autolog(run_tracer_inline=True)

LLM_ENDPOINT = cfg(
    "llm.databricks.llm_endpoint", "DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-4"
)


class AgentState(TypedDict, total=False):
    messages: Annotated[Sequence[AnyMessage], add_messages]
    # Prefilter context forwarded from custom_inputs.
    # Keys: role, insurance_department, cathay_no, system_code, session_id,
    # query_timestamp.
    custom_inputs: dict[str, Any]


# ---------------------------------------------------------------------------
# Agent factory (lazy, async)
# ---------------------------------------------------------------------------

_agent_instance = None
_checkpointer_instance = None
_tools_instance = None
_agent_prompt_identity = None
_agent_prompt_snapshot = None
_agent_lock = asyncio.Lock()


async def _get_agent():
    """Build or refresh the agent when the production prompt changes."""
    global _agent_instance, _checkpointer_instance, _tools_instance, _agent_prompt_identity
    global _agent_prompt_snapshot

    prompt_snapshot = get_agent_system_prompt_snapshot()
    if (
        _agent_instance is not None
        and _agent_prompt_identity == prompt_snapshot.identity
    ):
        return _agent_instance

    async with _agent_lock:
        prompt_snapshot = get_agent_system_prompt_snapshot()
        if (
            _agent_instance is not None
            and _agent_prompt_identity == prompt_snapshot.identity
        ):
            return _agent_instance

        if _tools_instance is None:
            _tools_instance = get_tools()
            logger.info(
                "Loaded %d tools: %s",
                len(_tools_instance),
                [t.name for t in _tools_instance],
            )

        if _checkpointer_instance is None:
            _checkpointer_instance = await get_async_checkpointer()

        old_identity = _agent_prompt_identity
        _agent_instance = create_core_agent(
            tools=_tools_instance,
            system_prompt=prompt_snapshot.template,
            checkpointer=_checkpointer_instance,
            use_reflection=False,
        )
        _agent_prompt_identity = prompt_snapshot.identity
        _agent_prompt_snapshot = prompt_snapshot
        if old_identity is None:
            logger.info(
                "Agent initialized with prompt source=%s name=%s alias=%s version=%s",
                prompt_snapshot.source,
                prompt_snapshot.registry_name,
                prompt_snapshot.alias,
                prompt_snapshot.version or "none",
            )
        else:
            logger.info(
                "Agent prompt changed old_identity=%s new_identity=%s; rebuilt agent",
                old_identity,
                _agent_prompt_identity,
            )
    return _agent_instance


_BASE62_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
_DEFAULT_SYSTEM_CODE = "arks"


def _base62_encode(value: int) -> str:
    if value == 0:
        return _BASE62_ALPHABET[0]
    chars: list[str] = []
    while value:
        value, remainder = divmod(value, 62)
        chars.append(_BASE62_ALPHABET[remainder])
    return "".join(reversed(chars))


def _ksuid_ms() -> str:
    """Return a millisecond-sortable ID similar to ksuid.ksuidMs."""
    timestamp_ms = int(time.time() * 1000)
    random_bits = int.from_bytes(os.urandom(16), "big")
    return f"{_base62_encode(timestamp_ms)}{_base62_encode(random_bits).zfill(22)}"


def _clean_session_part(value: Any, fallback: str) -> str:
    if not isinstance(value, str) or not value.strip():
        return fallback
    cleaned = "".join(
        ch if ch.isalnum() or ch in ("_", "-") else "-"
        for ch in value.strip()
    ).strip("-")
    return cleaned or fallback


def _get_system_code(request: ResponsesAgentRequest) -> str:
    raw_inputs = request.custom_inputs or {}
    return _clean_session_part(raw_inputs.get("system_code"), _DEFAULT_SYSTEM_CODE)


def _get_session_id(request: ResponsesAgentRequest) -> tuple[str, str]:
    raw_inputs = request.custom_inputs or {}
    explicit_session_id = raw_inputs.get("session_id")
    if isinstance(explicit_session_id, str) and explicit_session_id.strip():
        return explicit_session_id.strip(), "custom_inputs.session_id"

    system_code = _get_system_code(request)
    cathay_no = _clean_session_part(raw_inputs.get("cathay_no"), "anonymous")
    if raw_inputs.get("eval_client_request_id") or raw_inputs.get("eval_row_index") is not None:
        return f"{cathay_no}-{system_code}-{_ksuid_ms()}", "eval_request"

    if request.context and request.context.conversation_id:
        return request.context.conversation_id, "context.conversation_id"

    return f"{cathay_no}-{system_code}-{_ksuid_ms()}", "generated"


# ---------------------------------------------------------------------------
# MLflow App handlers — @invoke / @stream
# ---------------------------------------------------------------------------


@invoke()
async def invoke_handler(request: ResponsesAgentRequest) -> ResponsesAgentResponse:
    # 合併所有 stream chunks 成單一完整回應
    session_id, session_source = _get_session_id(request)
    message_id = f"msg_{_ksuid_ms()}"
    _update_trace_session(request, session_id, session_source)

    parts: list[str] = []
    async for event in _stream_events(request, session_id, message_id):
        if event.type == "response.output_item.done":
            for block in (event.item.get("content") or []):
                if block.get("type") == "output_text" and block.get("text"):
                    parts.append(block["text"])
    full_text = "".join(parts)
    return ResponsesAgentResponse(
        output=[create_text_output_item(text=full_text, id=message_id)],
        custom_outputs={
            "session_id": session_id,
            "arks_session_source": session_source,
            "arks_session_routing_version": _SESSION_ROUTING_VERSION,
        },
    )


@stream()
async def stream_handler(
    request: ResponsesAgentRequest,
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:
    session_id, session_source = _get_session_id(request)
    message_id = f"msg_{_ksuid_ms()}"
    _update_trace_session(request, session_id, session_source)

    async for event in _stream_events(request, session_id, message_id):
        event.custom_outputs = {
            **(event.custom_outputs or {}),
            "session_id": session_id,
            "arks_session_source": session_source,
            "arks_session_routing_version": _SESSION_ROUTING_VERSION,
        }
        yield event


def _update_trace_session(request: ResponsesAgentRequest, session_id: str, session_source: str) -> None:
    try:
        raw_inputs = request.custom_inputs or {}
        metadata = {"system_code": _get_system_code(request)}
        tags: dict[str, str] = {}
        cathay_no = raw_inputs.get("cathay_no")
        query_timestamp = raw_inputs.get("query_timestamp")
        if isinstance(query_timestamp, str) and query_timestamp:
            metadata["query_timestamp"] = query_timestamp
        for key in ("client_request_id", "eval_client_request_id", "eval_row_index"):
            value = raw_inputs.get(key)
            if value is not None and str(value):
                tags[key] = str(value)
        tags["arks_session_source"] = session_source
        tags["arks_session_routing_version"] = _SESSION_ROUTING_VERSION
        logger.info(
            "Resolved session_id=%s source=%s version=%s custom_input_keys=%s context_conversation_id=%s",
            session_id,
            session_source,
            _SESSION_ROUTING_VERSION,
            sorted(str(key) for key in raw_inputs.keys()),
            getattr(request.context, "conversation_id", None) if request.context else None,
        )
        kwargs: dict[str, Any] = {
            "session_id": session_id,
            "metadata": metadata,
        }
        if tags:
            kwargs["tags"] = tags
        if isinstance(cathay_no, str) and cathay_no:
            kwargs["user"] = cathay_no
        mlflow.update_current_trace(**kwargs)
    except Exception as exc:
        logger.debug("No active MLflow trace to update: %s", exc)


async def _stream_events(
    request: ResponsesAgentRequest,
    session_id: str,
    message_id: str,
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:

    config: dict[str, Any] = {"configurable": {"thread_id": session_id}}
    messages = to_chat_completions_input(
        [i.model_dump() for i in request.input]
    )

    # Extract request context from custom_inputs and forward to agent state.
    # Preferred schema:
    #   session_id: str
    #   system_code: str
    #   role: str | list[str]
    #   insurance_department: dict[str, list[str]]
    #   cathay_no: str
    #   query_timestamp: str (RFC 3339 UTC)
    # Backward compatibility: insurance_type + departmental are folded into
    # insurance_department when the preferred field is absent.

    def _normalize(val: Any) -> list[str] | None:
        if isinstance(val, list):
            items = [item for item in val if isinstance(item, str) and item]
            return items or None
        if isinstance(val, str):
            return [val]
        return None

    def _normalize_insurance_department(val: Any) -> dict[str, list[str]] | None:
        if not isinstance(val, dict):
            return None
        result: dict[str, list[str]] = {}
        for insurance_type, departments in val.items():
            if not isinstance(insurance_type, str) or not insurance_type:
                continue
            normalized_departments = _normalize(departments)
            if normalized_departments:
                result[insurance_type] = normalized_departments
        return result or None

    def _legacy_insurance_department(
        raw: dict[str, Any],
    ) -> dict[str, list[str]] | None:
        insurance_types = _normalize(raw.get("insurance_type"))
        departments = _normalize(raw.get("departmental"))
        if not insurance_types or not departments:
            return None
        return {insurance_type: departments for insurance_type in insurance_types}

    raw_inputs = request.custom_inputs or {}
    prefilter_ctx: dict[str, Any] = {}
    prefilter_ctx["session_id"] = session_id
    prefilter_ctx["system_code"] = _get_system_code(request)

    role = _normalize(raw_inputs.get("role"))
    if role is not None:
        prefilter_ctx["role"] = role

    insurance_department = _normalize_insurance_department(
        raw_inputs.get("insurance_department")
    )
    if insurance_department is None:
        insurance_department = _legacy_insurance_department(raw_inputs)
    if insurance_department is not None:
        prefilter_ctx["insurance_department"] = insurance_department

    cathay_no = raw_inputs.get("cathay_no")
    if isinstance(cathay_no, str) and cathay_no:
        prefilter_ctx["cathay_no"] = cathay_no

    query_timestamp = raw_inputs.get("query_timestamp")
    if isinstance(query_timestamp, str) and query_timestamp:
        prefilter_ctx["query_timestamp"] = query_timestamp

    state: dict[str, Any] = {"messages": messages}
    if prefilter_ctx:
        state["custom_inputs"] = prefilter_ctx

    agent = await _get_agent()

    async for chunk in agent.astream(
        state,
        config=config,
        stream_mode=["messages"],
        version="v2",
    ):
        if chunk["type"] == "messages":
            token, metadata = chunk["data"]
            if metadata.get("langgraph_node") == "model":
                for block in (token.content_blocks or []):
                    if block.get("type") == "text" and block.get("text"):
                        yield ResponsesAgentStreamEvent(
                            type="response.output_item.done",
                            item=create_text_output_item(
                                text=block["text"],
                                id=message_id,
                            ),
                        )


# ===========================================================================
# [LEGACY — Serving Endpoint mode]
#
# The code below was the original deployment path using MLflow Model Serving.
# It is preserved for reference and potential rollback.
# To revert: uncomment this section and comment out the @invoke/@stream
# handlers above.
# ===========================================================================

# """
# Databricks Agent — MLflow ResponsesAgent wrapper (Serving Endpoint).
#
# This was the MLflow entry point for Databricks Model Serving.
# Wraps create_core_agent in the ResponsesAgent interface.
#
# Memory:  Lakebase Autoscaling (LLM_PROVIDER=databricks + DATABRICKS_LAKEBASE_NAME set)
#          InMemorySaver otherwise (conversation_id from ChatContext used as thread_id).
# Tools:   Resolved via services.tools.registry.get_tools()
#
# Streaming:
#   MCP tools from langchain-mcp-adapters are async-only (only implement _arun).
#   Both paths run the agent with async methods (ainvoke / astream) inside a
#   dedicated thread so the sync predict_stream() generator can yield normally.
#
#   AGENT_STREAMING_ENABLED=false (default)
#     predict_stream() runs agent.ainvoke() in a ThreadPoolExecutor and yields
#     one event with the final response.
#
#   AGENT_STREAMING_ENABLED=true
#     predict_stream() runs agent.astream(stream_mode=["messages"], version="v2")
#     in a background thread, feeds chunks into a queue, and yields one event
#     per LLM text token from the model node.
#     Tool call chunks and raw tool results are filtered out — only the final
#     text response reaches the user.
# """
#
# import asyncio
# import contextvars
# import queue
# import threading
# from concurrent.futures import ThreadPoolExecutor
#
# from mlflow.pyfunc import ResponsesAgent
# from mlflow.types.responses import (
#     ResponsesAgentRequest,
#     ResponsesAgentResponse,
#     ResponsesAgentStreamEvent,
#     to_chat_completions_input,
# )
#
# from config.loader import cfg, cfg_bool
# from services.core.agent import create_core_agent
# from services.core.memory.store import get_checkpointer
# from config.prompts import AGENT_SYSTEM_PROMPT
# from services.tools.registry import get_tools
#
# LLM_ENDPOINT = cfg("llm.databricks.llm_endpoint", "DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-4")
#
# # When True, predict() returns a dummy response instead of running the agent.
# # Set during model logging so MLflow's automatic input-example validation
# # does not require a live LLM / tools.
# _LOGGING_MODE = os.environ.get("SKIP_MCP_TOOL_INIT", "").lower() in ("true", "1", "yes")
#
# # When True, predict_stream() uses agent.stream(stream_mode=["messages"]) to
# # yield one event per LLM text token. When False, uses agent.invoke().
# _STREAMING_ENABLED = cfg_bool("llm.streaming_enabled", "AGENT_STREAMING_ENABLED", False)
#
# _DUMMY_RESPONSE_TEXT = "Model validation placeholder — agent not initialized during logging."
#
#
# class ArksAgent(ResponsesAgent):
#     """Arks insurance assistant — Databricks Model Serving entry point."""
#
#     def __init__(self) -> None:
#         self._agent: Any | None = None
#
#     def _ensure_agent(self):
#         """Build the runtime lazily so model logging does not require MCP env vars."""
#         if self._agent is None:
#             tools = get_tools()
#             print(f"[ArksAgent] Loaded {len(tools)} tools: {[t.name for t in tools]}")
#             self._agent = create_core_agent(
#                 tools=tools,
#                 system_prompt=AGENT_SYSTEM_PROMPT,
#                 checkpointer=get_checkpointer(),
#                 use_reflection=True,
#             )
#         return self._agent
#
#     def _get_thread_id(self, request: ResponsesAgentRequest) -> str:
#         if request.custom_inputs and request.custom_inputs.get("thread_id"):
#             return request.custom_inputs["thread_id"]
#         if request.context and request.context.conversation_id:
#             return request.context.conversation_id
#         return str(uuid.uuid4())
#
#     def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
#         if _LOGGING_MODE:
#             return ResponsesAgentResponse(
#                 output=[self.create_text_output_item(text=_DUMMY_RESPONSE_TEXT, id="msg_1")]
#             )
#         # Collect all stream events from predict_stream() to build the full response.
#         outputs = [
#             event.item
#             for event in self.predict_stream(request)
#             if event.type == "response.output_item.done"
#         ]
#         return ResponsesAgentResponse(output=outputs)
#
#     def predict_stream(
#         self, request: ResponsesAgentRequest
#     ) -> Generator[ResponsesAgentStreamEvent, None, None]:
#         if _LOGGING_MODE:
#             yield ResponsesAgentStreamEvent(
#                 type="response.output_item.done",
#                 item=self.create_text_output_item(text=_DUMMY_RESPONSE_TEXT, id="msg_1"),
#             )
#             return
#
#         # to_chat_completions_input preserves the full conversation history
#         # (user + assistant turns), fixing the multi-turn context loss in the
#         # previous _run_request() implementation.
#         cc_msgs = to_chat_completions_input([i.model_dump() for i in request.input])
#         thread_id = self._get_thread_id(request)
#         agent = self._ensure_agent()
#
#         if not _STREAMING_ENABLED:
#             # Non-streaming path: run agent.ainvoke() in a new event loop on a
#             # dedicated thread (MCP tools are async-only; sync invoke() fails).
#             # copy_context() carries the MLflow active span into the new thread
#             # so LangGraph child spans are nested under predict_stream in the trace.
#             ctx = contextvars.copy_context()
#
#             def _invoke():
#                 return ctx.run(
#                     lambda: asyncio.run(
#                         agent.ainvoke(
#                             {"messages": cc_msgs},
#                             config={"configurable": {"thread_id": thread_id}},
#                         )
#                     )
#                 )
#
#             with ThreadPoolExecutor(max_workers=1) as pool:
#                 result = pool.submit(_invoke).result()
#
#             text = result["messages"][-1].content
#             yield ResponsesAgentStreamEvent(
#                 type="response.output_item.done",
#                 item=self.create_text_output_item(text=text, id="msg_1"),
#             )
#             return
#
#         # Streaming path: run agent.astream() in a background thread and feed
#         # chunks into a queue so this sync generator can yield them.
#         _q: queue.Queue = queue.Queue()
#         ctx = contextvars.copy_context()
#
#         async def _stream():
#             try:
#                 async for chunk in agent.astream(
#                     {"messages": cc_msgs},
#                     config={"configurable": {"thread_id": thread_id}},
#                     stream_mode=["messages"],
#                     version="v2",
#                 ):
#                     _q.put(chunk)
#             except Exception as exc:
#                 _q.put(exc)
#             finally:
#                 _q.put(None)  # sentinel
#
#         t = threading.Thread(
#             target=lambda: ctx.run(lambda: asyncio.run(_stream())),
#             daemon=True,
#         )
#         t.start()
#
#         while True:
#             item = _q.get()
#             if item is None:
#                 break
#             if isinstance(item, BaseException):
#                 t.join()
#                 raise item
#             if item["type"] == "messages":
#                 token, metadata = item["data"]
#                 if metadata.get("langgraph_node") == "model":
#                     for block in (token.content_blocks or []):
#                         if block.get("type") == "text" and block.get("text"):
#                             yield ResponsesAgentStreamEvent(
#                                 type="response.output_item.done",
#                                 item=self.create_text_output_item(
#                                     text=block["text"], id="msg_1"
#                                 ),
#                             )
#
#         t.join()
#
#
# if not os.environ.get("SKIP_MCP_TOOL_INIT"):
#     mlflow.langchain.autolog()
# AGENT = ArksAgent()
# mlflow.models.set_model(AGENT)
