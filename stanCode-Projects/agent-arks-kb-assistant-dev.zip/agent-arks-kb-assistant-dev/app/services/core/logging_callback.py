"""
Agent Logging Callback

Structured logging for every significant event during an agent run:
  - LLM invocations (prompt summary, completion text, token usage, latency)
  - Tool calls (name, input, output / error, latency)
  - Agent actions and final answers

Usage
-----
Pass an instance to agent.invoke() via the "callbacks" key in RunnableConfig:

    from services.core.logging_callback import AgentLoggingCallbackHandler

    handler = AgentLoggingCallbackHandler()
    agent.invoke(
        {"messages": [HumanMessage(content="...")]},
        config={"configurable": {"thread_id": tid}, "callbacks": [handler]},
    )
"""

from __future__ import annotations

import logging
import time
from typing import Any, Union
from uuid import UUID

from langchain_core.agents import AgentAction, AgentFinish
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatGeneration, LLMResult

logger = logging.getLogger("agent.trace")


def _truncate(text: str, max_len: int = 300) -> str:
    return text if len(text) <= max_len else text[:max_len] + " …[truncated]"


def _messages_summary(messages: list[list[BaseMessage]]) -> str:
    flat = [m for batch in messages for m in batch]
    if not flat:
        return "(no messages)"
    last = flat[-1]
    role = last.__class__.__name__.replace("Message", "").lower()
    return f"{len(flat)} msg(s), last={role}: {_truncate(str(last.content))}"


class AgentLoggingCallbackHandler(BaseCallbackHandler):
    """Logs LLM completions, tool calls, agent actions, and final answers."""

    # ------------------------------------------------------------------ #
    # Internal timing registry                                             #
    # ------------------------------------------------------------------ #

    def __init__(self) -> None:
        super().__init__()
        self._llm_start: dict[UUID, float] = {}
        self._tool_start: dict[UUID, float] = {}
        self._tool_names: dict[UUID, str] = {}

    # ------------------------------------------------------------------ #
    # LLM events                                                           #
    # ------------------------------------------------------------------ #

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._llm_start[run_id] = time.monotonic()
        model = serialized.get("kwargs", {}).get("model_name", "unknown")
        logger.info(
            "[LLM START] model=%s prompts=%d first=%s",
            model,
            len(prompts),
            _truncate(prompts[0]) if prompts else "",
        )

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._llm_start[run_id] = time.monotonic()
        model = (
            serialized.get("kwargs", {}).get("model_name")
            or serialized.get("kwargs", {}).get("model")
            or "unknown"
        )
        logger.info(
            "[LLM START] model=%s %s",
            model,
            _messages_summary(messages),
        )

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        elapsed = time.monotonic() - self._llm_start.pop(run_id, time.monotonic())
        usage = response.llm_output.get("token_usage", {}) if response.llm_output else {}

        for gen_list in response.generations:
            for gen in gen_list:
                if isinstance(gen, ChatGeneration):
                    text = _truncate(gen.text or str(gen.message.content))
                    finish = gen.generation_info.get("finish_reason", "?") if gen.generation_info else "?"
                    logger.info(
                        "[LLM END] latency=%.2fs finish=%s tokens=%s output=%s",
                        elapsed,
                        finish,
                        usage,
                        text,
                    )

    def on_llm_error(
        self, error: BaseException, *, run_id: UUID, **kwargs: Any
    ) -> None:
        self._llm_start.pop(run_id, None)
        logger.error("[LLM ERROR] %s", error)

    # ------------------------------------------------------------------ #
    # Tool events                                                          #
    # ------------------------------------------------------------------ #

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        name = serialized.get("name", "unknown_tool")
        self._tool_start[run_id] = time.monotonic()
        self._tool_names[run_id] = name
        logger.info(
            "[TOOL CALL] tool=%s input=%s",
            name,
            _truncate(input_str),
        )

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> None:
        elapsed = time.monotonic() - self._tool_start.pop(run_id, time.monotonic())
        name = self._tool_names.pop(run_id, "unknown_tool")
        logger.info("[TOOL END] tool=%s latency=%.2fs", name, elapsed)

    def on_tool_error(
        self, error: BaseException, *, run_id: UUID, **kwargs: Any
    ) -> None:
        elapsed = time.monotonic() - self._tool_start.pop(run_id, time.monotonic())
        name = self._tool_names.pop(run_id, "unknown_tool")
        logger.error(
            "[TOOL ERROR] tool=%s latency=%.2fs error=%s",
            name,
            elapsed,
            error,
        )

    # ------------------------------------------------------------------ #
    # Agent events                                                         #
    # ------------------------------------------------------------------ #

    def on_agent_action(
        self,
        action: AgentAction,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        logger.info(
            "[AGENT ACTION] tool=%s input=%s log=%s",
            action.tool,
            _truncate(str(action.tool_input)),
            _truncate(action.log or ""),
        )

    def on_agent_finish(
        self,
        finish: AgentFinish,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        output = finish.return_values.get("output", "")
        logger.info(
            "[AGENT FINISH] output=%s",
            _truncate(str(output)),
        )
