"""
Memory Snapshot

Utilities for reading thread state (conversation history)
from a checkpointer.
"""

from __future__ import annotations

from typing import Any

from langgraph.checkpoint.memory import InMemorySaver


def get_thread_messages(
    checkpointer: InMemorySaver,
    thread_id: str,
) -> list[dict[str, Any]]:
    """Return all messages stored for a given thread_id.

    Returns an empty list if the thread has no history yet.
    """
    config = {"configurable": {"thread_id": thread_id}}
    checkpoint = checkpointer.get(config)
    if checkpoint is None:
        return []
    return checkpoint.get("channel_values", {}).get("messages", [])


def thread_exists(checkpointer: InMemorySaver, thread_id: str) -> bool:
    """Return True if the thread_id has existing checkpoint state."""
    config = {"configurable": {"thread_id": thread_id}}
    return checkpointer.get(config) is not None
