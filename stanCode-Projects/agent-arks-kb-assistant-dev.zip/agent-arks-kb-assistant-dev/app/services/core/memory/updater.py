"""
Memory Updater

Utilities for managing conversation history length.
Prevents context-window overflow on long conversations.

Strategy options:
  - trim_messages : keep only the last N messages
  (future) summarize : compress old messages into a summary
"""

from __future__ import annotations

from langchain_core.messages import BaseMessage


def trim_messages(
    messages: list[BaseMessage],
    max_messages: int = 20,
) -> list[BaseMessage]:
    """Return the last `max_messages` messages.

    Always preserves the most recent exchange to avoid
    cutting off mid-conversation context.
    """
    if len(messages) <= max_messages:
        return messages
    return messages[-max_messages:]
