"""
Memory Store

Provides a checkpointer for short-term (thread-level) memory.
The checkpointer persists conversation state between invocations
on the same thread_id.

Backend is selected by LLM_PROVIDER env var:

  "openrouter" (default) — InMemorySaver (process-local, non-persistent).
    No extra configuration required.

  "databricks" — DatabricksLakebaseSaver (persistent, cross-process).
    Requires: DATABRICKS_LAKEBASE_NAME env var pointing to a Lakebase
    Autoscaling project (Databricks managed PostgreSQL).
    Optional: DATABRICKS_LAKEBASE_BRANCH (defaults to "production").
    Install: databricks-langchain[memory]

Usage:
    from services.core.memory.store import get_checkpointer

    checkpointer = get_checkpointer()
    agent = create_core_agent(tools=[...], checkpointer=checkpointer)

    # Each call with the same thread_id resumes the same conversation
    agent.invoke({"messages": [...]}, config={"configurable": {"thread_id": "abc"}})
"""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator, Iterator, Optional

logger = logging.getLogger(__name__)

from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

from config.loader import cfg


def _is_missing_async_checkpoint_saver(exc: ImportError) -> bool:
    """Return True only when the async saver symbol itself is unavailable."""
    message = str(exc)
    return (
        "AsyncCheckpointSaver" in message
        and "databricks_langchain" in message
    )


class _AsyncSyncWrapper(BaseCheckpointSaver):
    """Wraps a sync-only BaseCheckpointSaver with async methods.

    databricks_langchain.CheckpointSaver only implements sync methods, but
    LangGraph 1.x requires async counterparts (aget_tuple, alist, aput,
    aput_writes) when the graph is driven with ainvoke() / astream().
    This wrapper delegates to the sync methods via run_in_executor so the
    same Lakebase saver works in both sync and async contexts.
    """

    def __init__(self, inner: BaseCheckpointSaver) -> None:
        super().__init__()
        self._inner = inner

    @property
    def config_specs(self):
        return self._inner.config_specs

    # ------------------------------------------------------------------
    # Sync interface — delegate directly
    # ------------------------------------------------------------------

    def get_tuple(self, config) -> Optional[CheckpointTuple]:
        return self._inner.get_tuple(config)

    def list(self, config, *, filter=None, before=None, limit=None) -> Iterator[CheckpointTuple]:
        return self._inner.list(config, filter=filter, before=before, limit=limit)

    def put(self, config, checkpoint, metadata, new_versions):
        return self._inner.put(config, checkpoint, metadata, new_versions)

    def put_writes(self, config, writes, task_id):
        return self._inner.put_writes(config, writes, task_id)

    # ------------------------------------------------------------------
    # Async interface — run sync methods in executor
    # ------------------------------------------------------------------

    async def aget_tuple(self, config) -> Optional[CheckpointTuple]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.get_tuple, config)

    async def alist(self, config, *, filter=None, before=None, limit=None) -> AsyncIterator[CheckpointTuple]:
        loop = asyncio.get_running_loop()
        items = await loop.run_in_executor(
            None,
            lambda: list(self._inner.list(config, filter=filter, before=before, limit=limit)),
        )
        for item in items:
            yield item

    async def aput(self, config, checkpoint, metadata, new_versions):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, self.put, config, checkpoint, metadata, new_versions
        )

    async def aput_writes(self, config, writes, task_id):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, self.put_writes, config, writes, task_id
        )


def get_checkpointer() -> BaseCheckpointSaver:
    """Return a checkpointer appropriate for the active LLM_PROVIDER.

    This is the sync version, used by local dev scripts (e.g. run_agent.py).
    For Databricks App deployment, use get_async_checkpointer() instead.
    """
    provider = str(cfg("llm.provider", "LLM_PROVIDER", "openrouter")).strip().lower()

    if provider in ("databricks", "litellm"):
        lakebase_name = cfg("llm.databricks.lakebase_name", "DATABRICKS_LAKEBASE_NAME")
        lakebase_branch = cfg("llm.databricks.lakebase_branch", "DATABRICKS_LAKEBASE_BRANCH", "production")
        if lakebase_name and lakebase_name.lower() != "none":
            from databricks_langchain import CheckpointSaver
            inner = CheckpointSaver(project=lakebase_name, branch=lakebase_branch)
            inner.setup()  # Create checkpoints/checkpoint_blobs/checkpoint_writes tables
            return _AsyncSyncWrapper(inner)
        # Lakebase not configured — fall back to in-process memory with a warning
        import warnings
        warnings.warn(
            "DATABRICKS_LAKEBASE_NAME not set — using InMemorySaver. "
            "Conversation history will not persist across requests.",
            stacklevel=2,
        )

    # openrouter / local dev (default)
    from langgraph.checkpoint.memory import InMemorySaver

    return InMemorySaver()


async def get_async_checkpointer() -> BaseCheckpointSaver:
    """Return an async-native checkpointer for Databricks App deployment.

    Uses AsyncCheckpointSaver from databricks-langchain when available,
    which natively supports async operations without the _AsyncSyncWrapper.
    Falls back to the sync wrapper if AsyncCheckpointSaver is not available.
    """
    provider = str(cfg("llm.provider", "LLM_PROVIDER", "openrouter")).strip().lower()

    if provider in ("databricks", "litellm"):
        lakebase_name = cfg("llm.databricks.lakebase_name", "DATABRICKS_LAKEBASE_NAME")
        lakebase_branch = cfg("llm.databricks.lakebase_branch", "DATABRICKS_LAKEBASE_BRANCH", "production")
        if lakebase_name and lakebase_name.lower() != "none":
            try:
                from databricks_langchain import AsyncCheckpointSaver
                saver = AsyncCheckpointSaver(project=lakebase_name, branch=lakebase_branch)
                # AsyncConnectionPool is created with open=False; must be opened
                # before setup() can acquire a connection.
                await saver._lakebase.open()
                try:
                    await saver.setup()
                except Exception as exc:
                    err_msg = str(exc).lower()
                    err_type = type(exc).__name__.lower()
                    is_perm_error = (
                        "permission denied" in err_msg
                        or "must be owner" in err_msg
                        or "insufficientprivilege" in err_type
                    )
                    if is_perm_error:
                        # Verify tables actually exist before continuing
                        async with saver._lakebase.connection() as conn:
                            cur = await conn.execute(
                                "SELECT count(*) AS cnt FROM pg_tables "
                                "WHERE schemaname='public' AND tablename IN "
                                "('checkpoints','checkpoint_blobs','checkpoint_writes')"
                            )
                            row = await cur.fetchone()
                            # Support both tuple and dict-like row factories
                            if row is None:
                                table_count = 0
                            elif isinstance(row, (tuple, list)):
                                table_count = row[0]
                            else:
                                table_count = getattr(row, "cnt", None) or row.get("cnt", 0)
                        if table_count >= 3:
                            logger.warning(
                                "setup() skipped — %s. "
                                "Checkpoint tables already exist in Lakebase.",
                                exc,
                            )
                        else:
                            raise RuntimeError(
                                f"setup() failed ({exc}) and only {table_count}/3 "
                                "checkpoint tables exist. Run setup_lakebase.py "
                                "with owner credentials first."
                            ) from exc
                    else:
                        raise
                return saver
            except ImportError as exc:
                if not _is_missing_async_checkpoint_saver(exc):
                    raise
                # AsyncCheckpointSaver not available in this version —
                # fall back to sync wrapper
                from databricks_langchain import CheckpointSaver
                inner = CheckpointSaver(project=lakebase_name, branch=lakebase_branch)
                inner.setup()
                return _AsyncSyncWrapper(inner)

        import warnings
        warnings.warn(
            "DATABRICKS_LAKEBASE_NAME not set — using InMemorySaver. "
            "Conversation history will not persist across requests.",
            stacklevel=2,
        )

    from langgraph.checkpoint.memory import InMemorySaver
    return InMemorySaver()
