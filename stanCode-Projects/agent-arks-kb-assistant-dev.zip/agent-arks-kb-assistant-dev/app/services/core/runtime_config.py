"""
Runtime Configuration

Centralised settings for the agent runtime.
Values are read from app/config/config.yaml with environment variable overrides.
"""

from dataclasses import dataclass

from config.loader import cfg, cfg_float, cfg_int


def _llm_provider() -> str:
    return str(cfg("llm.provider", "LLM_PROVIDER", "openrouter")).strip().lower()


def _model_name() -> str:
    provider = _llm_provider()
    if provider == "litellm":
        return cfg("llm.litellm.model", "LITELLM_MODEL", "gpt-5.5")
    if provider == "databricks":
        return cfg("llm.databricks.llm_endpoint", "DATABRICKS_LLM_ENDPOINT", "databricks-gpt-5-4")
    return cfg("llm.openrouter.model", "AGENT_MODEL", "meta-llama/llama-4-maverick")


@dataclass
class RuntimeConfig:
    llm_provider:   str   = _llm_provider()
    model_name:     str   = _model_name()
    temperature:    float = cfg_float("llm.temperature", "AGENT_TEMPERATURE",    0.0)
    max_iterations: int   = cfg_int("llm.max_iterations", "AGENT_MAX_ITERATIONS", 10)
    recursion_limit: int  = cfg_int("llm.recursion_limit", "AGENT_RECURSION_LIMIT", 25)


# Global singleton
runtime_config = RuntimeConfig()
