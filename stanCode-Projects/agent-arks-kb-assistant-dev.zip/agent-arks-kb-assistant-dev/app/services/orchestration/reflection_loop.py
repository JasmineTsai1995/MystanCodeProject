"""
Reflection Loop Middleware

Uses an LLM-as-judge to grade the agent's final answer.
If the grade is NEEDS_REVISION, a second LLM call produces an improved response
that replaces the original in-place — one pass maximum, no recursion risk.

Architecture (from LangChain v1 docs):
    after_agent hook fires once the agent loop is complete.
    Mutating last_ai.content in-place is sufficient; no state dict return needed.
"""

from __future__ import annotations

from typing import Any

from langchain.agents import AgentState
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.runtime import Runtime

from services.core.runtime_config import runtime_config
from services.integrations.model.llm_adapter import get_llm
from config.prompts import get_judge_prompt, get_revise_prompt


class ReflectionMiddleware(AgentMiddleware):
    """Grade the agent's final answer; rewrite in-place if quality is insufficient.

    One reflection pass maximum to avoid any risk of infinite loops.

    Args:
        judge_model:       Model identifier; defaults to runtime_config.model_name.
        revise_model:      Model used to rewrite; defaults to judge_model.
        judge_temperature: Temperature for the judge call (deterministic).
        revise_temperature: Temperature for the rewrite call (slightly creative).
    """

    def __init__(
        self,
        judge_model: str = runtime_config.model_name,
        revise_model: str | None = None,
        judge_temperature: float = 0.0,
        revise_temperature: float = 0.3,
    ) -> None:
        super().__init__()
        # nostream tag: prevents judge/revise tokens from appearing in
        # agent.stream(stream_mode="messages") output to the end user.
        self._judge = get_llm(model=judge_model, temperature=judge_temperature).with_config(
            {"tags": ["nostream"]}
        )
        self._reviser = get_llm(model=revise_model or judge_model, temperature=revise_temperature).with_config(
            {"tags": ["nostream"]}
        )

    def after_agent(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        messages = state["messages"]
        if not messages:
            return None

        last_ai: AIMessage | None = next(
            (m for m in reversed(messages) if isinstance(m, AIMessage)), None
        )
        if last_ai is None or not last_ai.content:
            return None

        last_human: str = next(
            (str(m.content) for m in reversed(messages) if isinstance(m, HumanMessage)),
            "",
        )
        if not last_human:
            return None

        answer = str(last_ai.content)

        # --- Grade -----------------------------------------------------------
        grade_msg = self._judge.invoke(
            get_judge_prompt().format(question=last_human, answer=answer)
        )
        grade = str(grade_msg.content).strip()

        if "NEEDS_REVISION" not in grade:
            return None  # quality is fine

        critique = grade.replace("NEEDS_REVISION:", "").replace("NEEDS_REVISION", "").strip()
        if not critique:
            critique = "回答不夠完整或準確"

        # --- Revise in-place -------------------------------------------------
        revised_msg = self._reviser.invoke(
            get_revise_prompt().format(
                question=last_human,
                answer=answer,
                critique=critique,
            )
        )
        last_ai.content = str(revised_msg.content).strip()
        return None
