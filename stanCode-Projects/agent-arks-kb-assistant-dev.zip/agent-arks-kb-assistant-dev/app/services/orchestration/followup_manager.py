"""
Follow-Up Manager Middleware

After the agent finishes, generates 2-3 contextually relevant follow-up
questions and appends them to the final response so users know what they
can ask next.

Architecture (from LangChain v1 docs):
    after_agent hook fires once the agent loop is complete.
    Mutating last_ai.content in-place appends the suggestions without
    adding extra messages to the conversation history.
"""

from __future__ import annotations

from typing import Any

from langchain.agents import AgentState
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.runtime import Runtime

from services.core.runtime_config import runtime_config
from services.integrations.model.llm_adapter import get_llm
from config.prompts import get_followup_questions_prompt


class FollowUpMiddleware(AgentMiddleware):
    """Append suggested follow-up questions to the final AI response.

    Args:
        model:                Model identifier; defaults to runtime_config.model_name.
        max_followups:        Number of questions to suggest (default: 3).
        temperature:          Sampling temperature.
        answer_preview_chars: Characters of the answer to include as context.
    """

    def __init__(
        self,
        model: str = runtime_config.model_name,
        max_followups: int = 3,
        temperature: float = 0.5,
        answer_preview_chars: int = 400,
    ) -> None:
        super().__init__()
        self._llm = get_llm(model=model, temperature=temperature)
        self._max_followups = max_followups
        self._preview_chars = answer_preview_chars

    def after_agent(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        messages = state["messages"]
        if not messages:
            return None

        last_ai: AIMessage | None = next(
            (m for m in reversed(messages) if isinstance(m, AIMessage)), None
        )
        if last_ai is None or not last_ai.content:
            return None

        last_human: str = next(
            (str(m.content) for m in reversed(messages) if isinstance(m, HumanMessage)),
            "",
        )
        if not last_human:
            return None

        answer = str(last_ai.content)
        answer_summary = (
            answer[: self._preview_chars] + "…" if len(answer) > self._preview_chars else answer
        )

        result = self._llm.invoke(
            get_followup_questions_prompt().format(
                n=self._max_followups,
                question=last_human,
                answer_summary=answer_summary,
            )
        )
        followups = str(result.content).strip()

        if followups:
            last_ai.content = f"{answer}\n\n---\n**您可能還想了解：**\n{followups}"

        return None
