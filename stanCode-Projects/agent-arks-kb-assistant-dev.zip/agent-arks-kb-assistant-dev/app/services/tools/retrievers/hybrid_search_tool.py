from __future__ import annotations

import json
import logging
from typing import Optional

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.documents import Document
from langchain_core.tools import BaseTool
from langchain_mongodb import MongoDBAtlasVectorSearch
from langchain_mongodb.retrievers.hybrid_search import MongoDBAtlasHybridSearchRetriever
from pydantic import ConfigDict, Field
import certifi
from pymongo import MongoClient

from models.embedding_adapter import get_embeddings
from services.utils.config import (
    CHILD_TABLE,
    MONGODB_DB,
    MONGODB_URI,
    PARENT_TABLE,
    QA_RETRIEVE_TOP_K,
)
from services.utils.schema import MongoParentDocumentStore

logger = logging.getLogger(__name__)

_FTS_INDEX_NAME = "search_index"
_PARENT_ID_KEY = "doc_id"


def _json_safe(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return str(value)


def _documents_to_json(docs: list[Document]) -> str:
    payload = {
        "results": [
            {
                "rank": i + 1,
                "content": doc.page_content,
                "metadata": _json_safe(doc.metadata),
            }
            for i, doc in enumerate(docs)
        ],
        "total": len(docs),
    }
    return json.dumps(payload, ensure_ascii=False)


def _fetch_parents(
    docs: list[Document],
    parent_store: MongoParentDocumentStore,
) -> list[Document]:
    """Replace child chunks with their parent documents when available.

    The ``ParentDocumentRetriever`` stores a ``doc_id`` key in child chunk
    metadata that maps to the parent document in the parent store. If the key is
    absent (e.g. ingested without parent splitting) the child chunk is kept.
    """
    parent_ids = [doc.metadata.get(_PARENT_ID_KEY) for doc in docs]
    has_parents = any(pid is not None for pid in parent_ids)
    if not has_parents:
        return docs

    unique_ids = list(dict.fromkeys(pid for pid in parent_ids if pid is not None))
    fetched = parent_store.mget(unique_ids)
    id_to_parent = {uid: pdoc for uid, pdoc in zip(unique_ids, fetched) if pdoc is not None}

    result: list[Document] = []
    seen: set[str] = set()
    for doc, pid in zip(docs, parent_ids):
        if pid is not None and pid in id_to_parent and pid not in seen:
            result.append(id_to_parent[pid])
            seen.add(pid)
        elif pid is None:
            result.append(doc)
    return result


class MongoHybridSearchTool(BaseTool):
    """Hybrid (vector + full-text) search against MongoDB Atlas.

    Combines semantic vector search with BM25-style full-text search (Atlas
    Search) using the **Reciprocal Rank Fusion (RRF)** algorithm provided by
    :class:`~langchain_mongodb.retrievers.hybrid_search.MongoDBAtlasHybridSearchRetriever`.

    When ``use_parent_retriever=True`` (default) the tool transparently
    replaces returned child chunks with their parent documents from the
    parent store, matching the behaviour of ``ParentDocumentRetriever``.
    """

    name: str = "mongo_hybrid_search"
    description: str = (
        "Search the knowledge base using hybrid search (vector + full-text BM25). "
        "Input should be a plain-text query. "
        "Best for queries that mix semantic meaning with specific keywords or terms."
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)

    retriever: MongoDBAtlasHybridSearchRetriever = Field(exclude=True)
    parent_store: Optional[MongoParentDocumentStore] = Field(default=None, exclude=True)

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        docs = self.retriever.invoke(query)
        logger.info(
            "MongoHybridSearchTool | retrieved=%d query=%r",
            len(docs),
            query[:80],
        )
        if self.parent_store is not None:
            docs = _fetch_parents(docs, self.parent_store)
        return _documents_to_json(docs)

    @classmethod
    def build(
        cls,
        splitter: str = "recursive",
        top_k: int = QA_RETRIEVE_TOP_K,
        vector_penalty: float = 60.0,
        fulltext_penalty: float = 60.0,
        use_parent_retriever: bool = True,
        mongodb_uri: str = MONGODB_URI,
        mongodb_db: str = MONGODB_DB,
    ) -> "MongoHybridSearchTool":
        """Instantiate the tool, connecting to MongoDB and building the retriever.

        Args:
            splitter: Retained for backward compatibility. The current schema uses
                unified child/parent collection names and no longer distinguishes
                collections by splitter suffix.
            top_k: Maximum number of documents to return after RRF ranking.
            vector_penalty: RRF penalty for vector search results.
                Score = 1 / (rank + penalty).  Higher → less weight on vector.
            fulltext_penalty: RRF penalty for full-text search results.
                Higher → less weight on full-text.
            use_parent_retriever: When *True* (default) child chunks returned by
                the hybrid retriever are replaced with their parent documents
                from the parent store.
            mongodb_uri: MongoDB connection string.
            mongodb_db: Database name.
        """
        embeddings = get_embeddings()
        mongo_client = MongoClient(mongodb_uri, tlsCAFile=certifi.where())
        db = mongo_client[mongodb_db]

        child_collection = db[CHILD_TABLE]
        child_store = MongoDBAtlasVectorSearch(
            collection=child_collection,
            embedding=embeddings,
            text_key="content",
            metadata_key="metadata",
        )

        retriever = MongoDBAtlasHybridSearchRetriever(
            vectorstore=child_store,
            search_index_name=_FTS_INDEX_NAME,
            k=top_k,
            vector_penalty=vector_penalty,
            fulltext_penalty=fulltext_penalty,
        )

        parent_store: Optional[MongoParentDocumentStore] = None
        if use_parent_retriever:
            parent_collection = db[PARENT_TABLE]
            parent_store = MongoParentDocumentStore(collection=parent_collection)

        return cls(retriever=retriever, parent_store=parent_store)
