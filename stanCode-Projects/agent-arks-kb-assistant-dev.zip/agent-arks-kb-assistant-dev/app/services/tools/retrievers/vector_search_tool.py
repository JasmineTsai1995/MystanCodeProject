from __future__ import annotations

import json
import logging
from typing import Optional

from langchain_classic.retrievers import ParentDocumentRetriever
from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from langchain_core.tools import BaseTool
from langchain_mongodb import MongoDBAtlasVectorSearch
from pydantic import ConfigDict, Field
import certifi
from pymongo import MongoClient

from models.embedding_adapter import get_embeddings
from services.utils.config import (
    CHILD_TABLE,
    MONGODB_DB,
    MONGODB_URI,
    PARENT_TABLE,
    QA_RETRIEVE_THRESHOLD,
    QA_RETRIEVE_TOP_K,
)
from services.utils.schema import MongoParentDocumentStore
from services.utils.splitter import build_parent_splitter

logger = logging.getLogger(__name__)


def _json_safe(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return str(value)


def _documents_to_json(docs: list[Document]) -> str:
    payload = {
        "results": [
            {
                "rank": i + 1,
                "content": doc.page_content,
                "metadata": _json_safe(doc.metadata),
            }
            for i, doc in enumerate(docs)
        ],
        "total": len(docs),
    }
    return json.dumps(payload, ensure_ascii=False)


class MongoVectorSearchTool(BaseTool):
    """Vector similarity search against MongoDB Atlas child/parent collections.

    Uses ``ParentDocumentRetriever`` by default: child chunks are matched via
    vector search and the corresponding parent chunks are returned to provide
    full context.  Set ``use_parent_retriever=False`` in :meth:`build` to
    return raw child chunks instead.
    """

    name: str = "mongo_vector_search"
    description: str = (
        "搜尋保險知識庫，適用於所有與保險相關的問題，"
        "包含保單條款、申請流程、應備文件、理賠規定、費率說明等。"
        "輸入使用者的問題原文即可，系統會自動找出最相關的段落並回傳。"
        "只要使用者的問題涉及保險，都應優先使用此工具。"
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)

    retriever: BaseRetriever = Field(exclude=True)

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        docs = self.retriever.invoke(query)
        logger.info("MongoVectorSearchTool | retrieved=%d query=%r", len(docs), query[:80])
        for i, doc in enumerate(docs, 1):
            logger.debug("MongoVectorSearchTool | doc_%d_metadata=%s", i, doc.metadata)
        return _documents_to_json(docs)

    @classmethod
    def build(
        cls,
        splitter: str = "recursive",
        top_k: int = QA_RETRIEVE_TOP_K,
        threshold: float = QA_RETRIEVE_THRESHOLD,
        use_parent_retriever: bool = True,
        mongodb_uri: str = MONGODB_URI,
        mongodb_db: str = MONGODB_DB,
    ) -> "MongoVectorSearchTool":
        """Instantiate the tool, connecting to MongoDB and building the retriever.

        Args:
            splitter: Retained for backward compatibility. The current schema uses
                unified child/parent collection names and no longer distinguishes
                collections by splitter suffix.
            top_k: Maximum number of documents to return.
            threshold: Minimum similarity score for ``as_retriever`` when
                ``use_parent_retriever=False``.
            use_parent_retriever: When *True* (default) wraps the child store in a
                :class:`ParentDocumentRetriever` so parent chunks are returned.
                When *False* returns raw child chunks with score filtering.
            mongodb_uri: MongoDB connection string.
            mongodb_db: Database name.
        """
        embeddings = get_embeddings()
        mongo_client = MongoClient(mongodb_uri, tlsCAFile=certifi.where())
        db = mongo_client[mongodb_db]

        child_collection = db[CHILD_TABLE]
        child_store = MongoDBAtlasVectorSearch(
            collection=child_collection,
            embedding=embeddings,
            text_key="content",
            metadata_key="metadata",
        )

        if use_parent_retriever:
            parent_collection = db[PARENT_TABLE]
            parent_store = MongoParentDocumentStore(collection=parent_collection)
            retriever: BaseRetriever = ParentDocumentRetriever(
                vectorstore=child_store,
                docstore=parent_store,
                parent_splitter=build_parent_splitter(),
                search_kwargs={"k": top_k},
            )
        else:
            retriever = child_store.as_retriever(
                search_type="similarity_score_threshold",
                search_kwargs={"k": top_k, "score_threshold": threshold},
            )

        return cls(retriever=retriever)
