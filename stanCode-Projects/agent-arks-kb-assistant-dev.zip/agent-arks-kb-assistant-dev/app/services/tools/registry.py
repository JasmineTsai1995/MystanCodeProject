"""
Tool Registry

Returns retrieval tools based on RETRIEVAL_PROVIDER env var (independent of LLM_PROVIDER).

  "mongodb" (default) — MongoDB Atlas retrievers bundled in agent code:
    MongoVectorSearchTool, MongoHybridSearchTool
    Suitable for both local dev (openrouter) and Databricks deployment.

  "databricks" — Databricks-native tools via UC / Vector Search:
    VectorSearchRetrieverTool  (Databricks Vector Search index)
    UCFunctionToolkit          (Unity Catalog Functions)

  "mcp" — MCP Retriever server via langchain-mcp-adapters:
    Loads MCP tools directly from the MCP Databricks App.
    Requires: MCP_APP_URL env var

Note: RETRIEVAL_PROVIDER is independent of LLM_PROVIDER.
  Example: LLM on Databricks + retrieval from MCP is the recommended production setup —
  set LLM_PROVIDER=databricks and RETRIEVAL_PROVIDER=mcp.

Environment variables:
    RETRIEVAL_PROVIDER        — mongodb (default) | databricks | mcp
    MCP_APP_URL               — Databricks App base URL for the MCP retriever
    SKIP_MCP_TOOL_INIT        — when true, return no MCP tools (used during model logging)
    DATABRICKS_VS_INDEX_NAME  — UC Vector Search index (databricks provider only)
    DATABRICKS_UC_FUNCTIONS   — Comma-separated UC function names (databricks provider only)
    QA_RETRIEVE_TOP_K         — Number of documents to retrieve (default: 10)
"""

from langchain_core.tools import BaseTool

from config.loader import cfg, cfg_bool, cfg_int


def get_tools() -> list[BaseTool]:
    """Return tools for the active RETRIEVAL_PROVIDER."""
    retrieval_provider = cfg("retrieval.provider", "RETRIEVAL_PROVIDER", "mongodb")
    if retrieval_provider == "databricks":
        return _get_databricks_tools()
    if retrieval_provider == "mcp":
        return _get_mcp_tools()
    return _get_mongodb_tools()


def _get_mongodb_tools() -> list[BaseTool]:
    from services.tools.retrievers.vector_search_tool import MongoVectorSearchTool
    from services.tools.retrievers.hybrid_search_tool import MongoHybridSearchTool

    return [
        MongoVectorSearchTool.build(),
        MongoHybridSearchTool.build(),
    ]


def _get_databricks_tools() -> list[BaseTool]:
    from databricks_langchain import VectorSearchRetrieverTool, UCFunctionToolkit

    tools: list[BaseTool] = []
    top_k = cfg_int("retrieval.qa_top_k", "QA_RETRIEVE_TOP_K", default=10)

    vs_index = cfg("llm.databricks.vs_index_name", "DATABRICKS_VS_INDEX_NAME", "")
    if vs_index:
        tools.append(VectorSearchRetrieverTool(index_name=vs_index, num_results=top_k))

    uc_functions_raw = cfg("llm.databricks.uc_functions", "DATABRICKS_UC_FUNCTIONS", "")
    if uc_functions_raw:
        function_names = [f.strip() for f in uc_functions_raw.split(",") if f.strip()]
        tools.extend(UCFunctionToolkit(function_names=function_names).tools)

    return tools


def _get_mcp_tools() -> list[BaseTool]:
    if cfg_bool("retrieval.skip_mcp_tool_init", "SKIP_MCP_TOOL_INIT", False):
        return []

    from services.integrations.mcp.client import get_mcp_tools_sync

    return get_mcp_tools_sync()
