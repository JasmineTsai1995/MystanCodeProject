"""
資料庫模型基礎類別

提供所有 ORM 模型的基礎類別
"""

from sqlalchemy.ext.declarative import declarative_base

# 建立 SQLAlchemy Base 類別
Base = declarative_base()
