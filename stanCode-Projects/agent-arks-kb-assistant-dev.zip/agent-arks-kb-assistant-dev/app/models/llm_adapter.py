"""
LLM Model Adapter

Supports three providers, selected by the LLM_PROVIDER env var:

  "openrouter" routes through OpenRouter via OpenAI-compatible API.
    Requires: OPENROUTER_API_KEY
    Swap model via AGENT_MODEL.

  "litellm" routes through an internal LiteLLM OpenAI-compatible proxy.
    Requires: LITELLM_API_KEY and LITELLM_ENDPOINT
    Swap model via LITELLM_MODEL.

  "databricks" uses ChatDatabricks (Databricks Foundation Model API).
    Requires: Databricks workspace auth.
    Swap endpoint via DATABRICKS_LLM_ENDPOINT.
"""

from __future__ import annotations

import os

from langchain_core.language_models import BaseChatModel
from pydantic import SecretStr

from config.loader import cfg

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


def _openai_compatible_base_url(api_base: str | None) -> str:
    """Normalize an OpenAI-compatible API base URL for ChatOpenAI."""
    base_url = (api_base or "").strip()
    if not base_url:
        raise RuntimeError("LITELLM_ENDPOINT is required when LLM_PROVIDER=litellm.")

    base_url = base_url.rstrip("/")
    chat_completions_suffix = "/chat/completions"
    if base_url.endswith(chat_completions_suffix):
        base_url = base_url[: -len(chat_completions_suffix)]
    if not base_url.endswith("/v1"):
        base_url = f"{base_url}/v1"
    return base_url


def _required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"{name} is required for the selected LLM provider.")
    return value


def get_llm(
    model: str = "openai/gpt-oss-120b",
    temperature: float = 0.0,
) -> BaseChatModel:
    """Return a chat model based on LLM_PROVIDER config."""
    provider = str(cfg("llm.provider", "LLM_PROVIDER", "openrouter")).strip().lower()

    if provider == "databricks":
        from databricks_langchain import ChatDatabricks

        endpoint = cfg(
            "llm.databricks.llm_endpoint",
            "DATABRICKS_LLM_ENDPOINT",
            "databricks-llama-4-maverick",
        )
        return ChatDatabricks(endpoint=endpoint, temperature=temperature)

    from langchain_openai import ChatOpenAI

    if provider == "litellm":
        litellm_model = cfg("llm.litellm.model", "LITELLM_MODEL", model)
        api_base = cfg("llm.litellm.endpoint", "LITELLM_ENDPOINT", "")
        return ChatOpenAI(
            model=litellm_model,
            api_key=SecretStr(_required_env("LITELLM_API_KEY")),
            base_url=_openai_compatible_base_url(api_base),
            temperature=temperature,
        )

    if provider == "openrouter":
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            openai_api_key=os.environ["OPENROUTER_API_KEY"],
            openai_api_base=OPENROUTER_BASE_URL,
        )

    raise ValueError(
        f"Unsupported LLM_PROVIDER={provider!r}. "
        "Expected one of: databricks, litellm, openrouter."
    )
