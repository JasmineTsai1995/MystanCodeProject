"""
Embedding Adapter

Provider-aware embedding model factory, mirroring models.llm_adapter.

Embedding dimensions must match the vectors in the knowledge base. Switch
embedding models only after re-ingesting the knowledge base.
"""

from __future__ import annotations

import os

from langchain_core.embeddings import Embeddings
from pydantic import SecretStr

from config.loader import cfg
from models.llm_adapter import OPENROUTER_BASE_URL, _openai_compatible_base_url


def get_embeddings() -> Embeddings:
    """Return an embeddings instance based on LLM_PROVIDER config."""
    provider = str(cfg("llm.provider", "LLM_PROVIDER", "openrouter")).strip().lower()

    if provider == "databricks":
        from databricks_langchain import DatabricksEmbeddings

        endpoint = cfg(
            "llm.databricks.embedding_endpoint",
            "DATABRICKS_EMBEDDING_ENDPOINT",
            "databricks-gte-large-en",
        )
        return DatabricksEmbeddings(endpoint=endpoint)

    from langchain_openai import OpenAIEmbeddings

    if provider == "litellm":
        model = cfg(
            "llm.litellm.embedding_model",
            "LITELLM_EMBEDDING_MODEL",
            cfg("llm.kb_ingest.embed_model_name", "EMBED_MODEL_NAME", "google/gemini-embedding-001"),
        )
        return OpenAIEmbeddings(
            model=model,
            api_key=SecretStr(os.environ["LITELLM_API_KEY"]),
            base_url=_openai_compatible_base_url(cfg("llm.litellm.endpoint", "LITELLM_ENDPOINT", "")),
            check_embedding_ctx_length=False,
        )

    if provider == "openrouter":
        model = cfg("llm.kb_ingest.embed_model_name", "EMBED_MODEL_NAME", "google/gemini-embedding-001")
        return OpenAIEmbeddings(
            model=model,
            openai_api_key=os.environ["OPENROUTER_API_KEY"],
            openai_api_base=OPENROUTER_BASE_URL,
            check_embedding_ctx_length=False,
        )

    raise ValueError(
        f"Unsupported LLM_PROVIDER={provider!r}. "
        "Expected one of: databricks, litellm, openrouter."
    )
