"""
密碼雜湊工具

展示 utils/ 資料夾的核心價值：
- 可重用的工具函數
- 獨立的功能模組
- 無業務邏輯依賴
"""

import hashlib
import secrets
from typing import Tuple


def hash_password(password: str) -> str:
    """
    雜湊密碼
    
    使用 SHA-256 + 隨機 salt 進行密碼雜湊
    
    注意：這是簡化示範，生產環境應使用 bcrypt 或 argon2
    
    Args:
        password: 明文密碼
        
    Returns:
        雜湊後的密碼（格式：salt$hash）
        
    Examples:
        >>> hashed = hash_password("mypassword")
        >>> verify_password("mypassword", hashed)
        True
    """
    # 生成隨機 salt（16 bytes = 32 hex 字元）
    salt = secrets.token_hex(16)
    
    # 組合 salt 和密碼進行雜湊
    pwd_hash = hashlib.sha256((salt + password).encode()).hexdigest()
    
    # 返回格式：salt$hash
    return f"{salt}${pwd_hash}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    驗證密碼
    
    Args:
        plain_password: 明文密碼
        hashed_password: 雜湊後的密碼（格式：salt$hash）
        
    Returns:
        密碼是否匹配
        
    Examples:
        >>> hashed = hash_password("mypassword")
        >>> verify_password("mypassword", hashed)
        True
        >>> verify_password("wrongpassword", hashed)
        False
    """
    try:
        # 分離 salt 和 hash
        salt, pwd_hash = hashed_password.split('$')
        
        # 使用相同的 salt 重新雜湊輸入的密碼
        new_hash = hashlib.sha256((salt + plain_password).encode()).hexdigest()
        
        # 比較雜湊值
        return new_hash == pwd_hash
    except (ValueError, AttributeError):
        # 格式錯誤或其他異常
        return False


def generate_token(length: int = 32) -> str:
    """
    生成隨機 token
    
    Args:
        length: token 長度（bytes）
        
    Returns:
        隨機 hex token
        
    Examples:
        >>> token = generate_token(16)
        >>> len(token)
        32
    """
    return secrets.token_hex(length)


# ============================================================================
# 生產環境建議使用 passlib
# ============================================================================
# 
# from passlib.context import CryptContext
# 
# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# 
# def hash_password(password: str) -> str:
#     return pwd_context.hash(password)
# 
# def verify_password(plain_password: str, hashed_password: str) -> bool:
#     return pwd_context.verify(plain_password, hashed_password)
# 
