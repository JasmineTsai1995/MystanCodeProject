"""
HTTP 請求工具模組

提供統一的 HTTP 請求封裝，支援：
- 多種 HTTP 方法（GET, POST, PUT, PATCH, DELETE）
- Pydantic Schema 驗證（輸入/輸出）
- 自動錯誤處理
- 靈活的配置選項
"""

import requests
from typing import Optional, Dict, Any, Literal, Union
from pydantic import BaseModel, ValidationError
import json
import logging

# 設定日誌
logger = logging.getLogger(__name__)


class RequestError(Exception):
    """請求錯誤基類"""
    pass


class ValidationError(RequestError):
    """資料驗證錯誤"""
    pass


class HTTPError(RequestError):
    """HTTP 請求錯誤"""
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[requests.Response] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


def make_request(
    url: str,
    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "GET",
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Dict[str, Any]] = None,
    json_data: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 30,
    input_schema: Optional[type[BaseModel]] = None,
    output_schema: Optional[type[BaseModel]] = None,
    auth: Optional[tuple] = None,
    cookies: Optional[Dict[str, str]] = None,
    allow_redirects: bool = True,
    verify: bool = True,
    raise_for_status: bool = True,
    log_request: bool = True,
    log_response: bool = True,
    **kwargs
) -> Any:
    """
    通用的 HTTP 請求函數，支援多種配置選項
    
    Args:
        url: 請求的 URL
        method: HTTP 方法 (GET, POST, PUT, PATCH, DELETE)
        params: URL 查詢參數
        data: 表單數據
        json_data: JSON 數據
        headers: 請求標頭
        timeout: 超時時間（秒）
        input_schema: 輸入數據的 Pydantic schema（驗證 json_data 或 data）
        output_schema: 輸出數據的 Pydantic schema（驗證響應）
        auth: 認證元組 (username, password)
        cookies: Cookies
        allow_redirects: 是否允許重定向
        verify: 是否驗證 SSL 證書
        raise_for_status: 是否在 HTTP 錯誤時拋出異常
        log_request: 是否記錄請求日誌
        log_response: 是否記錄響應日誌
        **kwargs: 其他 requests 支援的參數
    
    Returns:
        如果有 output_schema，返回驗證後的 Pydantic 模型實例
        否則返回 response.json() 或 response.text
    
    Raises:
        ValidationError: 當輸入或輸出數據不符合 schema
        HTTPError: 當請求失敗
        RequestError: 其他請求相關錯誤
    
    Examples:
        >>> # 簡單 GET 請求
        >>> result = make_request("https://api.example.com/users")
        
        >>> # POST 請求帶 schema 驗證
        >>> result = make_request(
        ...     url="https://api.example.com/users",
        ...     method="POST",
        ...     json_data={"name": "John", "email": "john@example.com"},
        ...     input_schema=UserInput,
        ...     output_schema=UserOutput
        ... )
    """
    
    # 記錄請求資訊
    if log_request:
        logger.info(f"發送 {method} 請求到 {url}")
        if params:
            logger.debug(f"查詢參數: {params}")
        if json_data:
            logger.debug(f"JSON 數據: {json_data}")
    
    # 驗證輸入數據
    if input_schema:
        try:
            if json_data:
                validated_input = input_schema(**json_data)
                json_data = validated_input.model_dump()
                logger.debug("輸入數據驗證通過")
            elif data:
                validated_input = input_schema(**data)
                data = validated_input.model_dump()
                logger.debug("輸入數據驗證通過")
        except ValidationError as e:
            error_msg = f"輸入數據驗證失敗: {e}"
            logger.error(error_msg)
            raise ValidationError(error_msg) from e
    
    # 準備請求參數
    request_kwargs = {
        "params": params,
        "data": data,
        "json": json_data,
        "headers": headers,
        "timeout": timeout,
        "auth": auth,
        "cookies": cookies,
        "allow_redirects": allow_redirects,
        "verify": verify,
        **kwargs
    }
    
    # 移除 None 值
    request_kwargs = {k: v for k, v in request_kwargs.items() if v is not None}
    
    # 發送請求
    try:
        response = requests.request(method, url, **request_kwargs)
        
        # 檢查 HTTP 狀態碼
        if raise_for_status:
            response.raise_for_status()
        
        # 記錄響應資訊
        if log_response:
            logger.info(f"收到響應: {response.status_code}")
            logger.debug(f"響應標頭: {dict(response.headers)}")
        
    except requests.HTTPError as e:
        error_msg = f"HTTP 錯誤 {response.status_code}: {str(e)}"
        logger.error(error_msg)
        raise HTTPError(error_msg, status_code=response.status_code, response=response) from e
    except requests.Timeout as e:
        error_msg = f"請求超時 ({timeout}秒): {str(e)}"
        logger.error(error_msg)
        raise HTTPError(error_msg) from e
    except requests.ConnectionError as e:
        error_msg = f"連線錯誤: {str(e)}"
        logger.error(error_msg)
        raise HTTPError(error_msg) from e
    except requests.RequestException as e:
        error_msg = f"請求失敗: {str(e)}"
        logger.error(error_msg)
        raise HTTPError(error_msg) from e
    
    # 處理響應
    try:
        response_data = response.json()
        if log_response:
            logger.debug(f"響應數據類型: JSON")
    except json.JSONDecodeError:
        response_data = response.text
        if log_response:
            logger.debug(f"響應數據類型: TEXT")
    
    # 驗證輸出數據
    if output_schema and isinstance(response_data, dict):
        try:
            validated_output = output_schema(**response_data)
            logger.debug("輸出數據驗證通過")
            return validated_output
        except ValidationError as e:
            error_msg = f"輸出數據驗證失敗: {e}"
            logger.error(error_msg)
            raise ValidationError(error_msg) from e
    
    return response_data


class RequestClient:
    """
    HTTP 請求客戶端類別
    
    提供更物件導向的請求介面，支援預設配置和會話管理。
    
    Attributes:
        base_url: 基礎 URL
        default_headers: 預設請求標頭
        default_timeout: 預設超時時間
        session: requests.Session 實例
    
    Examples:
        >>> client = RequestClient(
        ...     base_url="https://api.example.com",
        ...     default_headers={"Authorization": "Bearer token123"}
        ... )
        >>> result = client.get("/users")
        >>> result = client.post("/users", json_data={"name": "John"})
    """
    
    def __init__(
        self,
        base_url: str = "",
        default_headers: Optional[Dict[str, str]] = None,
        default_timeout: int = 30,
        verify: bool = True,
        use_session: bool = True
    ):
        """
        初始化請求客戶端
        
        Args:
            base_url: 基礎 URL，會自動加到所有請求前面
            default_headers: 預設的請求標頭
            default_timeout: 預設的超時時間（秒）
            verify: 是否驗證 SSL 證書
            use_session: 是否使用 Session（保持連線）
        """
        self.base_url = base_url.rstrip("/")
        self.default_headers = default_headers or {}
        self.default_timeout = default_timeout
        self.verify = verify
        
        if use_session:
            self.session = requests.Session()
            self.session.headers.update(self.default_headers)
        else:
            self.session = None
        
        logger.info(f"RequestClient 初始化完成，base_url: {self.base_url}")
    
    def _build_url(self, path: str) -> str:
        """建立完整的 URL"""
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}{path}" if self.base_url else path
    
    def _merge_headers(self, headers: Optional[Dict[str, str]]) -> Dict[str, str]:
        """合併預設標頭和自訂標頭"""
        merged = self.default_headers.copy()
        if headers:
            merged.update(headers)
        return merged
    
    def request(
        self,
        path: str,
        method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "GET",
        **kwargs
    ) -> Any:
        """
        發送 HTTP 請求
        
        Args:
            path: 請求路徑（會自動加上 base_url）
            method: HTTP 方法
            **kwargs: 其他參數，傳遞給 make_request
        
        Returns:
            請求結果
        """
        url = self._build_url(path)
        headers = self._merge_headers(kwargs.pop("headers", None))
        timeout = kwargs.pop("timeout", self.default_timeout)
        verify = kwargs.pop("verify", self.verify)
        
        # 如果使用 session，則使用 session 發送請求
        if self.session:
            kwargs["session"] = self.session
        
        return make_request(
            url=url,
            method=method,
            headers=headers,
            timeout=timeout,
            verify=verify,
            **kwargs
        )
    
    def get(self, path: str, **kwargs) -> Any:
        """發送 GET 請求"""
        return self.request(path, method="GET", **kwargs)
    
    def post(self, path: str, **kwargs) -> Any:
        """發送 POST 請求"""
        return self.request(path, method="POST", **kwargs)
    
    def put(self, path: str, **kwargs) -> Any:
        """發送 PUT 請求"""
        return self.request(path, method="PUT", **kwargs)
    
    def patch(self, path: str, **kwargs) -> Any:
        """發送 PATCH 請求"""
        return self.request(path, method="PATCH", **kwargs)
    
    def delete(self, path: str, **kwargs) -> Any:
        """發送 DELETE 請求"""
        return self.request(path, method="DELETE", **kwargs)
    
    def close(self):
        """關閉 Session"""
        if self.session:
            self.session.close()
            logger.info("RequestClient Session 已關閉")
    
    def __enter__(self):
        """支援 context manager"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """支援 context manager"""
        self.close()


# 便捷函數
def get(url: str, **kwargs) -> Any:
    """發送 GET 請求的便捷函數"""
    return make_request(url, method="GET", **kwargs)


def post(url: str, **kwargs) -> Any:
    """發送 POST 請求的便捷函數"""
    return make_request(url, method="POST", **kwargs)


def put(url: str, **kwargs) -> Any:
    """發送 PUT 請求的便捷函數"""
    return make_request(url, method="PUT", **kwargs)


def patch(url: str, **kwargs) -> Any:
    """發送 PATCH 請求的便捷函數"""
    return make_request(url, method="PATCH", **kwargs)


def delete(url: str, **kwargs) -> Any:
    """發送 DELETE 請求的便捷函數"""
    return make_request(url, method="DELETE", **kwargs)
