"""
資料庫操作範例 API（精簡版）

將所有 DB 連線模式和完整分層架構的範例集中在此檔案：
1. SQLAlchemy AsyncEngine - 原生 SQL / ORM
2. psycopg AsyncConnectionPool - 原生 SQL
3. OCP Tool API - HTTP-based PostgreSQL
4. 完整分層架構 - Model → Schema → Service → Route

【設計原則】
- Route 層只負責 HTTP 請求/回應處理
- 所有操作都透過 Service 層 function 呼叫
- 業務邏輯封裝在 Service 層
- 參數統一由 config/settings 管理

【架構流程】
Client → Route（API 端點） → Service（業務邏輯） → Database（DB 操作）
"""

import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from database import OCPError

# Service 層匯入
from services.db_sqlalchemy import SQLAlchemyService
from services.db_psycopg import PsycopgService
from services.db_ocp import OCPService

# 完整分層架構的匯入
from schemas.sample_item import (
    SampleItemCreate,
    SampleItemUpdate,
    SampleItemResponse,
    SampleItemListResponse,
)
from services.sample_item import SampleItemService
from dependencies import get_db_session

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/sample",
    tags=["Sample - 資料庫操作範例"],
)


# ============================================================================
# 1. SQLAlchemy AsyncEngine 範例
# ============================================================================

@router.post(
    "/db/init",
    summary="初始化 SQLAlchemy AsyncEngine 並建立資料表",
)
async def init_database() -> Dict[str, Any]:
    """
    透過 SQLAlchemyService.init_engine_and_tables() 完成初始化。
    """
    try:
        return await SQLAlchemyService.init_engine_and_tables()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/db/health",
    summary="SQLAlchemy 健康檢查",
)
async def db_health_check() -> Dict[str, Any]:
    """
    透過 SQLAlchemyService.health_check() 檢查連線狀態。
    """
    return await SQLAlchemyService.health_check()


@router.get(
    "/db/query",
    summary="SQLAlchemy 原生 SQL 查詢",
)
async def db_raw_query() -> Dict[str, Any]:
    """
    透過 SQLAlchemyService.execute_query() 執行原生 SQL 查詢 PG 版本。
    """
    try:
        return await SQLAlchemyService.execute_query("SELECT version() as pg_version")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# 2. psycopg AsyncConnectionPool 範例
# ============================================================================

@router.post(
    "/psycopg/init",
    summary="初始化 psycopg 連線池",
)
async def init_psycopg_pool() -> Dict[str, Any]:
    """
    透過 PsycopgService.init_pool() 初始化連線池。
    """
    try:
        return await PsycopgService.init_pool()
    except ImportError:
        raise HTTPException(
            status_code=501,
            detail="psycopg not installed. Run: pip install 'psycopg[binary]' psycopg_pool",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/psycopg/query",
    summary="psycopg 原生 SQL 查詢",
)
async def psycopg_raw_query(sql: str) -> Dict[str, Any]:
    """
    透過 PsycopgService.execute_query() 執行原生 SQL。

    範例 SQL：
    - SELECT version()
    - SELECT current_database()
    """
    try:
        return await PsycopgService.execute_query(sql)
    except ImportError:
        raise HTTPException(status_code=501, detail="psycopg not installed")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# 3. OCP Tool API 範例
# ============================================================================

@router.get(
    "/ocp/test",
    summary="OCP API 連線測試",
)
async def ocp_test_connection(database: Optional[str] = None) -> Dict[str, Any]:
    """
    透過 OCPService.test_connection() 測試連線。
    """
    try:
        return OCPService.test_connection(database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/ocp/query",
    summary="OCP API 查詢（自動判斷 SELECT/DML）",
)
async def ocp_query(sql: str, database: Optional[str] = None) -> Dict[str, Any]:
    """
    透過 OCPService.execute_query() 執行查詢。
    自動判斷 SELECT 或 DML（INSERT/UPDATE/DELETE）。
    """
    try:
        return OCPService.execute_query(sql, database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# 4. 完整分層架構範例（Model → Schema → Service → Route）
#
#    展示標準的 FastAPI 分層架構：
#    - Route:   API 端點定義、HTTP 處理
#    - Schema:  請求驗證（SampleItemCreate/Update）、回應序列化（SampleItemResponse）
#    - Service: 業務邏輯封裝（SampleItemService）
#    - Model:   ORM 資料表定義（SampleItem）
#    - DB:      透過 orm_operations function 操作，不直接寫 SQL
# ============================================================================

@router.post(
    "/items",
    response_model=SampleItemResponse,
    status_code=status.HTTP_201_CREATED,
    summary="建立項目（完整架構範例）",
)
async def create_item(
    data: SampleItemCreate,
    db: AsyncSession = Depends(get_db_session),
) -> SampleItemResponse:
    """
    【架構流程】
    1. Schema (SampleItemCreate) 自動驗證請求 body
    2. Service (SampleItemService) 執行業務邏輯
    3. orm.create() 寫入 DB
    4. Schema (SampleItemResponse) 序列化回應
    """
    service = SampleItemService(db)
    return await service.create_item(data)


@router.get(
    "/items",
    response_model=SampleItemListResponse,
    summary="查詢項目列表（分頁 + 過濾）",
)
async def list_items(
    skip: int = Query(0, ge=0, description="跳過筆數"),
    limit: int = Query(10, ge=1, le=100, description="每頁筆數"),
    is_done: Optional[bool] = Query(None, description="過濾完成狀態"),
    db: AsyncSession = Depends(get_db_session),
) -> SampleItemListResponse:
    """
    透過 SampleItemService 分頁查詢 + 列表回應序列化。
    """
    service = SampleItemService(db)
    items = await service.get_items(skip=skip, limit=limit, is_done=is_done)
    total = await service.count_items(is_done=is_done)
    return SampleItemListResponse(total=total, items=items)


@router.get(
    "/items/{item_id}",
    response_model=SampleItemResponse,
    summary="取得單筆項目",
)
async def get_item(
    item_id: int,
    db: AsyncSession = Depends(get_db_session),
) -> SampleItemResponse:
    """
    透過 SampleItemService 查詢 + 404 錯誤處理。
    """
    service = SampleItemService(db)
    return await service.get_item(item_id)


@router.put(
    "/items/{item_id}",
    response_model=SampleItemResponse,
    summary="更新項目（部分更新）",
)
async def update_item(
    item_id: int,
    data: SampleItemUpdate,
    db: AsyncSession = Depends(get_db_session),
) -> SampleItemResponse:
    """
    透過 SampleItemService 部分更新（exclude_unset）。
    """
    service = SampleItemService(db)
    return await service.update_item(item_id, data)


@router.delete(
    "/items/{item_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="刪除項目",
)
async def delete_item(
    item_id: int,
    db: AsyncSession = Depends(get_db_session),
):
    """
    透過 SampleItemService 刪除 + 204 No Content 回應。
    """
    service = SampleItemService(db)
    await service.delete_item(item_id)
    return None
