"""
資料庫範例 API - LangGraph Checkpointer 方式

【分層架構】Route → Schema → Service(封裝) → Database
【使用者只需看】本檔案（Route）+ Service 的 docstring

【相關檔案】
  - schemas/db_common.py          → 通用請求/回應 Schema
  - schemas/db_langgraph.py       → LangGraph 專用 Schema
  - services/db_langgraph.py      → LangGraph 封裝服務
  - database/session.py           → 底層連線池管理（使用者不需要看）

【使用流程】
  1. POST   /init                       初始化 PostgresSaver
  2. POST   /checkpoint/save            儲存 Checkpoint
  3. GET    /checkpoint/{thread_id}     讀取最新 Checkpoint
  4. GET    /checkpoints/{thread_id}/history  Checkpoint 歷史
  5. DELETE /checkpoint/{thread_id}     刪除 Checkpoint

【前置需求】
  pip install langgraph "psycopg[binary]" psycopg_pool
"""

from typing import Dict, Any

from fastapi import APIRouter, HTTPException

from schemas.db_common import InitResponse, InfoResponse
from schemas.db_langgraph import (
    CheckpointSaveRequest,
    CheckpointSaveResponse,
    CheckpointDetailResponse,
    CheckpointHistoryResponse,
    CheckpointDeleteResponse,
)
from services.db_langgraph import LangGraphService

router = APIRouter(prefix="/api/db/langgraph", tags=["Database - LangGraph"])


# ============================================================================
# 說明
# ============================================================================

@router.get("/", summary="LangGraph 整合說明")
async def langgraph_info() -> Dict[str, Any]:
    """
    LangGraph PostgresSaver 整合說明
    """
    try:
        import langgraph
        langgraph_available = True
        langgraph_version = getattr(langgraph, "__version__", "unknown")
    except ImportError:
        langgraph_available = False
        langgraph_version = None

    return {
        "status": "info",
        "features": [
            "Agent 狀態持久化",
            "Checkpoint 管理",
            "狀態回溯",
            "多租戶支援",
        ],
        "examples": [
            {"name": "初始化 PostgresSaver", "endpoint": "POST /api/db/langgraph/init"},
            {"name": "儲存 Checkpoint", "endpoint": "POST /api/db/langgraph/checkpoint/save"},
            {"name": "讀取 Checkpoint", "endpoint": "GET /api/db/langgraph/checkpoint/{thread_id}"},
        ],
        "message": (
            f"LangGraph {langgraph_version} 已安裝並可用"
            if langgraph_available
            else "LangGraph 未安裝。請執行：pip install langgraph 'psycopg[binary]' psycopg_pool"
        ),
    }


# ============================================================================
# 基礎設施
# ============================================================================

@router.post("/init", response_model=InitResponse, summary="初始化 LangGraph PostgresSaver")
async def initialize_saver():
    """
    初始化 LangGraph PostgresSaver

    【調用鏈】Route → LangGraphService.init_saver()
    """
    try:
        return await LangGraphService.init_saver()
    except ImportError as e:
        raise HTTPException(
            status_code=501,
            detail=f"Required package not installed: {str(e)}. "
                   "Please run: pip install langgraph 'psycopg[binary]' psycopg_pool",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to initialize: {str(e)}")


# ============================================================================
# Checkpoint CRUD
# ============================================================================

@router.post("/checkpoint/save", response_model=CheckpointSaveResponse, summary="儲存 Checkpoint")
async def save_checkpoint(request: CheckpointSaveRequest):
    """
    儲存 Agent 狀態 Checkpoint

    【調用鏈】Schema(CheckpointSaveRequest) → LangGraphService.save_checkpoint()

    範例 body:
    ```json
    {
        "thread_id": "conversation-1",
        "state": {"messages": ["hello", "world"], "step": 3}
    }
    ```
    """
    try:
        return await LangGraphService.save_checkpoint(request.thread_id, request.state)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save checkpoint: {str(e)}")


@router.get("/checkpoint/{thread_id}", response_model=CheckpointDetailResponse, summary="讀取 Checkpoint")
async def get_checkpoint(thread_id: str):
    """
    讀取指定 thread_id 的最新 Checkpoint

    【調用鏈】Route → LangGraphService.get_checkpoint()
    """
    try:
        result = await LangGraphService.get_checkpoint(thread_id)
        if result.get("status") == "not_found":
            raise HTTPException(status_code=404, detail=f"No checkpoint found for thread_id: {thread_id}")
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get checkpoint: {str(e)}")


@router.get("/checkpoints/{thread_id}/history", response_model=CheckpointHistoryResponse, summary="Checkpoint 歷史")
async def get_checkpoint_history(thread_id: str, limit: int = 10):
    """
    獲取 Checkpoint 歷史記錄

    【調用鏈】Route → LangGraphService.get_checkpoint_history()
    """
    try:
        return await LangGraphService.get_checkpoint_history(thread_id, limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get history: {str(e)}")


@router.delete("/checkpoint/{thread_id}", response_model=CheckpointDeleteResponse, summary="刪除 Checkpoint")
async def delete_checkpoint(thread_id: str):
    """
    刪除指定 thread_id 的所有 Checkpoints

    【調用鏈】Route → LangGraphService.delete_checkpoint()
    """
    try:
        return await LangGraphService.delete_checkpoint(thread_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete checkpoints: {str(e)}")
