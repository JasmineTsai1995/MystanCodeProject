"""
資料庫範例 API - OCP Tool API 方式

【分層架構】Route → Schema → Service(封裝) → Database
【使用者只需看】本檔案（Route）+ Service 的 docstring

【相關檔案】
  - schemas/db_common.py      → 通用請求/回應 Schema
  - schemas/db_ocp.py         → OCP 專用 Schema
  - services/db_ocp.py        → OCP 封裝服務
  - database/ocp_client.py    → 底層 HTTP Client（使用者不需要看）

【使用流程】
  1. GET  /test          測試 OCP API 連線
  2. POST /query         自動判斷 SELECT/DML 並執行
  3. POST /select        執行 SELECT 查詢
  4. POST /dml           執行 DML 操作（INSERT/UPDATE/DELETE）
  5. POST /select/dict   SELECT 結果轉字典列表
  6. GET  /config        獲取 OCP 配置資訊
  7. POST /batch/select  批次 SELECT 查詢

【CRUD 範例端點】（使用通用 Schema，內部組裝 SQL 委託 Service）
  8. POST   /data/insert  通用插入（table_name + data dict）
  9. POST   /data/query   通用查詢（table_name + filters + 分頁）
  10. PUT    /data/update  通用更新（table_name + filters + data）
  11. DELETE /data/delete  通用刪除（table_name + filters）
"""

import logging
from typing import Dict, Any, List, Optional

from fastapi import APIRouter, HTTPException

from schemas.db_ocp import (
    OCPQueryExecuteRequest,
    OCPSelectResponse,
    OCPDMLResponse,
    OCPBatchResponse,
)
from schemas.db_common import (
    HealthCheckResponse,
    TableInsertRequest,
    TableQueryRequest,
    TableUpdateRequest,
    TableDeleteRequest,
    ExecuteResultResponse,
    QueryResultResponse,
)
from services.db_ocp import OCPService
from database import OCPError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/db/ocp", tags=["Database - OCP Tool API"])


# ============================================================================
# 基礎設施
# ============================================================================

@router.get("/test", response_model=HealthCheckResponse, summary="OCP API 連線測試")
async def test_connection(database: Optional[str] = None):
    """
    測試 OCP Tool API 連線

    【調用鏈】Route → OCPService.test_connection()
    """
    try:
        return OCPService.test_connection(database)
    except (OCPError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"連線測試失敗: {str(e)}")


@router.get("/config", response_model=HealthCheckResponse, summary="OCP 配置資訊")
async def get_config():
    """
    獲取 OCP 配置資訊

    【調用鏈】Route → OCPService.get_config()
    """
    try:
        return OCPService.get_config()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"獲取配置失敗: {str(e)}")


# ============================================================================
# 查詢操作
# ============================================================================

@router.post("/query", summary="自動判斷並執行查詢")
async def execute_query(request: OCPQueryExecuteRequest) -> Dict[str, Any]:
    """
    自動判斷 SELECT/DML 並執行

    【調用鏈】Schema(OCPQueryExecuteRequest) → OCPService.execute_query()
    【使用者帶入】sql（+ 可選 database）→ 自動判斷查詢類型

    範例 body:
    ```json
    {"sql": "SELECT * FROM users LIMIT 10"}
    {"sql": "INSERT INTO users(name) VALUES('Alice')", "database": "mydb"}
    ```
    """
    try:
        return OCPService.execute_query(request.sql, request.database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"執行失敗: {str(e)}")


@router.post("/select", response_model=OCPSelectResponse, summary="執行 SELECT 查詢")
async def execute_select(request: OCPQueryExecuteRequest):
    """
    執行 SELECT 查詢

    【調用鏈】Schema(OCPQueryExecuteRequest) → OCPService.execute_select()

    範例 body:
    ```json
    {"sql": "SELECT * FROM users LIMIT 10"}
    ```
    """
    try:
        return OCPService.execute_select(request.sql, request.database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"查詢失敗: {str(e)}")


@router.post("/dml", response_model=OCPDMLResponse, summary="執行 DML 操作")
async def execute_dml(request: OCPQueryExecuteRequest):
    """
    執行 DML 操作（INSERT/UPDATE/DELETE）

    【調用鏈】Schema(OCPQueryExecuteRequest) → OCPService.execute_dml()

    範例 body:
    ```json
    {"sql": "INSERT INTO public.test2(test1) VALUES ('TEST')"}
    {"sql": "UPDATE users SET status='active' WHERE id=1"}
    ```
    """
    try:
        return OCPService.execute_dml(request.sql, request.database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"操作失敗: {str(e)}")


@router.post("/select/dict", summary="SELECT 查詢（字典格式）")
async def execute_select_dict(request: OCPQueryExecuteRequest) -> Dict[str, Any]:
    """
    執行 SELECT 並將結果轉為字典列表格式

    【調用鏈】Schema(OCPQueryExecuteRequest) → OCPService.execute_select_as_dict()

    範例回應:
    ```json
    {"status": "success", "row_count": 2, "data": [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]}
    ```
    """
    try:
        return OCPService.execute_select_as_dict(request.sql, request.database)
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"查詢失敗: {str(e)}")


@router.post("/batch/select", response_model=OCPBatchResponse, summary="批次 SELECT 查詢")
async def batch_select(queries: List[OCPQueryExecuteRequest]):
    """
    批次執行多個 SELECT 查詢

    【調用鏈】Schema(List[OCPQueryExecuteRequest]) → OCPService.batch_select()

    範例 body:
    ```json
    [
        {"sql": "SELECT COUNT(*) FROM users"},
        {"sql": "SELECT * FROM products LIMIT 5"}
    ]
    ```
    """
    try:
        query_dicts = [{"sql": q.sql, "database": q.database} for q in queries]
        return OCPService.batch_select(query_dicts)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批次查詢失敗: {str(e)}")


# ============================================================================
# CRUD 範例端點（使用通用 Schema，內部組裝 SQL 委託 OCPService）
# ============================================================================

@router.post("/data/insert", response_model=ExecuteResultResponse, summary="CRUD 範例 - 插入資料")
async def crud_insert(request: TableInsertRequest):
    """
    CRUD 範例：通用資料插入

    【調用鏈】Schema(TableInsertRequest) → 組裝 INSERT SQL → OCPService.execute_dml()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "data": {"name": "Alice", "email": "alice@example.com"}
    }
    ```
    """
    try:
        cols = ", ".join(request.data.keys())
        vals = ", ".join(f"'{v}'" if isinstance(v, str) else str(v) for v in request.data.values())
        sql = f"INSERT INTO {request.table_name} ({cols}) VALUES ({vals})"

        result = OCPService.execute_dml(sql)
        return {
            "status": "success",
            "affected_rows": result.get("affected_rows", 0),
            "message": f"Data inserted into {request.table_name}",
        }
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"Insert failed: {str(e)}")


@router.post("/data/query", response_model=QueryResultResponse, summary="CRUD 範例 - 查詢資料")
async def crud_query(request: TableQueryRequest):
    """
    CRUD 範例：通用資料查詢（支援過濾、排序、分頁）

    【調用鏈】Schema(TableQueryRequest) → 組裝 SELECT SQL → OCPService.execute_select_as_dict()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"name": "Alice"},
        "order_by": "-created_at",
        "skip": 0,
        "limit": 10
    }
    ```
    """
    try:
        col_str = ", ".join(request.columns) if request.columns else "*"
        sql = f"SELECT {col_str} FROM {request.table_name}"

        if request.filters:
            conditions = " AND ".join(
                f"{k} = '{v}'" if isinstance(v, str) else f"{k} = {v}"
                for k, v in request.filters.items()
            )
            sql += f" WHERE {conditions}"

        if request.order_by:
            if request.order_by.startswith("-"):
                sql += f" ORDER BY {request.order_by[1:]} DESC"
            else:
                sql += f" ORDER BY {request.order_by} ASC"

        sql += f" OFFSET {request.skip} LIMIT {request.limit}"

        result = OCPService.execute_select_as_dict(sql)
        return {
            "status": "success",
            "row_count": result.get("row_count", 0),
            "data": result.get("data"),
        }
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")


@router.put("/data/update", response_model=ExecuteResultResponse, summary="CRUD 範例 - 更新資料")
async def crud_update(request: TableUpdateRequest):
    """
    CRUD 範例：通用資料更新

    【調用鏈】Schema(TableUpdateRequest) → 組裝 UPDATE SQL → OCPService.execute_dml()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1},
        "data": {"name": "Alice Updated", "email": "alice_new@example.com"}
    }
    ```
    """
    try:
        set_clause = ", ".join(
            f"{k} = '{v}'" if isinstance(v, str) else f"{k} = {v}"
            for k, v in request.data.items()
        )
        where_clause = " AND ".join(
            f"{k} = '{v}'" if isinstance(v, str) else f"{k} = {v}"
            for k, v in request.filters.items()
        )
        sql = f"UPDATE {request.table_name} SET {set_clause} WHERE {where_clause}"

        result = OCPService.execute_dml(sql)
        return {
            "status": "success",
            "affected_rows": result.get("affected_rows", 0),
            "message": f"Updated data in {request.table_name}",
        }
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")


@router.delete("/data/delete", response_model=ExecuteResultResponse, summary="CRUD 範例 - 刪除資料")
async def crud_delete(request: TableDeleteRequest):
    """
    CRUD 範例：通用資料刪除

    【調用鏈】Schema(TableDeleteRequest) → 組裝 DELETE SQL → OCPService.execute_dml()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1}
    }
    ```
    """
    try:
        if not request.filters:
            raise ValueError("filters is required (prevent full-table delete)")

        where_clause = " AND ".join(
            f"{k} = '{v}'" if isinstance(v, str) else f"{k} = {v}"
            for k, v in request.filters.items()
        )
        sql = f"DELETE FROM {request.table_name} WHERE {where_clause}"

        result = OCPService.execute_dml(sql)
        return {
            "status": "success",
            "affected_rows": result.get("affected_rows", 0),
            "message": f"Deleted data from {request.table_name}",
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except OCPError as e:
        raise HTTPException(status_code=500, detail=f"Delete failed: {str(e)}")
