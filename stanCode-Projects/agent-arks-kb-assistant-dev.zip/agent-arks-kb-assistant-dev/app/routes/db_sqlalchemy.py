"""
資料庫範例 API - SQLAlchemy ORM 方式

【分層架構】Route → Schema(通用) → Service(封裝) → Database
【使用者只需看】本檔案（Route）+ Service 的 docstring

【相關檔案】
  - schemas/db_common.py          → 通用請求/回應 Schema
  - services/db_sqlalchemy.py     → SQLAlchemy 封裝服務
  - database/session.py           → 底層連線管理（使用者不需要看）

【使用流程】
  1. POST   /init          初始化引擎 + 建立 ORM 資料表
  2. GET    /health        健康檢查
  3. POST   /query         通用原生 SQL 查詢
  4. POST   /table/create  建立自訂資料表
  5. POST   /data/insert   通用插入（table_name + data）
  6. POST   /data/query    通用查詢（table_name + filters + 分頁）
  7. PUT    /data/update   通用更新（table_name + filters + data）
  8. DELETE /data/delete   通用刪除（table_name + filters）
  9. DELETE /table/drop    刪除資料表
"""

from fastapi import APIRouter, HTTPException

from schemas.db_common import (
    RawSQLRequest,
    TableInsertRequest,
    TableQueryRequest,
    TableUpdateRequest,
    TableDeleteRequest,
    TableDDLRequest,
    HealthCheckResponse,
    InitResponse,
    QueryResultResponse,
    ExecuteResultResponse,
)
from services.db_sqlalchemy import SQLAlchemyService

router = APIRouter(prefix="/api/db/sqlalchemy", tags=["Database - SQLAlchemy"])


# ============================================================================
# 基礎設施
# ============================================================================

@router.post("/init", response_model=InitResponse, summary="初始化 SQLAlchemy AsyncEngine")
async def initialize_engine(pool_size: int = 5, max_overflow: int = 10):
    """
    初始化 SQLAlchemy 引擎並建立所有 ORM 資料表

    【調用鏈】Route → SQLAlchemyService.init_engine_and_tables()
    """
    try:
        return await SQLAlchemyService.init_engine_and_tables(pool_size, max_overflow)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to initialize engine: {str(e)}")


@router.get("/health", response_model=HealthCheckResponse, summary="SQLAlchemy 健康檢查")
async def health_check():
    """
    檢查 SQLAlchemy 連線健康狀態

    【調用鏈】Route → SQLAlchemyService.health_check()
    """
    try:
        return await SQLAlchemyService.health_check()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")


# ============================================================================
# 通用查詢
# ============================================================================

@router.post("/query", response_model=QueryResultResponse, summary="通用原生 SQL 查詢")
async def execute_query(request: RawSQLRequest):
    """
    執行原生 SQL 查詢

    【調用鏈】Schema(RawSQLRequest) → SQLAlchemyService.execute_query()
    【使用者帶入】sql + params → 查詢任意資料表

    範例 body:
    ```json
    {"sql": "SELECT version()"}
    {"sql": "SELECT * FROM users WHERE id = :id", "params": {"id": 1}}
    ```
    """
    try:
        return await SQLAlchemyService.execute_query(request.sql, request.params)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")


# ============================================================================
# 通用 CRUD
# ============================================================================

@router.post("/data/insert", response_model=ExecuteResultResponse, summary="通用資料插入")
async def insert_data(request: TableInsertRequest):
    """
    通用資料插入：任意 table + data dict

    【調用鏈】Schema(TableInsertRequest) → SQLAlchemyService.insert_data()
    【使用者帶入】table_name + data → 插入任意資料表

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "data": {"name": "Alice", "email": "alice@example.com"}
    }
    ```
    """
    try:
        return await SQLAlchemyService.insert_data(request.table_name, request.data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Insert failed: {str(e)}")


@router.post("/data/query", response_model=QueryResultResponse, summary="通用資料查詢")
async def query_data(request: TableQueryRequest):
    """
    通用資料查詢（支援過濾、排序、分頁）

    【調用鏈】Schema(TableQueryRequest) → SQLAlchemyService.query_data()
    【使用者帶入】table_name + filters + 分頁 → 查詢任意資料表

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"name": "Alice"},
        "order_by": "-created_at",
        "skip": 0,
        "limit": 10
    }
    ```
    """
    try:
        return await SQLAlchemyService.query_data(
            request.table_name,
            columns=request.columns,
            filters=request.filters,
            order_by=request.order_by,
            skip=request.skip,
            limit=request.limit,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")


@router.put("/data/update", response_model=ExecuteResultResponse, summary="通用資料更新")
async def update_data(request: TableUpdateRequest):
    """
    通用資料更新：任意 table + filters + data dict

    【調用鏈】Schema(TableUpdateRequest) → SQLAlchemyService.update_data()
    【使用者帶入】table_name + filters + data → 更新任意資料表

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1},
        "data": {"name": "Alice Updated", "email": "alice_new@example.com"}
    }
    ```
    """
    try:
        return await SQLAlchemyService.update_data(
            request.table_name, request.filters, request.data
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")


@router.delete("/data/delete", response_model=ExecuteResultResponse, summary="通用資料刪除")
async def delete_data(request: TableDeleteRequest):
    """
    通用資料刪除：任意 table + filters

    【調用鏈】Schema(TableDeleteRequest) → SQLAlchemyService.delete_data()
    【使用者帶入】table_name + filters → 刪除符合條件的資料

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1}
    }
    ```
    """
    try:
        return await SQLAlchemyService.delete_data(request.table_name, request.filters)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Delete failed: {str(e)}")


# ============================================================================
# DDL 操作
# ============================================================================

@router.post("/table/create", response_model=ExecuteResultResponse, summary="建立資料表")
async def create_table(request: TableDDLRequest):
    """
    建立資料表

    【調用鏈】Schema(TableDDLRequest) → SQLAlchemyService.create_table()
    【使用者帶入】table_name（+ 可選 ddl_sql）

    範例 body:
    ```json
    {"table_name": "test_users"}
    {"table_name": "my_table", "ddl_sql": "CREATE TABLE IF NOT EXISTS my_table (id SERIAL PRIMARY KEY, value TEXT)"}
    ```
    """
    try:
        result = await SQLAlchemyService.create_table(request.table_name, request.ddl_sql)
        return ExecuteResultResponse(status=result["status"], message=result["message"])
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Create table failed: {str(e)}")


@router.delete("/table/drop", response_model=ExecuteResultResponse, summary="刪除資料表")
async def drop_table(table_name: str):
    """
    刪除資料表

    【調用鏈】Route → SQLAlchemyService.drop_table()
    """
    try:
        result = await SQLAlchemyService.drop_table(table_name)
        return ExecuteResultResponse(status=result["status"], message=result["message"])
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Drop table failed: {str(e)}")
