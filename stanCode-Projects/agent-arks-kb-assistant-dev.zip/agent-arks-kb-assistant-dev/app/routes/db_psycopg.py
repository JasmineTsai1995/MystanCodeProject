"""
資料庫範例 API - psycopg 原生 SQL 方式

【分層架構】Route → Schema(通用) → Service(封裝) → Database
【使用者只需看】本檔案（Route）+ Service 的 docstring

【相關檔案】
  - schemas/db_common.py        → 通用請求/回應 Schema
  - services/db_psycopg.py      → psycopg 封裝服務
  - database/session.py         → 底層連線池管理（使用者不需要看）

【使用流程】
  1. POST   /init          初始化 psycopg 連線池
  2. GET    /health        健康檢查
  3. POST   /query         通用原生 SQL 查詢
  4. POST   /data/insert   通用插入（table_name + data）
  5. POST   /data/query    通用查詢（table_name + filters + 分頁）
  6. PUT    /data/update   通用更新（table_name + filters + data）
  7. DELETE /data/delete   通用刪除（table_name + filters）
  8. GET    /pool/stats    連線池統計資訊
"""

from fastapi import APIRouter, HTTPException

from schemas.db_common import (
    RawSQLRequest,
    TableInsertRequest,
    TableQueryRequest,
    TableUpdateRequest,
    TableDeleteRequest,
    HealthCheckResponse,
    InitResponse,
    QueryResultResponse,
    ExecuteResultResponse,
)
from services.db_psycopg import PsycopgService

router = APIRouter(prefix="/api/db/psycopg", tags=["Database - psycopg"])


# ============================================================================
# 基礎設施
# ============================================================================

@router.post("/init", response_model=InitResponse, summary="初始化 psycopg 連線池")
async def initialize_pool(min_size: int = 2, max_size: int = 10):
    """
    初始化 psycopg AsyncConnectionPool

    【調用鏈】Route → PsycopgService.init_pool()
    """
    try:
        return await PsycopgService.init_pool(min_size, max_size)
    except ImportError:
        raise HTTPException(
            status_code=501,
            detail="psycopg not installed. Run: pip install 'psycopg[binary]' psycopg_pool",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to initialize pool: {str(e)}")


@router.get("/health", response_model=HealthCheckResponse, summary="psycopg 健康檢查")
async def health_check():
    """
    檢查 psycopg 連線池健康狀態

    【調用鏈】Route → PsycopgService.health_check()
    """
    try:
        return await PsycopgService.health_check()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")


@router.get("/pool/stats", response_model=HealthCheckResponse, summary="連線池統計")
async def get_pool_stats():
    """
    獲取 psycopg 連線池統計資訊

    【調用鏈】Route → PsycopgService.get_pool_stats()
    """
    try:
        return await PsycopgService.get_pool_stats()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get pool stats: {str(e)}")


# ============================================================================
# 通用查詢
# ============================================================================

@router.post("/query", response_model=QueryResultResponse, summary="通用原生 SQL 查詢")
async def execute_query(request: RawSQLRequest):
    """
    使用 psycopg 執行原生 SQL 查詢

    【調用鏈】Schema(RawSQLRequest) → PsycopgService.execute_query()
    【使用者帶入】sql + params → 查詢任意資料表

    範例 body:
    ```json
    {"sql": "SELECT version()"}
    {"sql": "SELECT * FROM users WHERE id = %(id)s", "params": {"id": 1}}
    ```
    """
    try:
        return await PsycopgService.execute_query(request.sql, request.params)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")


# ============================================================================
# 通用 CRUD
# ============================================================================

@router.post("/data/insert", response_model=ExecuteResultResponse, summary="通用資料插入")
async def insert_data(request: TableInsertRequest):
    """
    通用資料插入：任意 table + data dict

    【調用鏈】Schema(TableInsertRequest) → PsycopgService.insert_data()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "data": {"name": "Alice", "email": "alice@example.com"}
    }
    ```
    """
    try:
        return await PsycopgService.insert_data(request.table_name, request.data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Insert failed: {str(e)}")


@router.post("/data/query", response_model=QueryResultResponse, summary="通用資料查詢")
async def query_data(request: TableQueryRequest):
    """
    通用資料查詢（支援過濾、排序、分頁）

    【調用鏈】Schema(TableQueryRequest) → PsycopgService.query_data()

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"name": "Alice"},
        "order_by": "-created_at",
        "skip": 0,
        "limit": 10
    }
    ```
    """
    try:
        return await PsycopgService.query_data(
            request.table_name,
            columns=request.columns,
            filters=request.filters,
            order_by=request.order_by,
            skip=request.skip,
            limit=request.limit,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")


@router.put("/data/update", response_model=ExecuteResultResponse, summary="通用資料更新")
async def update_data(request: TableUpdateRequest):
    """
    通用資料更新：任意 table + filters + data dict

    【調用鏈】Schema(TableUpdateRequest) → PsycopgService.update_data()
    【使用者帶入】table_name + filters + data → 更新任意資料表

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1},
        "data": {"name": "Alice Updated", "email": "alice_new@example.com"}
    }
    ```
    """
    try:
        return await PsycopgService.update_data(
            request.table_name, request.filters, request.data
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")


@router.delete("/data/delete", response_model=ExecuteResultResponse, summary="通用資料刪除")
async def delete_data(request: TableDeleteRequest):
    """
    通用資料刪除：任意 table + filters

    【調用鏈】Schema(TableDeleteRequest) → PsycopgService.delete_data()
    【使用者帶入】table_name + filters → 刪除符合條件的資料

    範例 body:
    ```json
    {
        "table_name": "test_users",
        "filters": {"id": 1}
    }
    ```
    """
    try:
        return await PsycopgService.delete_data(request.table_name, request.filters)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Delete failed: {str(e)}")
