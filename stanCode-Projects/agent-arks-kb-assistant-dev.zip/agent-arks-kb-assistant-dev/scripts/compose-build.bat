@echo off
REM ============================================================================
REM Docker Compose 建置腳本（推薦方式）- Windows 版
REM ============================================================================

REM 切換到專案根目錄
cd /d "%~dp0\.."

echo =========================================
echo FastAPI Docker Compose 建置
echo =========================================

REM 步驟 1: 建置 base 映像
echo.
echo [步驟 1/3] 建置 base 映像（包含 Python 環境和套件）...
docker build -t fastapi-base:latest -f base/Dockerfile .

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] Base 映像建置失敗
    exit /b 1
)
echo [成功] Base 映像建置成功

REM 步驟 2: 使用 Docker Compose 建置應用映像
echo.
echo [步驟 2/3] 建置應用映像（包含應用程式代碼）...
docker-compose build

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] 應用映像建置失敗
    exit /b 1
)
echo [成功] 應用映像建置成功

REM 步驟 3: 啟動所有服務
echo.
echo [步驟 3/3] 啟動所有服務...
docker-compose up -d

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] 服務啟動失敗
    exit /b 1
)
echo [成功] 服務啟動成功

REM 等待服務啟動
echo.
echo 等待服務啟動...
timeout /t 5 /nobreak >nul

REM 檢查服務狀態
echo.
echo 檢查服務狀態...
docker-compose ps

REM 完成
echo.
echo =========================================
echo 建置完成！
echo =========================================
echo.
echo 存取服務：
echo   - API 文件: http://localhost:8000/docs
echo   - 健康檢查: http://localhost:8000/health
echo   - PostgreSQL: localhost:5432
echo.
echo 常用命令：
echo   - 查看所有日誌: docker-compose logs -f
echo   - 查看應用日誌: docker-compose logs -f app
echo   - 查看資料庫日誌: docker-compose logs -f db
echo   - 重啟服務: docker-compose restart
echo   - 停止服務: docker-compose stop
echo   - 停止並移除: docker-compose down
echo   - 停止並清空資料: docker-compose down -v
echo.
echo 開發模式：
echo   - 代碼會自動熱重載（已掛載 .\app 目錄）
echo   - 修改代碼後無需重啟容器
