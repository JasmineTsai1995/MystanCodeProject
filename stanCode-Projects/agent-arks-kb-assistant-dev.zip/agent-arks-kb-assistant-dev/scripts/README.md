# 建置腳本說明

本目錄包含所有 Docker 建置相關的腳本。

## 📂 檔案說明

| 檔案 | 說明 | 系統 |
|------|------|------|
| `compose-build.sh` | Docker Compose 自動化建置 | Linux/Mac |
| `compose-build.bat` | Docker Compose 自動化建置 | Windows |
| `docker-build.sh` | 純 Docker 命令建置 | Linux/Mac |
| `docker-build.bat` | 純 Docker 命令建置 | Windows |

## 🚀 使用方式

### Docker Compose 方式（推薦）

**Linux/Mac**：
```bash
chmod +x scripts/compose-build.sh
./scripts/compose-build.sh
```

**Windows**：
```batch
scripts\compose-build.bat
```

### 純 Docker 命令方式

**Linux/Mac**：
```bash
chmod +x scripts/docker-build.sh
./scripts/docker-build.sh
```

**Windows**：
```batch
scripts\docker-build.bat
```

## 💡 腳本功能

### compose-build.sh/bat
1. 建置 base 映像
2. 使用 Docker Compose 建置應用
3. 啟動所有服務
4. 顯示服務狀態

### docker-build.sh/bat
1. 建立 Docker 網路
2. 建置 base 映像
3. 建置應用映像
4. 啟動 PostgreSQL 容器
5. 啟動 FastAPI 容器

## 📝 注意事項

- 腳本會自動切換到專案根目錄執行
- Linux/Mac 腳本需要先賦予執行權限（`chmod +x`）
- 所有腳本都包含錯誤處理和友善的輸出訊息
