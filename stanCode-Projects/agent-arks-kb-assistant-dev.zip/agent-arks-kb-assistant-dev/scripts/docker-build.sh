#!/bin/bash
# ============================================================================
# 純 Docker 命令建置腳本（不使用 Docker Compose）
# ============================================================================

set -e

# 切換到專案根目錄
cd "$(dirname "$0")/.."

echo "========================================="
echo "FastAPI Docker 建置（純 Docker 命令）"
echo "========================================="

# 取得專案根目錄的絕對路徑（相容 Windows）
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
    # Windows 環境：轉換路徑為 Docker Desktop 可識別的格式
    # 使用 pwd -W 取得 Windows 格式路徑（帶正斜線），若失敗則使用 pwd 並轉換反斜線為正斜線
    PROJECT_ROOT=$(pwd -W 2>/dev/null || pwd | sed 's|\\|/|g')
else
    # Linux/Mac 環境
    PROJECT_ROOT=$(pwd)
fi

# 顏色輸出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置
BASE_IMAGE="fastapi-base:latest"
APP_IMAGE="fastapi-app:latest"
DB_CONTAINER="fastapi_db"
APP_CONTAINER="fastapi_app"
NETWORK="fastapi_network"

# 步驟 1: 建立 Docker 網路
echo -e "\n${YELLOW}[步驟 1/5]${NC} 建立 Docker 網路..."
if docker network ls | grep -q "$NETWORK"; then
    echo -e "${BLUE}網路 $NETWORK 已存在${NC}"
else
    docker network create $NETWORK
    echo -e "${GREEN}✓ 網路建立成功${NC}"
fi

# 步驟 2: 建置 base 映像
echo -e "\n${YELLOW}[步驟 2/5]${NC} 建置 base 映像（包含 Python 環境和套件）..."
docker build -t $BASE_IMAGE -f base/Dockerfile .

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Base 映像建置成功${NC}"
else
    echo -e "${RED}✗ Base 映像建置失敗${NC}"
    exit 1
fi

# 步驟 3: 建置應用映像
echo -e "\n${YELLOW}[步驟 3/5]${NC} 建置應用映像（包含應用程式代碼）..."
docker build -t $APP_IMAGE .

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 應用映像建置成功${NC}"
else
    echo -e "${RED}✗ 應用映像建置失敗${NC}"
    exit 1
fi

# 步驟 4: 啟動 PostgreSQL 容器
echo -e "\n${YELLOW}[步驟 4/5]${NC} 啟動 PostgreSQL 資料庫..."

# 檢查容器是否已存在
if docker ps -a | grep -q "$DB_CONTAINER"; then
    echo -e "${BLUE}停止並移除舊的資料庫容器...${NC}"
    docker stop $DB_CONTAINER 2>/dev/null || true
    docker rm $DB_CONTAINER 2>/dev/null || true
fi

docker run -d \
    --name $DB_CONTAINER \
    --network $NETWORK \
    -e POSTGRES_USER=postgres \
    -e POSTGRES_PASSWORD=postgres \
    -e POSTGRES_DB=fastapi_db \
    -p 5432:5432 \
    -v postgres_data:/var/lib/postgresql/data \
    --restart unless-stopped \
    postgres:15-alpine

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 資料庫容器啟動成功${NC}"
else
    echo -e "${RED}✗ 資料庫容器啟動失敗${NC}"
    exit 1
fi

# 等待資料庫啟動
echo -e "${BLUE}等待資料庫啟動...${NC}"
sleep 5

# 步驟 5: 啟動應用容器
echo -e "\n${YELLOW}[步驟 5/5]${NC} 啟動 FastAPI 應用容器..."

# 檢查容器是否已存在
if docker ps -a | grep -q "$APP_CONTAINER"; then
    echo -e "${BLUE}停止並移除舊的應用容器...${NC}"
    docker stop $APP_CONTAINER 2>/dev/null || true
    docker rm $APP_CONTAINER 2>/dev/null || true
fi

docker run -d \
    --name $APP_CONTAINER \
    --network $NETWORK \
    -e ENVIRONMENT=development \
    -e LOG_LEVEL=INFO \
    -e DB_HOST=$DB_CONTAINER \
    -e DB_PORT=5432 \
    -e DB_USER=postgres \
    -e DB_PASSWORD=postgres \
    -e DB_NAME=fastapi_db \
    -p 8000:8000 \
    -v "${PROJECT_ROOT}/app:/app" \
    -v "${PROJECT_ROOT}/tests:/app/tests" \
    -v "${PROJECT_ROOT}/pytest.ini:/app/pytest.ini" \
    -v "${PROJECT_ROOT}/logs:/app/logs" \
    --restart unless-stopped \
    $APP_IMAGE \
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 應用容器啟動成功${NC}"
else
    echo -e "${RED}✗ 應用容器啟動失敗${NC}"
    exit 1
fi

# 完成
echo -e "\n${GREEN}=========================================${NC}"
echo -e "${GREEN}建置完成！${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo "存取服務："
echo "  - API 文件: http://localhost:8000/docs"
echo "  - 健康檢查: http://localhost:8000/health"
echo "  - PostgreSQL: localhost:5432"
echo ""
echo "管理容器："
echo "  - 查看日誌: docker logs -f $APP_CONTAINER"
echo "  - 停止應用: docker stop $APP_CONTAINER"
echo "  - 停止資料庫: docker stop $DB_CONTAINER"
echo "  - 移除容器: docker rm $APP_CONTAINER $DB_CONTAINER"
echo "  - 移除網路: docker network rm $NETWORK"
echo ""
echo "快速停止所有："
echo "  docker stop $APP_CONTAINER $DB_CONTAINER && docker rm $APP_CONTAINER $DB_CONTAINER"
