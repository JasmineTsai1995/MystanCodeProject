@echo off
REM ============================================================================
REM 純 Docker 命令建置腳本（不使用 Docker Compose）- Windows 版
REM ============================================================================

REM 切換到專案根目錄
cd /d "%~dp0\.."

echo =========================================
echo FastAPI Docker 建置（純 Docker 命令）
echo =========================================

REM 配置
set BASE_IMAGE=fastapi-base:latest
set APP_IMAGE=fastapi-app:latest
set DB_CONTAINER=fastapi_db
set APP_CONTAINER=fastapi_app
set NETWORK=fastapi_network

REM 步驟 1: 建立 Docker 網路
echo.
echo [步驟 1/5] 建立 Docker 網路...
docker network ls | findstr %NETWORK% >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo 網路 %NETWORK% 已存在
) else (
    docker network create %NETWORK%
    if %ERRORLEVEL% NEQ 0 (
        echo [錯誤] 網路建立失敗
        exit /b 1
    )
    echo [成功] 網路建立成功
)

REM 步驟 2: 建置 base 映像
echo.
echo [步驟 2/5] 建置 base 映像（包含 Python 環境和套件）...
docker build -t %BASE_IMAGE% -f base/Dockerfile .

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] Base 映像建置失敗
    exit /b 1
)
echo [成功] Base 映像建置成功

REM 步驟 3: 建置應用映像
echo.
echo [步驟 3/5] 建置應用映像（包含應用程式代碼）...
docker build -t %APP_IMAGE% .

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] 應用映像建置失敗
    exit /b 1
)
echo [成功] 應用映像建置成功

REM 步驟 4: 啟動 PostgreSQL 容器
echo.
echo [步驟 4/5] 啟動 PostgreSQL 資料庫...

REM 檢查容器是否已存在
docker ps -a | findstr %DB_CONTAINER% >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo 停止並移除舊的資料庫容器...
    docker stop %DB_CONTAINER% >nul 2>&1
    docker rm %DB_CONTAINER% >nul 2>&1
)

docker run -d ^
    --name %DB_CONTAINER% ^
    --network %NETWORK% ^
    -e POSTGRES_USER=postgres ^
    -e POSTGRES_PASSWORD=postgres ^
    -e POSTGRES_DB=fastapi_db ^
    -p 5432:5432 ^
    -v postgres_data:/var/lib/postgresql/data ^
    --restart unless-stopped ^
    postgres:15-alpine

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] 資料庫容器啟動失敗
    exit /b 1
)
echo [成功] 資料庫容器啟動成功

REM 等待資料庫啟動
echo 等待資料庫啟動...
timeout /t 5 /nobreak >nul

REM 步驟 5: 啟動應用容器
echo.
echo [步驟 5/5] 啟動 FastAPI 應用容器...

REM 檢查容器是否已存在
docker ps -a | findstr %APP_CONTAINER% >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo 停止並移除舊的應用容器...
    docker stop %APP_CONTAINER% >nul 2>&1
    docker rm %APP_CONTAINER% >nul 2>&1
)

docker run -d ^
    --name %APP_CONTAINER% ^
    --network %NETWORK% ^
    -e ENVIRONMENT=development ^
    -e LOG_LEVEL=INFO ^
    -e DB_HOST=%DB_CONTAINER% ^
    -e DB_PORT=5432 ^
    -e DB_USER=postgres ^
    -e DB_PASSWORD=postgres ^
    -e DB_NAME=fastapi_db ^
    -p 8000:8000 ^
    -v "%CD%\app:/app" ^
    -v "%CD%\tests:/app/tests" ^
    -v "%CD%\pytest.ini:/app/pytest.ini" ^
    -v "%CD%\logs:/app/logs" ^
    --restart unless-stopped ^
    %APP_IMAGE% ^
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload

if %ERRORLEVEL% NEQ 0 (
    echo [錯誤] 應用容器啟動失敗
    exit /b 1
)
echo [成功] 應用容器啟動成功

REM 完成
echo.
echo =========================================
echo 建置完成！
echo =========================================
echo.
echo 存取服務：
echo   - API 文件: http://localhost:8000/docs
echo   - 健康檢查: http://localhost:8000/health
echo   - PostgreSQL: localhost:5432
echo.
echo 管理容器：
echo   - 查看日誌: docker logs -f %APP_CONTAINER%
echo   - 停止應用: docker stop %APP_CONTAINER%
echo   - 停止資料庫: docker stop %DB_CONTAINER%
echo   - 移除容器: docker rm %APP_CONTAINER% %DB_CONTAINER%
echo   - 移除網路: docker network rm %NETWORK%
echo.
echo 快速停止所有：
echo   docker stop %APP_CONTAINER% %DB_CONTAINER% ^&^& docker rm %APP_CONTAINER% %DB_CONTAINER%
