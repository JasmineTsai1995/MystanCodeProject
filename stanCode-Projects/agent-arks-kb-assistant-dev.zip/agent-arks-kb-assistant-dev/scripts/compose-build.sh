#!/bin/bash
# ============================================================================
# Docker Compose 建置腳本（推薦方式）
# ============================================================================

set -e

# 切換到專案根目錄
cd "$(dirname "$0")/.."

echo "========================================="
echo "FastAPI Docker Compose 建置"
echo "========================================="

# 顏色輸出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 步驟 1: 建置 base 映像
echo -e "\n${YELLOW}[步驟 1/3]${NC} 建置 base 映像（包含 Python 環境和套件）..."
docker build -t fastapi-base:latest -f base/Dockerfile .

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Base 映像建置成功${NC}"
else
    echo -e "${RED}✗ Base 映像建置失敗${NC}"
    exit 1
fi

# 步驟 2: 使用 Docker Compose 建置應用映像
echo -e "\n${YELLOW}[步驟 2/3]${NC} 建置應用映像（包含應用程式代碼）..."
docker-compose build

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 應用映像建置成功${NC}"
else
    echo -e "${RED}✗ 應用映像建置失敗${NC}"
    exit 1
fi

# 步驟 3: 啟動所有服務
echo -e "\n${YELLOW}[步驟 3/3]${NC} 啟動所有服務..."
docker-compose up -d

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 服務啟動成功${NC}"
else
    echo -e "${RED}✗ 服務啟動失敗${NC}"
    exit 1
fi

# 等待服務啟動
echo -e "\n${YELLOW}等待服務啟動...${NC}"
sleep 5

# 檢查服務狀態
echo -e "\n${YELLOW}檢查服務狀態...${NC}"
docker-compose ps

# 完成
echo -e "\n${GREEN}=========================================${NC}"
echo -e "${GREEN}建置完成！${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo "存取服務："
echo "  - API 文件: http://localhost:8000/docs"
echo "  - 健康檢查: http://localhost:8000/health"
echo "  - PostgreSQL: localhost:5432"
echo ""
echo "常用命令："
echo "  - 查看所有日誌: docker-compose logs -f"
echo "  - 查看應用日誌: docker-compose logs -f app"
echo "  - 查看資料庫日誌: docker-compose logs -f db"
echo "  - 重啟服務: docker-compose restart"
echo "  - 停止服務: docker-compose stop"
echo "  - 停止並移除: docker-compose down"
echo "  - 停止並清空資料: docker-compose down -v"
echo ""
echo "開發模式："
echo "  - 代碼會自動熱重載（已掛載 ./app 目錄）"
echo "  - 修改代碼後無需重啟容器"
