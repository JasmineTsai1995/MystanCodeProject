#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# Arks Agent — DABs Deploy Script
#
# Usage:
#   ./scripts/deploy.sh              # deploy to ut (default)
#   ./scripts/deploy.sh ut           # deploy to ut
#   ./scripts/deploy.sh prod         # deploy to prod
#   ./scripts/deploy.sh ut --run     # deploy + start app
# ─────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# ── Args ──────────────────────────────────────────────────────
TARGET="${1:-ut}"
RUN_APP=false
if [[ "${2:-}" == "--run" ]]; then
    RUN_APP=true
fi

echo "═══════════════════════════════════════════════════════════"
echo " Arks Agent Deploy — target: ${TARGET}"
echo "═══════════════════════════════════════════════════════════"

# ── Step 1: Validate ──────────────────────────────────────────
echo ""
echo "▸ Step 1: Validating bundle..."
databricks bundle validate -t "$TARGET"
echo "  ✓ Validation passed"

# ── Step 2: Deploy ────────────────────────────────────────────
echo ""
echo "▸ Step 2: Deploying bundle..."
echo "  Resources: App, Lakebase Project, Experiment, Jobs"
databricks bundle deploy -t "$TARGET"
echo "  ✓ Deploy completed"

# ── Step 3: Verify Lakebase ───────────────────────────────────
echo ""
echo "▸ Step 3: Verifying Lakebase project..."
# List projects to confirm creation
databricks postgres list-projects --output json 2>/dev/null | python3 -c "
import json, sys
try:
    projects = json.load(sys.stdin)
    if not projects:
        print('  ⚠ No Lakebase projects found')
        sys.exit(0)
    for p in (projects if isinstance(projects, list) else [projects]):
        name = p.get('name', 'unknown')
        print(f'  ✓ {name}')
except Exception as e:
    print(f'  ⚠ Could not verify: {e}')
" || echo "  ⚠ Could not list projects (may need permissions)"

# ── Step 4: Setup Lakebase (SP role + tables) ─────────────────
echo ""
echo "▸ Step 4: Setting up Lakebase (SP role + checkpoint tables)..."
databricks bundle run arks_setup_lakebase -t "$TARGET"
echo "  ✓ Lakebase setup completed"

# ── Step 5: Setup MLflow (Prompt Registry permissions) ────────
echo ""
echo "▸ Step 5: Setting up MLflow (UC Prompt Registry grants)..."
databricks bundle run arks_setup_mlflow -t "$TARGET"
echo "  ✓ MLflow setup completed"

# ── Step 6: Run App (optional) ────────────────────────────────
if [ "$RUN_APP" = true ]; then
    echo ""
    echo "▸ Step 6: Starting app..."
    databricks bundle run arks_agent -t "$TARGET"
    echo "  ✓ App started"
else
    echo ""
    echo "▸ Step 6: Skipped (use --run to start app)"
    echo "  To start manually: databricks bundle run arks_agent -t ${TARGET}"
fi

# ── Summary ───────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo " Deploy complete"
echo ""
echo " Target:    ${TARGET}"
echo " App:       databricks bundle run arks_agent -t ${TARGET}"
echo " Logs:      databricks apps logs arks-agent"
echo " Destroy:   databricks bundle destroy -t ${TARGET}"
echo ""
echo " Note: Lakebase project cannot be destroyed via bundle."
echo "       Use: databricks postgres delete-project projects/<name>"
echo "═══════════════════════════════════════════════════════════"
